
-- Function f277; 3 recovered instruction blocks.
F.f277=function(function_metadata,upvalues)
local operand_i,operand_w,operand_g,operand_I,code_metadata,operand_t,operand_k=function_metadata[2],function_metadata[10],function_metadata[6],function_metadata[1],function_metadata[8],function_metadata[3],function_metadata[11]
local frame_size=function_metadata[7]
return function(...)
if startup_blocked then return end
local registers,top,environment,W,n,m,x,N,H,v,R,Q,q=new_frame(frame_size),1,andromeda_environment,1
local T,U,_,S,z,a=0
local instructions_left=startup_instruction_limit
local branch_taken
local function tick(pc)
 current_function,current_pc="f277",pc
 if startup_active then
  instructions_left=instructions_left-1
  if instructions_left<=0 then error("ANDROMEDA_STARTUP_LIMIT: f277 pc="..pc,0) end
  startup_poll_remaining=startup_poll_remaining-1
if startup_poll_remaining<=0 then
startup_poll_remaining=startup_poll_interval
check_startup_clock()
end
 end
end
 tick(1)
goto p20
::p20::
do
do
_, Q = pack_returns(...)
end

end
::p21::
do
do
a = 2
z = (_ - T - 1)
if z < 0 then
    z = (-1)
end
q = 0
for T = a, a + z, 1 do
    (registers)[T] = (Q[W + q])
    q = q + 1
end
top = (a + z)
end

end
::p22::
do
do
if N then
    for f, F in next, N do
        if not (f >= 1) then

        else
            (F)[2] = (F)
            F[3] = (registers[f]);
            (F)[1] = 3;
            (N)[f] = (nil)
        end
    end
end
return unpack_range(top, registers, 2)
end

end
end
end
