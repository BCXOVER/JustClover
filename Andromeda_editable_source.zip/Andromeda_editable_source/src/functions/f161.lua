
-- Function f161; 16 recovered instruction blocks.
F.f161=function(function_metadata,upvalues)
local operand_i,operand_w,operand_g,operand_I,code_metadata,operand_t,operand_k=function_metadata[2],function_metadata[10],function_metadata[6],function_metadata[1],function_metadata[8],function_metadata[3],function_metadata[11]
local frame_size=function_metadata[7]
return function(...)
if startup_blocked then return end
local registers,top,environment,W,n,m,x,N,H,v,R,Q,q=new_frame(frame_size),1,andromeda_environment,1
local T,U,_,S,z,a=0
local instructions_left=startup_instruction_limit
local branch_taken
local function tick(pc)
 current_function,current_pc="f161",pc
 if startup_active then
  instructions_left=instructions_left-1
  if instructions_left<=0 then error("ANDROMEDA_STARTUP_LIMIT: f161 pc="..pc,0) end
  startup_poll_remaining=startup_poll_remaining-1
if startup_poll_remaining<=0 then
startup_poll_remaining=startup_poll_interval
check_startup_clock()
end
 end
end
 tick(1)
goto p35
::p3::
tick(3)
do
do
if not (N) then

else
    for T, environment, W in next, N do
        if not (T >= 1) then

        else
            environment[2] = environment;
            (environment)[3] = (registers[T]);
            (environment)[1] = (3)
            N[T] = nil
        end
    end
end
return registers[1]
end

end
::p13::
tick(13)
do
do
a = (1)
z = registers[1]
registers[a + 1] = (z);
(registers)[a] = z["get"]
end

end
::p14::
do
do
a = (1);
(registers)[a] = registers[a](registers[a + 1])
top = (a)
end

end
goto p3
::p19::
tick(19)
do
do
(registers)[1] = upvalues[0]["ragebot"]
end

end
::p20::
do
do
a = registers
z = (1)
q = (registers)
end

end
::p21::
do
do
m = 1
q = q[m]
end

end
::p22::
do
do
m = ("quickpeek")
q = q[m]
end

end
::p23::
do
do
(a)[z] = q
end

end
::p24::
do
do
registers[1] = (registers[1][1])
end

end
::p25::
do
do
registers[1] = (registers[1]["hotkey"])
end

end
goto p13
::p35::
do
do
(registers)[1] = upvalues[0]["ragebot"]
end

end
::p36::
do
do
registers[1] = (registers[1]["quickpeek"])
end

end
::p37::
do
do
registers[1] = (registers[1][1])
end

end
::p38::
do
do
a = (1)
z = registers[1]
registers[a + 1] = (z);
(registers)[a] = z["get"]
end

end
::p69::
do
do
a = (1);
(registers)[a] = registers[a](registers[a + 1])
top = (a)
end

end
::p70::
branch_taken=false
do
do
if not registers[1] then
    branch_taken=true
end
end

end
if branch_taken then goto p3 end
goto p19
end
end
