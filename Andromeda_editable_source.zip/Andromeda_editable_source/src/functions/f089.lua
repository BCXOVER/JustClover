
-- Function f89; 12 recovered instruction blocks.
F.f89=function(function_metadata,upvalues)
local operand_i,operand_w,operand_g,operand_I,code_metadata,operand_t,operand_k=function_metadata[2],function_metadata[10],function_metadata[6],function_metadata[1],function_metadata[8],function_metadata[3],function_metadata[11]
local frame_size=function_metadata[7]
return function(...)
if startup_blocked then return end
local registers,top,environment,W,n,m,x,N,H,v,R,Q,q=new_frame(frame_size),1,andromeda_environment,1
local T,U,_,S,z,a=0
local instructions_left=startup_instruction_limit
local branch_taken
local function tick(pc)
 current_function,current_pc="f89",pc
 if startup_active then
  instructions_left=instructions_left-1
  if instructions_left<=0 then error("ANDROMEDA_STARTUP_LIMIT: f89 pc="..pc,0) end
  startup_poll_remaining=startup_poll_remaining-1
if startup_poll_remaining<=0 then
startup_poll_remaining=startup_poll_interval
check_startup_clock()
end
 end
end
 tick(1)
goto p57
::p11::
tick(11)
do
do
(registers)[5] = registers[5] * registers[6]
end

end
::p12::
do
do
a = (4);
(registers)[a] = registers[a](registers[a + 1])
top = (a)
end

end
::p13::
do
do
(registers)[4] = registers[2] + registers[4]
end

end
::p14::
do
do
if not (N) then

else
    for T, environment, W in next, N do
        if not (T >= 1) then

        else
            environment[2] = environment;
            (environment)[3] = (registers[T]);
            (environment)[1] = (3)
            N[T] = nil
        end
    end
end
return registers[4]
end

end
::p53::
tick(53)
do
do
registers[5] = (registers[3] - registers[2])
end

end
::p54::
do
do
registers[5] = registers[5] + 1
end

end
::p55::
do
do
registers[6] = registers[1] / 2147483648
end

end
goto p11
::p57::
do
do
a = {
    ...,
}
for f = 1, 3, 1 do
    registers[f] = (a[f])
end
end

end
::p58::
do
do
(registers)[4] = 1103515245 * registers[1]
end

end
::p59::
do
do
registers[4] = registers[4] + 12345
end

end
::p60::
do
do
registers[1] = registers[4] % 2147483648
end

end
::p61::
do
do
registers[4] = (upvalues[0])
end

end
goto p53
end
end
