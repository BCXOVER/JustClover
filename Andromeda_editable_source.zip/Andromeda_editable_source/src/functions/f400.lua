
-- Function f400; 17 recovered instruction blocks.
F.f400=function(function_metadata,upvalues)
local operand_i,operand_w,operand_g,operand_I,code_metadata,operand_t,operand_k=function_metadata[2],function_metadata[10],function_metadata[6],function_metadata[1],function_metadata[8],function_metadata[3],function_metadata[11]
local frame_size=function_metadata[7]
return function(...)
if startup_blocked then return end
local registers,top,environment,W,n,m,x,N,H,v,R,Q,q=new_frame(frame_size),1,andromeda_environment,1
local T,U,_,S,z,a=0
local instructions_left=startup_instruction_limit
local branch_taken
local function tick(pc)
 current_function,current_pc="f400",pc
 if startup_active then
  instructions_left=instructions_left-1
  if instructions_left<=0 then error("ANDROMEDA_STARTUP_LIMIT: f400 pc="..pc,0) end
  startup_poll_remaining=startup_poll_remaining-1
if startup_poll_remaining<=0 then
startup_poll_remaining=startup_poll_interval
check_startup_clock()
end
 end
end
 tick(1)
goto p64
::p2::
tick(2)
do
do
registers[2] = (registers[1]["raw"])
end

end
::p3::
do
do
registers[2]["hide_view_model_zoomed"] = false
end

end
::p4::
do
do
registers[2] = (upvalues[0])
end

end
::p5::
do
do
registers[2] = (#registers[2])
end

end
::p6::
do
do
registers[2] = registers[2] + 1
end

end
::p7::
do
do
registers[3] = (registers[1]["idx"])
end

end
goto p52
::p36::
tick(36)
do
do
if N then
    for f, F, u in next, N do
        if not (f >= 1) then

        else
            F[2] = F
            F[3] = registers[f];
            (F)[1] = 3
            N[f] = nil
        end
    end
end
return
end

end
::p52::
do
do
(upvalues[0])[registers[2]] = registers[3]
end

end
::p53::
do
do
if N then
    for f, F, u in next, N do
        if not (f >= 1) then

        else
            F[2] = F
            F[3] = registers[f];
            (F)[1] = 3
            N[f] = nil
        end
    end
end
return
end

end
::p55::
tick(55)
do
do
registers[2] = (registers[1]["raw"])
end

end
::p56::
do
do
registers[2] = (registers[2]["hide_view_model_zoomed"])
end

end
::p57::
branch_taken=false
do
do
if registers[2] then
    branch_taken=true
end
end

end
if branch_taken then goto p2 end
goto p36
::p61::
tick(61)
do
do
registers[2] = (registers[1]["raw"])
end

end
::p62::
branch_taken=false
do
do
if registers[2] ~= registers[0] then
    branch_taken=true
end
end

end
if branch_taken then goto p55 end
goto p67
::p64::
do
do
a = {
    ...,
}
for f = 1, 1, 1 do
    registers[f] = (a[f])
end
end

end
::p65::
branch_taken=false
do
do
if registers[1] == registers[0] then
    branch_taken=true
end
end

end
if branch_taken then goto p67 end
goto p61
::p67::
do
do
if N then
    for f, F, u in next, N do
        if not (f >= 1) then

        else
            F[2] = F
            F[3] = registers[f];
            (F)[1] = 3
            N[f] = nil
        end
    end
end
return
end

end
end
end
