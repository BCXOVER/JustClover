
-- Function f234; 15 recovered instruction blocks.
F.f234=function(function_metadata,upvalues)
local operand_i,operand_w,operand_g,operand_I,code_metadata,operand_t,operand_k=function_metadata[2],function_metadata[10],function_metadata[6],function_metadata[1],function_metadata[8],function_metadata[3],function_metadata[11]
local frame_size=function_metadata[7]
return function(...)
if startup_blocked then return end
local registers,top,environment,W,n,m,x,N,H,v,R,Q,q=new_frame(frame_size),1,andromeda_environment,1
local T,U,_,S,z,a=0
local instructions_left=startup_instruction_limit
local branch_taken
local function tick(pc)
 current_function,current_pc="f234",pc
 if startup_active then
  instructions_left=instructions_left-1
  if instructions_left<=0 then error("ANDROMEDA_STARTUP_LIMIT: f234 pc="..pc,0) end
  startup_poll_remaining=startup_poll_remaining-1
if startup_poll_remaining<=0 then
startup_poll_remaining=startup_poll_interval
check_startup_clock()
end
 end
end
 tick(1)
goto p27
::p4::
tick(4)
do
do
a = (1);
(registers)[a] = registers[a](registers[a + 1])
top = (a)
end

end
goto p36
::p27::
do
do
(registers)[1] = upvalues[0]["antiaim"]
end

end
::p28::
do
do
registers[1] = (registers[1]["other"])
end

end
::p29::
do
do
registers[1] = (registers[1]["slow_motion"])
end

end
::p30::
do
do
registers[1] = (registers[1][1])
end

end
goto p57
::p36::
tick(36)
do
do
if not (N) then

else
    for T, environment, W in next, N do
        if not (T >= 1) then

        else
            environment[2] = environment;
            (environment)[3] = (registers[T]);
            (environment)[1] = (3)
            N[T] = nil
        end
    end
end
return registers[1]
end

end
::p37::
tick(37)
do
do
registers[1] = (registers[1][1])
end

end
::p38::
do
do
registers[1] = (registers[1]["hotkey"])
end

end
::p39::
do
do
a = (1)
z = registers[1]
registers[a + 1] = (z);
(registers)[a] = z["get"]
end

end
goto p4
::p57::
do
do
a = (1)
z = registers[1]
registers[a + 1] = (z);
(registers)[a] = z["get"]
end

end
::p58::
do
do
a = (1);
(registers)[a] = registers[a](registers[a + 1])
top = (a)
end

end
::p59::
branch_taken=false
do
do
if not registers[1] then
    branch_taken=true
end
end

end
if branch_taken then goto p36 end
::p70::
do
do
(registers)[1] = upvalues[0]["antiaim"]
end

end
::p71::
do
do
registers[1] = (registers[1]["other"])
end

end
::p72::
do
do
registers[1] = (registers[1]["slow_motion"])
end

end
goto p37
end
end
