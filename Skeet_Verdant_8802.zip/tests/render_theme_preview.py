#!/usr/bin/env python3
"""Design preview: production chrome commands, schematic original controls.
Requires Pillow. This is not a game screenshot.
"""
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
S=2
im=Image.new('RGB',(1024*S,720*S),(10,13,16));d=ImageDraw.Draw(im)
fontroot=Path('/usr/share/fonts/truetype/dejavu')
def font(size,bold=False):
    name='DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'
    return ImageFont.truetype(str(fontroot/name),size*S)
def rect(x,y,w,h,color,outline=None):
    d.rectangle((x*S,y*S,(x+w)*S-1,(y+h)*S-1),fill=color,outline=outline,width=S)
def text(x,y,s,color,size=10,bold=False):d.text((x*S,y*S),s,fill=color,font=font(size,bold))

# Schematic representation of the existing native menu, not an extracted render.
rect(70,110,620,480,(16,20,24),outline=(48,60,56))
rect(76,116,65,468,(13,17,20))
labels=['R','AA','L','V','M','S','P','C','LUA']
for i,label in enumerate(labels):
    y=132+i*48
    if i==0:
        rect(77,y-9,63,40,(28,37,30));rect(77,y-9,2,40,(163,201,106))
    text(92,y,label,(163,201,106) if i==0 else (110,124,118),11,True)
for x,title in [(155,'Aimbot'),(421,'Other')]:
    rect(x,134,249,424,(23,28,30),outline=(48,60,56))
    text(x+13,145,title,(219,229,221),11,True)
    rect(x+13,168,223,1,(43,53,53))
def check(x,y,label,on=True):
    rect(x,y+2,9,9,(163,201,106) if on else (46,54,51))
    text(x+18,y,label,(212,222,215),10)
def combo(x,y,label,value):
    text(x,y,label,(137,151,143),9)
    rect(x,y+20,213,23,(30,37,38),outline=(46,57,53))
    text(x+8,y+25,value,(213,223,215),9)
    text(x+194,y+24,'v',(131,146,140),9)
def slider(x,y,label,value,fraction):
    text(x,y,label,(212,222,215),10)
    text(x+177,y,value,(163,201,106),9)
    rect(x,y+24,213,4,(42,51,47));rect(x,y+24,int(213*fraction),4,(163,201,106))
check(173,185,'Enabled');check(173,214,'Automatic fire')
combo(173,252,'Target selection','Cycle')
combo(173,318,'Target hitbox','Head, chest, stomach')
slider(173,390,'Minimum hit chance','80%',0.8)
slider(173,445,'Minimum damage','45',0.45)
check(439,185,'Accuracy boost');check(439,214,'Automatic scope')
combo(439,252,'Weapon','AWP')
check(439,322,'Prefer safe point');check(439,351,'Delay shot',False)
slider(439,397,'Multi-point scale','65%',0.65)
check(439,454,'Quick stop')
text(173,522,'Native controls shown schematically.',(94,111,102),8)

commands=json.loads((ROOT/'build/preview_scene.json').read_text())
for c in commands:
    packed=c['color'];col=tuple((packed>>(8*i))&255 for i in range(3))
    x,y,w,h=(c[k] for k in ['x','y','w','h'])
    if c['kind']==0:rect(x,y,w,h,col)
    elif c['kind']==1:
        d.rectangle((x*S,y*S,(x+w)*S-1,(y+h)*S-1),outline=col,width=S)
    else:
        flags=c['flags'];size=13 if flags&2 else 9 if flags&4 else 10
        text(x,y,c['text'],col,size,bool(flags&1))
text(70,657,'DESIGN PREVIEW / production theme commands + schematic native settings',(94,111,102),9)
out=ROOT/'Verdant_preview.png';im.save(out)
print(out)
