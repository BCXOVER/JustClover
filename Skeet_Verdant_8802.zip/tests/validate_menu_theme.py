#!/usr/bin/env python3
from pathlib import Path
import json, struct, subprocess, hashlib
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
CORE=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes()
BASE=0x43310000;ENTRY=0x433ac5e2;MEM=0x200000;STOP=0x100000
helper=BUILD/'test_menu_theme'
subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra',str(ROOT/'tests/test_menu_theme.cpp'),'-o',str(helper)],check=True)

def store(u,a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
def word(u,a):return struct.unpack('<I',u.mem_read(a,4))[0]
checks=0
for location in [0x10000000,0x60000000,0xf0000000]:
    path=BUILD/f'menu_plan_{location:x}.bin'
    subprocess.run([str(helper),str(BUILD/'preview_scene.json'),str(path),hex(location)],check=True)
    plan=path.read_bytes();assert len(plan)==19
    for opened in [False,True]:
        for visible in range(8):
            results=[]
            for hooked in [False,True]:
                u=Uc(UC_ARCH_X86,UC_MODE_32)
                u.mem_map(BASE,len(CORE));u.mem_write(BASE,CORE)
                u.mem_map(MEM,0x10000);u.mem_map(STOP,0x1000)
                u.mem_map(location,0x1000);u.mem_write(location,plan[:12])
                # A one-stack-argument __fastcall bridge, as used by production.
                callback=location+0x100
                code=b'\x55\x8b\xec\xff\x75\x08\xe8'+struct.pack('<I',(location-(callback+11))&0xffffffff)+b'\x5d\xc2\x04\x00'
                u.mem_write(callback,code)
                if hooked:u.mem_write(ENTRY,plan[12:])
                menu=MEM+0x5000;vtable=MEM+0x6000;tabs=MEM+0x7000
                store(u,menu,vtable);store(u,vtable+8,STOP+0x200)
                store(u,menu+0x34,int(opened));store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+12)
                for i in range(3):
                    tab=MEM+0x8000+i*0x100
                    store(u,tabs+i*4,tab);store(u,tab,vtable)
                    store(u,vtable+16,STOP+0x300)
                    u.mem_write(tab+0x15,bytes([(visible>>i)&1]))
                sp=MEM+0x1000;arg=0x1234abcd
                store(u,sp,STOP);store(u,sp+4,arg)
                saved={UC_X86_REG_EBX:0x12345678,UC_X86_REG_ESI:0x23456789,
                       UC_X86_REG_EDI:0x34567890,UC_X86_REG_EBP:0x45678901}
                for reg,val in saved.items():u.reg_write(reg,val)
                u.reg_write(UC_X86_REG_ECX,menu);u.reg_write(UC_X86_REG_EDX,0xabcdef01)
                u.reg_write(UC_X86_REG_ESP,sp)
                trace=[];finished=[]
                def hook(u,address,size,user):
                    frame=u.reg_read(UC_X86_REG_ESP)
                    if address in (0x43384045,STOP+0x200,STOP+0x300):
                        this=u.reg_read(UC_X86_REG_ECX)
                        argc=2 if address==STOP+0x300 else 1
                        args=[word(u,frame+4*(i+1)) for i in range(argc)]
                        assert args[0]==arg,(hex(address),args)
                        if argc==2:assert args[1]==menu+0xc
                        trace.append((address,this,args))
                        ret=word(u,frame)
                        u.reg_write(UC_X86_REG_ESP,frame+4+argc*4)
                        u.reg_write(UC_X86_REG_ECX,0xfeed0001)
                        u.reg_write(UC_X86_REG_EDX,0xfeed0002)
                        u.reg_write(UC_X86_REG_EAX,0xfeed0003)
                        u.reg_write(UC_X86_REG_EIP,ret)
                    elif address==STOP:
                        assert frame==sp+8
                        for reg,val in saved.items():assert u.reg_read(reg)==val
                        finished.append(True);u.emu_stop()
                u.hook_add(UC_HOOK_CODE,hook)
                u.emu_start(ENTRY,STOP+1,count=500)
                assert finished
                assert len(trace)==1+(1+visible.bit_count() if opened else 0)
                results.append(trace)
            assert results[0]==results[1],(location,opened,visible,results)
            checks+=1

pattern=[0xa1,None,None,None,None,0x83,0x64,0x24,0x04,0x00,0x89,0x54,0x24,0x18,0x89,0x44,0x24,0x10,0x53,0x56]
hits=[i for i in range(len(CORE)-len(pattern)+1) if CORE[i]==0xa1 and all(v is None or CORE[i+j]==v for j,v in enumerate(pattern))]
assert len(hits)==1
assert struct.unpack_from('<I',CORE,hits[0]+1)[0]==0x4347690c
report={'passed':True,'render_call_comparisons':checks,'scene_variants':27,'interaction_checks':50,
        'core_sha256':hashlib.sha256(CORE).hexdigest(),
        'checks':['Original x86 render routine vs relocated prologue; original stack argument, tab visibility order, stack cleanup and callee-saved registers.',
                  'Portable layout, hold-click debounce, independent controls, focus handling, accent selection, restore and fade alpha.'],
        'limits':'Compiled Windows renderer callback and actual in-game appearance are not runtime tested.',
        'game_tested':False}
(BUILD/'menu_theme_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
