#!/usr/bin/env python3
"""Static checks for the actual release DLL/EXE and exact embedded input bytes."""
from pathlib import Path
import hashlib
import json
import struct
import pefile

ROOT = Path(__file__).resolve().parents[1]

def sha(data): return hashlib.sha256(data).hexdigest()
def inspect(name, dll):
    path = ROOT/'build'/name
    pe = pefile.PE(str(path))
    assert pe.FILE_HEADER.Machine == 0x14c
    assert pe.OPTIONAL_HEADER.Magic == 0x10b
    assert pe.is_dll() == dll
    entry = pe.OPTIONAL_HEADER.AddressOfEntryPoint
    assert entry > 0
    section = pe.get_section_by_rva(entry)
    assert section and section.Characteristics & 0x20000000
    assert pe.OPTIONAL_HEADER.DllCharacteristics & 0x140 == 0x140
    assert getattr(pe,'DIRECTORY_ENTRY_BASERELOC',[])
    imports = {i.dll.decode():[x.name.decode() if x.name else x.ordinal for x in i.imports]
               for i in pe.DIRECTORY_ENTRY_IMPORT}
    assert not any(x.lower().startswith(('libc++','libstdc++','libgcc','vcruntime','msvcp')) for x in imports)
    return pe, {'file':name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'machine':'i386 PE32',
                'image_base':hex(pe.OPTIONAL_HEADER.ImageBase),'entry_point_rva':hex(entry),
                'aslr':True,'nx_compatible':True,'imports':imports,'pefile_warnings':pe.get_warnings()}

def main():
    dll, dll_report = inspect('skeet.dll',True)
    injector, injector_report = inspect('injector.exe',False)
    symbols = {s.name.decode():s.address for s in dll.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
    assert 'skeet_loader_status' in symbols
    status_rva = symbols['skeet_loader_status']
    status = dll.get_data(status_rva,256)
    assert len(status) == 256 and struct.unpack_from('<III',status) == (1,0,0)
    assert b'Waiting for game modules\0' in status
    section = dll.get_section_by_rva(status_rva)
    assert section and section.Characteristics & 0x80000000
    dll_report['loader_status_export_rva'] = hex(status_rva)
    expected = {('BINARY',102):ROOT/'source/skeet/Binary/skeet_cv.bin',
                ('BYTECODE',103):ROOT/'source/skeet/VM/bytecode.json',
                ('EXPORTS',101):ROOT/'source/skeet/Binary/exports.json'}
    resources = []
    for kind in dll.DIRECTORY_ENTRY_RESOURCE.entries:
        for item in kind.directory.entries:
            key = (str(kind.name), item.id)
            assert key in expected, key
            for lang in item.directory.entries:
                data = dll.get_data(lang.data.struct.OffsetToData,lang.data.struct.Size)
                original = expected[key].read_bytes()
                assert data == original, key
                resources.append({'type':key[0],'id':key[1],'language':lang.id,'bytes':len(data),'sha256':sha(data)})
    assert len(resources) == 3
    dll_report['resources'] = resources
    raw = expected[('BINARY',102)].read_bytes()
    dll_bytes=(ROOT/'build/skeet.dll').read_bytes()
    for label in ['VERDANT','History guard','Strict hit chance','Restore defaults']:
        assert label.encode('utf-16le') in dll_bytes, label
    assert raw[0x741a7:0x741aa] == bytes.fromhex('ff5024')
    assert raw[0x741bc:0x741bf] == bytes.fromhex('ff5028')
    required = {'CreateRemoteThread','WriteProcessMemory','ReadProcessMemory','VirtualAllocEx',
                'VirtualFreeEx','IsWow64Process','WaitForSingleObject','GetExitCodeThread'}
    imported = {name for names in injector_report['imports'].values() for name in names}
    assert required <= imported
    report = {'passed':True,'artifacts':[dll_report,injector_report],
              'embedded_core':'original skeet_cv.bin, unchanged on disk; overlay operands and two scan call sites patched only in mapped memory',
              'scan_record_guard_integrated':True,'sample_threshold_ceiling_integrated':True,
              'verdant_menu_integrated':True,'patch_switches_integrated':True,
              'prediction_module_integrated':False,'full_rage_rebuilt_from_source':False,
              'windows_loader_tested':False,'game_tested':False,
              'limits':['No target client.dll/engine.dll/gameoverlayrenderer.dll was available for runtime compatibility testing.',
                        'Existing client/engine RVAs in the supplied wrapper remain version-specific.',
                        'Compiler warnings from unused original SDK functions remain in build/dll.log.']}
    (ROOT/'build/release_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PE32 DLL/EXE, entry points, relocations, status export and all three exact resources: PASS')
if __name__=='__main__': main()
