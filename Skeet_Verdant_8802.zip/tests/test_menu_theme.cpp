#include "../source/skeet/menu_theme_design.h"
#include "../source/skeet/menu_theme_hook.h"
#include <cassert>
#include <fstream>
#include <iostream>
#include <string>

static void json_text(std::ostream& out,const wchar_t* text) {
    out << '"';
    if(text)for(auto* p=text;*p;p++) {
        if(*p=='"'||*p=='\\')out << '\\';
        out << char(*p);
    }
    out << '"';
}
int main(int argc,char** argv) {
    int layouts=0, interactions=0;
    for(const auto& screen:std::array<verdant::Rect,5>{{{0,0,800,600},{0,0,1024,768},{0,0,1280,720},{0,0,1920,1080},{0,0,2560,1440}}})
        for(const auto& size:std::array<verdant::Rect,2>{{{0,0,600,480},{0,0,800,650}}}) {
            if(size.w+16>screen.w||size.h+16>screen.h)continue;
            const auto native=verdant::centered_menu(size,screen.w,screen.h);
            const auto l=verdant::layout(native,screen.w,screen.h);
            assert(!l.rail.w || l.rail.x+l.rail.w<=native.x || l.rail.x>=native.x+native.w);
            verdant::State state{};
            assert(l.guard.w && l.strict.w);
            const auto click=[&](verdant::Rect r) {
                state.update(l,r.x+2,r.y+2,false,true,0.016f);
                const bool result=state.update(l,r.x+2,r.y+2,true,true,0.016f);
                for(int i=0;i<20;i++)assert(!state.update(l,r.x+2,r.y+2,true,true,0.016f));
                return result;
            };
            assert(click(l.guard));assert(!state.guard && state.strict);interactions++;
            assert(click(l.strict));assert(!state.guard && !state.strict);interactions++;
            state.mouse_down=false;
            assert(!state.update(l,l.guard.x+2,l.guard.y+2,true,false,0.016f));
            assert(!state.guard && !state.strict);interactions++;
            assert(!state.update(l,l.guard.x+2,l.guard.y+2,true,true,0.016f));
            assert(!state.guard);interactions++;
            if(l.has_rail) {
                assert(click(l.swatches[2]));assert(state.accent==2);interactions++;
                assert(click(l.restore));assert(state.guard && state.strict && state.accent==0);interactions++;
            }
            for(int accent=0;accent<3;accent++) {
                state.accent=accent;
                verdant::Scene scene{};
                verdant::build_scene(scene,l,state,L"RAGE",1.f);
                assert(scene.count<scene.commands.size());
                for(std::size_t i=0;i<scene.count;i++) {
                    auto& cmd=scene.commands[i];
                    assert(cmd.rect.x>=0 && cmd.rect.y>=0);
                    if(cmd.kind!=verdant::Kind::Text) {
                        assert(cmd.rect.x+cmd.rect.w<=screen.w && cmd.rect.y+cmd.rect.h<=screen.h);
                    }
                }
                verdant::build_scene(scene,l,state,L"RAGE",0.f);
                for(std::size_t i=0;i<scene.count;i++)assert(scene.commands[i].color.a==0);
                layouts++;
            }
        }
    if(argc>1) {
        std::ofstream out(argv[1]);
        const auto l=verdant::layout({70,110,620,480},1024,720);
        verdant::State state{};verdant::Scene scene{};
        verdant::build_scene(scene,l,state,L"RAGE",1.f);
        out << "[";
        for(std::size_t i=0;i<scene.count;i++) {
            auto& c=scene.commands[i];
            if(i)out << ',';
            out << "{\"kind\":" << int(c.kind) << ",\"x\":" << c.rect.x << ",\"y\":" << c.rect.y
                << ",\"w\":" << c.rect.w << ",\"h\":" << c.rect.h << ",\"color\":" << c.color.pack()
                << ",\"flags\":" << c.flags << ",\"text\":";
            json_text(out,c.text);out << '}';
        }
        out << "]\n";
    }
    if(argc>3) {
        const auto at=std::uint32_t(std::stoul(argv[3],nullptr,0));
        const auto plan=verdant::render_hook_plan(0x43310000,at,at+0x100);
        static_assert(sizeof(plan)==19);
        std::ofstream out(argv[2],std::ios::binary);
        out.write(reinterpret_cast<const char*>(&plan),sizeof(plan));
    }
    std::cout << layouts << " scene variants and " << interactions << " interaction checks passed.\n";
}
