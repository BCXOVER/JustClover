#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>

namespace verdant {
inline constexpr std::size_t render_offset=0x9c5e2;
inline constexpr std::uint8_t render_prefix[]={0x56,0xff,0x74,0x24,0x08,0x8b,0xf1,0xe8,0x57,0x7a,0xfd,0xff};
struct RenderHookPlan {std::uint8_t trampoline[12]{};std::uint8_t entry[7]{};};
inline RenderHookPlan render_hook_plan(std::uint32_t image_base,std::uint32_t trampoline,
                                      std::uint32_t callback) {
    RenderHookPlan p{};
    std::memcpy(p.trampoline,render_prefix,7);
    p.trampoline[7]=0xe9;
    auto delta=std::uint32_t(image_base+render_offset+7-(trampoline+12));
    std::memcpy(p.trampoline+8,&delta,4);
    p.entry[0]=0xe9;
    delta=callback-std::uint32_t(image_base+render_offset+5);
    std::memcpy(p.entry+1,&delta,4);
    p.entry[5]=p.entry[6]=0x90;
    return p;
}
}
