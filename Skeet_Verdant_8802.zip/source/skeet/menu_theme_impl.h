#pragma once
// Included only by saver.cpp, which owns the SDK implementation in this DLL.
#include "menu_theme.h"
#include "menu_theme_design.h"
#include "menu_theme_hook.h"
#include "scan_patch.h"
#include "overlay_patch.h"

namespace menu_theme {
using namespace SkeetSDK;
using DrawMenu=void(__thiscall*)(CMenu*,void*);
static DrawMenu original_draw=nullptr;
static SkeetClass_* context=nullptr;
static verdant::State controls{};
static bool centered=false;
static bool texture_attempted=false;
static int background_texture=-1;

static_assert(offsetof(SkeetClass_,Menu)==0x10);
static_assert(offsetof(Child,PWidgets)==0x90);
static_assert(offsetof(Child,Widgets)==0xa8);
static_assert(sizeof(CWidg)==0x20);
static_assert(offsetof(CWidg,NameCol)==0xc);
static_assert(offsetof(CWidg,BackCol)==0x18);
static_assert(offsetof(CTab,Color)==0x50);

static bool ready(CMenu* menu,IRenderer* renderer) {
    if(!menu || !renderer || !menu->Tabs.data()) return false;
    const auto count=menu->Tabs.size();
    return count>0 && count<=9 && menu->CurrentTab<count &&
        menu->Size.x>=400 && menu->Size.x<=4096 && menu->Size.y>=300 && menu->Size.y<=4096;
}
static VecCol native_color(verdant::Color c) {return VecCol(c.r,c.g,c.b,c.a);}
static void set_accent(CMenu* menu) {
    auto color=native_color(verdant::accents[controls.accent]);
    auto* value=reinterpret_cast<std::uint32_t*>(0x43468fb0);
    if(*value==color.pack())return;
    *value=color.pack();
    if(menu->Tabs.size()>MISC && menu->Tabs[MISC] && menu->Tabs[MISC]->Childs.size()>2) {
        auto* child=menu->Tabs[MISC]->Childs[2];
        if(child && child->Elements.size()>3) {
            auto* picker=child->Elements[3]->GetAs<CPicker>();
            if(picker && picker->Header.Type==UiColorPicker && picker->Value) {
                *picker->Value=color;
                picker->OnValueSet();
            }
        }
    }
}
static void style_native(CMenu* menu,IRenderer* renderer) {
    set_accent(menu);
    if(!texture_attempted) {
        texture_attempted=true;
        std::array<unsigned char,32*32*4> tile{};
        for(int y=0;y<32;y++)for(int x=0;x<32;x++) {
            const int k=(y*32+x)*4;
            const bool grid=(x%16==0)||(y%16==0);
            tile[k]=grid?28:24;tile[k+1]=grid?25:20;tile[k+2]=grid?22:16;tile[k+3]=255;
        }
        background_texture=renderer->AddTexture(tile.data(),32,32,tile.size(),0,0);
    }
    if(background_texture>0)menu->BackgroundTextureId=background_texture;
    const auto accent=native_color(verdant::accents[controls.accent]);
    for(std::size_t t=0;t<menu->Tabs.size();t++) {
        auto* tab=menu->Tabs[t];
        if(!tab)continue;
        tab->Color=t==menu->CurrentTab?accent:VecCol(139,151,145,255);
        if(tab->Childs.size()>32)continue;
        for(std::size_t c=0;c<tab->Childs.size();c++) {
            auto* child=tab->Childs[c];
            if(!child)continue;
            auto* widget=child->PWidgets;
            if(widget) {
                widget->NameCol=VecCol(219,229,221,255);
                widget->BorderCol=VecCol(48,60,56,255);
                widget->BackCol=VecCol(23,28,30,255);
                widget->ShadowCol=VecCol(0,0,0,70);
            }
            child->Color=VecCol(220,230,223,255);
            if(child->Elements.size()>1024)continue;
            for(std::size_t e=0;e<child->Elements.size();e++) {
                auto* element=child->Elements[e];
                if(!element)continue;
                auto* inspector=element->GetAs<Inspector>();
                if(inspector->Type>=UiButton && inspector->Type<=UiMultiselect)
                    *reinterpret_cast<VecCol*>(reinterpret_cast<char*>(element)+0x50)=VecCol(212,222,215,255);
            }
        }
    }
}
static bool pointer_input(IRenderer* renderer,int& x,int& y,bool& down) {
    down=(GetAsyncKeyState(VK_LBUTTON)&0x8000)!=0;
    const auto window=GetForegroundWindow();
    DWORD pid=0;
    GetWindowThreadProcessId(window,&pid);
    if(pid!=GetCurrentProcessId())return false;
    POINT cursor{};RECT client{};
    if(!GetCursorPos(&cursor)||!ScreenToClient(window,&cursor)||!GetClientRect(window,&client))return false;
    const int client_w=client.right-client.left,client_h=client.bottom-client.top;
    if(client_w<=0||client_h<=0)return false;
    int width=0,height=0;renderer->ScreenSize(&width,&height);
    x=static_cast<int>(static_cast<long long>(cursor.x)*width/client_w);
    y=static_cast<int>(static_cast<long long>(cursor.y)*height/client_h);
    return true;
}
static void draw_scene(IRenderer* renderer,const verdant::Scene& scene,int width,int height) {
    int previous_bounds[4]={0,0,width,height};
    renderer->GetBounds(previous_bounds);
    const auto z=renderer->GetZBuff();
    int full_bounds[4]={0,0,width,height};
    renderer->SetBounds(full_bounds);
    renderer->SetZBuff(0.f);
    for(std::size_t i=0;i<scene.count;i++) {
        const auto& c=scene.commands[i];
        const auto& r=c.rect;
        if(!c.color.a)continue;
        switch(c.kind) {
        case verdant::Kind::Fill:renderer->Rect(r.x,r.y,r.w,r.h,c.color.pack());break;
        case verdant::Kind::Outline:renderer->RectOut(1,r.x,r.y,r.w,r.h,c.color.pack());break;
        case verdant::Kind::Text:renderer->Text(c.flags,r.x,r.y,c.color.pack(),4096,c.text,wcslen(c.text));break;
        }
    }
    renderer->SetZBuff(z);
    renderer->SetBounds(previous_bounds);
}
static void __fastcall frame(CMenu* menu,void*,void* draw_argument) {
    // The native method is __thiscall with one stack argument (ret 4), unlike
    // the SDK's two-register RenderFn alias. Keep that stack argument intact.
    auto* renderer=context?context->IRenderer:nullptr;
    const bool root=context && context->Menu==menu && ready(menu,renderer);
    const bool open=root && (menu->MenuStatus&MenuOpened);
    int width=0,height=0;
    verdant::Layout layout{};
    static ULONGLONG previous_time=0;
    if(open) {
        renderer->ScreenSize(&width,&height);
        if(width>0&&height>0) {
            if(!centered) {
                const auto position=verdant::centered_menu({menu->Pos.x,menu->Pos.y,menu->Size.x,menu->Size.y},width,height);
                menu->Pos={position.x,position.y};
                menu->Mouse.LastMenuPos=menu->Pos;
                centered=true;
                controls.mouse_down=(GetAsyncKeyState(VK_LBUTTON)&0x8000)!=0;
            }
            layout=verdant::layout({menu->Pos.x,menu->Pos.y,menu->Size.x,menu->Size.y},width,height);
            controls.guard=scan_patch::history_guard_enabled!=0;
            controls.strict=scan_patch::strict_threshold_enabled!=0;
            int mouse_x=-1,mouse_y=-1;bool down=false;
            const bool active=pointer_input(renderer,mouse_x,mouse_y,down) && !(menu->MenuStatus&(MenuDragged|MenuScaled));
            const auto now=GetTickCount64();
            const float dt=previous_time?std::clamp(float(now-previous_time)/1000.f,0.f,0.05f):0.016f;
            previous_time=now;
            if(controls.update(layout,mouse_x,mouse_y,down,active,dt)) {
                InterlockedExchange(reinterpret_cast<volatile LONG*>(&scan_patch::history_guard_enabled),controls.guard?1:0);
                InterlockedExchange(reinterpret_cast<volatile LONG*>(&scan_patch::strict_threshold_enabled),controls.strict?1:0);
            }
            style_native(menu,renderer);
        }
    } else {
        previous_time=0;
        controls.mouse_down=(GetAsyncKeyState(VK_LBUTTON)&0x8000)!=0;
    }
    original_draw(menu,draw_argument);
    if(open && width>0 && height>0) {
        constexpr const wchar_t* tabs[]={L"RAGE",L"ANTI-AIM",L"LEGIT",L"VISUALS",L"MISC",L"SKINS",L"PLAYERS",L"CONFIGS",L"LUA"};
        verdant::Scene scene{};
        verdant::build_scene(scene,layout,controls,tabs[menu->CurrentTab],menu->MenuAlpha);
        draw_scene(renderer,scene,width,height);
    }
}
bool install(std::uint8_t* image,std::size_t size) {
    if(!image || size!=scan_patch::image_size ||
       std::memcmp(image+verdant::render_offset,verdant::render_prefix,sizeof(verdant::render_prefix))) {
        SetLastError(ERROR_REVISION_MISMATCH);return false;
    }
    constexpr int class_pattern[]={0xa1,-1,-1,-1,-1,0x83,0x64,0x24,0x04,0x00,0x89,0x54,0x24,0x18,0x89,0x44,0x24,0x10,0x53,0x56};
    const auto match=overlay_patch::find(image,size,class_pattern);
    if(match.count!=1){SetLastError(ERROR_REVISION_MISMATCH);return false;}
    std::uint32_t class_address=0;
    std::memcpy(&class_address,image+match.offset+1,4);
    const auto start=reinterpret_cast<std::uintptr_t>(image);
    if(class_address<start || class_address-start>size-sizeof(SkeetClass_)) {
        SetLastError(ERROR_INVALID_ADDRESS);return false;
    }
    auto* trampoline=static_cast<std::uint8_t*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
    if(!trampoline)return false;
    const auto plan=verdant::render_hook_plan(static_cast<std::uint32_t>(start),
        static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(trampoline)),
        static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(&frame)));
    std::memcpy(trampoline,plan.trampoline,sizeof(plan.trampoline));
    DWORD old=0;
    if(!VirtualProtect(trampoline,4096,PAGE_EXECUTE_READ,&old)||
       !FlushInstructionCache(GetCurrentProcess(),trampoline,sizeof(plan.trampoline))) {
        const auto error=GetLastError();VirtualFree(trampoline,0,MEM_RELEASE);SetLastError(error);return false;
    }
    original_draw=reinterpret_cast<DrawMenu>(trampoline);
    context=reinterpret_cast<SkeetClass_*>(class_address);
    std::memcpy(image+verdant::render_offset,plan.entry,sizeof(plan.entry));
    if(!FlushInstructionCache(GetCurrentProcess(),image+verdant::render_offset,sizeof(plan.entry))) {
        const auto error=GetLastError();
        std::memcpy(image+verdant::render_offset,verdant::render_prefix,sizeof(plan.entry));
        FlushInstructionCache(GetCurrentProcess(),image+verdant::render_offset,sizeof(plan.entry));
        original_draw=nullptr;context=nullptr;
        VirtualFree(trampoline,0,MEM_RELEASE);SetLastError(error);return false;
    }
    return true;
}
}
