#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace verdant {
struct Rect {
    int x=0, y=0, w=0, h=0;
    bool contains(int px, int py) const {
        return px>=x && py>=y && px<x+w && py<y+h;
    }
};
struct Color {
    unsigned char r=0,g=0,b=0,a=255;
    std::uint32_t pack() const {
        return r | (std::uint32_t(g)<<8) | (std::uint32_t(b)<<16) | (std::uint32_t(a)<<24);
    }
};
inline constexpr Color accents[]={{163,201,106,255},{112,190,207,255},{222,157,116,255}};
inline Color mix(Color a, Color b, float t) {
    t=std::clamp(t,0.f,1.f);
    return {static_cast<unsigned char>(a.r+(b.r-a.r)*t),
            static_cast<unsigned char>(a.g+(b.g-a.g)*t),
            static_cast<unsigned char>(a.b+(b.b-a.b)*t),
            static_cast<unsigned char>(a.a+(b.a-a.a)*t)};
}
struct Layout {
    Rect menu, header, rail, footer, guard, strict, restore;
    std::array<Rect,3> swatches{};
    bool has_rail=false;
};
inline Layout layout(Rect menu, int screen_w, int screen_h) {
    Layout out{};
    out.menu=menu;
    const int rail_w=232, gap=12;
    // Never place the new controls on top of original controls.
    if (menu.x+menu.w+gap+rail_w<=screen_w-8) {
        out.rail={menu.x+menu.w+gap,menu.y,rail_w,std::min(menu.h,480)};
        out.has_rail=out.rail.h>=414;
    } else if (menu.x-gap-rail_w>=8) {
        out.rail={menu.x-gap-rail_w,menu.y,rail_w,std::min(menu.h,480)};
        out.has_rail=out.rail.h>=414;
    }
    const int left=out.has_rail?std::min(menu.x,out.rail.x):menu.x;
    const int right=out.has_rail?std::max(menu.x+menu.w,out.rail.x+out.rail.w):menu.x+menu.w;
    if (menu.y>=64) out.header={left,menu.y-56,right-left,48};
    if (menu.y+menu.h+34<=screen_h-4) out.footer={left,menu.y+menu.h+8,right-left,24};
    if (out.has_rail) {
        out.guard={out.rail.x+14,out.rail.y+78,rail_w-28,92};
        out.strict={out.rail.x+14,out.rail.y+180,rail_w-28,92};
        for (int i=0;i<3;i++) out.swatches[i]={out.rail.x+14+i*68,out.rail.y+320,60,32};
        out.restore={out.rail.x+14,out.rail.y+370,rail_w-28,30};
    } else if(out.header.w>=520) {
        out.guard={out.header.x+out.header.w-266,out.header.y+10,124,28};
        out.strict={out.header.x+out.header.w-132,out.header.y+10,124,28};
    }
    return out;
}
inline Rect centered_menu(Rect menu, int screen_w, int screen_h) {
    const int rail=menu.w+260<=screen_w-16 && menu.h>=414?244:0;
    menu.x=std::max(8,(screen_w-menu.w-rail)/2);
    menu.y=std::max(64,(screen_h-menu.h-90)/2+56);
    if (menu.y+menu.h>screen_h-8) menu.y=std::max(0,screen_h-menu.h-8);
    return menu;
}
struct State {
    bool guard=true, strict=true, mouse_down=false;
    int accent=0;
    float guard_animation=1.f, strict_animation=1.f;
    float guard_hover=0.f, strict_hover=0.f;
    // True means a control changed, not merely an animation advancing.
    bool update(const Layout& l,int mouse_x,int mouse_y,bool down,bool interactive,float dt) {
        const bool click=interactive && down && !mouse_down;
        mouse_down=down;
        bool changed=false;
        if (click) {
            if (l.guard.contains(mouse_x,mouse_y)) {guard=!guard;changed=true;}
            else if (l.strict.contains(mouse_x,mouse_y)) {strict=!strict;changed=true;}
            else if (l.restore.contains(mouse_x,mouse_y)) {guard=strict=true;accent=0;changed=true;}
            else for (int i=0;i<3;i++) if(l.swatches[i].contains(mouse_x,mouse_y)) {accent=i;changed=true;}
        }
        const float t=std::clamp(dt*14.f,0.f,1.f);
        guard_animation+=(float(guard)-guard_animation)*t;
        strict_animation+=(float(strict)-strict_animation)*t;
        guard_hover+=(float(interactive&&l.guard.contains(mouse_x,mouse_y))-guard_hover)*t;
        strict_hover+=(float(interactive&&l.strict.contains(mouse_x,mouse_y))-strict_hover)*t;
        return changed;
    }
};
enum class Kind { Fill, Outline, Text };
struct Command {
    Kind kind=Kind::Fill;
    Rect rect{};
    Color color{};
    const wchar_t* text=nullptr;
    int flags=0x100;
};
struct Scene {
    std::array<Command,384> commands{};
    std::size_t count=0;
    void add(Command c) {if(count<commands.size()) commands[count++]=c;}
    void fill(Rect r,Color c) {if(r.w>0&&r.h>0)add({Kind::Fill,r,c});}
    void outline(Rect r,Color c) {if(r.w>0&&r.h>0)add({Kind::Outline,r,c});}
    void text(int x,int y,const wchar_t* s,Color c,int flags=0x100) {
        add({Kind::Text,{x,y,0,0},c,s,flags});
    }
    void rounded(Rect r,Color c,int radius=6) {
        radius=std::min({radius,r.w/2,r.h/2});
        if(radius<1){fill(r,c);return;}
        fill({r.x,r.y+radius,r.w,r.h-2*radius},c);
        for(int i=0;i<radius;i++) {
            const float dy=float(radius-i)-0.5f;
            const int inset=radius-int(std::sqrt(float(radius*radius)-dy*dy));
            fill({r.x+inset,r.y+i,r.w-2*inset,1},c);
            fill({r.x+inset,r.y+r.h-i-1,r.w-2*inset,1},c);
        }
    }
};
inline void draw_toggle(Scene& s,int x,int y,float amount,Color accent) {
    const auto track=mix({56,63,65,255},accent,amount);
    s.rounded({x,y,34,18},track,9);
    s.rounded({x+3+int(16*amount),y+3,12,12},{241,245,238,255},6);
}
inline void build_scene(Scene& s,const Layout& l,const State& state,
                        const wchar_t* active_tab,float alpha=1.f) {
    s.count=0;
    const Color accent=accents[std::clamp(state.accent,0,2)];
    constexpr Color text{225,232,227,255},muted{131,146,140,255};
    constexpr Color background{16,20,23,255},panel{22,28,30,255},line{43,53,53,255};
    s.outline({l.menu.x-1,l.menu.y-1,l.menu.w+2,l.menu.h+2},line);
    if(l.header.h) {
        s.rounded(l.header,background,7);
        s.fill({l.header.x+1,l.header.y+1,l.header.w-2,1},line);
        const int x=l.header.x+16,y=l.header.y;
        s.fill({x,y+15,3,17},accent);
        s.fill({x+6,y+19,3,13},mix(accent,{255,255,255,255},0.2f));
        s.fill({x+12,y+11,3,21},accent);
        s.text(x+29,y+8,L"VERDANT",text,0x103);
        s.text(x+30,y+29,L"S K E E T   /   P R E C I S I O N",muted,0x104);
        if(l.header.w>500 && l.has_rail) {
            s.text(l.header.x+l.header.w/2,y+17,active_tab,muted);
            s.rounded({l.header.x+l.header.w-136,y+13,120,22},{29,38,31,255},5);
            s.rounded({l.header.x+l.header.w-125,y+21,5,5},accent,2);
            s.text(l.header.x+l.header.w-112,y+17,L"LEGACY EDITION",accent,0x104);
        } else if(l.guard.w && l.strict.w) {
            for(int i=0;i<2;i++) {
                const Rect r=i?l.strict:l.guard;
                s.rounded(r,panel,4);
                s.text(r.x+8,r.y+10,i?L"Strict HC":L"History",text,0x104);
                draw_toggle(s,r.x+r.w-40,r.y+5,i?state.strict_animation:state.guard_animation,accent);
            }
        }
    }
    if(l.has_rail) {
        const int x=l.rail.x,y=l.rail.y;
        s.rounded(l.rail,background,7);
        s.text(x+15,y+17,L"PRECISION",text,0x101);
        s.text(x+15,y+39,L"Two independent controls.",muted,0x104);
        const int enabled=int(state.guard)+int(state.strict);
        s.rounded({x+166,y+16,50,20},{30,39,31,255},4);
        s.text(x+176,y+20,enabled==2?L"2 / 2":enabled==1?L"1 / 2":L"0 / 2",accent,0x104);
        s.fill({x+15,y+62,l.rail.w-30,1},line);
        auto card=[&](Rect r,const wchar_t* title,const wchar_t* a,const wchar_t* b,
                      float amount,float hover,bool enabled) {
            s.rounded(r,mix(panel,{29,39,35,255},hover),6);
            s.fill({r.x,r.y+12,2,r.h-24},mix(line,accent,amount));
            s.text(r.x+13,r.y+14,title,text,0x101);
            draw_toggle(s,r.x+r.w-47,r.y+12,amount,accent);
            s.text(r.x+13,r.y+41,a,muted,0x104);
            s.text(r.x+13,r.y+57,b,muted,0x104);
            s.text(r.x+13,r.y+75,enabled?L"ENABLED":L"DISABLED",enabled?accent:muted,0x104);
        };
        card(l.guard,L"History guard",L"Reject a failed history",L"record before scanning.",
             state.guard_animation,state.guard_hover,state.guard);
        card(l.strict,L"Strict hit chance",L"Round the sample target",L"up to your threshold.",
             state.strict_animation,state.strict_hover,state.strict);
        s.text(x+15,y+294,L"ACCENT",muted,0x104);
        for(int i=0;i<3;i++) {
            const Rect r=l.swatches[i];
            s.rounded(r,i==state.accent?Color{36,45,40,255}:panel,4);
            s.rounded({r.x+9,r.y+11,10,10},accents[i],4);
            s.text(r.x+25,r.y+11,i==0?L"01":i==1?L"02":L"03",i==state.accent?text:muted,0x104);
            if(i==state.accent)s.fill({r.x+7,r.y+r.h-2,r.w-14,1},accents[i]);
        }
        s.rounded(l.restore,panel,4);
        s.text(l.restore.x+48,l.restore.y+10,L"Restore defaults",text,0x104);
        if(l.rail.h>=450) {
            s.fill({x+15,y+422,l.rail.w-30,1},line);
            s.text(x+15,y+440,L"Native settings. Refined.",muted,0x104);
        }
    }
    if(l.footer.h) {
        s.rounded(l.footer,background,4);
        s.text(l.footer.x+12,l.footer.y+7,L"VERDANT / CS:GO LEGACY",muted,0x104);
        if(l.footer.w>500)s.text(l.footer.x+l.footer.w-224,l.footer.y+7,
            L"History guard + strict hit chance",accent,0x104);
    }
    alpha=std::clamp(alpha,0.f,1.f);
    for(std::size_t i=0;i<s.count;i++)s.commands[i].color.a=static_cast<unsigned char>(s.commands[i].color.a*alpha);
}
}
