#pragma once
#include <cstddef>
#include <cstdint>
namespace menu_theme {
bool install(std::uint8_t* image,std::size_t size);
}
