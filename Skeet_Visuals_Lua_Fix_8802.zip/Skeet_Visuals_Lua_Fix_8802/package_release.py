#!/usr/bin/env python3
"""Package already-built and validated Windows artifacts without running them."""
from pathlib import Path
import shutil,json,hashlib,difflib,zipfile
ROOT=Path(__file__).resolve().parent
NAME='Skeet_Visuals_Lua_Fix_8802'
DEST=ROOT/'release'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    if DEST.exists():shutil.rmtree(DEST)
    DEST.mkdir()
    for folder in ['source','tests','tools']:
        shutil.copytree(ROOT/folder,DEST/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for name in ['README_RU.md','requirements-build.txt','build_windows.py','package_release.py','Visuals_layout_preview.png','Visuals_icons_preview.png']:
        shutil.copy2(ROOT/name,DEST/name)
    (DEST/'bin').mkdir();(DEST/'reports').mkdir()
    for name in ['skeet.dll','injector.exe']:shutil.copy2(ROOT/'build'/name,DEST/'bin'/name)
    reports=['visuals_validation.json','motion_validation.json','scan_patch_validation.json','precision_validation.json','release_validation.json','resolver_validation.json','blend_audit.json']
    for name in reports:
        report=json.loads((ROOT/'build'/name).read_text());assert report['passed'],name
        shutil.copy2(ROOT/'build'/name,DEST/'reports'/name)
    for name in ['dll.log','injector.log','resources.log']:shutil.copy2(ROOT/'build'/name,DEST/'reports'/name)
    previous=ROOT.parent/'skeet-cs2-visuals-8802'
    diff=[]
    if previous.exists():
        for file in sorted((ROOT/'source').rglob('*')):
            if not file.is_file():continue
            rel=file.relative_to(ROOT);old=previous/rel
            if old.exists() and old.read_bytes()!=file.read_bytes():
                diff.extend(difflib.unified_diff(old.read_text().splitlines(True),file.read_text().splitlines(True),fromfile='before/'+str(rel),tofile='after/'+str(rel)))
    (DEST/'Visuals_Lua_Fix.diff').write_text(''.join(diff))
    entries={str(p.relative_to(DEST)):sha(p.read_bytes()) for p in sorted(DEST.rglob('*')) if p.is_file()}
    (DEST/'SHA256SUMS.txt').write_text(''.join(f'{digest}  {name}\n' for name,digest in entries.items()))
    archive=ROOT.parent/(NAME+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file():z.write(p,NAME+'/'+str(p.relative_to(DEST)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name,digest in entries.items():assert sha(z.read(NAME+'/'+name))==digest,name
    report={'passed':True,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
        'dll_sha256':sha((DEST/'bin/skeet.dll').read_bytes()),'manifest_files':len(entries),'zip_crc_verified':True,
        'supersampled_category_icons':True,'lua_lifecycle_cases':53,'reload_category_and_values_preserved':True,
        'unsupported_visuals_control_types':['textbox','listbox'],'unsupported_layout_recovers_after_script_unload':True,
        'custom_backtrack_patch':False,'patches_always_enabled':True,'inventory_changer_added':False,'skin_peer_sync_added':False,'game_tested':False}
    (ROOT/'build/package_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    archive.with_suffix('.sha256').write_text(report['sha256']+'  '+archive.name+'\n')
    archive.with_suffix('.validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
