#pragma once
// The native SDK implementation is owned solely by saver.cpp.
#include "cs2_visuals.h"
#include "cs2_visuals_design.h"
#include "cs2_visuals_hook.h"
#include "native_ui_names.h"
#include "native_ui_proxy.h"
#include "scan_patch.h"
#include "overlay_patch.h"

namespace cs2_visuals {
using namespace SkeetSDK;
using NativeDraw=void(__thiscall*)(CMenu*,void*);
using NativeChildDraw=void(__thiscall*)(Child*,IRenderer*,const Vec2*);
using NativeLayout=void(__thiscall*)(Child*);
using ChildCtor=void*(__thiscall*)(void*,void*,const wchar_t*,int,int,bool);
using AppendChild=void(__thiscall*)(void*,void*);
using AddButton=void*(__thiscall*)(void*,bool,const wchar_t*,void*,void*);
using Hide=void(__thiscall*)(void*,bool);
static NativeDraw original_draw=nullptr;
static SkeetClass_* context=nullptr;
static ChildCtor child_ctor=nullptr;
static AppendChild append_child=nullptr;
static AddButton add_button=nullptr;
static Hide hide=nullptr;
static native_ui_proxy::Api native{};
static bool attempted=false,attached=false,refreshing=false,rebuild_pending=false;
static int active=Enemy;
struct Group {Child* child=nullptr;void* table[9]{};NativeChildDraw draw=nullptr;NativeLayout layout=nullptr;int panel=-1;unsigned items=0;};
static Group groups[panel_count+1]{};
static Child* originals[32]{};static unsigned original_count=0;
static Button* buttons[category_count]{};
struct Binding {PElement proxy=nullptr,source=nullptr;Group* group=nullptr;unsigned char observed[8]{};int order=1000;};
static Binding bindings[512]{};static unsigned binding_count=0;
static Binding* pending=nullptr;
static std::uint64_t captured_topology=0;
static bool original_visible[32]{};
static bool rebuild(CMenu* menu);
static_assert(sizeof(Child)==0xc8&&sizeof(Checkbox)==0x78&&sizeof(Slider)==0x124);
// SDK Multiselect is only the prefix; the native class also has 32 inline items.
static_assert(sizeof(Combobox)==0xa8&&sizeof(Multiselect)==0x90&&sizeof(CPicker)==0x138);
static_assert(sizeof(Hotkey)==0x70&&sizeof(Label)==0x60&&sizeof(BoxVars<wchar_t>)==20);
static_assert(offsetof(CTab,Childs)==0x70&&offsetof(Child,Elements)==0x80);
static_assert(offsetof(Checkbox,Header)+offsetof(Header<Child>,Type)==0x19&&offsetof(Checkbox,Value)==0x5c);
static_assert(offsetof(Combobox,Vars)==0x7c&&offsetof(Multiselect,Vars)==0x80);

static bool ready(CMenu* menu) {
    if(!context||!context->IRenderer||context->Menu!=menu||!menu||menu->Tabs.size()!=9||menu->CurrentTab>=9)return false;
    if(menu->Size.x<400||menu->Size.x>4096||menu->Size.y<300||menu->Size.y>4096)return false;
    for(auto* tab:menu->Tabs)if(!tab)return false;
    if(menu->Tabs[LUA]->Childs.size()<2||!menu->Tabs[LUA]->Childs[1])return false;
    auto* tab=menu->Tabs[VISUALS];return tab&&!tab->Childs.empty()&&tab->Childs.size()<64;
}
static float scale() {
    // The same scale float used by native Checkbox::HandleDPI (0x433e085c).
    const float s=*reinterpret_cast<const float*>(0x4346d490);
    return s>=.5f&&s<=3.f?s:1.f;
}
static Group* group(Child* child) {
    for(auto& g:groups)if(g.child==child)return &g;return nullptr;
}
static void visible(void* object,bool value) {
    if(hide)hide(object,value);
    else *(static_cast<unsigned char*>(object)+0x15)=value;
}
static bool owned(Child* child) {
    auto* g=group(child);return g&&*reinterpret_cast<void***>(child)==g->table;
}
static std::uint64_t topology() {
    auto* menu=context?context->Menu:nullptr;
    if(!menu||menu->Tabs.size()!=9||!menu->Tabs[VISUALS]||!menu->Tabs[MISC])return 0;
    auto* visuals=menu->Tabs[VISUALS];
    if(visuals->Childs.size()>64)return 0;
    // Lua may append/remove elements and even whole children. Only enumerate
    // live menu ownership; never dereference an old source pointer here.
    std::uint64_t hash=0xcbf29ce484222325ULL;
    const auto add=[&](std::uintptr_t value){hash=(hash^value)*0x100000001b3ULL;};
    for(int pass=0;pass<2;pass++) {
        auto* tab=menu->Tabs[pass?MISC:VISUALS];const auto count=tab->Childs.size();
        if(count>64)return 0;add(reinterpret_cast<std::uintptr_t>(tab));
        for(unsigned i=0;i<count;i++) {
            auto* child=tab->Childs[i];if(!child)return 0;
            if(!pass&&owned(child)){add(reinterpret_cast<std::uintptr_t>(child));add(0x435332U);continue;}
            if(child->Elements.size()>1024)return 0;
            add(reinterpret_cast<std::uintptr_t>(child));add(child->Elements.size());
            for(auto* e:child->Elements) {
                if(!e)return 0;
                const int type=e->GetAs<Checkbox>()->Header.Type;
                add(reinterpret_cast<std::uintptr_t>(e));add(type);
                if(native_ui_proxy::supported(type)&&type!=UiLabel)
                    add(reinterpret_cast<std::uintptr_t>(native_ui_proxy::pointer(e,0x5c)));
            }
        }
    }
    return hash;
}
// A queued callback can outlive its Lua source. Stop forwarding immediately;
// defer deletion/reconstruction until the next frame outside callback dispatch.
static void invalidate() {
    attached=false;rebuild_pending=true;
    auto* menu=context?context->Menu:nullptr;
    if(!menu||menu->Tabs.size()!=9||!menu->Tabs[VISUALS])return;
    for(auto* child:menu->Tabs[VISUALS]->Childs)if(child&&owned(child)&&group(child)->panel>=0) {
        for(auto* e:child->Elements)if(e) {
            auto* view=e->GetAs<Checkbox>();
            view->Header.Flags.Visible=view->Header.Flags.Editable=view->Header.Flags.AllowMouseInput=false;
            view->Calls.clear();
            if(native_ui_proxy::supported(view->Header.Type))
                *reinterpret_cast<void**>(reinterpret_cast<char*>(e)+0x5c)=nullptr;
            view->ResetInputState();
        }
    }
}
static void restore_originals() {
    auto* menu=context?context->Menu:nullptr;
    if(!menu||menu->Tabs.size()!=9||!menu->Tabs[VISUALS])return;
    for(auto* child:menu->Tabs[VISUALS]->Childs)if(child) {
        if(owned(child))child->Header.Flags.Visible=false;
        else for(unsigned i=0;i<original_count;i++)if(child==originals[i])child->Header.Flags.Visible=original_visible[i];
    }
}
static void position(Group& g) {
    auto* menu=context?context->Menu:nullptr;if(!menu||!g.child)return;
    const auto plan=layout(menu->Size.x,menu->Size.y,scale());
    const Rect r=g.panel<0?plan.category:plan.panels[g.panel];
    g.child->Pos={r.x,r.y};g.child->Size={r.w,r.h};g.child->DefSize=g.child->Size;
}
static void place_buttons() {
    auto* menu=context->Menu;const auto plan=layout(menu->Size.x,menu->Size.y,scale());
    for(int i=0;i<category_count;i++)if(buttons[i]) {
        const Rect r=plan.icons[i];buttons[i]->Pos={r.x-plan.category.x,r.y-plan.category.y};
        buttons[i]->Size={r.w,r.h};buttons[i]->DefSize=buttons[i]->Size;
        buttons[i]->Header.Flags.Visible=i!=Danger||groups[DangerItems].items>0;
    }
}
static void __fastcall child_layout(Child* child,void*) {
    auto* g=group(child);if(!g)return;
    position(*g);
    if(g->panel<0) {
        // Category buttons form a horizontal row, not the native vertical
        // control column. Prevent a spurious scrollbar from its column height.
        *reinterpret_cast<unsigned char*>(reinterpret_cast<char*>(child)+0x94)=0;
        *reinterpret_cast<int*>(reinterpret_cast<char*>(child)+0xa8)=0;
        child->CurSize=child->Size;child->MinimizedCapacity=child->Size;
        place_buttons();
    } else g->layout(child);
}
static void __fastcall child_draw(Child* child,void*,IRenderer* renderer,const Vec2* origin) {
    if(!attached)return;
    auto* g=group(child);if(!g)return;
    const Vec2 old_pos=child->Pos,old_size=child->Size;position(*g);
    if(old_pos.x!=child->Pos.x||old_pos.y!=child->Pos.y||old_size.x!=child->Size.x||old_size.y!=child->Size.y)child_layout(child,nullptr);
    g->draw(child,renderer,origin);
    if(g->panel>=0||!origin||!renderer)return;
    // Paint only this category child's inner surface, at its existing depth.
    // Ordinary native popup ordering and all main-menu hit regions remain intact.
    const auto plan=layout(context->Menu->Size.x,context->Menu->Size.y,scale());
    auto bar=plan.category;bar.x+=origin->x;bar.y+=origin->y;
    auto icons=plan.icons;for(auto& r:icons){r.x+=origin->x;r.y+=origin->y;}
    int hovered=-1;for(int i=0;i<category_count;i++)if(buttons[i]&&buttons[i]->Header.Flags.Hovered)hovered=i;
    static Scene scene{};category_scene(scene,bar,icons,active,groups[DangerItems].items?category_count:category_count-1,scale(),1.f,hovered);
    for(unsigned i=0;i<scene.count;i++) {
        auto& c=scene.commands[i];const auto& r=c.r;
        if(c.kind==Fill)renderer->Rect(r.x,r.y,r.w,r.h,c.color.pack());
        else if(c.kind==Line)renderer->Line(r.x,r.y,r.w,r.h,c.color.pack());
    }
}
static unsigned model(Binding& b,unsigned char* out) {
    const auto* s=b.source->GetAs<Checkbox>();const int type=s->Header.Type;
    if(type==UiButton)return 0;
    void* value=native_ui_proxy::pointer(s,0x5c);
    if(type==UiLabel||!value)return 0;
    const unsigned n=type==UiHotkey?8:(type==UiCheckbox?1:4);
    auto* p=static_cast<unsigned char*>(value)+(type==UiHotkey?16:0);std::memcpy(out,p,n);
    if(type==UiHotkey) {std::uint32_t key;std::memcpy(&key,out,4);key&=~3U;std::memcpy(out,&key,4);}
    return n;
}
static void sync() {
    if(refreshing||!attached)return;refreshing=true;
    if(captured_topology&&topology()!=captured_topology){refreshing=false;invalidate();return;}
    bool dirty[panel_count+1]{};
    for(unsigned i=0;i<binding_count;i++) {
        auto& b=bindings[i];auto* p=b.proxy->GetAs<Checkbox>();auto* s=b.source->GetAs<Checkbox>();
        if(p->Header.Flags.Visible!=s->Header.Flags.Visible) {visible(p,s->Header.Flags.Visible);dirty[b.group-groups]=true;}
        p->Header.Flags.Editable=s->Header.Flags.Editable;p->Header.Flags.AllowMouseInput=s->Header.Flags.AllowMouseInput;
        unsigned char now[8]{};const auto n=model(b,now);
        if(n&&std::memcmp(now,b.observed,n)) {
            std::memcpy(b.observed,now,n);
            // Refresh the native view cache only after the shared value changes.
            // Its forwarding callback is guarded, so no callback loop is made.
            b.proxy->GetAs<Checkbox>()->OnConfigLoad();
        }
    }
    for(unsigned i=0;i<original_count;i++)if(originals[i]->Header.Flags.Visible)visible(originals[i],false);
    for(int p=0;p<panel_count;p++) {
        auto& g=groups[p];if(!g.child)continue;
        const bool shown=categories[p]==active&&g.items;
        if(g.child->Header.Flags.Visible!=shown){visible(g.child,shown);dirty[p]=true;}
    }
    for(int p=0;p<=panel_count;p++)if(dirty[p]&&groups[p].child)child_layout(groups[p].child,nullptr);
    refreshing=false;
}
static void __fastcall changed(void* ctx,void*) {
    if(refreshing||!attached)return;
    if(captured_topology&&topology()!=captured_topology){invalidate();return;}
    auto* b=static_cast<Binding*>(ctx);if(!b||!b->source)return;
    if(b->source->GetAs<Checkbox>()->Header.Type!=UiButton)b->source->GetAs<Checkbox>()->OnConfigLoad();
    if(captured_topology&&topology()!=captured_topology){invalidate();return;}
    b->source->GetAs<Checkbox>()->OnValueSet();
    if(captured_topology&&topology()!=captured_topology){invalidate();return;}
    model(*b,b->observed);sync();
}
static void __fastcall choose(void* ctx,void*) {
    const auto selected=int(reinterpret_cast<std::uintptr_t>(ctx));
    if(selected<0||selected>=category_count||(selected==Danger&&!groups[DangerItems].items))return;
    active=selected;sync();
}
static void destroy(void* p) {if(p)static_cast<Checkbox*>(p)->Decay(true);}
static bool copy(void* destination,void* source,int type) {
    if(type==UiCombobox) {
        auto* from=static_cast<Combobox*>(source);if(from->Vars.size()>128)return false;
        static_cast<Combobox*>(destination)->Vars=from->Vars;
    } else if(type==UiMultiselect) {
        auto* from=static_cast<Multiselect*>(source);if(from->Vars.size()>32)return false;
        static_cast<Multiselect*>(destination)->Vars=from->Vars;
    }
    static_cast<Checkbox*>(destination)->OnConfigLoad();
    return true;
}
static void link(void* destination,void* source) {
    if(!pending||pending->source!=source)throw std::runtime_error("Native UI binding mismatch");
    pending->proxy=static_cast<PElement>(destination);
    static_cast<Checkbox*>(destination)->Calls.emplace_back(pending,&changed);
}
static bool create_group(CMenu* menu,CTab* tab,Group& out,int panel) {
    auto* child=static_cast<Child*>(native.allocate(sizeof(Child)));if(!child)return false;
    child_ctor(child,tab,panel<0?L"Category":titles[panel],int(0xff000000U),0,false);
    child->Header.Flags.Visible=false;out.child=child;out.panel=panel;
    auto** table=*reinterpret_cast<void***>(child);std::memcpy(out.table,table,sizeof(out.table));
    out.draw=reinterpret_cast<NativeChildDraw>(table[4]);out.layout=reinterpret_cast<NativeLayout>(table[8]);
    out.table[4]=reinterpret_cast<void*>(&child_draw);out.table[8]=reinterpret_cast<void*>(&child_layout);
    *reinterpret_cast<void***>(child)=out.table;
    append_child(tab,child);position(out);return true;
}
static bool make_binding(Group& target,PElement source,const wchar_t* name,const wchar_t* anchor) {
    if(binding_count==std::size(bindings))return false;
    auto& b=bindings[binding_count];b={};b.source=source;b.group=&target;b.order=rank(target.panel,anchor);pending=&b;
    void* made=nullptr;
    if(source->GetAs<Checkbox>()->Header.Type==UiButton) {
        made=add_button(target.child,source->GetAs<Checkbox>()->Header.Flags.SameLine,caption(name),&b,reinterpret_cast<void*>(&changed));
        if(made) {
            b.proxy=static_cast<PElement>(made);
            auto* out=static_cast<Button*>(made);auto* from=source->GetAs<Button>();
            out->Header.Flags=from->Header.Flags;out->Header.Font=from->Header.Font;out->LeftPaddign=from->LeftPaddign;
        }
    } else made=native_ui_proxy::create(native,target.child,source,caption(name));
    pending=nullptr;
    if(!made)return false;
    model(b,b.observed);++binding_count;++target.items;return true;
}
static bool populate(CTab* source,bool misc) {
    if(!source||source->Childs.size()>64)return false;
    // Only the original children are enumerated; our children have been appended.
    const auto count=misc?source->Childs.size():original_count;
    for(unsigned c=0;c<count;c++) {
        Child* child=misc?source->Childs[c]:originals[c];if(!child||child->Elements.size()>512)return false;
        wchar_t group_name[128]{};native_ui_names::decode(child->Name.get(),group_name,std::size(group_name));
        Mask previous=0;wchar_t anchor[128]{};
        for(auto* element:child->Elements) {
            if(!element)return false;
            auto* item=element->GetAs<Checkbox>();wchar_t name[128]{};
            native_ui_names::decode(item->Name.get(),name,std::size(name));
            bool blank=true;for(auto* p=name;*p;p++)if(*p>L' '){blank=false;break;}
            const bool companion=item->Header.Type==UiColorPicker||(item->Header.Type==UiHotkey&&blank)||blank;
            const Mask mask=companion?previous:route(group_name,name,misc);
            if(!companion){previous=mask;std::wcscpy(anchor,name);}
            if(!mask)continue;
            if(item->Header.Type!=UiButton&&!native_ui_proxy::supported(item->Header.Type))return false;
            for(int panel=0;panel<panel_count;panel++)if(mask&bit(panel))
                if(!make_binding(groups[panel],element,name,anchor))return false;
        }
    }
    return true;
}
static bool attach(CMenu* menu) {
    auto* tab=menu->Tabs[VISUALS];original_count=tab->Childs.size();
    if(!original_count||original_count+panel_count+1>=32)return false;
    for(unsigned i=0;i<original_count;i++){originals[i]=tab->Childs[i];original_visible[i]=originals[i]->Header.Flags.Visible;}
    for(int panel=0;panel<panel_count;panel++)if(!create_group(menu,tab,groups[panel],panel))return false;
    if(!create_group(menu,tab,groups[panel_count],-1))return false;
    // The native button factory owns input, keyboard focus and click callbacks.
    constexpr const wchar_t* names[]={L"Enemy",L"Team",L"World",L"View",L"Danger Zone"};
    for(int i=0;i<category_count;i++) {
        buttons[i]=static_cast<Button*>(add_button(groups[panel_count].child,false,names[i],reinterpret_cast<void*>(std::uintptr_t(i)),reinterpret_cast<void*>(&choose)));
        if(!buttons[i])return false;
    }
    return rebuild(menu);
}
static bool rebuild(CMenu* menu) {
    auto* tab=menu->Tabs[VISUALS];
    // The appended children and the category selection survive Lua reloads.
    // Destroy only our fresh view objects; all original models remain owned by
    // the core/Lua, and no source callbacks or values are reset.
    for(auto& g:groups) {
        if(!g.child)return false;
        bool live=false;for(auto* child:tab->Childs)if(child==g.child&&owned(child))live=true;
        if(!live)return false;
    }
    for(int panel=0;panel<panel_count;panel++) {
        auto& g=groups[panel];
        for(auto* e:g.child->Elements)if(e) {
            auto* view=e->GetAs<Checkbox>();view->Calls.clear();
            if(native_ui_proxy::supported(view->Header.Type))
                *reinterpret_cast<void**>(reinterpret_cast<char*>(e)+0x5c)=nullptr;
            view->ResetInputState();destroy(e);
        }
        g.child->Elements.clear();g.items=0;
    }
    binding_count=0;pending=nullptr;captured_topology=0;
    Child* previous[32]{};bool was_visible[32]{};const unsigned previous_count=original_count;
    for(unsigned i=0;i<previous_count;i++){previous[i]=originals[i];was_visible[i]=original_visible[i];}
    original_count=0;
    for(auto* child:tab->Childs)if(child&&!owned(child)) {
        if(original_count==std::size(originals))return false;
        bool shown=child->Header.Flags.Visible;
        for(unsigned i=0;i<previous_count;i++)if(previous[i]==child){shown=was_visible[i];break;}
        originals[original_count]=child;original_visible[original_count++]=shown;
    }
    if(!populate(tab,false)||!populate(menu->Tabs[MISC],true)||!groups[EnemyESP].items)return false;
    const auto order=[](PElement e){for(unsigned i=0;i<binding_count;i++)if(bindings[i].proxy==e)return bindings[i].order;return 1000;};
    for(int panel=0;panel<panel_count;panel++) {
        auto& elements=groups[panel].child->Elements;
        // Stable insertion sort needs no CRT scratch allocations during Lua reload.
        for(unsigned i=1;i<elements.size();i++) {
            auto* item=elements[i];unsigned j=i;
            while(j&&order(item)<order(elements[j-1])){elements[j]=elements[j-1];--j;}
            elements[j]=item;
        }
    }
    captured_topology=topology();if(!captured_topology)return false;
    rebuild_pending=false;attached=true;
    if(active==Danger&&!groups[DangerItems].items)active=Enemy;
    visible(groups[panel_count].child,true);sync();
    for(auto& g:groups)child_layout(g.child,nullptr);
    return attached;
}
static void __fastcall frame(CMenu* menu,void*,void* argument) {
    if(attached&&captured_topology&&topology()!=captured_topology)invalidate();
    if(ready(menu)) {
        if(!attempted&&(menu->MenuStatus&MenuOpened)) {
            attempted=true;
            try {attach(menu);}catch(...){attached=false;}
            if(!attached) {
                restore_originals();
                if(groups[panel_count].child&&buttons[category_count-1]) {
                    captured_topology=topology();rebuild_pending=true;
                }
                OutputDebugStringA("CS2 Visuals layout unavailable; original Visuals retained.");
            }
        }
        if(rebuild_pending) {
            // A failed revision is retried only when ownership changes again.
            // This avoids an allocation loop for unsupported third-party UI.
            const auto revision=topology();
            if(revision&&revision!=captured_topology) {
                rebuild_pending=false;
                try {if(!rebuild(menu)){attached=false;restore_originals();captured_topology=topology();rebuild_pending=true;}}
                catch(...){attached=false;restore_originals();captured_topology=topology();rebuild_pending=true;}
            }
        }
        if(attached) {
            sync();
            if(attached)for(auto& g:groups)if(g.child) {
                position(g);if(g.child->Header.Flags.Visible)child_layout(g.child,nullptr);
            }
        }
    }
    original_draw(menu,argument);
}
template<class T,std::size_t N> static bool resolve(T& target,unsigned char* image,std::size_t size,const int(&pattern)[N]) {
    const auto match=overlay_patch::find(image,size,pattern);
    if(match.count!=1)return false;target=reinterpret_cast<T>(image+match.offset);return true;
}
bool install(unsigned char* image,std::size_t size) {
    if(!image||size!=scan_patch::image_size||std::memcmp(image+render_offset,render_prefix,sizeof(render_prefix)))return false;
    constexpr int allocator[]={0x56,0x8b,0xf1,0x33,0xc0,0x85};
    constexpr int deallocator[]={0x85,0xc9,0x74,0x17,0x8d,0x41,0xf0,0x2b,0x40,8,0x50,0x64,0xa1,0x30,0,0,0,0x6a,0,0xff,0x70,0x18,0xe8,-1,-1,-1,-1,0xc3};
    constexpr int child[]={0x55,0x8b,0xec,0x56,0xff,0x75,0x18};
    constexpr int append[]={0x55,0x8b,0xec,0x8b,0x45,8,0x56,0x8b,0xf1,0x89};
    constexpr int button[]={0x55,0x8b,0xec,0x83,0xe4,0xf8,0x51,0x51,0x56,0x57,0x8b,0xf9,0x6a};
    constexpr int check[]={0x56,0xff,0x74,0x24,0x10,0x8b,0xf1,0x6a,3};
    constexpr int slider[]={0x55,0x8b,0xec,0x53,0x56,0xff};
    constexpr int combo[]={0x56,0x57,0xff,0x74,0x24,0x14,0x8b,0xf1,0x6a,4};
    constexpr int multi[]={0x56,0x57,0xff,0x74,0x24,0x14,0x8b,0xf1,0x6a,0x0d};
    constexpr int picker[]={0x53,0x56,0x57,0xff,0x74,0x24,0x14,0x8b,0xd9,0x6a};
    constexpr int hotkey[]={0x53,0x8b,0x5c,0x24,0x0c,0x56,0x53};
    constexpr int label[]={0x56,0x6a,0,0x6a,8};
    constexpr int insert[]={0x56,0x57,0x8b,0xf9,0x8b,0x4f,0x10};
    constexpr int hide_pattern[]={0x8a,0x44,0x24,4,0x38};
    constexpr int context_pattern[]={0xa1,-1,-1,-1,-1,0x83,0x64,0x24,4,0,0x89,0x54,0x24,0x18,0x89,0x44,0x24,0x10,0x53,0x56};
    if(!resolve(native.allocate,image,size,allocator)||!resolve(Memory::Deallocator,image,size,deallocator)||
       !resolve(child_ctor,image,size,child)||!resolve(append_child,image,size,append)||!resolve(add_button,image,size,button)||
       !resolve(native.check,image,size,check)||!resolve(native.slider,image,size,slider)||!resolve(native.combo,image,size,combo)||
       !resolve(native.multi,image,size,multi)||!resolve(native.picker,image,size,picker)||!resolve(native.hotkey,image,size,hotkey)||
       !resolve(native.label,image,size,label)||!resolve(native.insert,image,size,insert)||!resolve(hide,image,size,hide_pattern))return false;
    Memory::Allocator=native.allocate;native.destroy=&destroy;native.copy=&copy;native.link=&link;
    const auto found=overlay_patch::find(image,size,context_pattern);if(found.count!=1)return false;
    std::uint32_t address=0;std::memcpy(&address,image+found.offset+1,4);
    if(address<scan_patch::image_base||address-scan_patch::image_base>size-sizeof(SkeetClass_))return false;
    context=reinterpret_cast<SkeetClass_*>(address);
    auto* trampoline=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));if(!trampoline)return false;
    const auto plan=render_hook_plan(scan_patch::image_base,reinterpret_cast<unsigned>(trampoline),reinterpret_cast<unsigned>(&frame));
    std::memcpy(trampoline,plan.trampoline,sizeof(plan.trampoline));DWORD protection=0;
    if(!VirtualProtect(trampoline,4096,PAGE_EXECUTE_READ,&protection)||!FlushInstructionCache(GetCurrentProcess(),trampoline,sizeof(plan.trampoline))) {
        const auto error=GetLastError();VirtualFree(trampoline,0,MEM_RELEASE);SetLastError(error);return false;
    }
    original_draw=reinterpret_cast<NativeDraw>(trampoline);std::memcpy(image+render_offset,plan.entry,sizeof(plan.entry));
    if(!FlushInstructionCache(GetCurrentProcess(),image+render_offset,sizeof(plan.entry))) {
        const auto error=GetLastError();std::memcpy(image+render_offset,render_prefix,sizeof(plan.entry));
        FlushInstructionCache(GetCurrentProcess(),image+render_offset,sizeof(plan.entry));VirtualFree(trampoline,0,MEM_RELEASE);SetLastError(error);return false;
    }
    return true;
}
}
