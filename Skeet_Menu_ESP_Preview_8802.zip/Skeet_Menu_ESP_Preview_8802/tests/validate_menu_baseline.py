"""Prove UI work did not alter any gameplay, loader or inventory source."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent/'skeet-hitscan-rollback-8802'
allowed={'source/skeet/cs2_visuals_design.h','source/skeet/cs2_visuals_impl.h'}
added={f'source/skeet/{name}.h' for name in ['agent_preview_native','agent_preview_plan','menu_interaction_design','menu_draw_helpers','ui_preview_input','esp_layout_runtime','rage_settings_ui','enemy_preview_ui','renderer_overlay_scope']}
sha=lambda b:hashlib.sha256(b).hexdigest()
old={str(p.relative_to(BASE)):p for p in (BASE/'source').rglob('*') if p.is_file()}
new={str(p.relative_to(ROOT)):p for p in (ROOT/'source').rglob('*') if p.is_file()}
assert new.keys()-old.keys()==added
assert not old.keys()-new.keys()
changes=[path for path in old if old[path].read_bytes()!=new[path].read_bytes()]
assert set(changes)==allowed,changes
unchanged={p:sha(new[p].read_bytes()) for p in old if p not in allowed}
report={'passed':True,'baseline_commit':'5b7ae4c996bf1457cd0924edb0b039c360c7cbb9','unchanged_source_files':len(unchanged),'changed_existing_source':sorted(changes),'new_presentation_headers':sorted(added),'gameplay_unchanged':True,'loader_unchanged':True,'skinchanger_unchanged':True,'embedded_resources_unchanged':True,'unchanged_source_sha256':unchanged}
(ROOT/'build/menu_baseline_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('UI scope verified:',len(unchanged),'baseline source files byte-for-byte unchanged; only 2 existing UI headers changed')
