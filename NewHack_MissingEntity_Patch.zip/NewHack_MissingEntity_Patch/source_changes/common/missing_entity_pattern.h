#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace missing_entity {
inline constexpr char error_text[]="CL_CallPostDataUpdates: missing ent %d";
// Real x86 engine loop. Only the ASLR-dependent string/IAT operands vary.
inline constexpr unsigned char context[]={
    0x8b,0xd8,0x85,0xdb,0x75,0x10,0xff,0x37,0x68,0,0,0,0,0xff,0x15,0,0,0,0,
    0x83,0xc4,0x08,0x8b,0x03,0x8b,0xcb,0xff,0x77,0x04,0xff,0x50,0x1c,
    0x8b,0x45,0xfc,0x46,0x83,0xc7,0x08,0x3b,0xb0,0x44,0x40,0,0,0x7c,0xc5};
inline constexpr unsigned patch_offset=6,advance_offset=32;
inline constexpr std::uint16_t original=0x37ff,replacement=0x18eb;
inline std::uint32_t u32(const void* p){std::uint32_t v;std::memcpy(&v,p,4);return v;}
inline std::uint16_t u16(const void* p){std::uint16_t v;std::memcpy(&v,p,2);return v;}
inline bool inside(std::size_t size,std::size_t at,std::size_t length){return at<=size&&length<=size-at;}
using Readable=bool(*)(const void*,std::size_t);
struct Match {std::size_t offset=0;bool patched=false;unsigned count=0;};
inline bool candidate(const unsigned char* image,std::size_t size,std::uint32_t base,std::size_t at,bool& patched,Readable readable=nullptr) {
    if(!image||!inside(size,at,sizeof(context)))return false;
    const auto* p=image+at;const auto state=u16(p+patch_offset);
    if(state!=original&&state!=replacement)return false;
    for(unsigned i=0;i<sizeof(context);++i) {
        if((i>=9&&i<13)||(i>=15&&i<19)||i==6||i==7)continue;
        if(p[i]!=context[i])return false;
    }
    const auto ptr=u32(p+9),iat=u32(p+15);
    if(ptr<base||iat<base||!inside(size,ptr-base,sizeof(error_text))||!inside(size,iat-base,4))return false;
    if(readable&&(!readable(image+(ptr-base),sizeof(error_text))||!readable(image+(iat-base),4)))return false;
    if(std::memcmp(image+(ptr-base),error_text,sizeof(error_text)))return false;
    patched=state==replacement;return true;
}
inline Match find(const unsigned char* image,std::size_t size,std::uint32_t base,std::size_t begin,std::size_t length,Readable readable=nullptr) {
    Match out{};if(!image||!inside(size,begin,length)||length<sizeof(context))return out;
    const auto end=begin+length-sizeof(context);
    for(std::size_t i=begin;i<=end;++i) {
        if(image[i]!=context[0]||image[i+1]!=context[1])continue;
        bool patched=false;if(!candidate(image,size,base,i,patched,readable))continue;
        ++out.count;out.offset=i;out.patched=patched;
        if(out.count>1)return out;
    }
    return out;
}
}
