#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include "missing_entity_pattern.h"
namespace missing_entity {
enum class Result:unsigned {installed=1,already_installed=2,no_engine=3,wrong_image=4,no_match=5,ambiguous=6,unaligned=7,protect_failed=8,changed=9,flush_failed=10,restore_failed=11};
struct Status {Result result;DWORD error;std::uint32_t rva;};
inline bool success(Status s){return s.result==Result::installed||s.result==Result::already_installed;}
// No heap, signature reads limited to committed readable module pages.
inline bool readable(const void* p,std::size_t length) {
    auto current=reinterpret_cast<std::uintptr_t>(p);
    if(length>static_cast<std::uintptr_t>(-1)-current)return false;
    const auto end=current+length;
    while(current<end) {
        MEMORY_BASIC_INFORMATION info{};
        if(VirtualQuery(reinterpret_cast<const void*>(current),&info,sizeof(info))!=sizeof(info)||info.State!=MEM_COMMIT||
           (info.Protect&(PAGE_NOACCESS|PAGE_GUARD))||!(info.Protect&(PAGE_READONLY|PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY)))return false;
        const auto next=reinterpret_cast<std::uintptr_t>(info.BaseAddress)+info.RegionSize;
        if(next<=current)return false;current=next<end?next:end;
    }
    return true;
}
inline Status apply() {
    auto* image=reinterpret_cast<unsigned char*>(GetModuleHandleW(L"engine.dll"));
    if(!image)return {Result::no_engine,ERROR_MOD_NOT_FOUND,0};
    if(!readable(image,sizeof(IMAGE_DOS_HEADER)))return {Result::wrong_image,ERROR_BAD_EXE_FORMAT,0};
    const auto* dos=reinterpret_cast<const IMAGE_DOS_HEADER*>(image);
    if(dos->e_magic!=IMAGE_DOS_SIGNATURE||dos->e_lfanew<0||dos->e_lfanew>0x10000||
       !readable(image+dos->e_lfanew,sizeof(IMAGE_NT_HEADERS32)))return {Result::wrong_image,ERROR_BAD_EXE_FORMAT,0};
    const auto* nt=reinterpret_cast<const IMAGE_NT_HEADERS32*>(image+dos->e_lfanew);
    if(nt->Signature!=IMAGE_NT_SIGNATURE||nt->FileHeader.Machine!=IMAGE_FILE_MACHINE_I386||nt->OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR32_MAGIC||
       nt->FileHeader.SizeOfOptionalHeader!=sizeof(IMAGE_OPTIONAL_HEADER32)||nt->FileHeader.NumberOfSections<1||nt->FileHeader.NumberOfSections>96||
       nt->OptionalHeader.SizeOfImage<4096||nt->OptionalHeader.SizeOfImage>256*1024*1024)return {Result::wrong_image,ERROR_BAD_EXE_FORMAT,0};
    const auto size=nt->OptionalHeader.SizeOfImage;
    const auto* sections=IMAGE_FIRST_SECTION(nt);
    if(!readable(sections,nt->FileHeader.NumberOfSections*sizeof(IMAGE_SECTION_HEADER)))return {Result::wrong_image,ERROR_BAD_EXE_FORMAT,0};
    // Validate declared ranges; discarded non-code sections need not be mapped.
    for(unsigned i=0;i<nt->FileHeader.NumberOfSections;++i) {
        const auto& sec=sections[i];const auto n=sec.Misc.VirtualSize;
        if(!inside(size,sec.VirtualAddress,n))return {Result::wrong_image,ERROR_INVALID_ADDRESS,0};
    }
    Match total{};
    for(unsigned i=0;i<nt->FileHeader.NumberOfSections;++i) {
        const auto& sec=sections[i];if(!(sec.Characteristics&IMAGE_SCN_MEM_EXECUTE))continue;
        if(!readable(image+sec.VirtualAddress,sec.Misc.VirtualSize))return {Result::wrong_image,ERROR_INVALID_ADDRESS,0};
        const auto m=find(image,size,reinterpret_cast<std::uint32_t>(image),sec.VirtualAddress,sec.Misc.VirtualSize,&readable);
        if(m.count){total.offset=m.offset;total.patched=m.patched;total.count+=m.count;}
        if(total.count>1)return {Result::ambiguous,ERROR_REVISION_MISMATCH,0};
    }
    if(total.count!=1)return {Result::no_match,ERROR_REVISION_MISMATCH,0};
    const auto rva=static_cast<std::uint32_t>(total.offset+patch_offset);
    auto* address=reinterpret_cast<volatile SHORT*>(image+rva);
    if(reinterpret_cast<std::uintptr_t>(address)&1)return {Result::unaligned,ERROR_INVALID_ADDRESS,rva};
    if(total.patched)return {Result::already_installed,0,rva};
    DWORD old=0;
    if(!VirtualProtect(const_cast<SHORT*>(address),2,PAGE_EXECUTE_READWRITE,&old))return {Result::protect_failed,GetLastError(),rva};
    // Aligned atomic exchange of exactly one two-byte instruction. There is no
    // partially written JMP for another game thread to fetch.
    const auto observed=static_cast<std::uint16_t>(InterlockedCompareExchange16(address,static_cast<SHORT>(replacement),static_cast<SHORT>(original)));
    const bool changed=observed==original||observed==replacement;
    const BOOL flushed=changed?FlushInstructionCache(GetCurrentProcess(),const_cast<SHORT*>(address),2):TRUE;
    DWORD error=flushed?0:GetLastError();
    if(!flushed&&observed==original) {
        InterlockedCompareExchange16(address,static_cast<SHORT>(original),static_cast<SHORT>(replacement));
        FlushInstructionCache(GetCurrentProcess(),const_cast<SHORT*>(address),2);
    }
    DWORD ignored=0;const BOOL restored=VirtualProtect(const_cast<SHORT*>(address),2,old,&ignored);
    if(!restored)return {Result::restore_failed,GetLastError(),rva};
    if(!changed)return {Result::changed,ERROR_REVISION_MISMATCH,rva};
    if(!flushed)return {Result::flush_failed,error,rva};
    return {observed==replacement?Result::already_installed:Result::installed,0,rva};
}
}
