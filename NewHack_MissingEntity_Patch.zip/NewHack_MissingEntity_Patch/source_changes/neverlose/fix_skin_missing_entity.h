#pragma once
bool apply_skin_missing_entity_fix();
