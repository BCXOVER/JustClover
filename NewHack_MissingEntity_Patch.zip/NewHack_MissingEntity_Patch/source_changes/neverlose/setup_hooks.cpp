#define WIN32_NO_STATUS
#include <winsock2.h>
#include <Windows.h>

#undef WIN32_NO_STATUS
#include <ntstatus.h>

#include "neverlose.h"
#include "HookFn.h"
#include "neverlosesdk.hpp"

#include "nadewarn.h"
#include "fix_records_size.h"
#include "fix_lerp_disable.h"
#include "fix_extrap_ticks.h"
#include "fix_hitscan.h"
#include "fix_backtrack_lerp.h"
#include "fix_persist.h"
#include "fix_menu_extra.h"
#include "fix_skin_missing_entity.h"

static void set_nl_logo(const char* name)
{
    constexpr size_t MAXLEN = 16;

    char buffer[MAXLEN] = {};

    size_t len = strlen(name);
    if (len > MAXLEN)
        len = MAXLEN;

    memcpy(buffer, name, len);

    auto* buff = reinterpret_cast<uint32_t*>(buffer);

    *reinterpret_cast<uint32_t*>(0x4160555E) = buff[0] ^ 0xD7E76FF9;
    *reinterpret_cast<uint32_t*>(0x41605558) = buff[1] ^ 0xBA5A7287;
    *reinterpret_cast<uint32_t*>(0x41605576) = buff[2] ^ 0x2D725D76;
    *reinterpret_cast<uint32_t*>(0x41605570) = buff[3] ^ 0x4066CCAE;
}

HMODULE WaitForSingleModule(const char* module_name)
{
    HMODULE mod = nullptr;

    while (!mod)
    {
        mod = GetModuleHandleA(module_name);
        Sleep(0);
    }

    return mod;
}

void WSAAPI ProceedGetAddrInfo(
    PVOID retaddr,
    PCSTR* ppNodeName,
    PCSTR* ppServiceName)
{
    PVOID pBase = nullptr;

    if (RtlPcToFileHeader(retaddr, &pBase) == reinterpret_cast<PVOID>(0x412A0000))
    {
        *ppNodeName = "127.0.0.1";
        *ppServiceName = "30030";
    }
}

void* getaddr_tram = nullptr;

INT __declspec(naked) WSAAPI hkgetaddrinfo(
    PCSTR pNodeName,
    PCSTR pServiceName,
    const ADDRINFOA* pHints,
    PADDRINFOA* ppResult)
{
    __asm
    {
        push ebp
        mov ebp, esp

        lea eax, [ebp + 12]
        push eax

        lea eax, [ebp + 8]
        push eax

        push[ebp + 4]
        call ProceedGetAddrInfo

        mov esp, ebp
        pop ebp

        push ebp
        mov ebp, esp
        jmp getaddr_tram
    }
}

void* term_tramp = nullptr;

NTSTATUS NTAPI hkterm(HANDLE hProc, NTSTATUS st)
{
    PVOID pBase = nullptr;

    if (hProc == NtCurrentProcess() &&
        RtlPcToFileHeader(_ReturnAddress(), &pBase) == reinterpret_cast<PVOID>(0x412A0000))
    {
        return STATUS_SUCCESS;
    }

    return reinterpret_cast<decltype(&NtTerminateProcess)>(term_tramp)(hProc, st);
}

void* exit_tramp = nullptr;

void hkexit(int code)
{
    reinterpret_cast<void(*)(int)>(exit_tramp)(code);
}

void __fastcall performmenu(neverlosesdk::gui::Menu& menu)
{
    menu.IsOpen = !menu.IsOpen;

    if (!menu.IsOpen)
    {
        auto config_entry =
            reinterpret_cast<PDWORD>(*reinterpret_cast<DWORD*>(0x425006F0));

        if (config_entry)
        {
            if (config_entry[39] == static_cast<DWORD>(-1))
                config_entry[39] = config_entry[38];

            reinterpret_cast<void(__thiscall*)(PDWORD)>(0x4153DFD0)(config_entry);
        }
    }
}

void neverlose::setup_hooks()
{
    // Install before the native Skinchanger can queue/delete client entities.
    if (!apply_skin_missing_entity_fix())
        panic("Missing-entity patch rejected this engine build; no unverified code was patched.");

    set_nl_logo("NEVERLACK.IN");

    HMODULE ws2 = WaitForSingleModule("ws2_32.dll");
    FARPROC getaddrinfo = GetProcAddress(ws2, "getaddrinfo");

    getaddr_tram = reinterpret_cast<PBYTE>(getaddrinfo) + 5;
    HookFn(getaddrinfo, hkgetaddrinfo, 0);

    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    FARPROC ntterm = GetProcAddress(ntdll, "NtTerminateProcess");

    HookFn(ntterm, hkterm, 0, &term_tramp);
    HookFn(reinterpret_cast<PVOID>(0x42026080), hkexit, 0, &exit_tramp);

    HookFn(reinterpret_cast<PVOID>(0x415E9086), performmenu, 0);
    HookFn(reinterpret_cast<PVOID>(0x41609C80), performmenu, 0);

    fix_vclient();
    setup_nadewarn();

    // ---- Viera Utils fixes (unified watchdog, check-before-write) ----
    apply_records_size_fix();    // Record window = 32 slots
    apply_lerp_disable();        // Disable lerping of BT size (4 sites, batched)
    apply_extrap_ticks_fix();    // Extrap ticks = 14 (~218ms)
    apply_hitscan_fix();         // Structural bypass (9 bytes × 2, batched)
    //apply_backtrack_lerp_fix(); // Disabled — breaks nade prediction

    apply_menu_extra();          // Extra — branding, about, profile, chat, URLs

    // Start the single unified persist thread (replaces 5 individual threads)
    start_persist_watchdog();
}