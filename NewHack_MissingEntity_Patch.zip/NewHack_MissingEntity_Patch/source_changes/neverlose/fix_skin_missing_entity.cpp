#include "../common/missing_entity_runtime.h"
#include "fix_skin_missing_entity.h"
#include <cstdio>
bool apply_skin_missing_entity_fix() {
    const auto status=missing_entity::apply();
    std::printf("[Missing entity fix] status=%u engine RVA=0x%08lX error=%lu\n",static_cast<unsigned>(status.result),static_cast<unsigned long>(status.rva),status.error);
    return missing_entity::success(status);
}
