#!/usr/bin/env python3
"""Build the small patch DLL and injector only. Original Neverlose requires MSVC STL."""
from pathlib import Path
import os,sys,subprocess
root=Path(__file__).resolve().parent;out=root/'ready';out.mkdir(exist_ok=True)
env=os.environ.copy()
for name,args in [('missing_entity_fix.dll',['-shared',str(root/'patch_loader/missing_entity_fix.cpp')]),('injector.exe',[str(root/'injector/main.cpp'),'-luser32'])]:
    command=[sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++20','-O2','-DNOMINMAX','-s',*args,'-o',str(out/name)]
    with (out/(name+'.build.log')).open('w') as f:subprocess.run(command,env=env,check=True,stdout=f,stderr=subprocess.STDOUT)
    print('Built',name)
