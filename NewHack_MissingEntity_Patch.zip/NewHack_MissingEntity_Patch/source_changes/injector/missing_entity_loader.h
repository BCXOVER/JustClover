#pragma once
#include <cstdint>
#include <cwchar>
namespace missing_entity_loader {
struct Handle {
    HANDLE value;
    explicit Handle(HANDLE h=nullptr):value(h){}
    ~Handle(){if(value&&value!=INVALID_HANDLE_VALUE)CloseHandle(value);}
    Handle(const Handle&)=delete;
};
int failure(const char* message){std::fprintf(stderr,"%s (Windows error %lu)\n",message,GetLastError());return 1;}
std::uintptr_t remote_load_library(HANDLE process,DWORD pid) {
    const auto fn=GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"LoadLibraryW");HMODULE owner=nullptr;
    if(!fn||!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(fn),&owner))return 0;
    wchar_t path[32768]{};if(!GetModuleFileNameW(owner,path,32768))return 0;
    const auto* slash=std::wcsrchr(path,L'\\');const auto* name=slash?slash+1:path;
    Handle snap(CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid));if(snap.value==INVALID_HANDLE_VALUE)return 0;
    MODULEENTRY32W item{};item.dwSize=sizeof(item);
    if(Module32FirstW(snap.value,&item))do {
        if(_wcsicmp(item.szModule,name))continue;
        auto* local=reinterpret_cast<const BYTE*>(owner);
        const auto* local_dos=reinterpret_cast<const IMAGE_DOS_HEADER*>(local);
        const auto* local_nt=reinterpret_cast<const IMAGE_NT_HEADERS32*>(local+local_dos->e_lfanew);
        IMAGE_DOS_HEADER dos{};IMAGE_NT_HEADERS32 nt{};SIZE_T got=0;
        if(!ReadProcessMemory(process,item.modBaseAddr,&dos,sizeof(dos),&got)||got!=sizeof(dos)||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<0||
           item.modBaseSize<sizeof(nt)||static_cast<DWORD>(dos.e_lfanew)>item.modBaseSize-sizeof(nt)||
           !ReadProcessMemory(process,item.modBaseAddr+dos.e_lfanew,&nt,sizeof(nt),&got)||got!=sizeof(nt)||nt.Signature!=IMAGE_NT_SIGNATURE||nt.FileHeader.Machine!=IMAGE_FILE_MACHINE_I386||
           nt.FileHeader.TimeDateStamp!=local_nt->FileHeader.TimeDateStamp||nt.OptionalHeader.SizeOfImage!=local_nt->OptionalHeader.SizeOfImage)return 0;
        const auto offset=reinterpret_cast<std::uintptr_t>(fn)-reinterpret_cast<std::uintptr_t>(owner);
        return offset<item.modBaseSize?reinterpret_cast<std::uintptr_t>(item.modBaseAddr)+offset:0;
    }while(Module32NextW(snap.value,&item));
    return 0;
}
bool file_exists(const wchar_t* path) {
    const auto attr=GetFileAttributesW(path);return attr!=INVALID_FILE_ATTRIBUTES&&!(attr&FILE_ATTRIBUTE_DIRECTORY);
}
bool inject(HANDLE process,std::uintptr_t load_library,const wchar_t* path) {
    const SIZE_T size=(std::wcslen(path)+1)*sizeof(wchar_t);SIZE_T written=0;
    auto* remote=VirtualAllocEx(process,nullptr,size,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    if(!remote)return false;
    if(!WriteProcessMemory(process,remote,path,size,&written)||written!=size) {const auto e=GetLastError();VirtualFreeEx(process,remote,0,MEM_RELEASE);SetLastError(e);return false;}
    Handle thread(CreateRemoteThread(process,nullptr,0,reinterpret_cast<LPTHREAD_START_ROUTINE>(load_library),remote,0,nullptr));
    if(!thread.value) {const auto e=GetLastError();VirtualFreeEx(process,remote,0,MEM_RELEASE);SetLastError(e);return false;}
    const auto state=WaitForSingleObject(thread.value,30000);
    if(state!=WAIT_OBJECT_0) {
        // The loader may still use this argument. Keep it until process exit.
        SetLastError(state==WAIT_TIMEOUT?ERROR_TIMEOUT:GetLastError());return false;
    }
    DWORD module=0;const BOOL got=GetExitCodeThread(thread.value,&module);const auto e=GetLastError();
    VirtualFreeEx(process,remote,0,MEM_RELEASE);
    if(!got){SetLastError(e);return false;}if(!module){SetLastError(ERROR_DLL_INIT_FAILED);return false;}return true;
}

inline bool install(HANDLE process,DWORD pid) {
    BOOL self=FALSE,target=FALSE;
    if(!IsWow64Process(GetCurrentProcess(),&self)||!IsWow64Process(process,&target)||self!=target)return false;
    wchar_t path[32768]{};const auto n=GetModuleFileNameW(nullptr,path,32768);
    if(!n||n>=32768)return false;
    auto* slash=std::wcsrchr(path,L'\\');if(!slash||slash-path+32>=32768)return false;
    std::wcscpy(slash+1,L"missing_entity_fix.dll");
    if(!file_exists(path)){SetLastError(ERROR_FILE_NOT_FOUND);return false;}
    const auto fn=remote_load_library(process,pid);
    if(!fn){SetLastError(ERROR_REVISION_MISMATCH);return false;}
    return inject(process,fn,path);
}
}
