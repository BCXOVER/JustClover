#!/usr/bin/env python3
"""Closed x86 load-argument and allocation lifecycle checks; WinAPI substituted."""
from pathlib import Path
import sys,subprocess,os,struct,json,hashlib
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT.parent/'build'
env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR','/workspace/skeet-motion-bt-8802/.cache/global')
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++20','-O2','-shared','-Wl,--image-base,0x30000000',str(ROOT/'tests/missing_entity_loader_probe.cpp'),'-o',str(BUILD/'missing_entity_loader_probe.dll')],env=env,check=True)
pe=pefile.PE(str(BUILD/'missing_entity_loader_probe.dll'));pb=pe.OPTIONAL_HEADER.ImageBase;entry=next(pb+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name and b'inject_probe' in s.name)
cases=0
for mode,expected in [('ok',1),('alloc_fail',0),('copy_fail',0),('partial_copy',0),('thread_fail',0),('timeout',0),('wait_fail',0),('dll_rejected',0),('exit_read_fail',0)]:
 u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(pb,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(pb,pe.get_memory_mapped_image());u.mem_map(0x100000,0x100000)
 def word(a):return struct.unpack('<I',u.mem_read(a,4))[0]
 def store(a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
 imports={}
 for lib in pe.DIRECTORY_ENTRY_IMPORT:
  for item in lib.imports:
   a=0x110000+len(imports)*16;imports[a]=item.name.decode() if item.name else str(item.ordinal);store(item.address,a)
 path='C:\\Мой чит\\missing_entity_fix.dll\0'.encode('utf-16le');u.mem_write(0x120000,path);events=[]
 def hook(u,a,size,user):
  if a==0x100000:u.emu_stop();return
  if a not in imports:return
  sp=u.reg_read(UC_X86_REG_ESP);ret=word(sp);name=imports[a];result=0;cleanup=4
  if name=='wcslen':result=len(path)//2-1
  elif name=='VirtualAllocEx':
   assert [word(sp+i) for i in [4,8,12,16,20]]==[0x900,0,len(path),0x3000,4];result=0 if mode=='alloc_fail' else 0x130000;cleanup=24
  elif name=='WriteProcessMemory':
   process,dst,src,n,out=[word(sp+i) for i in [4,8,12,16,20]];assert process==0x900 and dst==0x130000 and n==len(path);assert bytes(u.mem_read(src,n))==path
   store(out,n-2 if mode=='partial_copy' else n);result=0 if mode=='copy_fail' else 1;cleanup=24;events.append('copy')
  elif name=='CreateRemoteThread':
   assert [word(sp+i) for i in [4,8,12,16,20,24,28]]==[0x900,0,0,0x77889900,0x130000,0,0];result=0 if mode=='thread_fail' else 0x901;cleanup=32;events.append('thread')
  elif name=='WaitForSingleObject':assert word(sp+4)==0x901 and word(sp+8)==30000;result=258 if mode=='timeout' else (0xffffffff if mode=='wait_fail' else 0);cleanup=12
  elif name=='GetExitCodeThread':assert word(sp+4)==0x901;store(word(sp+8),0 if mode=='dll_rejected' else 0x50000000);result=0 if mode=='exit_read_fail' else 1;cleanup=12
  elif name=='VirtualFreeEx':assert [word(sp+i) for i in [4,8,12,16]]==[0x900,0x130000,0,0x8000];result=1;cleanup=20;events.append('free')
  elif name=='CloseHandle':assert word(sp+4)==0x901;result=1;cleanup=8;events.append('close')
  elif name=='GetLastError':result=5
  elif name=='SetLastError':cleanup=8
  else:raise AssertionError(name)
  u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
 u.hook_add(UC_HOOK_CODE,hook);store(0x1f0000,0x100000);store(0x1f0004,0x120000);u.reg_write(UC_X86_REG_ESP,0x1f0000);u.emu_start(entry,0x100001,count=50000)
 assert u.reg_read(UC_X86_REG_EIP)==0x100000 and u.reg_read(UC_X86_REG_EAX)==expected,mode
 assert events.count('free')==int(mode not in ['alloc_fail','timeout','wait_fail']),events
 assert events.count('close')==int(mode in ['ok','timeout','wait_fail','dll_rejected','exit_read_fail']),events
 cases+=1
main=(ROOT/'injector/main.cpp').read_text();assert main.index('missing_entity_loader::install(')<main.index('    RestoreNtOpenFile(process);')<main.index('    const SIZE_T path_length')
artifacts=[]
for name,is_dll in [('injector.exe',False),('missing_entity_fix.dll',True)]:
 p=ROOT/'ready'/name;exe=pefile.PE(str(p));assert exe.FILE_HEADER.Machine==0x14c and exe.OPTIONAL_HEADER.Magic==0x10b and exe.is_dll()==is_dll
 assert exe.OPTIONAL_HEADER.DllCharacteristics&0x140==0x140
 imports={x.dll.decode():[f.name.decode() if f.name else f.ordinal for f in x.imports] for x in exe.DIRECTORY_ENTRY_IMPORT}
 assert not any(n.lower().startswith(('libstdc++','libgcc','libc++')) for n in imports)
 if is_dll:assert b'missing_entity_fix_version' in [s.name for s in exe.DIRECTORY_ENTRY_EXPORT.symbols]
 artifacts.append({'name':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'machine':'x86 PE32','imports':imports})
report={'passed':True,'native_loader_lifecycle_cases':cases,'guard_load_precedes_original_neverlose_load':True,'original_ntopenfile_compatibility_path_preserved':True,'remote_loadlibrary_owner_rva_verified':True,'unicode_patch_dll_path':True,'timeout_allocation_retained':True,'artifacts':artifacts,'game_tested':False,'scope':__doc__}
(BUILD/'loader_validation.json').write_text(json.dumps(report,indent=2)+'\n');print('Loader and PE checks passed:',cases)
