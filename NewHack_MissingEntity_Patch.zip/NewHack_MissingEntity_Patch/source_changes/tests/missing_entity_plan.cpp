#include "../common/missing_entity_pattern.h"
#include <cassert>
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>
int main(int argc,char** argv) {
    using namespace missing_entity;
    if(argc!=5)return 2;
    std::ifstream in(argv[1],std::ios::binary);std::vector<unsigned char> image((std::istreambuf_iterator<char>(in)),{});
    auto base=static_cast<std::uint32_t>(std::stoul(argv[2],nullptr,0));auto begin=std::stoul(argv[3],nullptr,0),length=std::stoul(argv[4],nullptr,0);
    auto m=find(image.data(),image.size(),base,begin,length);assert(m.count==1&&!m.patched);
    const auto site=m.offset+patch_offset;assert(site%2==0&&image[site]==0xff&&image[site+1]==0x37);
    auto patched=image;patched[site]=0xeb;patched[site+1]=0x18;
    auto again=find(patched.data(),patched.size(),base,begin,length);assert(again.count==1&&again.patched);
    assert(site+2+0x18==m.offset+advance_offset);
    unsigned checks=0;
    for(unsigned i=0;i<sizeof(context);++i) {
        if((i>=9&&i<13)||(i>=15&&i<19))continue;
        auto bad=image;bad[m.offset+i]^=0x80;
        assert(!find(bad.data(),bad.size(),base,begin,length).count);++checks;
    }
    for(auto ptr:{base-1,base+static_cast<std::uint32_t>(image.size())-1,0xffffffffu}) {
        auto bad=image;std::memcpy(bad.data()+m.offset+9,&ptr,4);assert(!find(bad.data(),bad.size(),base,begin,length).count);++checks;
    }
    auto duplicate=image;const auto other=m.offset+0x200;assert(other+sizeof(context)<begin+length);
    std::memcpy(duplicate.data()+other,image.data()+m.offset,sizeof(context));assert(find(duplicate.data(),duplicate.size(),base,begin,length).count==2);++checks;
    auto wrong=image;wrong[u32(image.data()+m.offset+9)-base]='X';assert(!find(wrong.data(),wrong.size(),base,begin,length).count);++checks;
    bool flag=false;assert(!candidate(image.data(),image.size(),base,m.offset,flag,[](const void*,std::size_t){return false;}));++checks;
    assert(!find(image.data(),image.size(),base,image.size()-1,100).count);++checks;
    unsigned changed=0;for(std::size_t i=0;i<image.size();++i)if(image[i]!=patched[i])++changed;assert(changed==2);
    std::cout<<"site="<<std::hex<<site<<" checks="<<std::dec<<checks<<" two-byte patch verified\n";
}
