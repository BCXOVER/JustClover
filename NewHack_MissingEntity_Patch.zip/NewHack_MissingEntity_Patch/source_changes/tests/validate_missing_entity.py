#!/usr/bin/env python3
"""Actual engine post-data loop plus production patch in closed x86 fixtures.
No game process, uploaded executable or protected core startup is run.
"""
from pathlib import Path
import os,sys,subprocess,json,struct,itertools,hashlib
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT.parent/'build';BUILD.mkdir(exist_ok=True)
ENGINE=Path(os.environ.get('CSGO_ENGINE_DLL','/workspace/agent-preview-modules/engine.dll'));PE=pefile.PE(str(ENGINE));IMAGE=PE.get_memory_mapped_image();BASE=PE.OPTIONAL_HEADER.ImageBase;SIZE=PE.OPTIONAL_HEADER.SizeOfImage
MAPPED=BUILD/'engine-fixture.mapped.bin';MAPPED.write_bytes(IMAGE)
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/missing_entity_plan.cpp'),'-o',str(BUILD/'missing_entity_plan')],check=True)
text=next(s for s in PE.sections if s.Characteristics&0x20000000)
portable=subprocess.check_output([str(BUILD/'missing_entity_plan'),str(MAPPED),hex(BASE),hex(text.VirtualAddress),hex(text.Misc_VirtualSize)],text=True).strip();print(portable)
STOP=0x100000;MEM=0x200000;STACK=0x2f0000;CTX=MEM+0x10000;GET=STOP+0x100;UPDATE=STOP+0x200;STAGE=STOP+0x300;PROFILE=STOP+0x400;ERROR=STOP+0x500
ENTRY=BASE+0xd7020;SITE=BASE+0xd7092

def store(u,a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
def word(u,a):return struct.unpack('<I',u.mem_read(a,4))[0]
def setup_loop(ids,present,patched=True,delete_on_first=None):
    u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(BASE,SIZE);u.mem_map(STOP,0x1000);u.mem_map(MEM,0x100000)
    u.mem_write(ENTRY,IMAGE[0xd7020:0xd70f9]);u.mem_write(BASE+0x487d74,IMAGE[0x487d74:0x487d74+64])
    if patched:u.mem_write(SITE,b'\xeb\x18')
    # CClientState's current queue, original count and entity IDs are untouched.
    store(u,CTX+0x4044,len(ids))
    for i,eid in enumerate(ids):store(u,CTX+0x44+i*8,eid);store(u,CTX+0x48+i*8,i%2)
    stage=MEM+0x20000;stage_v=MEM+0x21000;store(u,BASE+0x3926f14,stage);store(u,stage,stage_v);store(u,stage_v+0x84,STAGE);store(u,stage_v+0x88,STAGE+16)
    list_=MEM+0x22000;list_v=MEM+0x23000;store(u,BASE+0x391b1cc,list_);store(u,list_,list_v);store(u,list_v,GET)
    pv=MEM+0x24000;store(u,BASE+0x59f198,pv);store(u,pv+0x18,PROFILE);store(u,pv+0x3c,PROFILE+16);store(u,BASE+0x4535d4,ERROR)
    entity_v=MEM+0x25000;store(u,entity_v+0x1c,UPDATE)
    alive=set(present);events=[];updates=[];fatal=[]
    for eid in set(ids):store(u,MEM+0x30000+eid*16,entity_v)
    def hook(u,a,size,user):
        if a==STOP:u.emu_stop();return
        if a not in [GET,UPDATE,STAGE,STAGE+16,PROFILE,PROFILE+16,ERROR]:return
        sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);cleanup=4;result=0
        if a==GET:
            eid=word(u,sp+4);result=MEM+0x30000+eid*16 if eid in alive else 0;cleanup=8
        elif a==UPDATE:
            entity=u.reg_read(UC_X86_REG_ECX);eid=(entity-(MEM+0x30000))//16;assert eid in alive
            updates.append((eid,word(u,sp+4)));cleanup=8
            if len(updates)==1 and delete_on_first is not None:alive.discard(delete_on_first)
        elif a in [STAGE,STAGE+16]:events.append('begin' if a==STAGE else 'end')
        elif a==PROFILE:result=7;cleanup=8
        elif a==PROFILE+16:result=1;cleanup=16
        elif a==ERROR:fatal.append(word(u,sp+8));u.emu_stop();return
        u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,hook)
    store(u,STACK,STOP);u.reg_write(UC_X86_REG_ESP,STACK);u.reg_write(UC_X86_REG_ECX,CTX)
    u.reg_write(UC_X86_REG_EBX,0x123456);u.reg_write(UC_X86_REG_ESI,0x234567);u.reg_write(UC_X86_REG_EDI,0x345678);u.reg_write(UC_X86_REG_EBP,0x456789)
    u.emu_start(ENTRY,STOP+1,count=100000)
    return u,updates,events,fatal
# Reproduce the user's exact missing-ent-3 fatal path on the unpatched code.
u,updates,events,fatal=setup_loop([1,3,4],{1,4},False);assert fatal==[3] and updates==[(1,0)]
cases=0
for length in range(7):
    ids=list(range(1,length+1))
    for bits in itertools.product([False,True],repeat=length):
        present={eid for eid,on in zip(ids,bits) if on}
        u,updates,events,fatal=setup_loop(ids,present)
        assert not fatal and updates==[(eid,i%2) for i,eid in enumerate(ids) if eid in present]
        assert events==['begin','end'] and u.reg_read(UC_X86_REG_EIP)==STOP
        assert word(u,CTX+0x4044)==length
        assert u.reg_read(UC_X86_REG_ESP)==STACK+4
        for reg,expected in [(UC_X86_REG_EBX,0x123456),(UC_X86_REG_ESI,0x234567),(UC_X86_REG_EDI,0x345678),(UC_X86_REG_EBP,0x456789)]:assert u.reg_read(reg)==expected
        cases+=1
u,updates,events,fatal=setup_loop([1,3,4],{1,3,4},True,3);assert not fatal and updates==[(1,0),(4,0)] and events==['begin','end'];cases+=1
# Production runtime scanner and atomic exchange, with controlled WinAPI calls.
env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR','/workspace/skeet-motion-bt-8802/.cache/global')
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++20','-O2','-shared','-Wl,--image-base,0x30000000',str(ROOT/'tests/missing_entity_runtime_probe.cpp'),'-o',str(BUILD/'missing_entity_runtime_probe.dll')],env=env,check=True)
probe=pefile.PE(str(BUILD/'missing_entity_runtime_probe.dll'));PB=probe.OPTIONAL_HEADER.ImageBase;function=next(PB+s.address for s in probe.DIRECTORY_ENTRY_EXPORT.symbols if s.name and b'apply_probe' in s.name)
runtime_cases=0
for relocate in [0,0x10000000]:
 for mode,expected in [('normal',1),('already',2),('no_engine',3),('wrong_magic',4),('no_match',5),('duplicate',6),('unaligned',7),('protect_fail',8),('changed',9),('flush_fail',10),('restore_fail',11),('inaccessible_string',5)]:
    eb=BASE+relocate;u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(eb,SIZE);u.mem_map(PB,probe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(PB,probe.get_memory_mapped_image());u.mem_map(STOP,0x4000);u.mem_map(MEM,0x100000)
    # Real NT headers with one bounded executable range containing the real loop.
    header=bytearray(IMAGE[:4096]);nt=struct.unpack_from('<I',header,0x3c)[0];struct.pack_into('<H',header,nt+6,1)
    sec=nt+24+224;struct.pack_into('<II',header,sec+8,0x500,0xd7020);struct.pack_into('<I',header,sec+36,0x60000020)
    u.mem_write(eb,bytes(header));u.mem_write(eb+0xd7020,IMAGE[0xd7020:0xd70f9]);u.mem_write(eb+0x487d74,IMAGE[0x487d74:0x487d74+64])
    # Relocate every absolute operand in this bounded function using real .reloc entries.
    for block in PE.DIRECTORY_ENTRY_BASERELOC:
        for item in block.entries:
            if item.type==3 and 0xd7020<=item.rva<0xd70f9:store(u,eb+item.rva,word(u,eb+item.rva)+relocate)
    site=eb+0xd7092
    if mode=='already':u.mem_write(site,b'\xeb\x18')
    if mode=='wrong_magic':u.mem_write(eb,b'XX')
    if mode=='no_match':u.mem_write(eb+0xd708c,b'\x90')
    if mode=='duplicate':u.mem_write(eb+0xd720c,bytes(u.mem_read(eb+0xd708c,47)))
    if mode=='unaligned':
        blob=bytes(u.mem_read(eb+0xd708c,47));u.mem_write(eb+0xd708c,b'\x90'*48);u.mem_write(eb+0xd708d,blob)
    before=bytes(u.mem_read(eb+0xd7020,0x500));imports={};calls=[]
    for lib in probe.DIRECTORY_ENTRY_IMPORT:
        for item in lib.imports:
            target=STOP+0x1000+len(imports)*16;imports[target]=item.name.decode() if item.name else str(item.ordinal);store(u,item.address,target)
    def hook(u,a,size,user):
        if a==STOP:u.emu_stop();return
        if a not in imports:return
        sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);name=imports[a];cleanup=4;result=0
        if name=='GetModuleHandleW':result=0 if mode=='no_engine' else eb;cleanup=8
        elif name=='VirtualQuery':
            address,out,n=[word(u,sp+i) for i in [4,8,12]];assert n==28
            protection=1 if mode=='inaccessible_string' and address==eb+0x487d74 else 0x20
            u.mem_write(out,struct.pack('<IIIIIII',eb,eb,0x20,SIZE,0x1000,protection,0x1000000));result=28;cleanup=16
        elif name=='VirtualProtect':
            address,n,protection,out=[word(u,sp+i) for i in [4,8,12,16]];assert address==site and n==2
            calls.append(('protect',protection));store(u,out,0x20);result=0 if (mode=='protect_fail' or (mode=='restore_fail' and protection==0x20)) else 1;cleanup=20
            if mode=='changed' and protection==0x40:u.mem_write(site,b'\x90\x90')
        elif name=='FlushInstructionCache':calls.append(('flush',));result=int(mode!='flush_fail');cleanup=16
        elif name=='GetCurrentProcess':result=0xffffffff
        elif name=='GetLastError':result=5
        elif name=='memcmp':
            x,y,n=[word(u,sp+i) for i in [4,8,12]];result=int(u.mem_read(x,n)!=u.mem_read(y,n))
        elif name in ['memcpy','memmove']:
            dst,src,n=[word(u,sp+i) for i in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)));result=dst
        else:raise AssertionError(('unexpected import',name))
        u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,hook);store(u,STACK,STOP);u.reg_write(UC_X86_REG_ESP,STACK);u.emu_start(function,STOP+1,count=300000)
    assert u.reg_read(UC_X86_REG_EIP)==STOP and u.reg_read(UC_X86_REG_EAX)==expected,(hex(eb),mode,u.reg_read(UC_X86_REG_EAX))
    if mode=='normal':
        after=bytes(u.mem_read(eb+0xd7020,0x500));assert sum(x!=y for x,y in zip(before,after))==2 and u.mem_read(site,2)==b'\xeb\x18';assert calls==[('protect',0x40),('flush',),('protect',0x20)]
    elif mode not in ['restore_fail','changed']:assert bytes(u.mem_read(eb+0xd7020,0x500))==before,mode
    runtime_cases+=1
report={'passed':True,'engine_sha256':hashlib.sha256(ENGINE.read_bytes()).hexdigest(),'engine_image_size':SIZE,'original_missing_ent_3_reproduced':True,'native_queue_cases':cases,'runtime_scanner_and_atomic_patch_cases':runtime_cases,'portable_pattern_checks':portable,'patch_bytes':2,'original_bytes':'ff37','replacement_bytes':'eb18','engine_rva':'0xd7092','valid_entity_postdataupdates_preserved':True,'missing_entries_skip_to_native_loop_advance':True,'stage_begin_end_and_profiling_cleanup_preserved':True,'no_null_vtable_call':True,'game_tested':False,'protected_neverlose_startup_tested':False,'scope':__doc__}
(BUILD/'missing_entity_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
