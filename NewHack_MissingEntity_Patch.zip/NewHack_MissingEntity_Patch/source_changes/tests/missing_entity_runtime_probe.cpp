#include "../common/missing_entity_runtime.h"
extern "C" __declspec(dllexport) unsigned apply_probe() {return static_cast<unsigned>(missing_entity::apply().result);}
