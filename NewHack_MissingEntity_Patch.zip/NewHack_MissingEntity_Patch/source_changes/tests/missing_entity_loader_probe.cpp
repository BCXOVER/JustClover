#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>
#include <cstring>
#include "../injector/missing_entity_loader.h"
extern "C" __declspec(dllexport) unsigned inject_probe(const wchar_t* path) {
    return missing_entity_loader::inject(reinterpret_cast<HANDLE>(0x900),0x77889900,path);
}
