#include "../common/missing_entity_runtime.h"
extern "C" {
__declspec(dllexport) unsigned missing_entity_fix_version=1;
__declspec(dllexport) unsigned missing_entity_fix_result=0;
__declspec(dllexport) unsigned missing_entity_fix_error=0;
__declspec(dllexport) unsigned missing_entity_fix_rva=0;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID) {
    if(reason!=DLL_PROCESS_ATTACH)return TRUE;
    DisableThreadLibraryCalls(module);
    const auto status=missing_entity::apply();
    missing_entity_fix_result=static_cast<unsigned>(status.result);
    missing_entity_fix_error=status.error;missing_entity_fix_rva=status.rva;
    return missing_entity::success(status)?TRUE:FALSE;
}
