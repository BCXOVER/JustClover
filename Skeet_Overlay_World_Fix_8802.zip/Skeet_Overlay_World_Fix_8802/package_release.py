#!/usr/bin/env python3
"""Package already-built and validated Windows artifacts without running them."""
from pathlib import Path
import shutil,json,hashlib,difflib,zipfile
ROOT=Path(__file__).resolve().parent
NAME='Skeet_Overlay_World_Fix_8802';DEST=ROOT/'release'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    built=ROOT/'build/skeet.dll'
    inputs=[*(ROOT/'source').rglob('*'),ROOT/'tools/build_ui_addon.py']
    assert all(not p.is_file() or p.stat().st_mtime<=built.stat().st_mtime for p in inputs),'DLL is older than a source input'
    checked=json.loads((ROOT/'build/release_validation.json').read_text())
    assert checked['passed'] and checked['artifacts'][0]['sha256']==sha(built.read_bytes()),'DLL differs from validated release'
    if DEST.exists():shutil.rmtree(DEST)
    DEST.mkdir()
    for folder in ['source','tests','tools','data','reverse']:
        shutil.copytree(ROOT/folder,DEST/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for name in ['README_RU.md','OVERLAY_WORLD_FIX_RU.md','CS2_INTERFACE_RU.md','requirements-tests.txt','OVERRIDE_PREVIEW_FIX_RU.md','MENU_ESP_PREVIEW_RU.md','CROUCH_MULTIPOINT_RU.md','ROLLBACK_RU.md','BODY_PREFERENCE_RU.md','Helper_icon_preview.png','requirements-build.txt','build_windows.py','package_release.py','Skinchanger_layout_preview.png','Visuals_icons_preview.png','Inventory_Integration_Status_RU.md','PREDICTION_IDEAS_RU.md','MENU_PROPOSAL_RU.md']:
        shutil.copy2(ROOT/name,DEST/name)
    (DEST/'bin').mkdir();(DEST/'reports').mkdir()
    for name in ['skeet.dll','injector.exe']:shutil.copy2(ROOT/'build'/name,DEST/'bin'/name)
    for name in ['night_mode_validation.json','lua_ui_validation.json','addon_bootstrap_validation.json','sticker_world_abi_audit.json','hitchance_override_validation.json','override_preview_validation.json','menu_interaction_validation.json','menu_baseline_validation.json','agent_preview_validation.json','agent_preview_abi_audit.json','visuals_validation.json','release_validation.json','resolver_validation.json','rarity_validation.json','scan_patch_validation.json','precision_validation.json','motion_validation.json','client_module_audit.json','body_preference_validation.json','inventory_validation.json','inventory_ui_validation.json','skin_mirror_validation.json','skin_mirror_selection_validation.json','skin_native_validation.json','rollback_validation.json','launcher_validation.json','crouch_multipoint_validation.json']:
        report=json.loads((ROOT/'build'/name).read_text());assert report['passed'],name
        shutil.copy2(ROOT/'build'/name,DEST/'reports'/name)
    shutil.copy2(ROOT/'build/inherited_report_provenance.json',DEST/'reports/inherited_report_provenance.json')
    for name in ['dll.log','injector.log','resources.log']:shutil.copy2(ROOT/'build'/name,DEST/'reports'/name)
    old_root=ROOT.parent/'skeet-cs2-interface-8802';diff=[]
    old={str(p.relative_to(old_root)):p for p in (old_root/'source').rglob('*') if p.is_file()}
    new={str(p.relative_to(ROOT)):p for p in (ROOT/'source').rglob('*') if p.is_file()}
    for path in sorted(old.keys()|new.keys()) if (old_root/'source').exists() else []:
        a=old[path].read_bytes() if path in old else b'';b=new[path].read_bytes() if path in new else b''
        if a==b:continue
        diff.extend(difflib.unified_diff(a.decode('utf-8').splitlines(True),b.decode('utf-8').splitlines(True),fromfile='before/'+path,tofile='after/'+path))
    if not (old_root/'source').exists():
        saved=ROOT/'Overlay_World_Fix.diff'
        diff=[saved.read_text() if saved.exists() else 'Comparison baseline is not bundled; current sources are in source/.\n']
    (DEST/'Overlay_World_Fix.diff').write_text(''.join(diff))
    entries={str(p.relative_to(DEST)):sha(p.read_bytes()) for p in sorted(DEST.rglob('*')) if p.is_file()}
    (DEST/'SHA256SUMS.txt').write_text(''.join(f'{digest}  {name}\n' for name,digest in entries.items()))
    archive=ROOT.parent/(NAME+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file():z.write(p,NAME+'/'+str(p.relative_to(DEST)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name,digest in entries.items():assert sha(z.read(NAME+'/'+name))==digest,name
    ui=json.loads((ROOT/'build/visuals_validation.json').read_text())
    report={'passed':True,'lua_loader_module_stem_fixed':True,'rage_popup_final_overlay_pass':True,'esp_element_rows_in_preview_only':10,'preview_rgba_uses_original_models':True,'night_mode_world_props_and_intensity':True,'max_night_material_operations_per_frame':64,'legacy_sticker_slots':4,'legacy_sticker_kits':6711,'stickers_in_owned_local_inventory':True,'world_panels':['Entity ESP','Grenade ESP','World effects'],'override_sky_fog_lighting':True,'cpu_usage_frequency_ram_watermark':True,'uploaded_lua_logs_integrated':True,'internal_lua_autoload_and_recovery':True,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
        'dll_sha256':sha((DEST/'bin/skeet.dll').read_bytes()),'manifest_files':len(entries),'zip_crc_verified':True,
        'helper_icon':'round grenade','extra_sync_checkboxes':0,'weapon_skin_native_callback_connected':True,'local_inventory_editor_required_for_sync':False,'skinchanger_native_state_mirror':True,'all_saved_presets_auto_enumerated':True,'native_profile_count':65,'native_config_hook_instruction_bytes':8,'native_presentation_hook_instruction_bytes':15,'config_completion_observer':True,'max_inventory_changes_per_frame':4,'agent_inventory_added':True,'knife_model_independent_of_paint_origin':True,'filter_affects_inventory_snapshot':False,'local_loadout_equip_added':True,'stattrak_mirror_added':True,'stattrak_initial_counter':0,'appearance_preview_added':True,'appearance_preview_removed':False,'preview_panel_reserved':'always docked inside Enemy Visuals','preview_always_open_in_visuals':'Enemy category','preview_model_and_controls_together':True,'native_preset_controls_added':False,'native_preset_controls_removed':True,'preview_draw_pass':'live native Category child draw','preview_uses_game_models':True,'custom_game_shaders_added':False,
        'appearance_presets':[],'lethal_torso_preference_integrated':True,'native_backup_hitchance_retry_preserved':True,'body_preference_scope':'native Rage scan worker evaluated point pool; eligible lethal torso over leg only',
        'native_size_roundtrip_checked':True,'native_renderer_depth_xmm0_abi_fixed':True,'native_child_vtable_slots':13,'native_resize_dpi_cases':ui['native_resize_dpi_cases'],
        'rarity_catalog_paint_kits':1147,'rarity_weapon_variants':1713,'rarity_unknown_policy':'neutral grey',
        'local_inventory_preview_added':False,'local_inventory_page_removed':True,'name_input_polled_without_callback':True,'name_only_update_preserves_id':True,'local_owned_weapon_name_bridge':True,'agent_schema_identity_resolution':True,'agent_create_separate_from_team_equip':True,'neverlose_dt_features_added':False,'custom_dt_accuracy_added':False,'custom_dt_features_removed':True,'rage_extrapolate_checkbox':None,'custom_extrapolation_enabled':False,'hitscan_modes':[],'default_hitscan':'existing Skeet record selection','animation_layers_repair':[],'record_retry_integrated':False,'shot_record_preference_integrated':False,'hitscan_regression_rollback':True,'closed_neverlose_core_transferred':False,'crouch_multipoint_checkbox':'Crouch multipoint','crouch_multipoint_integrated':True,'crouch_head_scale':.88,'crouch_torso_scale':.82,'crouch_historical_duck':True,'crouch_game_tested':False,'rage_prediction_worker_integrated':False,'injector_auto_launch_legacy':True,'agent_index_rows_per_frame':64,'agent_index_soft_budget_us':750,'inline_name_tag':True,'inline_rgb_pickers':4,'manual_add_equip_apply_buttons':0,'local_inventory_add_delete_name_tag':True,'local_inventory_persistent':False,'local_inventory_steam_items':False,'inventory_palette_scope':'shared locally per paint kit','helper_category_added':True,'helper_detection':'exact live Helper checkbox',
        'skinchanger_restyled':True,'skin_menu_cases':ui['skin_menu_cases'],'skin_geometry_cases':54,
        'lua_lifecycle_cases':ui['lua_lifecycle_cases'],'derived_native_model_row_renderers_preserved':True,
        'combined_owned_gameplay_instruction_bytes':120,'body_preference_game_tested':False,'custom_gameplay_patches_removed':False,'hit_chance_samples':128,'spatial_multipoints_increased':False,'custom_prediction_patch':False,
        'custom_interpolation_patch':True,'custom_backtrack_patch':False,'native_backtrack_lower_window_preserved':True,
        'minimum_forecast_samples':3,'forecast_horizon_ticks':0,'long_forecast_minimum_samples':4,'desync_60_added':False,
        'skin_peer_sync_added':False,'native_gc_equip_intercepted':False,'protected_skin_engine_replaced':False,'rage_gear_groups':7,'minimum_damage_override_popup':True,'per_weapon_hitchance_override':True,'hitchance_override_default_enabled':False,'preview_cloned_renderer_supported':True,'tab_fade_ms':150,'flags_drag_layout_in_game':True,'flag_owner_ambiguity_policy':'original position retained','esp_model':'CT SAS','ct_target_size':[256,512],'ct_max_fps':30,'gameplay_baseline_commit':'b14d60b73413773add822a5bc8974763f3383b33','gameplay_change':None,'game_tested':False,'visual_match_verified_in_game':False}
    (ROOT/'build/package_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    archive.with_suffix('.sha256').write_text(report['sha256']+'  '+archive.name+'\n')
    archive.with_suffix('.validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
