local ffi = require('ffi')
pcall(ffi.cdef,[[
 typedef struct { unsigned int size,valid; float cpu_percent,cpu_ghz,ram_used_gib,ram_total_gib,process_mib; } CloverTelemetry8802;
 typedef struct { int id; float wear,scale,rotation; } CloverSticker8802;
 void clover_ui_heartbeat(void);
 void clover_ui_module(unsigned int);
 void clover_night(int,unsigned int,unsigned int,unsigned int);
 void clover_night_reset(void);
 int clover_telemetry(void*,unsigned int);
 int clover_selected_weapon(void);
 int clover_sticker_set(int,unsigned int,int,float,float,float);
 int clover_sticker_get(int,unsigned int,void*);
 int clover_sky(const char*);
 int clover_sky_tint(const char*,unsigned int);
]])
local native = ffi.load('skeet.dll')
client.set_event_callback('paint_ui',function() native.clover_ui_heartbeat() end)
local hw = ffi.new('CloverTelemetry8802[1]')
local hw_time = -10
local function hardware()
 local now=globals.realtime()
 if now-hw_time>=1 then hw_time=now;native.clover_telemetry(hw,ffi.sizeof(hw[0])) end
 return hw[0]
end
