#pragma once
#include <array>
#include <cstdint>
#include <cmath>
#include <algorithm>
namespace night_mode {
enum class Group {Other,World,Props};
struct Settings {bool enabled=false;unsigned amount=70,world=0xff735a50,props=0xff917d73;bool operator==(const Settings& b)const{return enabled==b.enabled&&amount==b.amount&&world==b.world&&props==b.props;}};
struct Api {unsigned short(*first)();unsigned short(*next)(unsigned short);void*(*get)(unsigned short);bool(*describe)(void*,Group&,float*);void(*retain)(void*);void(*release)(void*);bool(*read)(void*,float*);void(*write)(void*,const float*);};
struct Entry {void* object=nullptr;Group group=Group::Other;float original[3]{},applied[3]{};};
struct State {
 Settings settings{};std::array<Entry,8192> entries{};std::array<unsigned,16384> index{};unsigned used=0,apply=0,last_scan=0;unsigned short cursor=0xffff;bool dirty=false,resetting=false,scanning=false;
 void configure(Settings s){s.amount=std::min(s.amount,100u);if(settings==s)return;settings=s;dirty=true;apply=0;scanning=false;}
 void reset(){resetting=true;scanning=false;apply=0;}
 bool work()const{return settings.enabled||used;}
 unsigned bucket(void* p)const {auto n=reinterpret_cast<std::uintptr_t>(p);return unsigned((n>>4)^(n>>17))&16383;}
 int lookup(void* p)const{unsigned at=bucket(p);for(unsigned n=0;n<index.size();n++,at=(at+1)&16383){if(!index[at])return -1;if(entries[index[at]-1].object==p)return int(index[at]-1);}return -1;}
 void remember(unsigned slot){auto at=bucket(entries[slot].object);while(index[at])at=(at+1)&16383;index[at]=slot+1;}
 static bool equal(const float* a,const float* b){for(int i=0;i<3;i++)if(std::fabs(a[i]-b[i])>.0001f)return false;return true;}
 void paint(const Api& api,Entry& e){const unsigned tint=e.group==Group::World?settings.world:settings.props;const float amount=float(settings.amount)/100;
  for(unsigned i=0;i<3;i++)e.applied[i]=e.original[i]*(1-amount)+float((tint>>(i*8))&255)/255*amount;
  api.write(e.object,e.applied);
 }
 unsigned tick(const Api& api,unsigned now,unsigned budget=64){unsigned operations=0;
  if(resetting||!settings.enabled){while(used&&operations<budget){auto& e=entries[--used];float live[3]{};if(api.read(e.object,live)&&equal(live,e.applied))api.write(e.object,e.original);api.release(e.object);e={};operations++;}
   if(!used){index.fill(0);resetting=false;dirty=true;apply=0;}return operations;}
  while(dirty&&apply<used&&operations<budget){paint(api,entries[apply++]);operations++;}
  if(dirty&&apply==used){dirty=false;scanning=true;cursor=api.first();last_scan=now;}
  if(!scanning&&now-last_scan>=1000){scanning=true;cursor=api.first();last_scan=now;}
  while(scanning&&cursor!=0xffff&&operations<budget){const auto at=cursor;cursor=api.next(at);if(cursor==at)cursor=0xffff;operations++;
   auto* object=api.get(at);if(!object||lookup(object)>=0||used==entries.size())continue;
   Group group=Group::Other;float color[3]{};if(!api.describe(object,group,color)||group==Group::Other)continue;
   auto& e=entries[used];e.object=object;e.group=group;std::copy(color,color+3,e.original);api.retain(object);remember(used++);paint(api,e);
  }
  if(cursor==0xffff)scanning=false;return operations;
 }
};
}
