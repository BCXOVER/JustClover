#include "../source/skeet/pch.h"
#include "../source/skeet/SkeetSDK/skeetsdk.h"
#include "../source/skeet/cs2_visuals_impl.h"
extern "C" {
__declspec(dllexport) void crouch_ui_frame_probe(SkeetSDK::CMenu* menu){cs2_visuals::crouch_ui::frame(menu);}
__declspec(dllexport) int crouch_ui_value_probe(){return crouch_multipoint::enabled.load(std::memory_order_relaxed);}

__declspec(dllexport) void prediction_ui_setup_probe(const native_ui_proxy::Api* api) {
    cs2_visuals::native=*api;SkeetSDK::Memory::Allocator=api->allocate;SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(api->destroy);
}
__declspec(dllexport) int prediction_ui_value_probe(){return motion_settings::extrapolation;}

__declspec(dllexport) void skin_config_setup_probe(unsigned trampoline){cs2_visuals::original_config=reinterpret_cast<cs2_visuals::NativeConfigLoaded>(trampoline);}
__declspec(dllexport) void __fastcall skin_config_callback_probe(void* tab,void*){cs2_visuals::config_loaded(tab,nullptr);}

__declspec(dllexport) void skin_mirror_connect_probe(){cs2_visuals::skin_mirror_ui::frame(cs2_visuals::context->Menu);}
__declspec(dllexport) int skin_mirror_pending_probe(int weapon){
 for(const auto& p:cs2_visuals::skin_mirror_ui::mirror.presets)if(p.weapon==weapon&&p.pending)return p.desired.paint;
 return -1;
}
__declspec(dllexport) unsigned skin_mirror_preset_count_probe(){
 unsigned n=0;for(const auto& p:cs2_visuals::skin_mirror_ui::mirror.presets)if(p.weapon)n++;return n;
}
__declspec(dllexport) int skin_mirror_selection_probe(void* spec,int* enabled){bool on=false;const bool valid=cs2_visuals::skin_mirror_ui::selection(*static_cast<local_inventory::Spec*>(spec),on);*enabled=on;return valid;}
__declspec(dllexport) void render_setup_probe(unsigned trampoline) {
    cs2_visuals::attached=false;cs2_visuals::rebuild_pending=false;cs2_visuals::captured_topology=0;
    cs2_visuals::context=nullptr;cs2_visuals::original_draw=reinterpret_cast<cs2_visuals::NativeDraw>(trampoline);
}
__declspec(dllexport) void __fastcall render_callback_probe(SkeetSDK::CMenu* menu,void*,void* argument) {
    cs2_visuals::frame(menu,nullptr,argument);
}
__declspec(dllexport) void binding_setup_probe(void* ctx,void* proxy,void* source,void* child,unsigned layout_callback) {
    using namespace cs2_visuals;
    context=static_cast<SkeetSDK::SkeetClass_*>(ctx);attached=true;attempted=true;refreshing=false;rebuild_pending=false;captured_topology=0;active=Enemy;
    original_count=0;binding_count=1;
    for(auto& g:groups)g=Group{};
    groups[0].child=static_cast<SkeetSDK::Child*>(child);groups[0].panel=EnemyESP;groups[0].items=1;
    groups[0].layout=reinterpret_cast<NativeLayout>(layout_callback);
    bindings[0]={};bindings[0].proxy=static_cast<SkeetSDK::PElement>(proxy);
    bindings[0].source=static_cast<SkeetSDK::PElement>(source);bindings[0].group=&groups[0];
    model(bindings[0],bindings[0].observed);
}
__declspec(dllexport) void binding_change_probe(){cs2_visuals::changed(&cs2_visuals::bindings[0],nullptr);}
__declspec(dllexport) void binding_sync_probe(){cs2_visuals::sync();}
__declspec(dllexport) int topology_capture_probe(void* original_child) {
    using namespace cs2_visuals;
    original_count=1;originals[0]=static_cast<SkeetSDK::Child*>(original_child);original_visible[0]=true;
    *reinterpret_cast<void***>(groups[0].child)=groups[0].table;
    captured_topology=topology();return captured_topology!=0;
}
__declspec(dllexport) void category_setup_probe(void* ctx,void** children,void** controls,unsigned layout_callback) {
    using namespace cs2_visuals;
    context=static_cast<SkeetSDK::SkeetClass_*>(ctx);attached=true;refreshing=false;active=Enemy;
    original_count=binding_count=0;helper_available=true;
    for(int i=0;i<=panel_count;i++){
        groups[i]=Group{};groups[i].child=static_cast<SkeetSDK::Child*>(children[i]);groups[i].panel=i==panel_count?-1:i;
        groups[i].items=1;groups[i].layout=reinterpret_cast<NativeLayout>(layout_callback);
    }
    for(int i=0;i<category_count;i++)buttons[i]=static_cast<SkeetSDK::Button*>(controls[i]);
    child_layout(groups[panel_count].child,nullptr);sync();
}
__declspec(dllexport) void lifecycle_setup_probe(const native_ui_proxy::Api* api,unsigned deallocator,unsigned draw,unsigned button) {
    using namespace cs2_visuals;
    native=*api;native.destroy=&destroy;native.copy=&copy;native.link=&link;
    SkeetSDK::Memory::Allocator=native.allocate;
    SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(deallocator);
    original_draw=reinterpret_cast<NativeDraw>(draw);add_button=reinterpret_cast<AddButton>(button);hide=nullptr;
    attempted=true;attached=false;rebuild_pending=false;captured_topology=0;
    original_count=binding_count=0;helper_available=true;
    for(auto& g:groups)*reinterpret_cast<void***>(g.child)=g.table;
}
__declspec(dllexport) int lifecycle_rebuild_probe(){return cs2_visuals::rebuild(cs2_visuals::context->Menu);}
__declspec(dllexport) int lifecycle_status_probe(){return (cs2_visuals::attached?1:0)|(cs2_visuals::rebuild_pending?2:0)|(cs2_visuals::active<<8);}
__declspec(dllexport) void lifecycle_callback_probe(unsigned index){cs2_visuals::changed(&cs2_visuals::bindings[index],nullptr);}
__declspec(dllexport) void choose_category_probe(int category) {
    cs2_visuals::choose(reinterpret_cast<void*>(std::uintptr_t(category)),nullptr);
}
__declspec(dllexport) void child_draw_setup_probe(unsigned callback) {
    cs2_visuals::groups[0].draw=reinterpret_cast<cs2_visuals::NativeChildDraw>(callback);
}
__declspec(dllexport) void __fastcall child_draw_probe(SkeetSDK::Child* child,void*,SkeetSDK::IRenderer* renderer,const SkeetSDK::Vec2* origin) {
    cs2_visuals::child_draw(child,nullptr,renderer,origin);
}
__declspec(dllexport) void skins_setup_probe(void* ctx,const native_ui_proxy::Api* api,unsigned deallocator,
        void** children,unsigned layout,unsigned draw,unsigned list,unsigned text) {
    using namespace cs2_visuals;
    context=static_cast<SkeetSDK::SkeetClass_*>(ctx);native=*api;
    native.destroy=&destroy;native.copy=&copy;
    SkeetSDK::Memory::Allocator=native.allocate;
    SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(deallocator);hide=nullptr;
    skin::list_ctor=reinterpret_cast<skin::ListCtor>(list);skin::text_ctor=reinterpret_cast<skin::TextCtor>(text);
    skin::initialized=true;skin::attached=false;skin::pending_refresh=true;skin::refreshing=false;
    skin::captured=skin::failed=0;skin::view_count=skin::source_count=0;
    for(int i=0;i<3;i++) {
        auto& p=skin::panes[i];p={};p.index=i;p.child=static_cast<SkeetSDK::Child*>(children[i]);
        p.layout=reinterpret_cast<NativeLayout>(layout);p.draw=reinterpret_cast<NativeChildDraw>(draw);
        *reinterpret_cast<void***>(p.child)=p.table;
    }
}
__declspec(dllexport) int skins_rebuild_probe(){return cs2_visuals::skin::rebuild(cs2_visuals::context->Menu);}
__declspec(dllexport) void skins_update_probe(){cs2_visuals::skin::update(cs2_visuals::context->Menu);}
__declspec(dllexport) void skins_change_probe(unsigned index){cs2_visuals::skin::changed(&cs2_visuals::skin::views[index],nullptr);}
__declspec(dllexport) int skins_status_probe(){return cs2_visuals::skin::attached?int(cs2_visuals::skin::view_count):-1;}
__declspec(dllexport) void __fastcall skins_row_probe(void* self,void*,SkeetSDK::IRenderer* renderer,const SkeetSDK::Vec2* pos,
        int height,unsigned index,unsigned color,unsigned flags) {
    cs2_visuals::skin::agent_row(self,nullptr,renderer,pos,height,index,color,flags);
}
__declspec(dllexport) void __fastcall skins_list_draw_probe(void* self,void*,SkeetSDK::IRenderer* renderer,const SkeetSDK::Vec2* origin) {
    cs2_visuals::skin::list_draw(self,nullptr,renderer,origin);
}
__declspec(dllexport) void* resize_create_probe(void* ctx,void* tab,unsigned allocator,unsigned constructor,unsigned append,unsigned kind) {
    using namespace cs2_visuals;
    context=static_cast<SkeetSDK::SkeetClass_*>(ctx);native.allocate=reinterpret_cast<native_ui_proxy::Allocate>(allocator);
    child_ctor=reinterpret_cast<ChildCtor>(constructor);append_child=reinterpret_cast<AppendChild>(append);
    if(kind==0) {
        groups[0]={};if(!create_group(context->Menu,static_cast<SkeetSDK::CTab*>(tab),groups[0],EnemyESP))return nullptr;
        return groups[0].child;
    }
    for(auto& p:skin::panes)p={};
    if(!skin::create_panes(context->Menu))return nullptr;
    return skin::panes[0].child;
}
__declspec(dllexport) int variants_copy_probe(void* dst,void* src,int type,unsigned allocator,unsigned deallocator) {
    SkeetSDK::Memory::Allocator=reinterpret_cast<SkeetSDK::AllocatorFn>(allocator);
    SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(deallocator);
    return cs2_visuals::copy(dst,src,type);
}
__declspec(dllexport) unsigned renderer_depth_probe(void* renderer) {
    const float depth=static_cast<SkeetSDK::IRenderer*>(renderer)->GetZBuff();unsigned bits;std::memcpy(&bits,&depth,4);return bits;
}
__declspec(dllexport) unsigned renderer_set_depth_probe(void* renderer,unsigned bits) {
    float depth;std::memcpy(&depth,&bits,4);static_cast<SkeetSDK::IRenderer*>(renderer)->SetZBuff(depth);
    return renderer_depth_probe(renderer);
}
__declspec(dllexport) void inventory_ui_setup_probe(void* ctx,const native_ui_proxy::Api* api,void** old_panels,unsigned constructor,unsigned append,unsigned button,unsigned text,unsigned layout_callback) {
 using namespace cs2_visuals;context=static_cast<SkeetSDK::SkeetClass_*>(ctx);native=*api;
 SkeetSDK::Memory::Allocator=native.allocate;SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(native.destroy);
 child_ctor=reinterpret_cast<ChildCtor>(constructor);append_child=reinterpret_cast<AppendChild>(append);add_button=reinterpret_cast<AddButton>(button);
 skin::text_ctor=reinterpret_cast<skin::TextCtor>(text);skin::attached=true;skin::view_count=skin::source_count=0;
 for(int i=0;i<3;i++){auto& p=skin::panes[i];p={};p.child=static_cast<SkeetSDK::Child*>(old_panels[i]);p.index=i;p.layout=reinterpret_cast<NativeLayout>(layout_callback);*reinterpret_cast<void***>(p.child)=p.table;}
}
__declspec(dllexport) void inventory_ui_frame_probe(){cs2_visuals::inventory_ui::frame(cs2_visuals::context->Menu);}
__declspec(dllexport) void* inventory_inline_control_probe(unsigned n){return n<7?cs2_visuals::inventory_ui::controls[n]:nullptr;}
__declspec(dllexport) int inventory_inline_select_probe(void* spec){auto& s=*static_cast<local_inventory::Spec*>(spec);cs2_visuals::inventory_ui::select(s);return 1;}
__declspec(dllexport) void inventory_inline_native_tag_probe(void* source,void* proxy){
 using namespace cs2_visuals;skin::view_count=1;auto& v=skin::views[0];v={};v.source=static_cast<SkeetSDK::PElement>(source);v.proxy=static_cast<SkeetSDK::PElement>(proxy);v.type=SkeetSDK::UiTextbox;v.pane=&skin::panes[skin_menu_design::Weapon];skin::captured=skin::fingerprint(context->Menu);
}
__declspec(dllexport) void inventory_inline_callback_probe(unsigned palette,unsigned on_edit){cs2_visuals::inventory_ui::palette_access=reinterpret_cast<bool(*)(int,unsigned*,int)>(palette);cs2_visuals::inventory_ui::on_edit=reinterpret_cast<void(*)(SkeetSDK::CMenu*)>(on_edit);}
__declspec(dllexport) void inventory_ui_invalidate_skin_probe(){cs2_visuals::skin::invalidate(cs2_visuals::context->Menu);}
}
extern "C" {
__declspec(dllexport) void rage_setup_probe(void* ctx,const native_ui_proxy::Api* api,unsigned ctor,unsigned append,unsigned button){
 using namespace cs2_visuals;context=static_cast<SkeetSDK::SkeetClass_*>(ctx);native=*api;native.copy=&copy;native.destroy=&destroy;
 SkeetSDK::Memory::Allocator=api->allocate;SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(api->destroy);
 child_ctor=reinterpret_cast<ChildCtor>(ctor);append_child=reinterpret_cast<AppendChild>(append);add_button=reinterpret_cast<AddButton>(button);
}
__declspec(dllexport) int rage_rebuild_probe(){return cs2_visuals::rage_settings::rebuild(cs2_visuals::context->Menu);}
__declspec(dllexport) unsigned rage_pane_probe(int id){return reinterpret_cast<unsigned>(cs2_visuals::rage_settings::panes[id].child);}
__declspec(dllexport) unsigned rage_proxy_probe(int i){return reinterpret_cast<unsigned>(cs2_visuals::rage_settings::views[i].proxy);}
__declspec(dllexport) void rage_change_probe(int i){cs2_visuals::rage_settings::changed(&cs2_visuals::rage_settings::views[i],nullptr);}
__declspec(dllexport) void rage_open_probe(int id){cs2_visuals::rage_settings::open(reinterpret_cast<void*>(id),nullptr);}
__declspec(dllexport) int rage_popup_probe(){return cs2_visuals::rage_settings::popup;}
__declspec(dllexport) void rage_close_probe(){cs2_visuals::rage_settings::close();}
__declspec(dllexport) unsigned esp_hook_probe(){return reinterpret_cast<unsigned>(&esp_layout_runtime::text);}
__declspec(dllexport) void esp_setup_probe(void* r,unsigned callback,int mode,int packed){
 using namespace esp_layout_runtime;renderer=static_cast<SkeetSDK::IRenderer*>(r);original=reinterpret_cast<Text>(callback);menu_drawing=mode==1;
 for(auto& p:menu_interaction::placements)p=0;menu_interaction::placements[2]=unsigned(packed);show_hit=false;
 count=mode==3?2:1;last_frame=0;bound=true;candidates[0]={{100,100,100,200},mode!=2};candidates[1]={{101,100,100,200},true};
}
__declspec(dllexport) int preview_flag_models_probe(void* ctx,void* source,int* values){
 using namespace cs2_visuals;context=static_cast<SkeetSDK::SkeetClass_*>(ctx);attached=true;binding_count=1;groups[0].panel=EnemyESP;
 auto& b=bindings[0];b={};b.source=static_cast<SkeetSDK::PElement>(source);b.proxy=b.source;b.group=&groups[0];std::wcscpy(b.name,L"Flags");captured_topology=topology();
 enemy_preview::flag_sources();unsigned enabled=0;for(int i=0;i<menu_interaction::flag_count;i++){values[i]=int(enemy_preview::flags[i].bit);if(enemy_preview::enabled_flags[i])enabled|=1u<<i;}return int(enabled);
}
__declspec(dllexport) void preview_toggle_flag_probe(int id){cs2_visuals::enemy_preview::toggle_flag(id);}
__declspec(dllexport) unsigned input_probe(unsigned msg,unsigned w,unsigned l){return ui_preview_input::consume(msg,w,l);}
__declspec(dllexport) void input_area_probe(int shown){ui_preview_input::publish(100,100,200,300,shown!=0);}
__declspec(dllexport) unsigned input_poll_probe(){static ui_preview_input::Poll p;p.tick();return (p.press?1:0)|(p.release?2:0)|(p.cancelled?4:0)|(ui_preview_input::held?8:0);}
}
extern "C" __declspec(dllexport) void overlay_scope_probe(void* renderer,int* out){
 auto* r=static_cast<SkeetSDK::IRenderer*>(renderer);{RendererOverlayScope pass(r);auto* bytes=static_cast<unsigned char*>(renderer);out[0]=bytes[0x69];std::memcpy(out+1,bytes+0x7c,8);int other[]={7,11,800,900};r->SetBounds(other);r->SetAlpha(.25f);r->SetZBuff(.25f);r->ResetBounds(false);}
}
extern "C" {
__declspec(dllexport) void hit_event_probe(void* event,int enabled){esp_layout_runtime::show_hit=enabled!=0;esp_layout_runtime::event_received(nullptr,nullptr,event);}
__declspec(dllexport) unsigned hit_until_probe(int index){return esp_layout_runtime::hit_until[index];}
__declspec(dllexport) void preview_image_probe(void* r,int x,int y,int w,int h){cs2_visuals::enemy_preview::draw_image(static_cast<SkeetSDK::IRenderer*>(r),{x,y,w,h});}
}

extern "C" __declspec(dllexport) unsigned menu_accent_probe(){return cs2_visuals::menu_paint::accent();}

extern "C" {
__declspec(dllexport) unsigned rage_proxy_for_source_probe(void* source){for(auto& v:cs2_visuals::rage_settings::views)if(v.source==source)return reinterpret_cast<unsigned>(v.proxy);return 0;}
__declspec(dllexport) unsigned rage_index_probe(void* source){for(unsigned i=0;i<cs2_visuals::rage_settings::used;i++)if(cs2_visuals::rage_settings::views[i].source==source)return i;return ~0u;}
__declspec(dllexport) int hc_array_profile_probe(void* value){return cs2_visuals::hitchance_ui::array_profile(value);}
__declspec(dllexport) int hc_weapon_name_probe(const wchar_t* text){return cs2_visuals::hitchance_ui::weapon_name(text);}
__declspec(dllexport) void hc_setting_probe(unsigned id,unsigned setting){hitchance_override::settings[id]=setting;hitchance_override::keys[id]=0;}
__declspec(dllexport) int hc_capture_probe(void* root,void* scope){return hitchance_override::capture(root,scope);}
__declspec(dllexport) int renderer_supported_probe(void* r){return esp_layout_runtime::supported_renderer(static_cast<SkeetSDK::IRenderer*>(r));}
__declspec(dllexport) int renderer_install_probe(void* r){return esp_layout_runtime::install(static_cast<SkeetSDK::IRenderer*>(r));}
}
extern "C" {
__declspec(dllexport) void preview_surface_setup_probe(unsigned draw){
 using namespace cs2_visuals;for(auto& g:groups)*reinterpret_cast<void***>(g.child)=g.table;groups[panel_count].draw=reinterpret_cast<NativeChildDraw>(draw);captured_topology=topology();
}
__declspec(dllexport) void __fastcall preview_surface_draw_probe(SkeetSDK::Child* child,void*,SkeetSDK::IRenderer* r,const SkeetSDK::Vec2* origin){cs2_visuals::paint_enemy_preview(r);}
__declspec(dllexport) unsigned preview_surface_state_probe(){return cs2_visuals::enemy_preview::shown;}
}

extern "C" {
__declspec(dllexport) void preview_prepare_geometry_probe(void* r){cs2_visuals::enemy_preview::prepare(cs2_visuals::context->Menu,static_cast<SkeetSDK::IRenderer*>(r),false);}
__declspec(dllexport) int preview_settings_open_probe(){return cs2_visuals::enemy_preview::settings_open;}
}

extern "C" __declspec(dllexport) void rage_cursor_probe(POINT* out){*out=cs2_visuals::rage_settings::cursor_point();}

extern "C" __declspec(dllexport) int rage_native_editor_probe(){return cs2_visuals::rage_settings::native_editor_open();}
extern "C" {
__declspec(dllexport) void rage_frame_probe(){cs2_visuals::rage_settings::frame(cs2_visuals::context->Menu);}
__declspec(dllexport) void rage_gear_rect_probe(int id,int x,int y,int w,int h){cs2_visuals::rage_settings::gears[id].last={x,y,w,h};}
}
extern "C" {
__declspec(dllexport) void addon_reset_probe(){ui_addon::attempted=false;ui_addon::loaded=false;ui_addon::start=0;ui_addon::heartbeat_at.store(0);ui_addon::heartbeat_gap.store(0);}
__declspec(dllexport) int addon_bootstrap_probe(void* menu){ui_addon::bootstrap(static_cast<SkeetSDK::CMenu*>(menu));return (ui_addon::attempted?1:0)|(ui_addon::loaded?2:0);}
}

extern "C" __declspec(dllexport) void addon_heartbeat_probe(){ui_addon::heartbeat();}
extern "C" {
__declspec(dllexport) void rage_draw_pane_probe(int id,void* r,const SkeetSDK::Vec2* origin){cs2_visuals::rage_settings::draw(cs2_visuals::rage_settings::panes[id].child,nullptr,static_cast<SkeetSDK::IRenderer*>(r),origin);}
__declspec(dllexport) void rage_paint_overlay_probe(void* r){cs2_visuals::rage_settings::paint_overlay(cs2_visuals::context->Menu,static_cast<SkeetSDK::IRenderer*>(r));}
__declspec(dllexport) int preview_managed_probe(const wchar_t* n){return cs2_visuals::preview_managed(n);}
__declspec(dllexport) int preview_color_probe(const wchar_t* anchor,unsigned value){return cs2_visuals::enemy_preview::set_color(anchor,value);}
__declspec(dllexport) void preview_color_setup_probe(void* source){using namespace cs2_visuals;binding_count=1;auto& b=bindings[0];b={};b.source=static_cast<SkeetSDK::PElement>(source);b.proxy=b.source;b.group=&groups[0];groups[0].panel=EnemyESP;std::wcscpy(b.anchor,L"Bounding box");captured_topology=topology();}
__declspec(dllexport) void preview_binding_setup_probe(void* source,void* proxy,const wchar_t* name,const wchar_t* anchor){using namespace cs2_visuals;binding_count=1;auto& b=bindings[0];b={};b.source=static_cast<SkeetSDK::PElement>(source);b.proxy=static_cast<SkeetSDK::PElement>(proxy);b.group=&groups[0];groups[0].panel=EnemyESP;std::wcscpy(b.name,name);std::wcscpy(b.anchor,anchor);model(b,b.observed);captured_topology=topology();}
__declspec(dllexport) void preview_sync_probe(){cs2_visuals::sync();}
}
