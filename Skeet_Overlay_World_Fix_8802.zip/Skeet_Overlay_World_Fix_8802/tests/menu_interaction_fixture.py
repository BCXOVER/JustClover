"""Bounded x86 tests of the production presentation/input bridges."""
def check_menu_interaction(ns):
 globals().update(ns)
 cases=0
 # Callback ABI and layout policy: only emitted text XY may change.
 u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',{'towupper':lambda u,sp:(ord(chr(word(u,sp+4)).upper()),4)})
 store(u,0x43468fb0,0xff996655);assert call(u,exp('menu_accent_probe'))==0xff996655;cases+=1
 r,vt=MEM+0x10000,MEM+0x11000;store(u,r,vt);store(u,vt+17*4,STOP+0x510)
 text=MEM+0x12000;u.mem_write(text,'ZOOM\0'.encode('utf-16le'));received=[]
 def mock(u,a,size,user):
  sp=u.reg_read(UC_X86_REG_ESP)
  if a==STOP+0x510:
   assert u.reg_read(UC_X86_REG_ECX)==r;out=u.reg_read(UC_X86_REG_EDX);store(u,out,24);store(u,out+4,10);cleanup=16
  elif a==STOP+0x500:
   assert u.reg_read(UC_X86_REG_ECX)==r and u.reg_read(UC_X86_REG_EDX)==7
   received.append([word(u,sp+i) for i in range(4,28,4)]);cleanup=28
  else:return
  u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,word(u,sp))
 u.hook_add(UC_HOOK_CODE,mock);hook=call(u,exp('esp_hook_probe'))
 for mode in range(4):
  for side in range(4):
   for custom in [False,True]:
    packed=(0x80000000|side|(32768<<2)) if custom else 0
    call(u,exp('esp_setup_probe'),[r,STOP+0x500,mode,packed]);ret=0x43311000
    original=[205,120,0xff123456,400,text,4]
    for i,v in enumerate([ret,*original]):store(u,SP+4*i,v)
    saved={UC_X86_REG_EBX:0x12345678,UC_X86_REG_ESI:0x23456789,UC_X86_REG_EDI:0x34567890,UC_X86_REG_EBP:0x456789ab}
    for reg,v in saved.items():u.reg_write(reg,v)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,r);u.reg_write(UC_X86_REG_EDX,7)
    run_until(u,hook,ret,20000)
    assert u.reg_read(UC_X86_REG_ESP)==SP+28
    assert all(u.reg_read(reg)==v for reg,v in saved.items())
    actual=received[-1];assert actual[2:]==original[2:]
    if mode!=0 or not custom:assert actual==original
    else:assert actual[:2]!=original[:2]
    cases+=1
 # Execute native SetBounds/ResetBounds/SetAlpha/SetZ and restore BOTH clip states.
 def packets(u,a,size,user):
  if a!=0x433ab0fa or u.reg_read(UC_X86_REG_EDX)==11:return
  sp=u.reg_read(UC_X86_REG_ESP);u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+8)
 u.hook_add(UC_HOOK_CODE,packets)
 store(u,r,0x43472a80)
 for disabled in [0,1]:
  u.mem_write(r+0x69,bytes([disabled]));floats(u,r+0x7c,.4,.6);original_bounds=struct.pack('<4i',17,23,1000,750);u.mem_write(r+0x6c,original_bounds)
  output=MEM+0x13000;call(u,exp('overlay_scope_probe'),[r,output]);assert word(u,output)==0 and word(u,output+4)==0 and word(u,output+8)==fbits(1)
  assert bytes(u.mem_read(r+0x69,1))==bytes([disabled]);assert bytes(u.mem_read(r+0x6c,16))==original_bounds;assert abs(scalar(u,r+0x7c)-.4)<1e-6
  assert abs(scalar(u,r+0x80)-.6)<1e-6;cases+=1
 # Execute the native backend consumer as well, with only D3D COM and the
 # geometry flush stubbed. Its boolean maps directly to render state 174.
 backend,bdata,device,device_vt=[MEM+0x15000+i*0x1000 for i in range(4)]
 store(u,backend,0x4346f46c);store(u,backend+4,bdata);store(u,bdata+0xc8,device);store(u,device,device_vt)
 store(u,device_vt+0xe4,STOP+0x680);store(u,device_vt+0xe8,STOP+0x6a0)
 actual_scissor=[1];state_calls=[]
 def d3d(u,a,size,user):
  if a not in [0x433b18b1,STOP+0x680,STOP+0x6a0]:return
  sp=u.reg_read(UC_X86_REG_ESP);cleanup=4
  if a!=0x433b18b1:
   assert word(u,sp+4)==device and word(u,sp+8)==174
   if a==STOP+0x680:actual_scissor[0]=word(u,sp+12);state_calls.append(actual_scissor[0])
   else:store(u,word(u,sp+12),actual_scissor[0])
   cleanup=16
  u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
 u.hook_add(UC_HOOK_CODE,d3d)
 for enabled in [0,1,0,0,1]:
  call(u,0x433ed99e,[],backend,enabled);assert actual_scissor[0]==enabled
 assert state_calls==[0,1,0,1];cases+=5
 # The native texture packet receives output pixel dimensions and unit UV scale.
 texture_packet=MEM+0x14000
 def texture(u,a,size,user):
  if a!=0x433ab0fa:return
  if u.reg_read(UC_X86_REG_EDX)!=11:return
  sp=u.reg_read(UC_X86_REG_ESP);assert word(u,sp+4)==40;u.reg_write(UC_X86_REG_EAX,texture_packet);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+8)
 u.hook_add(UC_HOOK_CODE,texture)
 for width,height in [(148,296),(200,400),(256,512)]:
  call(u,exp('preview_image_probe'),[r,900,120,width,height]);assert [word(u,texture_packet+i) for i in [0,4,0x18,0x1c,0x20,0x24]]==[900,120,width,height,1,fbits(1)];cases+=1
 # Preview/window input: press, drag outside, release, cancellation, resize.
 call(u,exp('input_area_probe'),[1]);call(u,exp('input_poll_probe'))
 pos=lambda x,y:(x&65535)|((y&65535)<<16)
 assert call(u,exp('input_probe'),[0x201,0,pos(120,140)])==1
 assert call(u,exp('input_poll_probe'))==9
 assert call(u,exp('input_probe'),[0x200,0,pos(500,600)])==1
 assert call(u,exp('input_probe'),[0x202,0,pos(500,600)])==1
 assert call(u,exp('input_poll_probe'))==2
 assert call(u,exp('input_probe'),[0x201,0,pos(20,40)])==0
 call(u,exp('input_probe'),[0x201,0,pos(120,140)]);call(u,exp('input_probe'),[0x8,0,0])
 assert call(u,exp('input_poll_probe'))==4
 call(u,exp('input_probe'),[0x201,0,pos(120,140)]);call(u,exp('input_area_probe'),[0]);assert call(u,exp('input_poll_probe'))==4
 cases+=7
 # Native multiselect Index is a BIT MASK, not an ordinal. Include bit 31.
 ctx,menu,tabs,visuals,misc,child,items,source,value,vars,out=[MEM+0x20000+i*0x1000 for i in range(11)]
 store(u,ctx+0x10,menu);store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs+12,visuals);store(u,tabs+16,misc)
 store(u,visuals+0x70,items);store(u,visuals+0x74,items+4);store(u,items,child);store(u,child+0x80,items+0x100);store(u,child+0x84,items+0x104);store(u,items+0x100,source)
 store(u,source+0x5c,value);u.mem_write(source+0x19,b'\x0d');store(u,source+0x80,vars);store(u,source+0x84,vars+60);store(u,value,0x80000010)
 for i,(name,mask) in enumerate([('Money',1),('Scoped',16),('Fake duck',0x80000000)]):
  p=vars+0x100+i*0x100;data=(name+'\0').encode();u.mem_write(p,data);store(u,vars+20*i,p);store(u,vars+20*i+4,p+len(data));store(u,vars+20*i+16,mask)
 active=call(u,exp('preview_flag_models_probe'),[ctx,source,out]);assert active==(1<<2)|(1<<8)
 assert [word(u,out+4*i) for i in [0,2,8]]==[1,16,0x80000000];cases+=1
 # HIT comes from a local player's player_hurt event, not sampled health.
 engine,event=MEM+0x40000,MEM+0x41000;evt_vt,engine_vt=MEM+0x42000,MEM+0x43000
 store(u,0x4346a514,engine);store(u,engine,engine_vt);store(u,event,evt_vt);store(u,engine_vt+9*4,STOP+0x600);store(u,engine_vt+12*4,STOP+0x620);store(u,evt_vt+6*4,STOP+0x640)
 attacker=[101]
 def event_mock(u,a,size,user):
  sp=u.reg_read(UC_X86_REG_ESP);result=0;cleanup=4
  if a==STOP+0x600:result={101:1,102:2,103:3}.get(word(u,sp+4),0);cleanup=8
  elif a==STOP+0x620:result=1
  elif a==STOP+0x640:
   at=word(u,sp+4);name=bytes(u.mem_read(at,16)).split(b'\0')[0];result=attacker[0] if name==b'attacker' else 103;cleanup=12
  else:return
  u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
 u.hook_add(UC_HOOK_CODE,event_mock)
 call(u,exp('hit_event_probe'),[event,0]);assert call(u,exp('hit_until_probe'),[3])==0
 attacker[0]=102;call(u,exp('hit_event_probe'),[event,1]);assert call(u,exp('hit_until_probe'),[3])==0
 attacker[0]=101;call(u,exp('hit_event_probe'),[event,1]);assert call(u,exp('hit_until_probe'),[3])==700;cases+=3
 return {'native_d3d_scissor_boolean_semantics_verified':True,'presentation_cases':cases,'native_text_xy_only':True,'native_text_abi_and_preserved_registers':True,'default_menu_friendly_ambiguous_passthrough':True,'window_drag_capture_cancel':True,'native_flags_use_bitmasks':True}
