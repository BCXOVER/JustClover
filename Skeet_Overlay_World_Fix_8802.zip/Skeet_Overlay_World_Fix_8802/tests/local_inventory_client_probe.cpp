#include "../source/skeet/pch.h"
#include "../source/skeet/local_inventory_client.h"
#include "../source/skeet/local_loadout_client.h"
#include "../source/skeet/local_weapon_names.h"
#include "../source/skeet/weapon_sticker_client.h"
#include "../source/skeet/agent_inventory_client.h"
static local_loadout::Loadout loadout;
extern "C" {
__declspec(dllexport) void inventory_agent_step_probe(){agent_inventory_client::index.step();}
__declspec(dllexport) unsigned inventory_agent_cursor_probe(){return agent_inventory_client::index.cursor;}
__declspec(dllexport) unsigned inventory_agent_max_rows_probe(){return agent_inventory_client::index.stats.max_step_rows;}
__declspec(dllexport) unsigned inventory_agent_total_rows_probe(){return agent_inventory_client::index.stats.examined;}
__declspec(dllexport) unsigned inventory_agent_reset_probe(){agent_inventory_client::reset();return 1;}

__declspec(dllexport) unsigned inventory_weapon_names_probe(void* requests,unsigned count){return local_weapon_names::apply(static_cast<local_weapon_names::Request*>(requests),count);}
__declspec(dllexport) unsigned inventory_weapon_name_size_probe(){return sizeof(local_weapon_names::Request);}
__declspec(dllexport) int inventory_agent_resolve_probe(void* schema,void* tab,unsigned side,int value){if(!agent_inventory_client::index.prepare(schema))return 0;wchar_t name[256]{};agent_inventory_client::label(tab,side,value,name);return agent_inventory_client::index.lookup(value,name);}

__declspec(dllexport) int inventory_local_clear_probe(void* session,void* object,void* spec){
 auto& s=*static_cast<local_inventory::Session*>(session);auto& v=*static_cast<local_inventory::Spec*>(spec);
 return local_loadout_client::clear(s,{object,local_inventory_client::read64(object,8),v});
}
__declspec(dllexport) unsigned inventory_local_equip_probe(void* session,void* object,void* spec){
 auto& s=*static_cast<local_inventory::Session*>(session);auto& v=*static_cast<local_inventory::Spec*>(spec);
 local_inventory::Item item{object,local_inventory_client::read64(object,8),v};return loadout.equip(local_loadout_client::api,s,item);
}
__declspec(dllexport) int inventory_local_restore_probe(unsigned lo,unsigned hi){return loadout.detach(local_loadout_client::api,(std::uint64_t(hi)<<32)|lo);}

__declspec(dllexport) int inventory_client_session_probe(void* out){return local_inventory_client::session(*static_cast<local_inventory::Session*>(out));}
__declspec(dllexport) int inventory_client_initialize_probe(void* object,void* session,void* spec,unsigned lo,unsigned hi,unsigned position){return local_inventory_client::initialize(object,*static_cast<local_inventory::Session*>(session),*static_cast<local_inventory::Spec*>(spec),(std::uint64_t(hi)<<32)|lo,position);}
__declspec(dllexport) void* inventory_client_create_probe(){return local_inventory_client::create();}
__declspec(dllexport) int inventory_client_palette_probe(int id,void* colors,int action){return local_inventory_client::palette(id,static_cast<unsigned*>(colors),action);}
__declspec(dllexport) int inventory_client_notify_probe(void* session,int event,void* object){return local_inventory_client::notify(*static_cast<local_inventory::Session*>(session),event,object);}
__declspec(dllexport) int inventory_client_insert_probe(void* session,void* item){return local_inventory_client::insert(*static_cast<local_inventory::Session*>(session),item);}
__declspec(dllexport) int inventory_client_remove_probe(void* session,void* item){return local_inventory_client::remove(*static_cast<local_inventory::Session*>(session),item);}

}

extern "C" __declspec(dllexport) int inventory_sticker_set_probe(int w,unsigned slot,int id,float wear,float scale,float rotation){return sticker_state::set(w,slot,{id,wear,scale,rotation});}

extern "C" __declspec(dllexport) void inventory_weapon_stickers_probe(void* session,void* object,void* spec){local_inventory::Inventory inv;inv.current=*static_cast<local_inventory::Session*>(session);inv.items[0]={object,local_inventory_client::read64(object,8),*static_cast<local_inventory::Spec*>(spec)};weapon_sticker_client::apply(inv);}
