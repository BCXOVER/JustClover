"""Execute reviewed Lua with mocked GameSense/FFI only; never load a game DLL."""
from pathlib import Path
import json,hashlib,sys,tempfile
from lupa.luajit21 import LuaRuntime
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build'
lua=LuaRuntime(unpack_returned_tuples=True)
lua.execute((ROOT/'tests/lua_ui_fixture.lua').read_text())
lua.globals().fixture_skin_group='Knife options'
source=(ROOT/'source/lua/clover_cs2_ui_8802.lua').read_text()
# Exercise LuaJIT's real filename/module search. The previous native boundary
# stub accepted the wrong .lua suffix and therefore hid this exact failure.
folder=tempfile.TemporaryDirectory(prefix='clover-lua-resolution-')
module=Path(folder.name)/'clover_cs2_ui_8802.lua';module.write_text(source)
lua.globals().fixture_module_path=str(Path(folder.name)/'?.lua')
lua.execute("package.path=fixture_module_path")
ok,err=lua.eval("function() local ok,err=pcall(require,'clover_cs2_ui_8802.lua');return ok,err end")()
assert not ok and "module 'clover_cs2_ui_8802.lua' not found" in str(err)
lua.eval('require')('clover_cs2_ui_8802')
errors=lua.eval('errors');assert len(errors)==0,list(errors.values())
lua.execute('fire("paint_ui")');assert len(errors)==0,list(errors.values())
lua.execute('''
assert(module_mask==15)
assert(find('Stickers').group=='Knife options' and find('Sticker slot').group=='Knife options')
ui.set(find('Brightness adjustment'),'Night mode');ui.set(find('Night mode'),true);ui.set(find('Night mode intensity'),85);now=.2;fire('paint_ui');assert(night_calls[#night_calls][1]==1 and night_calls[#night_calls][2]==85 and ui.get(find('Brightness adjustment'))=='Off')
ui.set(find('Night mode'),false);now=.4;fire('paint_ui');assert(night_calls[#night_calls][1]==0 and ui.get(find('Brightness adjustment'))=='Night mode')
assert(find('CS2 watermark').tab=='MISC' and find('CS2 logs').tab=='MISC')
ui.set(find('Remove fog'),true);ui.set(find('Override fog'),true);ui.set(find('Fog start'),200);ui.set(find('Fog end'),120);now=1;fire('paint_ui');assert(ui.get(find('Remove fog'))==false)
assert(cvar.fog_override.value=='1' and cvar.fog_start.value=='200' and cvar.fog_end.value=='201')
assert(cvar.fog_color.value=='170 185 205')
ui.set(find('Override fog'),false);now=2;fire('paint_ui');assert(cvar.fog_override.value=='legacy_fog_override' and cvar.fog_color.value=='legacy_fog_color' and ui.get(find('Remove fog'))==true)
ui.set(find('Override lighting'),true);now=3;fire('paint_ui');assert(cvar.mat_ambient_light_r.value~='legacy_mat_ambient_light_r')
ui.set(find('Override lighting'),false);now=4;fire('paint_ui');assert(cvar.mat_ambient_light_r.value=='legacy_mat_ambient_light_r')
ui.set(find('Override sky'),true);ui.set(find('Skybox'),'Night');now=5;fire('paint_ui');assert(skies[#skies]=='sky_csgo_night02')
ui.set(find('Skybox'),'Custom');ui.set(find('Custom skybox name'),'../../bad');now=6;fire('paint_ui');assert(skies[#skies]=='sky_csgo_night02')
ui.set(find('Override sky'),false);now=7;fire('paint_ui');assert(skies[#skies]=='sky_map_default')
ui.set(find('Find sticker'),'howling');local pick=find('Sticker');assert(#pick.options>1 and #pick.options<=62)
ui.set(pick,pick.options[2]);local first=stickers[9][0].id;assert(first>0)
ui.set(find('Sticker slot'),'Slot 4');ui.set(find('Sticker'),find('Sticker').options[2]);assert(stickers[9][3].id>0)
ui.set(find('Sticker wear'),30);ui.set(find('Sticker rotation'),-60);assert(stickers[9][3].wear==.3 and stickers[9][3].rotation==-60)
chosen_weapon=7;now=8;fire('paint_ui');ui.set(find('Find sticker'),'crown');ui.set(pick,pick.options[2]);assert(stickers[7][3].id>0 and stickers[9][0].id==first)
ui.set(pick,'None');assert(stickers[7][3].id==0 and stickers[9][3].id>0)
chosen_weapon=508;now=9;fire('paint_ui');assert(not find('Sticker slot').visible)
ui.set(find('CS2 watermark'),true);ui.set(find('Watermark elements'),'CPU usage','CPU frequency','RAM','Game memory','FPS');now=10;fire('paint_ui')
local all=table.concat(draws,'|');assert(all:find('3.80 GHz',1,true) and all:find('5.0/16.0 GB',1,true) and all:find('37%',1,true))
ui.set(find('CS2 logs'),true);fire('aim_fire',{id=1,damage=80,hitgroup=1,hit_chance=75,tick=630,target=2});fire('aim_hit',{id=1,target=2,damage=80,hitgroup=1});now=10.3;fire('paint_ui')
all=table.concat(draws,'|');assert(all:find('Enemy',1,true))
fire('pre_config_save');local saved=ui.get(find('Clover sticker profiles 8802'));assert(saved:sub(1,3)=='v1;')
fire('pre_config_load');ui.set(find('Clover sticker profiles 8802'),'v1;9,1,1,0.25,1.5,-45;7,4,2,0.1,0.5,90;')
ui.set(find('Sticker'),'None');fire('post_config_load')
assert(stickers[9][0].id==1 and stickers[9][0].rotation==-45 and stickers[7][3].id==2 and stickers[9][3].id==0)
fire('pre_config_load');ui.set(find('Clover sticker profiles 8802'),'v1;9,1,999999,0,1,0;');fire('post_config_load');assert(stickers[9][0].id==1)
ui.set(find('Override fog'),true);fire('shutdown')
controls={};events={};draws={}
''')
lua.execute(source)
lua.execute("assert(ui.get(find('Override fog'))==true and ui.get(find('CS2 watermark'))==true);now=20;fire('paint_ui');assert(cvar.fog_override.value=='1')")
report={'passed':True,'lua_version':'LuaJIT 2.1','restricted_api_fixture':True,'modules_loaded_without_external_requires':True,'real_require_reproduces_old_suffix_failure':True,'real_require_loads_extensionless_module':True,'all_four_module_ready_bits_reported':True,'night_intensity_and_palette_bridge_called':True,'sticker_container_fallback_exercised':True,'legacy_world_conflicts_restored':True,'internal_ui_values_survive_lua_reload':True,'world_fog_clamps_end_after_start':True,'fog_and_lighting_restore_on_disable':True,'sky_restore_and_invalid_name_rejected':True,'sticker_search_bounded_choices':62,'four_slots_and_per_weapon_isolation':True,'none_removes_sticker':True,'per_weapon_config_serialization_by_sticker_id':True,'config_load_ignores_transient_filtered_combo_indices':True,'invalid_sticker_config_is_atomic_noop':True,'knives_hide_sticker_editor':True,'watermark_cpu_frequency_usage_and_ram_drawn':True,'uploaded_hit_log_rendered':True,'compiled_script_sha256':hashlib.sha256(source.encode()).hexdigest(),'game_tested':False}
(BUILD/'lua_ui_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
