-- Restricted GameSense API fixture. No game, OS FFI, filesystem or network calls.
now=0;chosen_weapon=9;controls={};events={};draws={};errors={};skies={};db={};stickers={}
local function control(kind,tab,group,name,...)
 if tab=='SKINS' and fixture_skin_group then assert(group==fixture_skin_group,'Unknown Skinchanger container') end
 local args={...};local ref={kind=kind,tab=tab,group=group,name=name,visible=true,options=args}
 if kind=='checkbox' then ref.value=false elseif kind=='slider' then ref.value=args[3] elseif kind=='color' then ref.value=args elseif kind=='combo' then ref.value=args[1] elseif kind=='multi' then ref.value={} else ref.value='' end
 controls[#controls+1]=ref;return ref
end
ui={}
for name,kind in pairs({new_checkbox='checkbox',new_slider='slider',new_color_picker='color',new_combobox='combo',new_multiselect='multi',new_textbox='text',new_label='label'}) do ui[name]=function(...) return control(kind,...) end end
function ui.new_string(name,default) local r=control('text','','',name);r.value=default;r.visible=false;return r end
function ui.reference(tab,group,name) local r=control('combo',tab,group,name,'100%');return r end
function ui.get(r) if r.kind=='color' then return unpack(r.value) end return r.value end
function ui.set(r,...)
 local args={...};if r.kind=='multi' or r.kind=='color' then r.value=args else r.value=args[1] end
 if r.callback then r.callback(r) end
end
function ui.update(r,...) r.options={...} end
function ui.set_visible(r,v) r.visible=v end
function ui.set_callback(r,fn) r.callback=fn end
function ui.is_menu_open() return true end
client={}
function client.set_event_callback(name,fn) events[name]=events[name] or {};table.insert(events[name],fn) end
function client.error_log(x) errors[#errors+1]=x end
function client.screen_size() return 1920,1080 end
function client.unix_time() return math.floor(now) end
function client.system_time() return 12,34,56 end
function client.latency() return .025 end
function client.userid_to_entindex(x) return x end
function fire(name,e) for _,f in ipairs(events[name] or {}) do f(e or {}) end end
function find(name) for _,r in ipairs(controls) do if r.name==name then return r end end error('missing control '..name) end
local system={ [0]={[78]=function() return nil end} }
function client.create_interface() return system end
local native={}
module_mask=0;night_calls={}
function native.clover_ui_module(mask) module_mask=bit.bor(module_mask,mask) end
function native.clover_night(on,amount,world,props) night_calls[#night_calls+1]={on,amount,world,props} end
function native.clover_night_reset() end
function native.clover_ui_heartbeat() end
function native.clover_selected_weapon() return chosen_weapon end
local guns={[7]=true,[9]=true,[40]=true}
function native.clover_sticker_get(w,s,out)
 if not guns[w] or s<0 or s>=4 then return 0 end
 local st=stickers[w] and stickers[w][s] or {id=0,wear=0,scale=1,rotation=0}
 out[0]={id=st.id,wear=st.wear,scale=st.scale,rotation=st.rotation};return 1
end
function native.clover_sticker_set(w,s,id,wear,scale,rot)
 if not guns[w] or s<0 or s>=4 then return 0 end
 stickers[w]=stickers[w] or {};stickers[w][s]={id=id,wear=wear,scale=scale,rotation=rot};return 1
end
function native.clover_telemetry(out,size)
 out[0]={valid=15,cpu_percent=37,cpu_ghz=3.8,ram_used_gib=5,ram_total_gib=16,process_mib=500};return 1
end
function native.clover_sky(name) skies[#skies+1]=name;return 1 end
function native.clover_sky_tint(name,color) return 1 end
local ffi={}
function ffi.cdef() end
function ffi.new(typename) return {[0]={id=0,wear=0,scale=1,rotation=0,valid=0}} end
function ffi.load(name) assert(name=='skeet.dll');return native end
function ffi.sizeof() return 28 end
function ffi.typeof(t) return t end
function ffi.cast(t,v) return v end
function ffi.string(x) return x end
package.preload.ffi=function() return ffi end
renderer={}
function renderer.measure_text(flags,s) return #tostring(s)*6,12 end
function renderer.text(x,y,r,g,b,a,flags,w,s) draws[#draws+1]=tostring(s) end
function renderer.rectangle() end
function renderer.gradient() end
function renderer.indicator() end
panorama={open=function() return {MyPersonaAPI={GetName=function() return 'Tester' end}} end}
globals={realtime=function() return now end,absoluteframetime=function() return 1/144 end,frametime=function() return 1/144 end,tickcount=function() return math.floor(now*64) end}
entity={get_local_player=function() return nil end,get_player_resource=function() return nil end,get_prop=function() return 75 end,get_player_name=function() return 'Enemy' end,is_enemy=function() return true end}
database={read=function(k) return db[k] end,write=function(k,v) db[k]=v end}
cvar=setmetatable({}, {__index=function(t,k) local v={value=k=='sv_skyname' and 'sky_map_default' or 'legacy_'..k};function v:get_string() return self.value end;function v:set_string(x) self.value=x end;rawset(t,k,v);return v end})
