#!/usr/bin/env python3
"""Portable ownership/loadout checks; never starts the target application."""
from pathlib import Path
import subprocess,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
build=ROOT/'build';build.mkdir(exist_ok=True)
source=ROOT/'tests/skin_mirror_plan.cpp'
subprocess.run(['g++','-std=c++17','-O2',str(source),'-o',str(build/'skin_mirror_plan')],check=True)
subprocess.run([str(build/'skin_mirror_plan')],check=True)
report={'passed':True,'sticker_only_edit_replaces_inventory_id':True,'unchanged_stickers_allocate_nothing':True,'sticker_removal_reconciles':True,'pending_agent_retains_old_team_selection':True,'pending_agent_does_not_delay_weapon_config':True,'resolved_agent_side_replaces_independently':True,'name_only_update_keeps_inventory_id':True,'name_clear_keeps_inventory_id':True,'debounce_ms':350,'native_snapshot_debounce_ms':0,'default_agent_does_not_block_weapon_snapshot':True,'duplicate_prevention':True,'missing_cached_item_recreated':True,'failed_old_item_removal_retried':True,'full_config_snapshot_without_visiting_presets':True,'bounded_batch_operations_per_frame':4,'butterfly_to_m9_cross_weapon_finish_replacement':True,'removed_config_items_retired':True,'agent_lifecycle':True,'preset_replacement':True,'independent_weapon_presets_with_shared_paint':True,
        'disable_restores_previous_loadout':True,'later_manual_loadout_preserved':True,
        'manual_delete_suppresses_recreation_until_change':True,'account_change_drops_old_references':True,
        'manually_created_items_not_deleted_by_mirror':True,'game_tested':False,
        'source_sha256':{name:hashlib.sha256((ROOT/'source/skeet'/name).read_bytes()).hexdigest()
                         for name in ['skin_mirror.h','local_loadout.h','skin_native_state.h','skin_native_client.h']}}
(build/'skin_mirror_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
