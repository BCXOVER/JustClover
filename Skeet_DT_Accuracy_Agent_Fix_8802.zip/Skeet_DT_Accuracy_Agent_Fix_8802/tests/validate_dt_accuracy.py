#!/usr/bin/env python3
"""Closed x86 execution of production DT thunks and native HC task setup.
No DLL entry, game startup, Steam or networking calls are executed.
"""
from pathlib import Path
import subprocess,sys,os,struct,json,hashlib,math
import pefile
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build';CORE=0x43310000
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/dt_accuracy_plan.cpp'),'-o',str(BUILD/'dt_accuracy_plan')],check=True)
result=subprocess.run([str(BUILD/'dt_accuracy_plan'),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(BUILD/'dt_accuracy.bin'),'0x50000000'],check=True,text=True,capture_output=True);print(result.stdout.strip());portable_cases=int(result.stdout.split()[0])
if '--reuse-probe' not in sys.argv:
 env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']='/workspace/skeet-motion-bt-8802/.cache/global'
 with (BUILD/'dt-probe.log').open('w') as log:
  subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++23','-O1','-shared','-I',str(ROOT/'source/compat'),'-I',str(ROOT/'source/skeet'),'-Wl,--image-base,0x40000000',str(ROOT/'tests/dt_accuracy_probe.cpp'),'-o',str(BUILD/'dt_accuracy_probe.dll')],env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
# Reuse the pinned-client fixture and its memory/ABI boundaries. It validates
# the inventory changes independently before exposing the closed machine.
import validate_inventory_client as native
u=native.u;MEM=native.MEM;SP=native.SP;STOP=native.STOP
word=native.word;put=native.put;finish=native.finish
image=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes();u.mem_write(CORE,image)
pe=pefile.PE(str(BUILD/'dt_accuracy_probe.dll'));PB=pe.OPTIONAL_HEADER.ImageBase;u.mem_map(PB,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(PB,pe.get_memory_mapped_image());u.mem_map(0x150000,0x2000)
exports={x.name.decode():PB+x.address for x in pe.DIRECTORY_ENTRY_EXPORT.symbols if x.name}
def exp(name):return next(v for k,v in exports.items() if name in k)
imports={}
for library in pe.DIRECTORY_ENTRY_IMPORT:
 for item in library.imports:
  address=0x150000+len(imports)*16;put(item.address,address);imports[address]=item.name.decode()
ctx,ctrl,cmd,job,frame,pool,selected,log,entry,victim,interval=[MEM+0xe0000+i*0x1000 for i in range(11)]
player=native.player;weapon=native.own_weapon;entities=native.entities;entity_vt=native.entity_vt
put(0x4346a890,entities);put(entity_vt+3*4,0x150900);put(entity_vt+4*4,0x150920);put(0x4346a338,interval);u.mem_write(interval,struct.pack('<f',1/64))
put(weapon+0x14c,99);u.mem_write(weapon+0x2fba,struct.pack('<H',38));put(weapon+0x3274,2)
for at,value in [(player+0x2d80,1.),(weapon+0x3248,1.)]:u.mem_write(at,struct.pack('<f',value))
for off,value in [(0,0x400),(0xc,player),(0x10,weapon),(0xd8,38),(0xc8,1000),(0xac,100),(0x1d4,2)]:put(ctx+off,value)
for off,value in [(0xc4,.01),(0xd0,.02)]:u.mem_write(ctx+off,struct.pack('<f',value))
for off,value in [(0xf4,2),(0xfc,12),(0x104,15)]:put(ctrl+off,value)
put(cmd+4,100);put(victim+0x100,100)
put(log+0x4c,entry);put(log+0x50,entry+0xc0);put(entry+0x94,5);put(entry+0xb8,60);put(0x43475a7c,log)
put(job+4,5);put(job+8,100);put(job+0x28,50);u.mem_write(job+0xd4,struct.pack('<f',.5));put(frame+8,ctx);put(frame+12,job)
retry=[False];native_worker=[False];tasks=[]
def hook(u,address,size,user):
 sp=u.reg_read(UC_X86_REG_ESP)
 if address in imports:
  fn=imports[address]
  if fn=='GetModuleHandleW':finish(sp,native.BASE,8)
  elif fn=='VirtualQuery':
   addr,out,n=[word(sp+i) for i in [4,8,12]];assert n==28
   for lo,hi,_ in u.mem_regions():
    if lo<=addr<=hi:u.mem_write(out,struct.pack('<IIIIIII',lo,lo,0x40,hi-lo+1,0x1000,0x40,0x20000));finish(sp,28,16);break
   else:finish(sp,0,16)
  elif fn in ['memcpy','memmove']:
   dst,src,n=[word(sp+i) for i in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)));finish(sp,dst)
  elif fn=='memset':
   dst,c,n=[word(sp+i) for i in [4,8,12]];u.mem_write(dst,bytes([c&255])*n);finish(sp,dst)
  elif fn=='fmaxf':
   a,b=[struct.unpack('<f',u.mem_read(sp+i,4))[0] for i in [4,8]]
   raise AssertionError('Unexpected out-of-line floating ABI')
  else:raise AssertionError(fn)
 elif address==0x150900:finish(sp,{1:player,5:victim}.get(word(sp+4),0),8)
 elif address==0x150920:finish(sp,player if word(sp+4)==99 else 0,8)
 elif address==0x433eb28b and native_worker[0]:finish(sp,u.reg_read(UC_X86_REG_ECX),12)
 elif address==0x433df8a0 and not native_worker[0]:
  descriptor=u.reg_read(UC_X86_REG_ECX);tasks.append((word(descriptor),word(descriptor+4)));finish(sp)
 elif address==0x4341b4c2 and retry[0]:
  assert word(sp+4)==ctx and word(sp+8)==job and word(job+0x30)==1
  u.mem_write(word(sp+12),struct.pack('<f',.8));finish(sp,1,16)
u.hook_add(UC_HOOK_CODE,hook)
def run(start,stop,count=1000000):
 ended=[]
 def stop_hook(u,a,size,user):
  if a==stop:ended.append(True);u.emu_stop()
 h=u.hook_add(UC_HOOK_CODE,stop_hook)
 try:u.emu_start(start,stop+1,count=count)
 finally:u.hook_del(h)
 assert ended or (stop==STOP and u.reg_read(UC_X86_REG_EIP)==STOP),hex(u.reg_read(UC_X86_REG_EIP))
def call(name,args=()):
 for i,value in enumerate([STOP,*args]):put(SP+4*i,value)
 u.reg_write(UC_X86_REG_ESP,SP);run(exp(name),STOP);return u.reg_read(UC_X86_REG_EAX)
blob=bytearray((BUILD/'dt_accuracy.bin').read_bytes());assert len(blob)==1152
for token,name in [(0x11223344,'dt_profile_probe'),(0x55667788,'dt_capture_probe')]:
 pos=blob[:768].find(struct.pack('<I',token));assert pos>=0;struct.pack_into('<I',blob,pos,exp(name))
CODE=0x50000000;u.mem_map(CODE,0x1000);u.mem_write(CODE,bytes(blob[:768]))
for i in range(8):
 off,n=struct.unpack_from('<II',blob,768+i*48);before=blob[768+i*48+8:768+i*48+8+n];after=blob[768+i*48+28:768+i*48+28+n];assert bytes(u.mem_read(CORE+off,n))==before;u.mem_write(CORE+off,bytes(after))
# Execute the original controller's charge->context assignment and finalized
# mode validation, then the actual production tail detour and ret 8 cleanup.
def capture(number,charged,ready=2):
 put(ctx+0xac,number);put(cmd+4,number);put(ctrl+0x104,charged);put(ctx+0x1d4,ready)
 tail=SP;put(tail-4,0x12345678);put(tail,0x2468abcd);put(tail+0x20,STOP);put(tail+0x24,player);put(tail+0x28,cmd)
 u.reg_write(UC_X86_REG_ESP,tail-4);u.reg_write(UC_X86_REG_ECX,ctx);u.reg_write(UC_X86_REG_ESI,ctrl)
 run(0x433ce86b,STOP)
 assert u.reg_read(UC_X86_REG_ESP)==tail+0x2c and u.reg_read(UC_X86_REG_ESI)==0x2468abcd
# Native writer uses mode only when charge meets the required shift.
for charged,expected in [(11,0),(12,2),(15,2)]:
 put(ctrl+0x104,charged);put(SP+0x1c,ctx);u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ESI,ctrl);u.reg_write(UC_X86_REG_EDX,ctx);run(0x433ce4e0,0x433ce502);assert word(ctx+0x1d4)==expected
capture(100,15)
# Check every original GPR/FP register except the native block's documented outputs.
def profile(health=100,damage=50,chance=.5,initial=64):
 put(job+8,health);put(job+0x28,damage);u.mem_write(job+0xd4,struct.pack('<f',chance));put(SP+0x10,initial);u.mem_write(SP+0xb,b'\0')
 for reg,value in [(UC_X86_REG_EBX,0x12345678),(UC_X86_REG_ESI,0x23456789),(UC_X86_REG_EDI,job),(UC_X86_REG_EBP,frame)]:u.reg_write(reg,value)
 xmm={UC_X86_REG_XMM0+i:0x3f800001+i for i in range(8)}
 for reg,value in xmm.items():u.reg_write(reg,value)
 u.reg_write(UC_X86_REG_MXCSR,0x1f80);u.reg_write(UC_X86_REG_ESP,SP)
 run(0x4341bc00,0x4341bc46)
 assert u.reg_read(UC_X86_REG_ESP)==SP and u.reg_read(UC_X86_REG_EBX)==0x12345678 and u.reg_read(UC_X86_REG_ESI)==0x23456789 and u.reg_read(UC_X86_REG_EDI)==job and u.reg_read(UC_X86_REG_EBP)==frame
 assert all(u.reg_read(reg)==value for reg,value in list(xmm.items())[2:]) and u.reg_read(UC_X86_REG_MXCSR)==0x1f80
 return word(SP+0x10),struct.unpack('<f',u.mem_read(SP+0x40,4))[0]
assert profile()==(128,.75)
for chance in [.75,1.]:assert profile(chance=chance)==(128,chance)
assert profile(health=40,damage=40,initial=32)==(32,.5)
assert profile(health=1000)==(64,.5)
put(weapon+0x3274,1);assert profile()==(64,.5);put(weapon+0x3274,2)
u.mem_write(weapon+0x3248,struct.pack('<f',100.));assert profile()==(64,.5);u.mem_write(weapon+0x3248,struct.pack('<f',1.))
put(weapon+0x14c,100);assert profile()==(64,.5);put(weapon+0x14c,99)
capture(101,14);put(weapon+0x3274,1);assert profile()==(128,.75)
assert profile(health=40,damage=40,initial=32)==(128,.75)
capture(102,0,0);assert profile()==(128,.75)
capture(102,0,0);assert profile()==(128,.75)
# Native prediction can pass a copied context; identify the player/weapon
# command stream independently of the temporary context's address.
original_context=ctx;ctx=MEM+0xec000;u.mem_write(ctx,bytes(u.mem_read(original_context,0x1e0)));put(frame+8,ctx)
capture(103,0,0);assert profile()==(128,.75)
u.mem_write(original_context,bytes(u.mem_read(ctx,0x1e0)));ctx=original_context;put(frame+8,ctx)
# Native task initialization/serial iteration uses 128 complete descriptors in
# appended stack space; both original snapshots and neighboring memory survive.
u.mem_write(SP+0x4d0,b'\x5a'*0x100);u.mem_write(SP+0x72a0-4,b'LEFT');u.mem_write(SP+0x76a0,b'RIGHT')
u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_EAX,0);run(0x4341c720,0x4341c73b)
assert all(word(SP+0x72a0+i*8)==SP+0xc8 and word(SP+0x72a4+i*8)==i for i in range(128))
assert bytes(u.mem_read(SP+0x4d0,0x100))==b'\x5a'*0x100 and bytes(u.mem_read(SP+0x729c,4))==b'LEFT' and bytes(u.mem_read(SP+0x76a0,5))==b'RIGHT'
put(SP+0x10,128);u.reg_write(UC_X86_REG_ESP,SP);run(0x4341c7cf,0x4341c7e9);assert len(tasks)==128 and [i for _,i in tasks]==list(range(128))
# Execute the original worker's sample addressing for both halves of the
# 128-entry table. Only its trace-filter constructor is a boundary here.
table=MEM+0xeb000;shared=SP+0xc8
for i in range(128):u.mem_write(table+i*8,struct.pack('<ff',i/1000,(127-i)/1000))
for off,value in [(0,ctx),(4,job+0xc),(0x10,table),(0x54,1),(0x64,0)]:put(shared+off,value)
for off,value in [(0x48,.5),(0x4c,.25),(0x50,.25)]:u.mem_write(shared+off,struct.pack('<f',value))
u.mem_write(shared+0x58,b'\0');native_worker[0]=True
for i in [0,31,63,64,95,127]:
 u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,SP+0x72a0+i*8);run(0x433df8a0,0x433df942)
 x=struct.unpack('<f',struct.pack('<I',u.reg_read(UC_X86_REG_XMM4)&0xffffffff))[0]
 y=struct.unpack('<f',struct.pack('<I',u.reg_read(UC_X86_REG_XMM1)&0xffffffff))[0]
 assert abs(x-i/2000)<1e-7 and abs(y-(127-i)/1000)<1e-7,(i,x,y)
native_worker[0]=False
# Exact native pending-damage helper + the compiled finisher choose lethal
# torso over nonlethal head only for a valid second command and matched target.
put(ctx,0x400);put(job,0);put(job+4,5);put(job+8,40);put(selected,pool)
for off,value in [(0x1c,20),(0x24,1),(0x34,0x14)]:put(pool+off,value)
for off,value in [(0x1c,45),(0x24,2),(0x34,0x14)]:put(pool+56+off,value)
assert call('dt_finisher_probe',[job,pool,112,selected,0xff,ctx])==1
assert word(selected)==pool+56 and word(job)&8 and bytes(u.mem_read(job+0x44,56))==bytes(u.mem_read(pool,56))
put(job,0);put(selected,pool);put(entry+0x94,6);assert call('dt_finisher_probe',[job,pool,112,selected,0xff,ctx])==0;put(entry+0x94,5)
put(job+8,39);assert call('dt_finisher_probe',[job,pool,112,selected,0xff,ctx])==0;put(job+8,40)
put(pool+56+0x1c,39);assert call('dt_finisher_probe',[job,pool,112,selected,0xff,ctx])==0;put(pool+56+0x1c,45)
put(pool+0x1c,40);assert call('dt_finisher_probe',[job,pool,112,selected,0xff,ctx])==0;put(pool+0x1c,20)
# The production scan-worker bridge reaches the registered DT finisher.
put(job,0);call('dt_bind_body_probe')
for off,value in [(0x18,pool),(0x28,0xff),(0x5c,job),(0x47e0,pool),(0x47e4,pool+112)]:put(SP+off,value)
u.reg_write(UC_X86_REG_ECX,SP);u.reg_write(UC_X86_REG_EDX,ctx);call('dt_body_probe')
assert word(SP+0x18)==pool+56 and word(job)&8
# The actual original retry branch retains the old head point on HC failure.
put(job,8);u.mem_write(job+0x44,bytes(u.mem_read(pool,56)));put(SP+0x18,job);put(SP+0x14,ctx);put(SP+0xa0,frame)
u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_EDI,ctx);retry[0]=True;run(0x43354b62,0x43354bf4);retry[0]=False;assert not(word(job)&8) and word(job+0x30)==1
# Disable/invalid mode must return to the exact original HC profile.
put(ctrl+0xf4,0);capture(104,0,0);assert profile()==(64,.5)
report={'implementation_sha256':{name:hashlib.sha256((ROOT/'source/skeet'/name).read_bytes()).hexdigest() for name in ['dt_accuracy.h','dt_accuracy_client.h','dt_accuracy_patch.h','body_preference.h']},'passed':True,'portable_cases':portable_cases,'native_charge_to_mode_writer':True,'native_controller_tail_and_fastcall_abi':True,'native_rage_hc_profile_executed':True,'native_first_lethal_sample_count_preserved':True,'native_dt_followup_with_one_round':True,'native_context_copy_preserves_command_stream':True,'native_cooldown_and_owner_fallback':True,'gpr_sse_and_mxcsr_preserved':True,'native_task_descriptors_initialized':128,'native_serial_tasks_executed':len(tasks),'original_worker_seed_address_cases':6,'task_stack_bounds_canaries':True,'original_snapshots_preserved':True,'native_pending_damage_helper_executed':True,'pending_target_and_health_mismatch_rejected':True,'native_backup_retry_executed':True,'production_scan_bridge_dt_finisher_connected':True,'minimum_dt_chance':.75,'samples':128,'task_array_offset':'0x72a0','frame_size':'0x7698','new_owned_instruction_bytes':66,'game_tested':False,'scope':'Closed x86 execution; entity list, client module lookup, memory queries and expensive individual trace tasks are controlled boundaries.'}
(BUILD/'dt_accuracy_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
