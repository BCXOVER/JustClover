#!/usr/bin/env python3
"""Static checks for the actual release DLL/EXE and exact embedded input bytes."""
from pathlib import Path
import hashlib
import json
import struct
import pefile

ROOT = Path(__file__).resolve().parents[1]

def sha(data): return hashlib.sha256(data).hexdigest()
def inspect(name, dll):
    path = ROOT/'build'/name
    pe = pefile.PE(str(path))
    assert pe.FILE_HEADER.Machine == 0x14c
    assert pe.OPTIONAL_HEADER.Magic == 0x10b
    assert pe.is_dll() == dll
    entry = pe.OPTIONAL_HEADER.AddressOfEntryPoint
    assert entry > 0
    section = pe.get_section_by_rva(entry)
    assert section and section.Characteristics & 0x20000000
    assert pe.OPTIONAL_HEADER.DllCharacteristics & 0x140 == 0x140
    assert getattr(pe,'DIRECTORY_ENTRY_BASERELOC',[])
    imports = {i.dll.decode():[x.name.decode() if x.name else x.ordinal for x in i.imports]
               for i in pe.DIRECTORY_ENTRY_IMPORT}
    assert not any(x.lower().startswith(('libc++','libstdc++','libgcc','vcruntime','msvcp')) for x in imports)
    return pe, {'file':name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'machine':'i386 PE32',
                'image_base':hex(pe.OPTIONAL_HEADER.ImageBase),'entry_point_rva':hex(entry),
                'aslr':True,'nx_compatible':True,'imports':imports,'pefile_warnings':pe.get_warnings()}

def main():
    dll, dll_report = inspect('skeet.dll',True)
    injector, injector_report = inspect('injector.exe',False)
    symbols = {s.name.decode():s.address for s in dll.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
    assert 'skeet_loader_status' in symbols
    status_rva = symbols['skeet_loader_status']
    status = dll.get_data(status_rva,256)
    assert len(status) == 256 and struct.unpack_from('<III',status) == (1,0,0)
    assert b'Waiting for game modules\0' in status
    section = dll.get_section_by_rva(status_rva)
    assert section and section.Characteristics & 0x80000000
    dll_report['loader_status_export_rva'] = hex(status_rva)
    expected = {('BINARY',102):ROOT/'source/skeet/Binary/skeet_cv.bin',
                ('BYTECODE',103):ROOT/'source/skeet/VM/bytecode.json',
                ('EXPORTS',101):ROOT/'source/skeet/Binary/exports.json'}
    resources = []
    for kind in dll.DIRECTORY_ENTRY_RESOURCE.entries:
        for item in kind.directory.entries:
            key = (str(kind.name), item.id)
            assert key in expected, key
            for lang in item.directory.entries:
                data = dll.get_data(lang.data.struct.OffsetToData,lang.data.struct.Size)
                original = expected[key].read_bytes()
                assert data == original, key
                resources.append({'type':key[0],'id':key[1],'language':lang.id,'bytes':len(data),'sha256':sha(data)})
    assert len(resources) == 3
    dll_report['resources'] = resources
    raw = expected[('BINARY',102)].read_bytes()
    dll_bytes=(ROOT/'build/skeet.dll').read_bytes()
    removed_labels=['Patch: history guard','Patch: strict hit chance','Patch: 64-sample hit chance','Patch: consistent records',
                  'Patch: coherent interpolation','Interpolation gap (ticks)','Patch: adaptive extrapolation',
                  'Extrapolation horizon (ticks)','Patch: bounded backtrack','BT depth (ms)']
    for label in removed_labels:
        assert label.encode('utf-16le') not in dll_bytes,label
    for label in ['Sync Skinchanger selections','Local inventory','Local items','Back to skinchanger','Apply name tag','Add to local CS:GO inventory','Equip selected item locally','Apply RGB palette']:
        assert (label+'\0').encode('utf-16le') not in dll_bytes,label
    for label in ['Name tag','Skin colors']:
        assert (label+'\0').encode('utf-16le') in dll_bytes,label
    assert 'VERDANT'.encode('utf-16le') not in dll_bytes
    assert raw[0x741a7:0x741aa] == bytes.fromhex('ff5024')
    assert raw[0x741bc:0x741bf] == bytes.fromhex('ff5028')
    required = {'CreateRemoteThread','WriteProcessMemory','ReadProcessMemory','VirtualAllocEx',
                'VirtualFreeEx','IsWow64Process','WaitForSingleObject','GetExitCodeThread'}
    imported = {name for names in injector_report['imports'].values() for name in names}
    assert required <= imported
    required_modules=['scan_patch','precision_patch','motion_patch','motion_plan','motion_records','motion_trace','motion_settings','motion_blend_sites','record_eligibility','body_preference','body_preference_patch','local_inventory','local_inventory_client','local_inventory_ui','inventory_catalog','helper_icon_data','skin_mirror','skin_mirror_ui','skin_native_state','skin_native_client','local_loadout','local_loadout_client','local_client_interfaces','local_weapon_names','agent_inventory_client','dt_accuracy','dt_accuracy_client','dt_accuracy_patch']
    main_source=(ROOT/'source/skeet/skeet.cpp').read_text()
    for module in required_modules:
        assert (ROOT/'source/skeet'/(module+'.h')).exists(),module
    install_sites=[main_source.index(module+'::apply(') for module in ['scan_patch','precision_patch','motion_patch','body_preference_patch','dt_accuracy_patch']]
    assert install_sites==sorted(install_sites)
    assert install_sites[-1] < main_source.index('cs2_visuals::install(') < main_source.index('    recompile();')
    assert not (ROOT/'source/skeet/backtrack_patch.h').exists()
    assert 'cs2_visuals::install' in main_source
    ui_source=(ROOT/'source/skeet/cs2_visuals_impl.h').read_text()
    assert 'native_layout_state::fixed' in ui_source
    assert 'preview_toggle' not in ui_source and 'appearance_enabled' not in ui_source
    for label in ['Player color preset','Teammate color preset','Local player color preset','Weapon viewmodel color preset','Glacier','Amethyst','Crimson','Champagne']:
        assert (label+'\0').encode('utf-16le') not in dll_bytes,label
    for label in ['Illustrated appearance preview','Enemy ESP preview','Team ESP preview','Local player preview','Weapon viewmodel preview','Manage elements']:
        assert label.encode('utf-16le') not in dll_bytes,label
    for token in ['appearance_preview::','appearance_reserve_width','preview_window_input','agent_preview']:
        assert token not in ui_source,token
    for path in ['appearance_preview_impl.h','appearance_preview_design.h','preview_window_input.h','agent_preview_native.h','agent_preview_plan.h']:
        assert not (ROOT/'source/skeet'/path).exists(),path
    import subprocess
    subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/test_core_image.cpp'),'-o',str(ROOT/'build/test_core_image')],check=True)
    subprocess.run([str(ROOT/'build/test_core_image'),str(expected[('BINARY',102)])],check=True)
    subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/skin_menu_plan.cpp'),'-o',str(ROOT/'build/skin_menu_plan')],check=True)
    subprocess.run([str(ROOT/'build/skin_menu_plan'),str(ROOT/'build/skin_menu_layout.json')],check=True)
    subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/combined_patch_plan.cpp'),'-o',str(ROOT/'build/combined_patch_plan')],check=True)
    subprocess.run([str(ROOT/'build/combined_patch_plan'),str(expected[('BINARY',102)])],check=True)
    for name in ['precision_validation','motion_validation','scan_patch_validation','visuals_validation','body_preference_validation','inventory_validation','inventory_ui_validation','skin_mirror_validation','skin_mirror_selection_validation','skin_native_validation','dt_accuracy_validation']:
        assert json.loads((ROOT/'build'/(name+'.json')).read_text())['passed'],name
    assert json.loads((ROOT/'build/visuals_validation.json').read_text())['native_renderer_depth_abi_cases']==10
    report = {'passed' :True,'artifacts':[dll_report,injector_report],
              'embedded_core':'original resources preserved; guarded runtime scan, precision, motion and presentation patches before checksum',
              'required_gameplay_modules':required_modules,'combined_patch_plan_allocations':5,'combined_owned_instruction_bytes':154,
              'lethal_torso_preference_integrated':True,'native_backup_hitchance_retry_preserved':True,'custom_hit_chance_patch':True,'precision_samples':128,'spatial_multipoints_increased':False,
              'consistent_records_integrated':True,'coherent_interpolation_integrated':True,
              'prediction_module_integrated':True,'bounded_backtrack_integrated':False,
              'native_rage_checkboxes':0,'native_rage_sliders':0,'custom_patch_controls_registered':False,
              'removed_labels_absent_in_dll':removed_labels,'native_lower_backtrack_window_preserved':True,'desync_60_added':False,
              'helper_icon':'round grenade','extra_sync_checkboxes':0,'weapon_skin_native_callback_connected':True,'local_inventory_editor_required_for_sync':False,'skinchanger_native_state_mirror':True,'all_saved_presets_auto_enumerated':True,'native_profile_count':65,'native_config_hook_instruction_bytes':8,'native_presentation_hook_instruction_bytes':15,'config_completion_observer':True,'max_inventory_changes_per_frame':4,'agent_inventory_added':True,'knife_model_independent_of_paint_origin':True,'filter_affects_inventory_snapshot':False,'local_loadout_equip_added':True,'stattrak_mirror_added':True,'stattrak_initial_counter':0,
              'menu_style':'Native Visuals with dynamic Helper and Skinchanger with inline name tag and four automatic color pickers',
              'visuals_native_bindings_integrated':True,'visuals_refresh_after_lua_changes':True,
              'supersampled_category_icons':True,'skinchanger_restyled':True,
              'skin_panels':['Model customization','Weapon skin','Settings'],
              'native_child_vtable_slots':13,'resize_dpi_dispatch_preserved':True,'canonical_sizes_preserved':True,
              'appearance_preview_added':False,'appearance_preview_removed':True,'preview_panel_reserved':False,'preview_always_open_in_visuals':False,'preview_model_and_controls_together':False,'native_preset_controls_added':False,'native_preset_controls_removed':True,'preview_native_category_render_pass':False,'preview_uses_game_models':False,'new_game_shaders_added':False,'native_renderer_depth_xmm0_abi_fixed':True,
              'legacy_rarity_colors_integrated':True,'rarity_data_source_commit':'e63fc7fdb8dfb4f1873f0db214c0cc16613d5beb',
              'skin_selected_values_and_source_callbacks_preserved':True,'skin_geometry_cases':54,
              'local_inventory_changer_added':True,'local_inventory_page_removed':True,'inline_name_tag':True,'inline_rgb_pickers':4,'manual_add_equip_apply_buttons':0,'local_inventory_persistent':False,'local_inventory_steam_items':False,'inventory_owns_only_its_items':True,'native_inventory_rgb_palette_shared_by_kit':True,'helper_category_added':True,'helper_detection':'exact live Helper checkbox','skin_peer_sync_added':False,'inventory_functions_game_tested':False,'native_gc_equip_intercepted':False,'protected_skin_engine_replaced':False,
              'full_cs2_menu_replica':False,'windows_loader_tested':False,'game_tested':False,
              'limits':['No target game client was available for runtime/visual verification.',
                        'Original protected core and wrapper compatibility fixes remain.',
                        'Compiler warnings from unused original SDK functions remain in build/dll.log.']}
    (ROOT/'build/release_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PE32 DLL/EXE, entry points, relocations, status export and all three exact resources: PASS')
if __name__=='__main__': main()
