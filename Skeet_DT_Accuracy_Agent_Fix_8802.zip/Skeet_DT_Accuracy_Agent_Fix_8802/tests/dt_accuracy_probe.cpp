#include "../source/skeet/pch.h"
#include "../source/skeet/dt_accuracy_client.h"
extern "C" {
__declspec(dllexport) void dt_bind_body_probe(){body_preference::two_bullet=&dt_accuracy_client::finish;}
__declspec(dllexport) void __fastcall dt_body_probe(unsigned char* stack,const void* shooter){body_preference::bridge(stack,shooter);}

__declspec(dllexport) void __fastcall dt_profile_probe(unsigned char* stack,const void* frame,void* fx){dt_accuracy_client::profile(stack,frame,fx);}
__declspec(dllexport) void __fastcall dt_capture_probe(void* context,void* controller,void* command){dt_accuracy_client::capture(context,controller,command);}
__declspec(dllexport) int dt_finisher_probe(void* job,void* pool,unsigned bytes,const unsigned char** selected,unsigned mask,void* context){return dt_accuracy_client::finish(job,static_cast<const unsigned char*>(pool),bytes,*selected,mask,context);}
__declspec(dllexport) void dt_state_reset_probe(){for(auto& s:dt_accuracy_client::slots)s={};dt_accuracy_client::replacement=0;}
}
