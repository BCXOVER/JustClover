#include "../source/skeet/dt_accuracy.h"
#include "../source/skeet/dt_accuracy_patch.h"
#include <cassert>
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>
using namespace dt_accuracy;
int main(int argc,char** argv) {
 unsigned cases=0;
 for(int mode:{0,1,2,3})for(int charged:{0,7,12,15})for(int ready:{0,1,2}) {
  Window w;Command c{100,123,38,mode,ready,charged,12,true};w.observe(c);assert(w.active==(mode==2&&ready==2&&charged>=12));++cases;
 }
 Window w;Command c{100,123,38,2,2,15,12,true};w.observe(c);assert(w.matches(100,123,38)&&!w.matches(100,123,38,true));
 c.number++;c.charged--;w.observe(c);assert(w.matches(101,123,38,true));
 c.number++;c.native_ready=0;c.charged=0;w.observe(c);assert(w.matches(102,123,38,true));
 for(unsigned n=103;n<=112;n++){c.number=n;w.observe(c);assert(w.matches(n,123,38,true));}
 c.number=113;w.observe(c);assert(!w.active);cases+=14;
 // Re-prediction may visit the same command repeatedly; spending charge on
 // that command must still arm the next one, without erasing the window.
 Window repeat;Command r{100,123,38,2,2,15,12,true};repeat.observe(r);repeat.observe(r);assert(repeat.matches(100,123,38));
 r.charged=0;r.native_ready=0;repeat.observe(r);r.number++;repeat.observe(r);assert(repeat.matches(101,123,38,true));repeat.observe(r);assert(repeat.matches(101,123,38,true));cases+=3;
 for(int change=0;change<5;change++) {
  Window v;Command a{100,123,38,2,2,15,12,true};v.observe(a);a.number++;a.charged--;
  if(change==0)a.weapon=999;if(change==1)a.definition=11;if(change==2)a.number=105;if(change==3)a.mode=0;if(change==4)a.valid=false;
  v.observe(a);assert(!v.matches(101,123,38,true));++cases;
 }
 for(float chance:{0.f,.5f,.75f,.9f,1.f})for(unsigned hp:{1,40,100,1000})for(unsigned damage:{0,1,39,40,100})for(bool enabled:{false,true}) {
  auto p=profile(enabled,false,hp,damage,chance,.01f,.01f);const bool expected=enabled&&hp<=100&&damage&&damage<hp;assert(p.active==expected);
  if(expected){assert(p.chance_samples==128&&p.chance>=chance&&p.chance>=.75f);}else assert(!p.chance_samples&&p.chance==chance);++cases;
 }
 for(float bad:{-1.f,1.1f,INFINITY,NAN}){assert(!profile(true,false,100,50,.5f,bad,.01f).active);assert(!profile(true,false,100,50,bad,.01f,.01f).active);cases+=2;}
 unsigned char job[512]{},pool[112]{};const auto put=[](void* p,unsigned off,unsigned x){std::memcpy(static_cast<unsigned char*>(p)+off,&x,4);};
 for(unsigned hp:{35,100})for(int first:{0,20,35,60,99,100})for(unsigned damage:{0,19,39,40,99,100})for(unsigned group:{1,2,3,6,7}) {
  std::memset(job,0,sizeof(job));std::memset(pool,0,sizeof(pool));put(job,4,5);put(job,8,hp);put(pool,0x1c,10);put(pool,0x24,1);put(pool,0x34,0x14);put(pool+56,0x1c,damage);put(pool+56,0x24,group);put(pool+56,0x34,0x14);
  const unsigned char* selected=pool;const bool expected=first>0&&first<int(hp)&&damage>=hp-unsigned(first)&&(group==2||group==3)&&hp-unsigned(first)>10;
  put(job,8,first<int(hp)?hp-unsigned(first):1000);assert(finish(job,pool,112,selected,0xff,0x400,5,first,int(hp))==expected);
  if(expected){assert(selected==pool+56&&(body_preference::u32(job,0)&8));assert(std::memcmp(job+0x44,pool,56)==0);}++cases;
 }
 if(argc==4) {
  std::ifstream input(argv[1],std::ios::binary);std::vector<unsigned char> image((std::istreambuf_iterator<char>(input)),{});dt_accuracy_patch::Plan p{};
  assert(dt_accuracy_patch::make(image.data(),image.size(),unsigned(std::stoul(argv[3],nullptr,0)),0x11223344,0x55667788,p));
  for(auto e:p.edits){auto corrupt=image;corrupt[e.offset]^=1;dt_accuracy_patch::Plan rejected{};assert(!dt_accuracy_patch::make(corrupt.data(),corrupt.size(),0x10000000,1,2,rejected));++cases;}
  std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<char*>(&p),sizeof(p));
 }
 std::cout<<cases<<" DT state, lethal bypass, exact pending-damage finish and guarded plan cases passed\n";
}
