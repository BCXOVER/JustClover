#pragma once
#include "dt_accuracy.h"
#include "local_client_interfaces.h"
#include <atomic>
namespace dt_accuracy_client {
using local_inventory_client::memory;using local_inventory_client::pointer;using local_inventory_client::read32;
struct Slot {void* owner=nullptr;dt_accuracy::Window window{};};
inline Slot slots[32]{};inline std::atomic_flag busy=ATOMIC_FLAG_INIT;inline unsigned replacement=0;
inline bool lock(){return !busy.test_and_set(std::memory_order_acquire);}inline void unlock(){busy.clear(std::memory_order_release);}
inline float number(const void* p,unsigned off){float f;std::memcpy(&f,static_cast<const unsigned char*>(p)+off,4);return f;}
inline bool client_layout() {
 auto* b=reinterpret_cast<unsigned char*>(GetModuleHandleW(L"client.dll"));if(!memory(b,0x1000)||*reinterpret_cast<unsigned short*>(b)!=IMAGE_DOS_SIGNATURE)return false;
 const auto pe=read32(b,0x3c);if(pe>0x800||!memory(b+pe,sizeof(IMAGE_NT_HEADERS32)))return false;
 auto* nt=reinterpret_cast<IMAGE_NT_HEADERS32*>(b+pe);
 if(nt->Signature!=IMAGE_NT_SIGNATURE||nt->FileHeader.TimeDateStamp!=0x65272025||nt->FileHeader.Machine!=IMAGE_FILE_MACHINE_I386||nt->OptionalHeader.SizeOfImage!=0x5509000)return false;
 struct Field {unsigned rva,value;};constexpr Field fields[]={{0x6f33,0x3274},{0x647b,0x3248},{0xa8ab,0x2d80},{0x3a7b8,0x100}};
 for(auto f:fields)if(b[f.rva]!=0xc7||b[f.rva+1]!=5||read32(b,f.rva+6)!=f.value)return false;return true;
}
inline bool weapon_state(const void* context,int& ammo,bool& can_shoot) {
 can_shoot=false;ammo=0;if(!memory(context,0x1e0)||!client_layout())return false;
 auto* player=pointer(context,0xc);auto* weapon=pointer(context,0x10);
 if(!memory(player,0x2d84)||!memory(weapon,0x3278))return false;
 const auto definition=*reinterpret_cast<unsigned short*>(static_cast<unsigned char*>(weapon)+0x2fba);
 if(definition!=read32(context,0xd8))return false;
 auto* entities=local_client_interfaces::core_interface(0x4346a890);auto* get=local_client_interfaces::method(entities,4);if(!get)return false;
 using Get=void*(__thiscall*)(void*,unsigned);if(reinterpret_cast<Get>(get)(entities,read32(weapon,0x14c))!=player)return false;
 ammo=int(read32(weapon,0x3274));if(ammo<0||ammo>200)return false;
 auto* interval=local_client_interfaces::core_interface(0x4346a338);if(!memory(interval,4))return false;
 const float dt=number(interval,0);const int tick=int(read32(context,0xc8));
 const float primary=number(weapon,0x3248),attack=number(player,0x2d80);
 if(!std::isfinite(dt)||dt<.001f||dt>.1f||tick<0||tick>100000000||!std::isfinite(primary)||!std::isfinite(attack))return false;
 const float time=tick*dt;can_shoot=ammo>0&&primary<=time&&attack<=time;return true;
}
inline void __fastcall capture(void* context,void* controller,void* command) {
 dt_accuracy::Command c{};void* owner=nullptr;
 if(memory(context,0x1e0)&&memory(controller,0x108)&&memory(command,0x34)) {
  owner=pointer(context,0xc);c.number=read32(command,4);c.weapon=read32(context,0x10);c.definition=int(read32(context,0xd8));c.mode=int(read32(controller,0xf4));c.native_ready=int(read32(context,0x1d4));c.charged=int(read32(controller,0x104));c.required=int(read32(controller,0xfc));
  // Both the finalized native context and its user command must identify this invocation.
  c.valid=owner&&c.number==read32(context,0xac)&&c.weapon&&c.definition>0&&c.definition<65536;
 }
 if(!lock())return;Slot* found=nullptr;for(auto& s:slots)if(s.owner==owner){found=&s;break;}
 if(!found)for(auto& s:slots)if(!s.owner){found=&s;break;}
 if(!found)found=&slots[replacement++%32];if(found->owner!=owner){*found={};found->owner=owner;}
 found->window.observe(c);unlock();
}
inline bool active(const void* context,bool followup=false) {
 if(!memory(context,0x1e0))return false;auto* owner=pointer(context,0xc);if(!owner||!lock())return false;bool result=false;
 for(const auto& s:slots)if(s.owner==owner){result=s.window.matches(read32(context,0xac),read32(context,0x10),int(read32(context,0xd8)),followup);break;}
 unlock();if(!result)return false;int ammo=0;bool shoot=false;
 if(!weapon_state(context,ammo,shoot)||!shoot)return false;
 return ammo>=(followup?1:2);
}
inline void __fastcall profile(unsigned char* stack,const void* frame,void* fx) {
 if(!memory(frame,0x10)||!memory(stack,0x14,true)||!memory(fx,512,true))return;
 auto* shooter=pointer(frame,8);auto* job=pointer(frame,12);
 if(!memory(shooter,0x1e0)||!memory(job,0xd8))return;
 const bool followup=active(shooter,true);const bool on=followup||active(shooter,false);
 const auto plan=dt_accuracy::profile(on,followup,read32(job,8),read32(job,0x28),number(fx,160),number(shooter,0xc4),number(shooter,0xd0));
 if(plan.active){std::memcpy(stack+0x10,&plan.chance_samples,4);std::memcpy(static_cast<unsigned char*>(fx)+160,&plan.chance,4);}
}
inline bool finish(void* job,const unsigned char* begin,std::size_t bytes,const unsigned char*& selected,unsigned mask,const void* shooter) {
 if(!active(shooter,true)||!memory(job,0xdc))return false;
 int target=-1,pending=-1;using Pending=bool(__fastcall*)(int*,int*);
 if(!reinterpret_cast<Pending>(0x4341f16e)(&target,&pending)||target!=int(read32(job,4)))return false;
 auto* entities=local_client_interfaces::core_interface(0x4346a890);auto* get=local_client_interfaces::method(entities,3);if(!get||target<1||target>64)return false;
 using Get=void*(__thiscall*)(void*,unsigned);auto* player=reinterpret_cast<Get>(get)(entities,unsigned(target));if(!memory(player,0x104))return false;
 return dt_accuracy::finish(job,begin,bytes,selected,mask,read32(shooter,0),target,pending,int(read32(player,0x100)));
}
}
