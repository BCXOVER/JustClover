#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cmath>
// Verified layout of the native Rage scan worker's *already evaluated* points.
// A point is 14 dwords. The job's primary is +0x0c, backup is +0x44.
namespace body_preference {
inline constexpr std::size_t point_size=0x38;
inline std::uint32_t u32(const void* p,std::size_t off){std::uint32_t v;std::memcpy(&v,static_cast<const unsigned char*>(p)+off,4);return v;}
inline void put(void* p,std::size_t off,std::uint32_t v){std::memcpy(static_cast<unsigned char*>(p)+off,&v,4);}
inline bool coordinates(const unsigned char* p) {
    for(int i=0;i<3;i++){float f;std::memcpy(&f,p+4*i,4);if(!std::isfinite(f)||std::fabs(f)>32768.f)return false;}
    return true;
}
inline bool promote(void* job,const unsigned char* begin,std::size_t bytes,
                    const unsigned char*& selected,std::uint32_t priority_mask,std::uint32_t shooter_flags) {
    if(!job||!begin||!selected||!bytes||bytes%point_size||bytes/point_size>4096)return false;
    const auto first=reinterpret_cast<std::uintptr_t>(begin),at=reinterpret_cast<std::uintptr_t>(selected);
    if(at<first||at-first>=bytes||(at-first)%point_size)return false;
    // Only the native callers with this flag implement their backup HC retry.
    // Keep pre-existing alternates and every native scan eligibility mask.
    if(!(shooter_flags&0x400)||(u32(job,0)&0x18))return false;
    const auto health=u32(job,8),group=u32(selected,0x24);
    if(!health||health>1000||(group!=6&&group!=7)||!u32(selected,0x1c)||!coordinates(selected))return false;
    const auto baseline=u32(selected,0x34)&priority_mask;
    const unsigned char* best=nullptr;std::uint32_t score=0,damage=0;
    for(std::size_t off=0;off<bytes;off+=point_size) {
        const auto* point=begin+off;const auto hitgroup=u32(point,0x24),d=u32(point,0x1c),s=u32(point,0x34)&priority_mask;
        if((hitgroup!=2&&hitgroup!=3)||d<health||d>10000||s<baseline||!coordinates(point))continue;
        if(!best||s>score||(s==score&&d>damage)){best=point;score=s;damage=d;}
    }
    if(!best)return false;
    // The caller's existing HC failure branch consumes this same backup format.
    std::memcpy(static_cast<unsigned char*>(job)+0x44,selected,point_size);
    put(job,0,u32(job,0)|8);selected=best;return true;
}
#ifdef _WIN32
using TwoBullet=bool(*)(void*,const unsigned char*,std::size_t,const unsigned char*&,unsigned,const void*);
inline TwoBullet two_bullet=nullptr;
inline void __fastcall bridge(unsigned char* stack,const void* shooter) {
    const auto first=u32(stack,0x47e0),end=u32(stack,0x47e4);
    if(!shooter||end<first)return;
    auto* job=reinterpret_cast<void*>(u32(stack,0x5c));
    const auto* selected=reinterpret_cast<const unsigned char*>(u32(stack,0x18));
    if(promote(job,reinterpret_cast<const unsigned char*>(first),end-first,selected,u32(stack,0x28),u32(shooter,0))||(two_bullet&&two_bullet(job,reinterpret_cast<const unsigned char*>(first),end-first,selected,u32(stack,0x28),shooter)))
        put(stack,0x18,static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(selected)));
}
#endif
}
