#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cmath>
#include "body_preference.h"
namespace dt_accuracy {
inline constexpr unsigned samples=128;
inline constexpr float minimum_chance=.75f;
struct Command {
 std::uint32_t number=0,weapon=0;int definition=0,mode=0,native_ready=0,charged=0,required=0;
 bool valid=false;
};
struct Window {
 Command last{};unsigned first=0,horizon=0;bool armed=false,spent=false,active=false;
 void observe(const Command& c) {
  if(!c.valid||(c.native_ready!=0&&c.native_ready!=2)||c.mode!=2||!c.number||!c.weapon||c.required<1||c.required>15||c.charged<0||c.charged>64){*this={};return;}
  const bool repeated=last.valid&&last.weapon==c.weapon&&last.definition==c.definition&&c.number==last.number;
  if(repeated) {
   if(armed&&c.charged<last.charged)spent=true;
   if(c.charged>last.charged){armed=spent=false;}
   if(!armed&&c.native_ready==2&&c.charged>=c.required){first=c.number;horizon=unsigned(c.required);armed=true;spent=false;}
   active=armed&&(c.native_ready==2||(spent&&c.number>first));last=c;return;
  }
  const bool continuity=last.valid&&last.weapon==c.weapon&&last.definition==c.definition&&c.number==last.number+1;
  if(!continuity){armed=spent=active=false;}
  const bool decreasing=continuity&&c.charged<last.charged;
  const bool replenishing=continuity&&c.charged>last.charged;
  const bool in_window=armed&&c.number>=first&&c.number-first<=horizon;
  if(c.native_ready==2&&c.charged>=c.required&&(!in_window||replenishing||(!spent&&!decreasing))) {
   first=c.number;horizon=unsigned(c.required);armed=true;spent=false;
  }else if(!in_window||replenishing){armed=spent=false;}
  if(armed&&decreasing)spent=true;
  active=armed&&(c.native_ready==2||(spent&&c.number>first));last=c;
 }
 bool matches(unsigned number,unsigned weapon,int definition,bool followup=false)const {
  return active&&last.number==number&&last.weapon==weapon&&last.definition==definition&&(!followup||(spent&&number>first));
 }
};
struct Profile {bool active=false,followup=false;unsigned chance_samples=0;float chance=0;};
inline bool valid_chance(float x){return std::isfinite(x)&&x>=0.f&&x<=1.f;}
inline Profile profile(bool active,bool followup,unsigned health,unsigned damage,float chance,float inaccuracy,float spread) {
 Profile p{false,followup,0,chance};
 // A lethal single shot retains its native threshold and original sample count.
 if(!active||!health||health>100||!damage||damage>10000||(damage>=health&&!followup)||!valid_chance(chance)||!valid_chance(inaccuracy)||!valid_chance(spread))return p;
 p.active=true;p.chance_samples=samples;p.chance=(std::fmax)(chance,minimum_chance);return p;
}
inline bool finish(void* job,const unsigned char* begin,std::size_t bytes,const unsigned char*& selected,unsigned mask,unsigned shooter_flags,int pending_target,int pending_damage,int live_health) {
 using namespace body_preference;
 if(!job||!begin||!selected||!bytes||bytes%point_size||bytes/point_size>4096||!(shooter_flags&0x400)||(body_preference::u32(job,0)&0x18))return false;
 const auto first=reinterpret_cast<std::uintptr_t>(begin),at=reinterpret_cast<std::uintptr_t>(selected);
 if(at<first||at-first>=bytes||(at-first)%point_size)return false;
 const int remaining=int(body_preference::u32(job,8));const int target=int(body_preference::u32(job,4));
 const int hp=live_health>100?100:live_health;
 // Use the exact native pending-damage reduction; never invent 2 * first damage.
 if(target!=pending_target||pending_damage<1||hp<1||pending_damage>=hp||remaining!=hp-pending_damage||remaining<1||remaining>100)return false;
 const auto damage=body_preference::u32(selected,0x1c),group=body_preference::u32(selected,0x24);
 if(!coordinates(selected)||!damage||damage>=unsigned(remaining)||(group!=1&&group!=6&&group!=7))return false;
 const unsigned baseline=body_preference::u32(selected,0x34)&mask;const unsigned char* best=nullptr;unsigned score=0,best_damage=0;
 for(std::size_t off=0;off<bytes;off+=point_size) {
  const auto* p=begin+off;const auto g=body_preference::u32(p,0x24),d=body_preference::u32(p,0x1c),s=body_preference::u32(p,0x34)&mask;
  if((g!=2&&g!=3)||d<unsigned(remaining)||d>10000||s<baseline||!coordinates(p))continue;
  if(!best||s>score||(s==score&&d>best_damage)){best=p;score=s;best_damage=d;}
 }
 if(!best)return false;
 std::memcpy(static_cast<unsigned char*>(job)+0x44,selected,point_size);put(job,0,body_preference::u32(job,0)|8);selected=best;return true;
}
}
