#pragma once
#include "scan_patch.h"
#ifdef _WIN32
#include "dt_accuracy_client.h"
#endif
namespace dt_accuracy_patch {
inline constexpr unsigned profile_site=0x10bc00,capture_site=0xbe8ab,frame_site=0x10b4c8,loop_site=0x10c736;
inline constexpr unsigned task_start=0x72a0,frame_size=0x7698,code_size=768;
static_assert(task_start+128*8==frame_size+8);
struct Edit {unsigned offset=0,size=0;unsigned char before[20]{},after[20]{};};
struct Plan {unsigned char code[code_size]{};Edit edits[8]{};};
inline bool make(const unsigned char* image,std::size_t size,unsigned location,unsigned profile,unsigned capture,Plan& out) {
 if(!image||size!=scan_patch::image_size)return false;Plan p{};
 const unsigned char profile_before[]={0x33,0xd2,0x0f,0xb6,0x4c,0x24,0x0b,0xb8,0x80,0,0,0,0xf3,0x0f,0x10,0x87,0xd4,0,0,0};
 const unsigned char capture_before[]={0x5e,0x83,0xc4,0x1c,0xc2,8,0};
 const unsigned char frame_before[]={0x81,0xec,0x98,0x72,0,0};
 const unsigned char loop_before[]={0x83,0xf8,0x40,0x7c,0xe5};
 const unsigned char index_before[]={0x89,0x84,0xc4,0xd4,2,0,0},ptr_before[]={0x89,0x8c,0xc4,0xd0,2,0,0};
 const unsigned char dispatch_before[]={0x8d,0x84,0x24,0xd4,2,0,0},serial_before[]={0x8d,0xb4,0x24,0xd0,2,0,0};
 auto edit=[&](unsigned i,unsigned at,const unsigned char* before,unsigned n){if(std::memcmp(image+at,before,n))return false;auto& e=p.edits[i];e.offset=at;e.size=n;std::memcpy(e.before,before,n);std::memcpy(e.after,before,n);return true;};
 if(!edit(0,profile_site,profile_before,sizeof(profile_before))||!edit(1,capture_site,capture_before,sizeof(capture_before))||!edit(2,frame_site,frame_before,sizeof(frame_before))||!edit(3,loop_site,loop_before,sizeof(loop_before))||!edit(4,0x10c727,index_before,7)||!edit(5,0x10c72e,ptr_before,7)||!edit(6,0x10c7a7,dispatch_before,7)||!edit(7,0x10c7d3,serial_before,7))return false;
 const auto put=[](unsigned char* to,unsigned x){std::memcpy(to,&x,4);};
 const auto jump=[&](unsigned which,unsigned offset){auto& e=p.edits[which];std::memset(e.after,0x90,e.size);e.after[0]=0xe9;put(e.after+1,location+offset-(scan_patch::image_base+e.offset+5));};
 jump(0,0);jump(1,0x100);jump(3,0x200);put(p.edits[2].after+2,frame_size);
 for(unsigned i=4;i<8;i++)put(p.edits[i].after+3,task_start+((i==4||i==6)?4:0));
 unsigned n=0;
 const auto bytes=[&](const unsigned char* from,unsigned size){std::memcpy(p.code+n,from,size);n+=size;};
 const auto dword=[&](unsigned v){put(p.code+n,v);n+=4;};
 // Keep integer flags, registers and the complete x87/SSE state across helpers.
 const unsigned char save[]={0x9c,0x60,0x89,0xe6,0x81,0xec,0x10,2,0,0,0x83,0xe4,0xf0,0x0f,0xae,4,0x24};
 const unsigned char restore[]={0x0f,0xae,0x0c,0x24,0x89,0xf4,0x61,0x9d};
 const unsigned char load[]={0xf3,0x0f,0x10,0x87,0xd4,0,0,0};bytes(load,sizeof(load));bytes(save,sizeof(save));
 // fastcall profile(native ESP, EBP, FXSAVE*) owns the threshold XMM0 only.
 const unsigned char arguments[]={0x89,0xe0,0x50,0x8d,0x4e,0x24,0x89,0xea,0xb8};bytes(arguments,sizeof(arguments));dword(profile);const unsigned char call[]={0xff,0xd0};bytes(call,2);bytes(restore,sizeof(restore));bytes(profile_before,12);
 p.code[n++]=0xe9;dword(scan_patch::image_base+profile_site+20-(location+n+4));
 n=0x100;bytes(save,sizeof(save));
 // At the native tail ESP+0x28 is its second stack argument (CUserCmd*).
 const unsigned char capture_args[]={0xff,0x76,0x4c,0x8b,0x4e,0x18,0x8b,0x56,4,0xb8};bytes(capture_args,sizeof(capture_args));dword(capture);bytes(call,2);bytes(restore,sizeof(restore));bytes(capture_before,sizeof(capture_before));
 // 128 requires an imm32 compare: imm8 0x80 would mean signed -128.
 n=0x200;p.code[n++]=0x3d;dword(128);p.code[n++]=0x0f;p.code[n++]=0x8c;dword(scan_patch::image_base+0x10c720-(location+n+4));p.code[n++]=0xe9;dword(scan_patch::image_base+0x10c73b-(location+n+4));
 out=p;return true;
}
#ifdef _WIN32
inline bool apply(unsigned char* image,std::size_t size) {
 if(reinterpret_cast<unsigned>(image)!=scan_patch::image_base)return false;
 auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));if(!code)return false;Plan p{};
 if(!make(image,size,reinterpret_cast<unsigned>(code),reinterpret_cast<unsigned>(&dt_accuracy_client::profile),reinterpret_cast<unsigned>(&dt_accuracy_client::capture),p)){VirtualFree(code,0,MEM_RELEASE);SetLastError(ERROR_REVISION_MISMATCH);return false;}
 std::memcpy(code,p.code,sizeof(p.code));DWORD old=0;
 if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(p.code))){const auto error=GetLastError();VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;}
 for(auto& e:p.edits)std::memcpy(image+e.offset,e.after,e.size);
 if(!FlushInstructionCache(GetCurrentProcess(),image,size)) {const auto error=GetLastError();for(auto& e:p.edits)std::memcpy(image+e.offset,e.before,e.size);FlushInstructionCache(GetCurrentProcess(),image,size);VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;}
 body_preference::two_bullet=&dt_accuracy_client::finish;return true;
}
#endif
}
