#!/usr/bin/env python3
"""Static byte/layout audit of the pinned client and the DT patch's eight sites."""
from pathlib import Path
import hashlib,json,struct,re
ROOT=Path(__file__).resolve().parents[1];data=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes()
client=Path('/workspace/game-8802-modules/client.mapped.bin').read_bytes()
fields=[('clip',0x6f33,0x3274),('next_primary_attack',0x647b,0x3248),('next_attack',0xa8ab,0x2d80),('health',0x3a7b8,0x100)]
for _,at,value in fields:assert client[at:at+2]==b'\xc7\x05' and struct.unpack_from('<I',client,at+6)[0]==value
sites=[(0x10bc00,20),(0xbe8ab,7),(0x10b4c8,6),(0x10c736,5),(0x10c727,7),(0x10c72e,7),(0x10c7a7,7),(0x10c7d3,7)]
assert sum(n for _,n in sites)==66
# Existing host exception handlers must not replace any new instruction sites.
handler=(ROOT/'source/skeet/Binary/mem_int3.h').read_text();addresses=[int(x,16) for x in re.findall(r'0x([a-fA-F0-9]+)',handler)]
for offset,n in sites:assert not any(0x43310000+offset<=a<0x43310000+offset+n for a in addresses)
report={'passed':True,'core_sha256':hashlib.sha256(data).hexdigest(),'client_sha256':hashlib.sha256(Path('/workspace/game-8802-modules/client.dll').read_bytes()).hexdigest(),'recvprop_initializers':[{'field':name,'rva':hex(at),'offset':hex(value),'instruction':client[at:at+10].hex()} for name,at,value in fields],'sites':[{'address':hex(0x43310000+at),'bytes':data[at:at+n].hex(),'length':n} for at,n in sites],'new_instruction_bytes':66,'host_exception_handlers_do_not_overlap_new_sites':True,'game_tested':False}
(ROOT/'data/dt_native_layout_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
