"""Actual category-child preview rendering and native ESP/Win32 ownership checks."""
def check_appearance(ns):
    globals().update(ns)
    API=0x140000
    cases=0;render_cases=0
    for selected in [0,1,2,3]:
        u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',{'GetForegroundWindow':lambda u,sp:(0,4)})
        u.mem_map(API,0x1000)
        ctx,menu=MEM+0x10000,MEM+0x11000
        store(u,ctx+0x10,menu);store(u,menu+0x14,800);store(u,menu+0x18,700)
        store(u,menu+0x34,1);store(u,menu+0x64,3) # Visuals open; HWND and MenuAlpha intentionally zero.
        store(u,0x4346d490,fbits(1.))
        source_list,proxy_list,panel_list,name_list,anchor_list=[MEM+0x12000+i*0x1000 for i in range(5)]
        records=[];callbacks=[]
        for i,(label,kind) in enumerate([('Bounding box',3),('Flags',13)]):
            src=MEM+0x20000+i*0x1000;proxy=src+0x400;value=src+0x700;vt=src+0x800;pvt=src+0x900;text=src+0xa00
            for obj,table in [(src,vt),(proxy,pvt)]:
                store(u,obj,table);store(u,obj+0x5c,value);u.mem_write(obj+0x14,bytes([1,1,0,1,0,kind]))
            for table,slot,target in [(vt,5,API+0x100),(vt,7,API+0x120),(pvt,5,API+0x140)]:store(u,table+4*slot,target)
            u.mem_write(value,b'\0\xa5\xa5\xa5' if kind==3 else s32(8))
            u.mem_write(text,(label+'\0').encode('utf-16le'))
            for base,val in [(source_list,src),(proxy_list,proxy),(panel_list,0),(name_list,text),(anchor_list,text)]:store(u,base+4*i,val)
            if kind==13:
                variables=src+0xb00
                for off,val in [(0x80,variables),(0x84,variables+60),(0x88,variables+60)]:store(u,src+off,val)
                for j,mask in enumerate([1,8,0x40]):store(u,variables+20*j+16,mask)
            records.append((src,value))
        def callback(u,a,size,user):
            if a not in [API+0x100,API+0x120,API+0x140]:return
            sp=u.reg_read(UC_X86_REG_ESP);callbacks.append((a,u.reg_read(UC_X86_REG_ECX)))
            u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+4)
        u.hook_add(UC_HOOK_CODE,callback)
        call(u,exp('appearance_setup_probe'),[ctx,2,source_list,proxy_list,panel_list,name_list,anchor_list])
        call(u,exp('appearance_subject_probe'),[0])
        assert call(u,exp('appearance_toggle_probe'),[0])==1
        assert bytes(u.mem_read(records[0][1],4))==b'\1\xa5\xa5\xa5'
        assert call(u,exp('appearance_toggle_probe'),[7])==1 and word(u,records[1][1])==0
        assert call(u,exp('appearance_toggle_probe'),[7])==1 and word(u,records[1][1])==8
        u.mem_write(records[1][0]+0x6a,b'\1')
        assert call(u,exp('appearance_toggle_probe'),[7])==0 and word(u,records[1][1])==8
        assert callbacks
        renderer,vt,child,origin=MEM+0x70000,MEM+0x71000,MEM+0x72000,MEM+0x73000
        store(u,renderer,vt);store(u,origin,40);store(u,origin+4,60)
        methods={4:API+0x180,8:API+0x190,15:API+0x1a0,10:API+0x1c0,
                 24:API+0x200,25:API+0x220,26:API+0x240,27:API+0x260}
        for slot,address in methods.items():store(u,vt+slot*4,address)
        initial_bounds=[10,20,900,900];bounds=initial_bounds.copy();clipped=[True]
        painted=[];texts=[];triangles=[];native_draw=[];commands=[]
        def render(u,a,size,user):
            if a not in [*methods.values(),API+0x280]:return
            sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX);cleanup=4
            if a==API+0x280:
                assert this==child and [word(u,sp+4),word(u,sp+8)]==[renderer,origin]
                native_draw.append(True);cleanup=12
            else:
                assert this==renderer
                if a==API+0x180:
                    params=[word(u,sp+4*k) for k in range(1,6)];assert params[2]>0 and params[3]>0;painted.append(params);commands.append(['rect',*params]);cleanup=24
                elif a==API+0x190:commands.append(['line',*[word(u,sp+4*k) for k in range(1,6)]]);cleanup=24
                elif a==API+0x1c0:triangles.append([word(u,sp+4*k) for k in range(1,8)]);commands.append(['triangle',*triangles[-1]]);cleanup=32
                elif a==API+0x1a0:
                    assert u.reg_read(UC_X86_REG_EDX)==0
                    params=[word(u,sp+4*k) for k in range(1,7)];assert params[3]>0
                    texts.append(wide(u,params[4]));commands.append(['text',*params[:4],texts[-1]]);assert params[5]==len(texts[-1]);cleanup=28
                elif a==API+0x200:
                    ptr=u.reg_read(UC_X86_REG_EDX);bounds[:]=[word(u,ptr+4*k) for k in range(4)];clipped[0]=True
                elif a==API+0x220:
                    ptr=u.reg_read(UC_X86_REG_EDX)
                    for k,val in enumerate(bounds):store(u,ptr+4*k,val)
                elif a==API+0x240:clipped[0]=False
                elif a==API+0x260:u.reg_write(UC_X86_REG_EAX,int(clipped[0]))
            u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
        u.hook_add(UC_HOOK_CODE,render)
        call(u,exp('appearance_category_setup_probe'),[child,API+0x280])
        # Start in Enemy so native category change is synchronized, then test
        # every subject across repeat shrink/grow and DPI transitions.
        for width,height,dpi in [[(800,700,1.),(640,480,1.),(1000,800,1.5),(800,700,1.)][selected]]:
            store(u,menu+0x14,width);store(u,menu+0x18,height);store(u,0x4346d490,fbits(dpi))
            call(u,exp('appearance_subject_probe'),[selected]);painted.clear();texts.clear();triangles.clear();commands.clear()
            call(u,exp('child_draw_probe'),[renderer,origin],ecx=child,limit=120000000)
            assert native_draw and len(painted)>30 and len(triangles)>(200 if selected==3 else 1000)
            assert any('preview' in t for t in texts) and 'Manage elements' in texts
            assert all(t not in texts for t in ['Glacier','Amethyst','Crimson','Champagne','Color presets'])
            assert clipped[0] and bounds==initial_bounds
            if selected==0:(BUILD/'native_preview_draw_commands.json').write_text(json.dumps(commands))
            render_cases+=1
            print(f'Actual category preview rendered: subject={selected}, size={width}x{height}, dpi={dpi}',flush=True)
        call(u,exp('appearance_invalidate_probe'))
        for src,_ in records:u.mem_unmap(src,0x1000)
        assert call(u,exp('appearance_toggle_probe'),[0])==0
        cases+=1
    # Window procedures queue coordinates; they never invoke a native callback.
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll')
    def publish(x=100,y=100,show=1):call(u,exp('preview_publish_probe'),[x,y,280,500,show])
    def event(msg,x=120,y=130):return call(u,exp('preview_consume_probe'),[msg,(y<<16)|(x&0xffff)])
    def take():
        ret=call(u,exp('preview_take_probe'),[MEM+0x5000,MEM+0x5004]);return ret,word(u,MEM+0x5000),word(u,MEM+0x5004)
    publish();assert event(0x201)==1 and event(0x202)==1 and take()==(1,120,130);assert take()[0]==0
    for msg in [0x200,0x204,0x205,0x20a]:assert event(msg)==1
    assert take()[0]==0
    assert event(0x201,5,5)==0 and event(0x202)==0 and take()[0]==0
    assert event(0x201)==1 and event(0x202,5,5)==1 and take()[0]==0
    assert event(0x203)==1 and event(0x202)==1 and take()[0]==1
    assert event(0x201)==1 and event(0x202)==1;publish(400);assert take()[0]==0
    publish();assert event(0x201)==1;event(0x8);assert event(0x202)==0 and take()[0]==0
    publish(show=0);assert event(0x201)==0 and event(0x202)==0
    # Confirm real x86 WinAPI arguments, forwarding and teardown with WinAPI mocks.
    calls=[];proc=[0x12340000];pid=771
    def is_window(u,sp):return int(word(u,sp+4)==0x777),8
    def owner(u,sp):store(u,word(u,sp+8),pid);return 123,12
    def current(u,sp):return pid,4
    def getlong(u,sp):assert word(u,sp+4)==0x777;return proc[0],12
    def setlong(u,sp):
        assert word(u,sp+4)==0x777 and word(u,sp+8)==0xfffffffc
        old=proc[0];proc[0]=word(u,sp+12);calls.append('install');return old,16
    def forward(u,sp):
        assert word(u,sp+4)==0x12340000 and word(u,sp+8)==0x777
        calls.append(('forward',word(u,sp+12)));return 0x11223344,24
    def noerror(u,sp):return 0,8
    handlers={'IsWindow':is_window,'GetWindowThreadProcessId':owner,'GetCurrentProcessId':current,
        'GetWindowLongW':getlong,'SetWindowLongW':setlong,'GetWindowLongPtrW':getlong,'SetWindowLongPtrW':setlong,
        'CallWindowProcW':forward,'SetLastError':noerror}
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',handlers)
    assert call(u,exp('preview_attach_probe'),[0x777])==1
    assert call(u,exp('preview_attach_probe'),[0x777])==1 and calls==['install']
    publish()
    assert call(u,exp('preview_proc_probe'),[0x777,0x100,0,0])==0x11223344
    assert call(u,exp('preview_proc_probe'),[0x777,0x201,0,(130<<16)|120])==0
    assert call(u,exp('preview_proc_probe'),[0x777,0x202,0,(130<<16)|120])==0 and take()==(1,120,130)
    assert call(u,exp('preview_proc_probe'),[0x777,0x82,0,0])==0x11223344
    assert event(0x201)==0
    assert calls==['install',('forward',0x100),('forward',0x82)]
    # Actual native getter returns XMM0. The old SDK declaration expected x87,
    # which would restore an invalid depth after drawing the preview.
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');renderer,vt=MEM+0x70000,MEM+0x71000
    store(u,renderer,vt);store(u,vt+30*4,0x433cfd53);store(u,vt+29*4,0x433b360e)
    depth_calls=[]
    def command(u,a,size,user):
        if a!=0x433ab0fa:return
        sp=u.reg_read(UC_X86_REG_ESP);assert u.reg_read(UC_X86_REG_ECX)==renderer
        assert u.reg_read(UC_X86_REG_EDX)==15 and word(u,sp+4)==4
        depth_calls.append(True);u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+8)
    u.hook_add(UC_HOOK_CODE,command)
    for depth in [0.,.01,.35,.99,1.]:
        bits=fbits(depth);store(u,renderer+0x7c,bits)
        assert call(u,exp('renderer_depth_probe'),[renderer])==bits
        store(u,renderer+0x7c,fbits(.66))
        assert call(u,exp('renderer_set_depth_probe'),[renderer,bits])==bits
    assert len(depth_calls)==5
    return {'native_preset_controls_added':False,'removed_color_presets':['Glacier','Amethyst','Crimson','Champagne'],
        'esp_toggle_and_invalidation_cases':cases*5,'category_child_preview_render_cases':render_cases,
        'preview_render_without_hwnd_or_alpha':True,'native_clip_restored':True,
        'input_ownership_cases':12,'real_win32_abi_cases':7,'native_renderer_depth_abi_cases':10}
