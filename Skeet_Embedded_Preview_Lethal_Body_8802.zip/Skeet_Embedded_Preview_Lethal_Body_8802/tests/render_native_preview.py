#!/usr/bin/env python3
"""Render captured commands from the closed x86 category-child fixture.
This is an illustrative fixture image, never presented as an in-game capture.
"""
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
commands=json.loads((ROOT/'build/native_preview_draw_commands.json').read_text())
box=next(c[1:5] for c in commands if c[0]=='rect' and c[5]==0xff111111)
x,y,w,h=box
image=Image.new('RGB',(w,h),'#111111');draw=ImageDraw.Draw(image)
font_path=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
font=ImageFont.truetype(str(font_path),10) if font_path.exists() else ImageFont.load_default()
def color(n):return tuple((n>>i)&255 for i in [0,8,16])
for kind,*args in commands:
 if kind=='rect':
  a,b,width,height,c=args;draw.rectangle((a-x,b-y,a-x+width-1,b-y+height-1),fill=color(c))
 elif kind=='line':
  a,b,c,d,tint=args;draw.line((a-x,b-y,c-x,d-y),fill=color(tint))
 elif kind=='triangle':
  a,b,c,d,e,f,tint=args;draw.polygon([(a-x,b-y),(c-x,d-y),(e-x,f-y)],fill=color(tint))
 elif kind=='text':
  a,b,tint,width,text=args
  if not x<=a<x+w:continue
  layer=Image.new('RGBA',(max(1,width),16));ImageDraw.Draw(layer).text((0,0),text,font=font,fill=(*color(tint),255))
  image.paste(layer,(a-x,b-y),layer)
image.save(ROOT/'ESP_Preview_Embedded.png')
print('Wrote illustrative native-command fixture preview:',image.size)
