#pragma once
namespace appearance_preview {
using namespace cs2_visuals;using namespace SkeetSDK;
namespace design=appearance_design;
static int subject=design::Enemy,last_category=-1;
static float yaw=.25f;static unsigned saved_flags[4]{};
static const wchar_t* status=L"Illustrated appearance preview";
static bool live() {return attached&&(!captured_topology||topology()==captured_topology);}
static int esp_panel(){return subject==design::Team?TeamESP:EnemyESP;}
static int model_panel(){return subject==design::Enemy?EnemyModels:subject==design::Team?TeamModels:ViewPanel;}
static const wchar_t* model_name(){return subject==design::Enemy?L"Player":subject==design::Team?L"Teammate":subject==design::Local?L"Local player":L"Weapon viewmodel";}
static Binding* find(int panel,const wchar_t* name,int type) {
    if(!live())return nullptr;
    for(unsigned i=0;i<binding_count;i++) {
        auto& b=bindings[i];
        if(b.group&&b.group->panel==panel&&eq(b.anchor,name)&&b.source&&b.source->GetAs<Checkbox>()->Header.Type==type)return &b;
    }
    return nullptr;
}
static void* value(Binding* b){return b?native_ui_proxy::pointer(b->source,0x5c):nullptr;}
static bool editable(Binding* b){return b&&value(b)&&b->source->GetAs<Checkbox>()->Header.Flags.Editable;}
static unsigned read(Binding* b,unsigned fallback=0) {
    const auto* p=value(b);if(!p)return fallback;
    if(b->source->GetAs<Checkbox>()->Header.Type==UiCheckbox)return *static_cast<const unsigned char*>(p)!=0;
    unsigned n=0;std::memcpy(&n,p,4);return n;
}
static bool write(Binding* b,unsigned n) {
    if(!editable(b)||!live())return false;
    if(b->source->GetAs<Checkbox>()->Header.Type==UiCheckbox)*static_cast<unsigned char*>(value(b))=n!=0;
    else std::memcpy(value(b),&n,4);
    changed(b,nullptr);return live();
}
static Binding* element(int index) {
    if(subject>design::Team||index<0||index>=8)return nullptr;
    auto* b=find(esp_panel(),design::elements[index],UiCheckbox);
    if(!b&&index==7)b=find(esp_panel(),L"Flags",UiMultiselect);
    return b;
}
static bool toggle(int index) {
    auto* b=element(index);if(!editable(b))return false;
    const auto old=read(b);unsigned next=!old;
    if(b->source->GetAs<Checkbox>()->Header.Type==UiMultiselect) {
        auto* source=b->source->GetAs<Multiselect>();if(source->Vars.size()>32)return false;
        unsigned mask=0;for(const auto& v:source->Vars)mask|=static_cast<unsigned>(v.Index);
        if(old){if(source->NotNull)return false;saved_flags[subject]=old;next=0;}
        else {next=saved_flags[subject]&mask;if(!next)next=mask;}
    }
    return write(b,next);
}
static void action(int code) {
    if(code>=10&&code<14){subject=code-10;status=L"Illustrated appearance preview";}
    else if(code>=20&&code<28){if(!toggle(code-20))status=L"Option unavailable in this profile";}
}
static bool native_popup() {
    for(unsigned i=0;i<binding_count;i++) {
        auto* e=bindings[i].proxy;if(!e)continue;
        auto* base=e->GetAs<Checkbox>();if(!base->Header.Flags.Visible||(bindings[i].group&&bindings[i].group->child&&!bindings[i].group->child->Header.Flags.Visible))continue;
        const int t=base->Header.Type;
        if((t==UiCombobox&&e->GetAs<Combobox>()->Open)||(t==UiMultiselect&&e->GetAs<Multiselect>()->Popup)||
           (t==UiColorPicker&&e->GetAs<CPicker>()->Status!=PickerIdle)||
           (t==UiHotkey&&e->GetAs<Hotkey>()->Popup&&e->GetAs<Hotkey>()->Popup->Header.Flags.Visible))return true;
    }
    return false;
}
static unsigned opacity(unsigned c,float alpha){return (c&0xffffffU)|(unsigned((c>>24)*alpha)<<24);}
struct Paint {
    IRenderer* r;float dpi,alpha;Rect clip;
    int s(int n)const{return std::max(1,int(n*dpi+.5f));}
    void fill(Rect box,unsigned color){if(box.w>0&&box.h>0)r->Rect(box.x,box.y,box.w,box.h,opacity(color,alpha));}
    void border(Rect b,unsigned c){fill({b.x,b.y,b.w,1},c);fill({b.x,b.y+b.h-1,b.w,1},c);fill({b.x,b.y,1,b.h},c);fill({b.x+b.w-1,b.y,1,b.h},c);}
    void text(int x,int y,const wchar_t* str,unsigned color,int max=0) {
        if(!str)return;int available=std::max(0,clip.x+clip.w-x-s(4));if(max>0)available=std::min(available,max);
        if(available>0)r->Text(0,x,y,opacity(color,alpha),available,str,std::wcslen(str));
    }
    void button(Rect b,const wchar_t* label,bool selected=false,bool available=true) {
        fill(b,selected?0xff303a24U:0xff222222U);border(b,selected?0xff719e99U:0xff383838U);
        text(b.x+s(6),b.y+s(5),label,available?(selected?0xffa8d59bU:0xffc8c8c8U):0xff666666U,b.w-s(10));
    }
};
static void draw(IRenderer* renderer,Rect box,float dpi,float alpha) {
    Paint p{renderer,dpi,alpha,box};const auto ui=design::controls(box,dpi);
    p.fill(box,0xff111111U);p.border(box,0xff404040U);p.border({box.x+2,box.y+2,box.w-4,box.h-4},0xff242424U);
    p.fill({box.x+p.s(4),box.y+p.s(4),box.w-p.s(8),1},0xff9bc166U);
    p.text(box.x+p.s(13),box.y+p.s(13),design::titles[subject],0xffdadadaU,box.w-p.s(50));
    p.fill({box.x+p.s(12),box.y+p.s(33),box.w-p.s(24),1},0xff303030U);
    {
        p.fill(ui.settings,0xff191919U);
        for(int i=0;i<4;i++)p.button(ui.subjects[i],design::names[i],subject==i);
        for(int i=0;i<8;i++) {
            auto* b=element(i);const bool available=editable(b),on=read(b)!=0;const auto r=ui.elements[i];
            const int d=p.s(5);p.fill({r.x,r.y+p.s(5),d,d},available?(on?0xff75b4a8U:0xff494949U):0xff2b2b2bU);
            p.text(r.x+p.s(11),r.y+p.s(3),design::elements[i],available?0xffbbbbbbU:0xff626262U,r.w-p.s(12));
        }

    }
    {
        p.text(ui.settings.x,ui.settings.y,L"Manage elements",0xffd0d0d0U);
        const Rect body=ui.model;
        const auto color=read(find(model_panel(),model_name(),UiColorPicker),0xffbab7aeU);
        auto tint=design::Color{static_cast<unsigned char>(color),static_cast<unsigned char>(color>>8),static_cast<unsigned char>(color>>16),static_cast<unsigned char>(color>>24)};
        if(!read(find(model_panel(),model_name(),UiCheckbox)))tint={124,132,145,255};
        static design::Mesh mesh;static Rect old_body{};static unsigned old_tint=0;static float old_yaw=0;static int old_subject=-1;
        if(!(body==old_body)||old_tint!=tint.pack()||old_yaw!=yaw||old_subject!=subject) {
            mesh.build(body,tint,yaw,subject==design::Weapon);old_body=body;old_tint=tint.pack();old_yaw=yaw;old_subject=subject;
        }
        for(unsigned i=0;i<mesh.count;i++) {
            const auto& t=mesh.triangles[i];renderer->Triangle(t.x[0],t.y[0],t.x[1],t.y[1],t.x[2],t.y[2],opacity(t.color.pack(),alpha));
        }
        if(subject<=design::Team) {
            const Rect target{body.x+p.s(18),body.y+p.s(25),std::max(1,body.w-p.s(25)),body.h-p.s(21)};
            if(read(element(0)))p.border(target,read(find(esp_panel(),L"Bounding box",UiColorPicker),0xffeeeeeeU));
            if(read(element(1))){p.fill({target.x-p.s(7),target.y,p.s(3),target.h},0xff242424U);p.fill({target.x-p.s(7),target.y+target.h/4,p.s(3),target.h*3/4},0xff68c58cU);}
            if(read(element(2)))p.text(target.x+p.s(12),target.y-p.s(18),L"Player",read(find(esp_panel(),L"Name",UiColorPicker),0xffeeeeeeU));
            if(read(element(3))) {
                const int x=target.x+target.w/2,y=target.y;const unsigned c=opacity(read(find(esp_panel(),L"Skeleton",UiColorPicker),0xffeed1a2U),alpha);
                const int pts[][4]={{0,12,0,55},{0,29,-20,48},{0,29,20,48},{0,55,-14,91},{0,55,14,91}};
                for(const auto& v:pts)renderer->Line(x+v[0]*target.w/100,y+v[1]*target.h/100,x+v[2]*target.w/100,y+v[3]*target.h/100,c);
            }
            if(read(element(4))||read(element(5)))p.text(target.x+p.s(16),target.y+target.h+p.s(6),L"AWP",0xffdededeU);
            if(read(element(6))){p.fill({target.x,target.y+target.h+p.s(3),target.w,p.s(2)},0xff303030U);p.fill({target.x,target.y+target.h+p.s(3),target.w*3/4,p.s(2)},0xffd3a964U);}
            if(read(element(7)))p.text(target.x+target.w+p.s(5),target.y+p.s(9),L"HK",0xff9dcbd3U,p.s(30));
        }
    }
    p.text(box.x+p.s(12),box.y+box.h-p.s(10),status,0xff818181U,box.w-p.s(24));
}
static void prepare(CMenu* menu) {
    appearance_reserve_width=0;
    if(menu&&ready(menu)&&menu->CurrentTab==VISUALS&&(menu->MenuStatus&MenuOpened))
        appearance_reserve_width=design::embedded(menu->Size.x,menu->Size.y,scale()).reserved;
}
static void paint(IRenderer* renderer,const Vec2* origin) {
    using namespace preview_window_input;
    auto* menu=context?context->Menu:nullptr;
    if(!renderer||!origin||!menu||!live()||menu->CurrentTab!=VISUALS||!(menu->MenuStatus&MenuOpened))return;
    auto placement=design::embedded(menu->Size.x,menu->Size.y,scale());
    placement.area.x+=origin->x;placement.area.y+=origin->y;
    const auto box=placement.area;const float dpi=placement.dpi;
    if(active!=last_category) {
        if(active==Enemy)subject=design::Enemy;else if(active==Team)subject=design::Team;else if(active==View)subject=design::Local;
        last_category=active;
    }
    // Window input is optional. It must never gate the native renderer.
    const HWND foreground=GetForegroundWindow();const bool interactive=preview_window_input::attach(foreground)&&!native_popup();
    publish(box.x,box.y,box.w,box.h,interactive);
    int x,y;if(interactive&&take(x,y))action(design::action(design::controls(box,dpi),x,y));
    if(!live())return;
    int bounds[4]{};const bool clipped=renderer->IsBoundsPresent();if(clipped)renderer->GetBounds(bounds);
    renderer->ResetBounds(false);int ours[]={box.x,box.y,box.w,box.h};renderer->SetBounds(ours);
    // Match the working category glyph pass: inherit native alpha/depth, and
    // avoid the unverified MenuAlpha field and screen-size/window prerequisites.
    draw(renderer,box,dpi,1.f);
    if(clipped)renderer->SetBounds(bounds);else renderer->ResetBounds(false);
}
static void frame(CMenu* menu) {
    if(!menu||!live()||menu->CurrentTab!=VISUALS||!(menu->MenuStatus&MenuOpened))
        preview_window_input::publish(0,0,0,0,false);
}
}
