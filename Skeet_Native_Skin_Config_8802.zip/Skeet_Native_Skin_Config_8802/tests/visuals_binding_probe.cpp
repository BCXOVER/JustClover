#include "../source/skeet/pch.h"
#include "../source/skeet/SkeetSDK/skeetsdk.h"
#include "../source/skeet/cs2_visuals_impl.h"
extern "C" {
__declspec(dllexport) void skin_config_setup_probe(unsigned trampoline){cs2_visuals::original_config=reinterpret_cast<cs2_visuals::NativeConfigLoaded>(trampoline);}
__declspec(dllexport) void __fastcall skin_config_callback_probe(void* tab,void*){cs2_visuals::config_loaded(tab,nullptr);}

__declspec(dllexport) void skin_mirror_connect_probe(){cs2_visuals::skin_mirror_ui::frame(cs2_visuals::context->Menu);}
__declspec(dllexport) int skin_mirror_pending_probe(int weapon){
 for(const auto& p:cs2_visuals::skin_mirror_ui::mirror.presets)if(p.weapon==weapon&&p.pending)return p.desired.paint;
 return -1;
}
__declspec(dllexport) unsigned skin_mirror_preset_count_probe(){
 unsigned n=0;for(const auto& p:cs2_visuals::skin_mirror_ui::mirror.presets)if(p.weapon)n++;return n;
}
__declspec(dllexport) int skin_mirror_selection_probe(void* spec,int* enabled){bool on=false;const bool valid=cs2_visuals::skin_mirror_ui::selection(*static_cast<local_inventory::Spec*>(spec),on);*enabled=on;return valid;}
__declspec(dllexport) void render_setup_probe(unsigned trampoline) {
    cs2_visuals::attached=false;cs2_visuals::rebuild_pending=false;cs2_visuals::captured_topology=0;
    cs2_visuals::context=nullptr;cs2_visuals::original_draw=reinterpret_cast<cs2_visuals::NativeDraw>(trampoline);
}
__declspec(dllexport) void __fastcall render_callback_probe(SkeetSDK::CMenu* menu,void*,void* argument) {
    cs2_visuals::frame(menu,nullptr,argument);
}
__declspec(dllexport) void binding_setup_probe(void* ctx,void* proxy,void* source,void* child,unsigned layout_callback) {
    using namespace cs2_visuals;
    context=static_cast<SkeetSDK::SkeetClass_*>(ctx);attached=true;attempted=true;refreshing=false;rebuild_pending=false;captured_topology=0;active=Enemy;
    original_count=0;binding_count=1;
    for(auto& g:groups)g=Group{};
    groups[0].child=static_cast<SkeetSDK::Child*>(child);groups[0].panel=EnemyESP;groups[0].items=1;
    groups[0].layout=reinterpret_cast<NativeLayout>(layout_callback);
    bindings[0]={};bindings[0].proxy=static_cast<SkeetSDK::PElement>(proxy);
    bindings[0].source=static_cast<SkeetSDK::PElement>(source);bindings[0].group=&groups[0];
    model(bindings[0],bindings[0].observed);
}
__declspec(dllexport) void binding_change_probe(){cs2_visuals::changed(&cs2_visuals::bindings[0],nullptr);}
__declspec(dllexport) void binding_sync_probe(){cs2_visuals::sync();}
__declspec(dllexport) int topology_capture_probe(void* original_child) {
    using namespace cs2_visuals;
    original_count=1;originals[0]=static_cast<SkeetSDK::Child*>(original_child);original_visible[0]=true;
    *reinterpret_cast<void***>(groups[0].child)=groups[0].table;
    captured_topology=topology();return captured_topology!=0;
}
__declspec(dllexport) void category_setup_probe(void* ctx,void** children,void** controls,unsigned layout_callback) {
    using namespace cs2_visuals;
    context=static_cast<SkeetSDK::SkeetClass_*>(ctx);attached=true;refreshing=false;active=Enemy;
    original_count=binding_count=0;helper_available=true;
    for(int i=0;i<=panel_count;i++){
        groups[i]=Group{};groups[i].child=static_cast<SkeetSDK::Child*>(children[i]);groups[i].panel=i==panel_count?-1:i;
        groups[i].items=1;groups[i].layout=reinterpret_cast<NativeLayout>(layout_callback);
    }
    for(int i=0;i<category_count;i++)buttons[i]=static_cast<SkeetSDK::Button*>(controls[i]);
    child_layout(groups[panel_count].child,nullptr);sync();
}
__declspec(dllexport) void lifecycle_setup_probe(const native_ui_proxy::Api* api,unsigned deallocator,unsigned draw,unsigned button) {
    using namespace cs2_visuals;
    native=*api;native.destroy=&destroy;native.copy=&copy;native.link=&link;
    SkeetSDK::Memory::Allocator=native.allocate;
    SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(deallocator);
    original_draw=reinterpret_cast<NativeDraw>(draw);add_button=reinterpret_cast<AddButton>(button);hide=nullptr;
    attempted=true;attached=false;rebuild_pending=false;captured_topology=0;
    original_count=binding_count=0;helper_available=true;
    for(auto& g:groups)*reinterpret_cast<void***>(g.child)=g.table;
}
__declspec(dllexport) int lifecycle_rebuild_probe(){return cs2_visuals::rebuild(cs2_visuals::context->Menu);}
__declspec(dllexport) int lifecycle_status_probe(){return (cs2_visuals::attached?1:0)|(cs2_visuals::rebuild_pending?2:0)|(cs2_visuals::active<<8);}
__declspec(dllexport) void lifecycle_callback_probe(unsigned index){cs2_visuals::changed(&cs2_visuals::bindings[index],nullptr);}
__declspec(dllexport) void choose_category_probe(int category) {
    cs2_visuals::choose(reinterpret_cast<void*>(std::uintptr_t(category)),nullptr);
}
__declspec(dllexport) void child_draw_setup_probe(unsigned callback) {
    cs2_visuals::groups[0].draw=reinterpret_cast<cs2_visuals::NativeChildDraw>(callback);
}
__declspec(dllexport) void __fastcall child_draw_probe(SkeetSDK::Child* child,void*,SkeetSDK::IRenderer* renderer,const SkeetSDK::Vec2* origin) {
    cs2_visuals::child_draw(child,nullptr,renderer,origin);
}
__declspec(dllexport) void skins_setup_probe(void* ctx,const native_ui_proxy::Api* api,unsigned deallocator,
        void** children,unsigned layout,unsigned draw,unsigned list,unsigned text) {
    using namespace cs2_visuals;
    context=static_cast<SkeetSDK::SkeetClass_*>(ctx);native=*api;
    native.destroy=&destroy;native.copy=&copy;
    SkeetSDK::Memory::Allocator=native.allocate;
    SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(deallocator);hide=nullptr;
    skin::list_ctor=reinterpret_cast<skin::ListCtor>(list);skin::text_ctor=reinterpret_cast<skin::TextCtor>(text);
    skin::initialized=true;skin::attached=false;skin::pending_refresh=true;skin::refreshing=false;
    skin::captured=skin::failed=0;skin::view_count=skin::source_count=0;
    for(int i=0;i<3;i++) {
        auto& p=skin::panes[i];p={};p.index=i;p.child=static_cast<SkeetSDK::Child*>(children[i]);
        p.layout=reinterpret_cast<NativeLayout>(layout);p.draw=reinterpret_cast<NativeChildDraw>(draw);
        *reinterpret_cast<void***>(p.child)=p.table;
    }
}
__declspec(dllexport) int skins_rebuild_probe(){return cs2_visuals::skin::rebuild(cs2_visuals::context->Menu);}
__declspec(dllexport) void skins_update_probe(){cs2_visuals::skin::update(cs2_visuals::context->Menu);}
__declspec(dllexport) void skins_change_probe(unsigned index){cs2_visuals::skin::changed(&cs2_visuals::skin::views[index],nullptr);}
__declspec(dllexport) int skins_status_probe(){return cs2_visuals::skin::attached?int(cs2_visuals::skin::view_count):-1;}
__declspec(dllexport) void __fastcall skins_row_probe(void* self,void*,SkeetSDK::IRenderer* renderer,const SkeetSDK::Vec2* pos,
        int height,unsigned index,unsigned color,unsigned flags) {
    cs2_visuals::skin::agent_row(self,nullptr,renderer,pos,height,index,color,flags);
}
__declspec(dllexport) void __fastcall skins_list_draw_probe(void* self,void*,SkeetSDK::IRenderer* renderer,const SkeetSDK::Vec2* origin) {
    cs2_visuals::skin::list_draw(self,nullptr,renderer,origin);
}
__declspec(dllexport) void* resize_create_probe(void* ctx,void* tab,unsigned allocator,unsigned constructor,unsigned append,unsigned kind) {
    using namespace cs2_visuals;
    context=static_cast<SkeetSDK::SkeetClass_*>(ctx);native.allocate=reinterpret_cast<native_ui_proxy::Allocate>(allocator);
    child_ctor=reinterpret_cast<ChildCtor>(constructor);append_child=reinterpret_cast<AppendChild>(append);
    if(kind==0) {
        groups[0]={};if(!create_group(context->Menu,static_cast<SkeetSDK::CTab*>(tab),groups[0],EnemyESP))return nullptr;
        return groups[0].child;
    }
    for(auto& p:skin::panes)p={};
    if(!skin::create_panes(context->Menu))return nullptr;
    return skin::panes[0].child;
}
__declspec(dllexport) int variants_copy_probe(void* dst,void* src,int type,unsigned allocator,unsigned deallocator) {
    SkeetSDK::Memory::Allocator=reinterpret_cast<SkeetSDK::AllocatorFn>(allocator);
    SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(deallocator);
    return cs2_visuals::copy(dst,src,type);
}
__declspec(dllexport) unsigned renderer_depth_probe(void* renderer) {
    const float depth=static_cast<SkeetSDK::IRenderer*>(renderer)->GetZBuff();unsigned bits;std::memcpy(&bits,&depth,4);return bits;
}
__declspec(dllexport) unsigned renderer_set_depth_probe(void* renderer,unsigned bits) {
    float depth;std::memcpy(&depth,&bits,4);static_cast<SkeetSDK::IRenderer*>(renderer)->SetZBuff(depth);
    return renderer_depth_probe(renderer);
}
__declspec(dllexport) void inventory_ui_setup_probe(void* ctx,const native_ui_proxy::Api* api,void** old_panels,unsigned constructor,unsigned append,unsigned button,unsigned text,unsigned layout_callback) {
 using namespace cs2_visuals;context=static_cast<SkeetSDK::SkeetClass_*>(ctx);native=*api;
 SkeetSDK::Memory::Allocator=native.allocate;SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(native.destroy);
 child_ctor=reinterpret_cast<ChildCtor>(constructor);append_child=reinterpret_cast<AppendChild>(append);add_button=reinterpret_cast<AddButton>(button);
 skin::text_ctor=reinterpret_cast<skin::TextCtor>(text);skin::attached=true;skin::view_count=skin::source_count=0;
 for(int i=0;i<3;i++){auto& p=skin::panes[i];p={};p.child=static_cast<SkeetSDK::Child*>(old_panels[i]);p.index=i;p.layout=reinterpret_cast<NativeLayout>(layout_callback);*reinterpret_cast<void***>(p.child)=p.table;}
}
__declspec(dllexport) void inventory_ui_frame_probe(){cs2_visuals::inventory_ui::frame(cs2_visuals::context->Menu);}
__declspec(dllexport) void* inventory_inline_control_probe(unsigned n){return n<7?cs2_visuals::inventory_ui::controls[n]:nullptr;}
__declspec(dllexport) int inventory_inline_select_probe(void* spec){auto& s=*static_cast<local_inventory::Spec*>(spec);cs2_visuals::inventory_ui::select(s);return 1;}
__declspec(dllexport) void inventory_inline_native_tag_probe(void* source,void* proxy){
 using namespace cs2_visuals;skin::view_count=1;auto& v=skin::views[0];v={};v.source=static_cast<SkeetSDK::PElement>(source);v.proxy=static_cast<SkeetSDK::PElement>(proxy);v.type=SkeetSDK::UiTextbox;v.pane=&skin::panes[skin_menu_design::Weapon];skin::captured=skin::fingerprint(context->Menu);
}
__declspec(dllexport) void inventory_inline_callback_probe(unsigned palette,unsigned on_edit){cs2_visuals::inventory_ui::palette_access=reinterpret_cast<bool(*)(int,unsigned*,int)>(palette);cs2_visuals::inventory_ui::on_edit=reinterpret_cast<void(*)(SkeetSDK::CMenu*)>(on_edit);}
__declspec(dllexport) void inventory_ui_invalidate_skin_probe(){cs2_visuals::skin::invalidate(cs2_visuals::context->Menu);}
}
