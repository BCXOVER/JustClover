"""Fresh inventory controls, callback dispatch, stable resize and menu ownership."""
def check_inventory_ui(ns):
 globals().update(ns)
 u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');API=0x140000;u.mem_map(API,0x2000);u.mem_map(0x500000,0x200000)
 ctx,menu,tabs,skin_tab,children,old_panels,api,vt,element_vt,combo_vt=[MEM+0x10000+i*0x1000 for i in range(10)]
 store(u,ctx+0x10,menu);store(u,menu+0x14,800);store(u,menu+0x18,650);store(u,menu+0x34,1);store(u,menu+0x64,5)
 store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs+20,skin_tab)
 store(u,skin_tab+0x70,children);store(u,skin_tab+0x74,children+12);store(u,skin_tab+0x78,children+128)
 for i in range(3):
  c=MEM+0x20000+i*0x1000;store(u,children+4*i,c);store(u,old_panels+4*i,c)
  vec=MEM+0x24000+i*0x1000
  for off,v in [(0x80,vec),(0x84,vec),(0x88,vec+1024)]:store(u,c+off,v)
  u.mem_write(c+0x15,b'\1')
 floats(u,0x4346d490,1)
 for i in range(13):store(u,vt+4*i,API+0x700+0x20*i)
 for i in range(13):store(u,element_vt+4*i,API+0x900+0x20*i)
 store(u,combo_vt,0x4333f5c2);store(u,combo_vt+20,0x43383770);store(u,combo_vt+28,0x433adee6)
 allocations=[];buttons={};combos={};constructed=[];events=[]
 def alloc(n):
  p=0x500000+len(allocations)*0x1000;assert n<=0x1000
  allocations.append((p,n));u.mem_write(p,bytes(0x1000));return p
 def insert(c,obj):
  end=word(u,c+0x84);assert end+4<=word(u,c+0x88);store(u,end,obj);store(u,c+0x84,end+4)
 def base(obj,parent,kind,table=element_vt):
  store(u,obj,table);store(u,obj+0x10,parent);u.mem_write(obj+0x14,bytes([1,1,0,1,0,kind]));constructed.append((obj,kind))
 def callback(obj,context,fn):
  ptr=alloc(8);store(u,ptr,context);store(u,ptr+4,fn)
  for off,val in [(0x40,ptr),(0x44,ptr+8),(0x48,ptr+8)]:store(u,obj+off,val)
 def mock(u,a,size,user):
  if not API<=a<API+0x2000:return
  sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX);cleanup=4;result=0
  if a==API+0x100:result=alloc(this)
  elif a==API+0x140: # Sync checkbox.
   parent,nm,value=[word(u,sp+k) for k in [4,8,12]];assert wide(u,nm)=='Sync Skinchanger selections';base(this,parent,3);store(u,this+0x5c,value);u.mem_write(value,b'\0');cleanup=16
  elif a==API+0x160: # Slider.
   parent,nm,lo,hi,value=[word(u,sp+k) for k in [4,8,12,16,20]];base(this,parent,5);store(u,this+0x5c,value);store(u,value,0);cleanup=36
   assert lo==0 and hi in [1000,10000]
  elif a==API+0x180: # Combobox.
   parent,nm,value=[word(u,sp+k) for k in [4,8,12]];base(this,parent,4,combo_vt);store(u,this+0x5c,value);store(u,value,0);cleanup=20;combos[wide(u,nm)]=this
  elif a==API+0x1c0:base(this,word(u,sp+4),12);store(u,this+0x5c,word(u,sp+8));cleanup=12
  elif a==API+0x200:base(this,word(u,sp+4),8);cleanup=12
  elif a==API+0x220:assert word(u,sp+4) in [0,1];insert(this,word(u,sp+8));cleanup=12
  elif a==API+0x300: # Native Child constructor.
   parent=word(u,sp+4);base(this,parent,1,vt);vec=alloc(1024)
   for off,val in [(0x80,vec),(0x84,vec),(0x88,vec+1024)]:store(u,this+off,val)
   cleanup=24;result=this
  elif a==API+0x320:
   end=word(u,this+0x74);store(u,end,word(u,sp+4));store(u,this+0x74,end+4);cleanup=8
  elif a==API+0x340:
   same,nm,context,fn=[word(u,sp+k) for k in [4,8,12,16]];result=alloc(0x70);base(result,this,2);callback(result,context,fn);insert(this,result);buttons[wide(u,nm)]=result;cleanup=20
  elif a==API+0x360:base(this,word(u,sp+4),10);cleanup=8
  elif a in [API+0x380,API+0x800,API+0x820,API+0x840]:events.append(a)
  elif a==API+0x900:cleanup=8
  elif a in [API+0x120,API+0x9c0]:pass # Skeet allocator deallocator, no host freeing.
  else:raise AssertionError(hex(a))
  u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,word(u,sp))
 u.hook_add(UC_HOOK_CODE,mock)
 for i in range(12):store(u,api+i*4,API+0x100+0x20*i)
 call(u,exp('inventory_ui_setup_probe'),[ctx,api,old_panels,API+0x300,API+0x320,API+0x340,API+0x360,API+0x380])
 def invoke(label):
  obj=buttons[label];ptr=word(u,obj+0x40);fn=word(u,ptr+4);call(u,fn,ecx=word(u,ptr),edx=obj)
 call(u,exp('inventory_ui_frame_probe'))
 assert list(buttons)==['Local inventory']
 invoke('Local inventory');call(u,exp('inventory_ui_frame_probe'),limit=2000000)
 assert call(u,exp('inventory_ui_opened_probe'))==1
 assert all(n in buttons for n in ['Equip selected item locally','Add to local CS:GO inventory','Delete selected local item','Apply name tag','Remove name tag','Apply RGB palette','Restore original palette','Back to skinchanger'])
 assert len([k for _,k in constructed if k==12])==4
 checks=[obj for obj,kind in constructed if kind==3];assert len(checks)==1 and bytes(u.mem_read(word(u,checks[0]+0x5c),1))==b'\1'
 weapon_control=combos['Weapon / knife / gloves'];assert word(u,word(u,weapon_control+0x5c))==9
 skin_control=combos['Skin'];assert word(u,word(u,skin_control+0x5c))==344
 assert (word(u,skin_tab+0x74)-word(u,skin_tab+0x70))//4==5
 count=len(allocations);cases=0
 for factor in [1.,.75,1.5,2.,1.]:
  floats(u,0x4346d490,factor);store(u,menu+0x14,int(800*factor));store(u,menu+0x18,int(650*factor))
  call(u,exp('inventory_ui_frame_probe'))
  for n in [0,1]:
   c=call(u,exp('inventory_ui_child_probe'),[n]);assert word(u,c+0x28)>0 and word(u,c+0x2c)>0
   assert abs(word(u,c+0x30)*factor-word(u,c+0x28))<=2
   for slot in [0,1,2,3,5,6,7,11,12]:assert word(u,word(u,c)+4*slot)==API+0x700+0x20*slot
  assert len(allocations)==count;cases+=1
 invoke('Back to skinchanger');call(u,exp('inventory_ui_frame_probe'));assert call(u,exp('inventory_ui_opened_probe'))==0
 for i in range(3):assert bytes(u.mem_read(word(u,old_panels+4*i)+0x15,1))==b'\1'
 invoke('Local inventory');call(u,exp('inventory_ui_frame_probe'));assert call(u,exp('inventory_ui_opened_probe'))==1 and len(allocations)==count
 removed=call(u,exp('inventory_ui_child_probe'),[0]);call(u,exp('inventory_ui_remove_child_probe'),[0]);u.mem_unmap(removed,0x1000)
 call(u,exp('inventory_ui_frame_probe'));assert call(u,exp('inventory_ui_opened_probe'))==0
 remaining=call(u,exp('inventory_ui_child_probe'),[1]);assert bytes(u.mem_read(remaining+0x15,1))==b'\0'
 invoke('Local inventory');call(u,exp('inventory_ui_frame_probe'),limit=2000000)
 assert call(u,exp('inventory_ui_opened_probe'))==1 and call(u,exp('inventory_ui_child_probe'),[0])!=removed
 weapon_control=combos['Weapon / knife / gloves']
 ptr=word(u,weapon_control+0x5c);own_button=buttons['Apply name tag'];calls_before=word(u,own_button+0x44)-word(u,own_button+0x40)
 call(u,exp('inventory_ui_invalidate_skin_probe'))
 assert word(u,weapon_control+0x5c)==ptr and word(u,ptr)==9
 assert word(u,own_button+0x44)-word(u,own_button+0x40)==calls_before and calls_before==8
 return {'fresh_native_controls':len(constructed),'rgb_pickers':4,'native_button_callback_dispatches':5,'removed_inventory_child_recovery':True,'resize_roundtrip_cases':cases,'external_inventory_controls_survive_skin_invalidation':True,'idle_and_reopen_allocate_nothing':True,'weapon_and_paint_initial_values_preserved':True}
