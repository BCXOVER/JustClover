#!/usr/bin/env python3
"""Portable ownership/loadout checks; never starts the target application."""
from pathlib import Path
import subprocess,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
build=ROOT/'build';build.mkdir(exist_ok=True)
source=ROOT/'tests/skin_mirror_plan.cpp'
subprocess.run(['g++','-std=c++17','-O2',str(source),'-o',str(build/'skin_mirror_plan')],check=True)
subprocess.run([str(build/'skin_mirror_plan')],check=True)
report={'passed':True,'debounce_ms':350,'duplicate_prevention':True,'preset_replacement':True,
        'disable_restores_previous_loadout':True,'later_manual_loadout_preserved':True,
        'manual_delete_suppresses_recreation_until_change':True,'account_change_drops_old_references':True,
        'manually_created_items_not_deleted_by_mirror':True,'game_tested':False,
        'source_sha256':{name:hashlib.sha256((ROOT/'source/skeet'/name).read_bytes()).hexdigest()
                         for name in ['skin_mirror.h','local_loadout.h']}}
(build/'skin_mirror_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
