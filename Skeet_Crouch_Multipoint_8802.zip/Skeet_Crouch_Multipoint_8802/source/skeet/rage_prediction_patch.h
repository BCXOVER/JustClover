#pragma once
#include "rage_prediction.h"
#include "scan_patch.h"
namespace rage_prediction_patch {
inline constexpr unsigned site=0x4cd45,code_size=128;
inline constexpr unsigned char original[]={0x8b,0x7d,0x1c,0x89,0x8c,0x24,0x80,0,0,0};
struct Plan {unsigned char code[code_size]{};unsigned char jump[sizeof(original)]{};};
inline bool make(const unsigned char* image,std::size_t size,unsigned location,unsigned callback,Plan& out) {
    if(!image||size!=scan_patch::image_size||std::memcmp(image+site,original,sizeof(original)))return false;
    Plan p{};unsigned n=0;
    const auto bytes=[&](const unsigned char* b,unsigned count){std::memcpy(p.code+n,b,count);n+=count;};
    const auto byte=[&](unsigned char b){p.code[n++]=b;};
    const auto dword=[&](unsigned v){std::memcpy(p.code+n,&v,4);n+=4;};
    bytes(original,sizeof(original));
    // Replay before saving, so the native job/owner store survives the bridge.
    // FXSAVE requires a 16-byte aligned 512-byte area. ESI is callee-saved.
    const unsigned char save[]={0x9c,0x60,0x89,0xe6,0x81,0xec,0x10,0x02,0,0,0x83,0xe4,0xf0,0x0f,0xae,0x04,0x24,
        0x8b,0xcd,0xb8};
    bytes(save,sizeof(save));dword(callback);
    const unsigned char restore[]={0xff,0xd0,0x0f,0xae,0x0c,0x24,0x89,0xf4,0x61,0x9d};
    bytes(restore,sizeof(restore));byte(0xe9);dword(scan_patch::image_base+site+sizeof(original)-(location+n+4));
    std::memset(p.jump,0x90,sizeof(p.jump));p.jump[0]=0xe9;
    scan_patch::put32(p.jump+1,location-(scan_patch::image_base+site+5));out=p;return true;
}
#ifdef _WIN32
inline DWORD tls_slot=TLS_OUT_OF_INDEXES;
inline void* scratch() {
    if(tls_slot==TLS_OUT_OF_INDEXES)return nullptr;
    void* p=TlsGetValue(tls_slot);
    if(!p) {
        p=HeapAlloc(GetProcessHeap(),0,motion_records::record_size);
        if(p&&!TlsSetValue(tls_slot,p)){HeapFree(GetProcessHeap(),0,p);p=nullptr;}
    }
    return p;
}
inline void __fastcall bridge(void* frame) {
    if(!motion_settings::extrapolation.load(std::memory_order_relaxed))return;
    auto* shooter=reinterpret_cast<void*>(motion_records::u32(frame,8));
    auto* actor=reinterpret_cast<void*>(motion_records::u32(frame,0x10));
    auto* job=reinterpret_cast<void*>(motion_records::u32(frame,0x1c));
    if(!shooter||!actor||!job)return;
    const unsigned index=motion_records::u32(job,4);if(index<1||index>64)return;
    // Same cache slot as the native 0x433b8a2b accessor, without its lazy
    // allocation path on a scan worker. A missing cache simply skips prediction.
    auto* history=*reinterpret_cast<void**>(0x434797bc+(index&63u)*4);
    auto* buffer=scratch();if(!buffer)return;
    rage_prediction::prepare(job,actor,history,motion_patch::options(),motion_patch::clock(shooter),motion_patch::api,buffer);
}
inline bool apply(unsigned char* image,std::size_t size) {
    if(reinterpret_cast<std::uintptr_t>(image)!=scan_patch::image_base)return false;
    auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));if(!code)return false;
    Plan p{};
    if(!make(image,size,reinterpret_cast<unsigned>(code),reinterpret_cast<unsigned>(&bridge),p)) {
        VirtualFree(code,0,MEM_RELEASE);SetLastError(ERROR_REVISION_MISMATCH);return false;
    }
    std::memcpy(code,p.code,sizeof(p.code));DWORD old=0;
    if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(p.code))) {
        const auto error=GetLastError();VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    tls_slot=TlsAlloc();if(tls_slot==TLS_OUT_OF_INDEXES){VirtualFree(code,0,MEM_RELEASE);return false;}
    std::memcpy(image+site,p.jump,sizeof(p.jump));
    if(!FlushInstructionCache(GetCurrentProcess(),image+site,sizeof(p.jump))) {
        const auto error=GetLastError();std::memcpy(image+site,original,sizeof(original));FlushInstructionCache(GetCurrentProcess(),image+site,sizeof(original));
        TlsFree(tls_slot);tls_slot=TLS_OUT_OF_INDEXES;VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    return true;
}
#endif
}
