#pragma once
#include "skin_native_state.h"
#include "local_inventory_client.h"
namespace skin_native_client {
using local_inventory_client::memory;using local_inventory_client::read32;using local_inventory_client::pointer;
inline bool payload(void* tab,unsigned field,unsigned bytes,unsigned hash,unsigned type,void*& out,bool control=false) {
 out=nullptr;if(!memory(tab,field+4))return false;auto* p=pointer(tab,field);
 if(control){if(!memory(p,0x60)||*(static_cast<unsigned char*>(p)+0x19)!=4)return false;p=pointer(p,0x5c);}
 if(!p||reinterpret_cast<std::uintptr_t>(p)<16)return false;
 auto* node=static_cast<unsigned char*>(p)-16;if(!memory(node,16+bytes))return false;
 std::uint16_t size=0;std::memcpy(&size,node+12,2);
 if(read32(node,8)!=hash||size!=bytes||node[14]!=type)return false;out=p;return true;
}
inline bool read(void* tab,skin_native_state::Raw& raw) {
 if(!memory(tab,0x158)||read32(tab,0)!=0x43470684)return false;
 void* records=nullptr;if(!payload(tab,0x130,0x410,0xb6218fec,6,records))return false;
 raw={};std::memcpy(raw.records.data(),records,0x410);
 struct Field {unsigned offset,hash;};
 constexpr Field knife_on[]={{0xc8,0xd347bc87},{0xcc,0xd4f2a320}};
 constexpr Field knife_id[]={{0xd0,0xe0bda969},{0xd4,0xb3c4b6ca}};
 constexpr Field glove_on[]={{0xa8,0x3a8ef907},{0xac,0xe5249ca0}};
 constexpr Field glove_id[]={{0xb0,0x7439e8b5},{0xb4,0x5101537e}};
 constexpr Field glove_paint[]={{0xb8,0xe13f61e0},{0xbc,0x7cfd0011}};
 constexpr Field agent_on[]={{0xc0,0x191a5a61},{0xc4,0x6caf4832}};
 constexpr Field agent_id[]={{0x110,0x3eb3f20b},{0x114,0x8191d9bc}};
 for(unsigned i=0;i<2;i++) {
  const auto boolean=[&](Field f,bool& value){void* p=nullptr;if(!payload(tab,f.offset,1,f.hash,1,p))return false;const unsigned b=*static_cast<unsigned char*>(p);if(b>1)return false;value=b!=0;return true;};
  const auto integer=[&](Field f,int& value,bool control=false){void* p=nullptr;if(!payload(tab,f.offset,4,f.hash,3,p,control))return false;std::memcpy(&value,p,4);return true;};
  if(!boolean(knife_on[i],raw.knife_on[i])||!integer(knife_id[i],raw.knife_model[i])||!boolean(glove_on[i],raw.glove_on[i])||!integer(glove_id[i],raw.glove_model[i])||!integer(glove_paint[i],raw.glove_paint[i])||!boolean(agent_on[i],raw.agent_on[i])||!integer(agent_id[i],raw.agent_model[i],true))return false;
 }
 return true;
}
inline unsigned active_source(void* tab) {
 void* records=nullptr;if(!payload(tab,0x130,0x410,0xb6218fec,6,records))return 0;
 auto* control=pointer(tab,0x11c);if(!memory(control,0x60)||*(static_cast<unsigned char*>(control)+0x19)!=3)return 0;
 const auto value=reinterpret_cast<std::uintptr_t>(pointer(control,0x5c)),base=reinterpret_cast<std::uintptr_t>(records);
 if(value<base||value-base>=0x410||(value-base)%16)return 0;
 const auto slot=unsigned((value-base)/16);return slot==42?0x10003u:(slot==59?0x10002u:slot);
}
}
