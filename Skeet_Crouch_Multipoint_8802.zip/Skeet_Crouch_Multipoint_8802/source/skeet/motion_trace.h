#pragma once
#include "motion_records.h"
namespace motion_trace {
using motion_records::Vec;
struct alignas(16) AlignedVec {float x,y,z,w;};
struct alignas(16) Ray {
    AlignedVec start,delta,offset,extents;
    const void* transform;bool is_ray,is_swept;
};
struct Trace {
    Vec start,end;float normal[3],distance;unsigned char type,sign,padding[2];
    float fraction;int contents;unsigned short displacement;bool all_solid,start_solid;
    float fraction_left;const char* surface_name;short surface_properties;unsigned short surface_flags;
    int hitgroup;short physics_bone;unsigned short world_surface;void* entity;int hitbox;
};
static_assert(sizeof(Ray)==80&&offsetof(Ray,transform)==64);
static_assert(sizeof(Trace)==84&&offsetof(Trace,fraction)==44&&offsetof(Trace,all_solid)==54);
struct Filter {
    void* skip;
    virtual bool ShouldHitEntity(void* entity,int){return entity!=skip;}
    virtual int GetTraceType(){return 0;}
};
inline void* engine=nullptr;
inline void initialize() {
    auto* module=GetModuleHandleA("engine.dll");if(!module)return;
    using Factory=void*(__cdecl*)(const char*,int*);
    auto factory=reinterpret_cast<Factory>(GetProcAddress(module,"CreateInterface"));
    if(factory)engine=factory("EngineTraceClient004",nullptr);
}
inline bool sweep(void* actor,Vec from,Vec to) {
    if(!engine||!actor||!motion_records::finite(from)||!motion_records::finite(to))return false;
    Ray ray{};ray.start={from.x,from.y,from.z+36,0};
    ray.delta={to.x-from.x,to.y-from.y,to.z-from.z,0};ray.offset={0,0,-36,0};ray.extents={16,16,36,0};
    ray.is_ray=false;ray.is_swept=ray.delta.x!=0||ray.delta.y!=0||ray.delta.z!=0;
    Filter filter;filter.skip=actor;Trace trace{};trace.fraction=0;
    using TraceRay=void(__thiscall*)(void*,const Ray&,unsigned,Filter*,Trace*);
    auto trace_ray=reinterpret_cast<TraceRay>((*reinterpret_cast<void***>(engine))[5]);
    if(!trace_ray)return false;
    trace_ray(engine,ray,0x200400bU,&filter,&trace);
    return !trace.all_solid&&!trace.start_solid&&motion_records::finite(trace.fraction)&&trace.fraction==1;
}
}
