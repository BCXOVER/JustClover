#pragma once
#include <atomic>
#include <cstdint>
#include <cstring>
#include <cmath>
namespace crouch_multipoint {
inline std::atomic<int> enabled{1};
static_assert(std::atomic<int>::is_always_lock_free);
inline constexpr unsigned native_point_size=0x18,raw_record=0xf0,duck_offset=0x3c;
inline constexpr float start=.55f,full=.90f,body_scale=.82f,head_scale=.88f;
inline std::uint32_t number(const void* p,unsigned off){std::uint32_t v;std::memcpy(&v,static_cast<const unsigned char*>(p)+off,4);return v;}
inline float scalar(const void* p,unsigned off){float v;std::memcpy(&v,static_cast<const unsigned char*>(p)+off,4);return v;}
inline bool coordinate(float x){return std::isfinite(x)&&std::fabs(x)<=32768.f;}
inline float scale(float duck,unsigned group) {
    if(!std::isfinite(duck)||duck<-.01f||duck>1.01f||duck<=start||group<1||group>3)return 1;
    const float blend=duck>=full?1.f:(duck-start)/(full-start);
    return 1.f-blend*(1.f-(group==1?head_scale:body_scale));
}
// Native pre-scan point: XYZ, native scale, hitgroup, flags (24 bytes).
// Work on a stack copy; the generator's point vector and center stay intact.
inline bool copy_contracted(const void* source,const void* center,float duck,void* out) {
    if(!source||!center||!out||source==center)return false;
    const unsigned group=number(source,0x10);
    if(number(center,0x10)!=group)return false;
    const float factor=scale(duck,group);if(factor>=1)return false;
    float xyz[3]{};bool moved=false;
    for(unsigned i=0;i<3;i++) {
        const float p=scalar(source,i*4),c=scalar(center,i*4);
        if(!coordinate(p)||!coordinate(c))return false;
        xyz[i]=c+(p-c)*factor;
        if(!coordinate(xyz[i]))return false;
        moved|=xyz[i]!=p;
    }
    if(!moved)return false;
    std::memcpy(out,source,native_point_size);std::memcpy(out,xyz,sizeof(xyz));return true;
}
#ifdef _WIN32
inline int bridge(const unsigned char* args,const void* frame,void* out,unsigned center_delta) {
    if(!enabled.load(std::memory_order_relaxed)||!args||!frame||!out)return 0;
    const auto* job=reinterpret_cast<const unsigned char*>(number(frame,0x1c));
    if(!job||!(number(job,raw_record+0x5c)&4))return 0;
    const auto* point=reinterpret_cast<const void*>(number(args,8));
    return copy_contracted(point,args+center_delta,scalar(job,raw_record+duck_offset),out)?1:0;
}
inline int __fastcall primary(const unsigned char* args,const void* frame,void* out){return bridge(args,frame,out,0x300);}
inline int __fastcall secondary(const unsigned char* args,const void* frame,void* out){return bridge(args,frame,out,0x260);}
#endif
}
