#pragma once
#include "motion_records.h"
namespace rage_prediction {
using namespace motion_records;
inline constexpr unsigned raw_offset=0xf0;
struct Session {void* actor;const void* history;Options options;Clock clock;int count;const void* first;};
// The worker owns this job. Never overwrite the ring-buffer records or replace
// an intentionally selected older backtrack pose. Point generation and HC will
// subsequently consume the same translated record (including its timestamp).
inline int prepare(void* job,void* actor,const void* history,Options options,Clock clock,const Api& api,void* buffer) {
    if(!job||!actor||!history||!buffer||!options.extrapolation||!valid_clock(clock))return 0;
    const auto count=motion_records::u32(history,0x5d8);if(count<3||count>32)return 0;
    const auto* newest=record(history,0);auto* selected=static_cast<unsigned char*>(job)+raw_offset;
    if(!valid_pose(newest)||!valid_pose(selected)||(motion_records::u32(selected,0x5c)&0x200)||
       tick(selected)!=tick(newest)||!same(position(selected,0x30),position(newest,0x30))||
       !same(position(history,0x13c),position(newest,0x30)))return 0;
    // Equal ticks alone do not identify a pose: an existing alternate resolver
    // matrix must not silently be replaced by another pose from the same tick.
    if(std::memcmp(selected,newest,record_size))return 0;
    const Session session{actor,history,options,clock,static_cast<int>(count),newest};
    const int high=std::min(tick(newest)+clamp(options.horizon,0,8),time_upper(clock));
    for(int requested=high;requested>tick(newest);--requested) {
        if(!forecast(session,requested,api,buffer))continue;
        std::memcpy(selected,buffer,record_size);return requested-tick(newest);
    }
    return 0;
}
}
