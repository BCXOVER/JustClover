#pragma once
#include <cstddef>
#include <cstdint>
namespace cs2_visuals {bool install(std::uint8_t*,std::size_t);}
