#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
#include "scan_patch.h"

namespace precision_patch {
inline constexpr int enabled=1;
inline constexpr std::uint32_t base=scan_patch::image_base;
inline constexpr std::size_t generator=0x88f25, generator_size=436;
inline constexpr std::size_t clone_offset=0x200;
inline constexpr std::uint32_t sample_count=0x760, snapshot=0x770, frame_size=0x4a38;
static_assert(sample_count==0x160+128*12 && snapshot>=sample_count+16);
static_assert((frame_size&15)==8);
struct Edit {std::uint32_t offset=0;std::uint8_t size=0;std::uint8_t before[12]{},after[12]{};};
struct Plan {std::uint8_t code[1024]{};Edit edits[7]{};};
inline std::uint64_t fingerprint(const std::uint8_t* p,std::size_t n) {
    std::uint64_t v=0xcbf29ce484222325ULL;
    for(std::size_t i=0;i<n;i++)v=(v^p[i])*0x100000001b3ULL;
    return v;
}
inline bool expect(const std::uint8_t* image,std::size_t offset,const std::uint8_t* p,std::size_t n) {
    return std::memcmp(image+offset,p,n)==0;
}
inline bool make_plan(const std::uint8_t* image,std::size_t size,std::uint32_t code_address,
                      std::uint32_t precision_state,std::uint32_t strict_state,Plan& p) {
    if(!image||size!=scan_patch::image_size)return false;
    constexpr std::uint8_t allocation[]={0x81,0xec,0xa8,0x45,0,0};
    constexpr std::uint8_t ctor[]={0x8d,0x8c,0x24,0xe4,0x02,0,0};
    constexpr std::uint8_t apply[]={0x8d,0x8c,0x24,0xec,0x02,0,0};
    constexpr std::uint8_t cleanup[]={0x8d,0x8c,0x24,0xe0,0x02,0,0};
    constexpr std::uint8_t gen_call[]={0xe8,0x02,0x8f,0x06,0};
    constexpr std::uint8_t loop[]={0xc7,0x44,0x24,0x14,0x20,0,0,0};
    constexpr std::uint8_t scale[]={0xc1,0xe0,0x05,0x6a,0x64,0x59};
    if(!expect(image,0x1fd31,allocation,6)||!expect(image,0x1fde0,ctor,7)||
       !expect(image,0x1ffaa,apply,7)||!expect(image,0x200cb,cleanup,7)||
       !expect(image,0x2001e,gen_call,5)||!expect(image,0x200e9,loop,8)||
       !expect(image,0x20172,scale,6)||image[0x20178]!=0xe8||image[0x2017d]!=0x90)
        return false;
    // Exact generator body, after import relocation: its only call is internal.
    if(fingerprint(image+generator,generator_size)!=0x87fb4251986f6e41ULL)return false;
    p=Plan{};
    auto write32=[](std::uint8_t* out,std::uint32_t v){std::memcpy(out,&v,4);};
    auto edit=[&](int i,std::uint32_t offset,std::uint8_t n) {
        auto& e=p.edits[i];e.offset=offset;e.size=n;
        std::memcpy(e.before,image+offset,n);std::memcpy(e.after,e.before,n);
    };
    edit(0,0x1fd31,6);edit(1,0x1fde0,7);edit(2,0x1ffaa,7);edit(3,0x200cb,7);
    edit(4,0x2001e,5);edit(5,0x200e9,8);edit(6,0x20172,12);
    auto branch=[&](int i,std::size_t target,bool call) {
        auto& e=p.edits[i];std::memset(e.after,0x90,e.size);e.after[0]=call?0xe8:0xe9;
        write32(e.after+1,std::uint32_t(code_address+target-(base+e.offset+5)));
    };
    branch(0,0,false);
    write32(p.edits[1].after+3,snapshot+4);
    write32(p.edits[2].after+3,snapshot+12);
    write32(p.edits[3].after+3,snapshot);
    branch(4,0x40,true);branch(5,0x80,true);branch(6,0xc0,true);

    // One count is captured per invocation. A menu toggle cannot make a scan
    // consume 128 directions after the generator has produced only 32.
    constexpr std::uint8_t setup[]={
        0x81,0xec,0x38,0x4a,0,0,0xb8,0x20,0,0,0,
        0x80,0x3d,0,0,0,0,0,0x74,0x05,0xb8,0x80,0,0,0,
        0x89,0x84,0x24,0x58,0x07,0,0,0xe9,0,0,0,0};
    std::memcpy(p.code,setup,sizeof(setup));
    write32(p.code+13,precision_state);
    write32(p.code+33,std::uint32_t(base+0x1fd37-(code_address+37)));
    constexpr std::uint8_t dispatch[]={0x83,0xbc,0x24,0x70,0x07,0,0,0x20,0x0f,0x84,0,0,0,0,0xe9,0,0,0,0};
    std::memcpy(p.code+0x40,dispatch,sizeof(dispatch));
    write32(p.code+0x40+10,std::uint32_t(base+generator-(code_address+0x40+14)));
    write32(p.code+0x40+15,std::uint32_t(code_address+clone_offset-(code_address+0x40+19)));
    constexpr std::uint8_t loop_init[]={0x50,0x8b,0x84,0x24,0x68,0x07,0,0,0x89,0x44,0x24,0x1c,0x58,0xc3};
    std::memcpy(p.code+0x80,loop_init,sizeof(loop_init));
    constexpr std::uint8_t threshold[]={
        0x0f,0xaf,0x84,0x24,0x64,0x07,0,0,0x6a,0x64,0x59,0x99,0xf7,0xf9,
        0x80,0x3d,0,0,0,0,0,0x74,0x05,0x85,0xd2,0x7e,0x01,0x40,0x33,0xc9,0x41,0xc3};
    std::memcpy(p.code+0xc0,threshold,sizeof(threshold));write32(p.code+0xc0+16,strict_state);
    std::memcpy(p.code+clone_offset,image+generator,generator_size);
    // Use every byte of the existing 128-entry seed table instead of
    // every fourth byte. Raising the old loop limit would read the next table.
    p.code[clone_offset+0xa6]=1;
    write32(p.code+clone_offset+0x9c,std::uint32_t(0x433adb4f-(code_address+clone_offset+0xa0)));
    return true;
}
#ifdef _WIN32
inline bool apply(std::uint8_t* image,std::size_t size) {
    auto* code=static_cast<std::uint8_t*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
    if(!code)return false;
    Plan plan{};
    if(reinterpret_cast<std::uintptr_t>(image)!=base || !make_plan(image,size,
        static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(code)),
        static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(&enabled)),
        static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(&scan_patch::strict_threshold_enabled)),plan)) {
        VirtualFree(code,0,MEM_RELEASE);SetLastError(ERROR_REVISION_MISMATCH);return false;
    }
    std::memcpy(code,plan.code,sizeof(plan.code));
    DWORD protection=0;
    if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&protection)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(plan.code))) {
        const auto error=GetLastError();VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    for(const auto& e:plan.edits)std::memcpy(image+e.offset,e.after,e.size);
    if(!FlushInstructionCache(GetCurrentProcess(),image,size)) {
        const auto error=GetLastError();
        for(const auto& e:plan.edits)std::memcpy(image+e.offset,e.before,e.size);
        FlushInstructionCache(GetCurrentProcess(),image,size);
        VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    return true;
}
#endif
}
