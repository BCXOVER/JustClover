#pragma once
#include <array>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cmath>
namespace local_inventory {
struct Spec {int weapon=9,paint=344,seed=0;float wear=.01f;unsigned rarity=5;char name[129]{};unsigned source=0,teams=0,flags=0;};
struct Session {void* inventory=nullptr;void* cache=nullptr;std::uint64_t owner=0;unsigned owner_type=0,account=0;
 bool operator==(const Session& b)const{return inventory==b.inventory&&cache==b.cache&&owner==b.owner&&owner_type==b.owner_type&&account==b.account;}};
struct Api {
 bool(*session)(Session&);bool(*highest)(const Session&,std::uint64_t&,unsigned&);
 bool(*contains)(const Session&,void*,std::uint64_t);
 void*(*create)();bool(*initialize)(void*,const Session&,const Spec&,std::uint64_t,unsigned);
 bool(*name)(void*,const char*);bool(*insert)(const Session&,void*);
 bool(*notify)(const Session&,int,void*);bool(*remove)(const Session&,void*);void(*destroy)(void*);
};
inline bool valid_name(const char* text) {
 if(!text)return false;unsigned points=0;
 for(unsigned i=0;i<129;) {
  unsigned a=static_cast<unsigned char>(text[i]);if(!a)return true;if(a<32||a==127)return false;
  unsigned n=a<0x80?1:(a>=0xc2&&a<=0xdf?2:(a>=0xe0&&a<=0xef?3:(a>=0xf0&&a<=0xf4?4:0)));
  if(!n||i+n>=129||++points>32)return false;
  for(unsigned k=1;k<n;k++)if((static_cast<unsigned char>(text[i+k])&0xc0)!=0x80)return false;
  if(n==3&&((a==0xe0&&static_cast<unsigned char>(text[i+1])<0xa0)||(a==0xed&&static_cast<unsigned char>(text[i+1])>=0xa0)))return false;
  if(n==4&&((a==0xf0&&static_cast<unsigned char>(text[i+1])<0x90)||(a==0xf4&&static_cast<unsigned char>(text[i+1])>=0x90)))return false;
  i+=n;
 }
 return false;
}
inline bool valid(const Spec& s){return s.source<0x40000&&(s.teams==0||s.teams==4||s.teams==8||s.teams==12)&&s.flags<8&&s.weapon>0&&s.weapon<65536&&s.paint>=0&&s.paint<=65535&&s.seed>=0&&s.seed<=1000&&s.rarity<=7&&std::isfinite(s.wear)&&s.wear>=0&&s.wear<=1&&valid_name(s.name);}
struct Item {void* object=nullptr;std::uint64_t id=0;Spec spec{};};
struct Inventory {
 Session current{};std::array<Item,128> items{};const char* error="";
 bool refresh(const Api& api) {
  Session next{};if(!api.session(next)||!next.inventory||!next.cache||!next.account){error="Local game inventory is unavailable";return false;}
  if(!(next==current)){items={};current=next;}return true;
 }
 bool owned(const Api& api,unsigned slot) {
  if(slot>=items.size()||!refresh(api)||!items[slot].object){error="Select an item added by this module";return false;}
  if(!api.contains(current,items[slot].object,items[slot].id)){items[slot]={};error="Item cache changed; stale entry removed";return false;}return true;
 }
 int add(const Api& api,const Spec& spec) {
  if(!valid(spec)){error="Invalid item, wear, seed or name tag";return -1;}
  if(!refresh(api))return -1;unsigned slot=0;while(slot<items.size()&&items[slot].object)++slot;
  if(slot==items.size()){error="Local item limit reached";return -1;}
  std::uint64_t id=0;unsigned position=0;
  if(!api.highest(current,id,position)||id>=0x0ffffffffffffffeULL||position==0xffffffffU){error="No collision-free local item ID is available";return -1;}
  auto* object=api.create();if(!object){error="Game item allocation failed";return -1;}
  if(!api.initialize(object,current,spec,++id,++position)){api.destroy(object);error="Game item attributes are unavailable";return -1;}
  if(!api.insert(current,object)||!api.contains(current,object,id)){api.destroy(object);error="Item could not be added to the game cache";return -1;}
  if(!api.notify(current,0,object)) {
   if(api.remove(current,object))api.destroy(object);
   error="Game inventory notification failed";return -1;
  }
  items[slot]={object,id,spec};error="Item added to local CS:GO inventory";return int(slot);
 }
 bool erase(const Api& api,unsigned slot) {
  if(!owned(api,slot))return false;auto item=items[slot];
  if(!api.notify(current,2,item.object)||!api.remove(current,item.object)||api.contains(current,item.object,item.id)){error="Game refused removal; item has not been freed";return false;}
  api.destroy(item.object);items[slot]={};error="Local item deleted";return true;
 }
 bool rename(const Api& api,unsigned slot,const char* name) {
  if(!valid_name(name)){error="Name tag must contain at most 32 valid characters";return false;}
  if(!owned(api,slot))return false;
  if(!api.name(items[slot].object,name)||!api.notify(current,1,items[slot].object)){error="Name tag update failed";return false;}
  std::strcpy(items[slot].spec.name,name);error="Name tag applied to local item";return true;
 }
};
}
