#pragma once
#include "local_inventory.h"
#include <array>
namespace skin_native_state {
using local_inventory::Spec;
// Native config node 0xb6218fec: 65 entries x 16 bytes. No paint/weapon inference.
struct Record {unsigned char enabled=0,stattrak=0,padding[2]{};int quality=100,seed=0,paint=0;};
static_assert(sizeof(Record)==16);
inline constexpr int knives[]={500,505,506,507,508,509,515,512,516,514,519,520,522,523,503,517,518,521,525};
struct Raw {
 std::array<Record,65> records{};
 bool knife_on[2]{},glove_on[2]{},agent_on[2]{};
 int knife_model[2]{},glove_model[2]{},glove_paint[2]{},agent_model[2]{};
};
struct Rows {
 std::array<Spec,96> data{};unsigned count=0;
 const Spec* begin()const{return data.data();}const Spec* end()const{return data.data()+count;}
 bool add(const Spec& s){if(count==data.size()||!local_inventory::valid(s))return false;data[count++]=s;return true;}
};
inline bool gun(int n){switch(n){case 1:case 2:case 3:case 4:case 7:case 8:case 9:case 10:case 11:case 13:case 14:case 16:case 17:case 19:case 23:case 24:case 25:case 26:case 27:case 28:case 29:case 30:case 32:case 33:case 34:case 35:case 36:case 38:case 39:case 40:case 60:case 61:case 63:case 64:return true;default:return false;}}
inline bool record(const Record& r){return r.enabled<=1&&r.stattrak<=1&&r.quality>=0&&r.quality<=100&&r.seed>=0&&r.seed<=1000&&r.paint>=0&&r.paint<=65535;}
inline Spec finish(const Record& r,int weapon,unsigned key,unsigned teams=0){Spec s{};s.weapon=weapon;s.paint=r.paint;s.seed=r.seed;s.wear=(100-r.quality)/100.f;s.source=key;s.teams=teams;s.flags=1u|(r.stattrak?4u:0u);return s;}
inline bool same_item(const Spec& a,const Spec& b){return a.weapon==b.weapon&&a.paint==b.paint&&a.seed==b.seed&&a.wear==b.wear&&a.flags==b.flags&&!std::strcmp(a.name,b.name);}
inline void merge_teams(Rows& rows) {
 for(unsigned i=0;i<rows.count;i++)for(unsigned j=i+1;j<rows.count;) {
  auto& a=rows.data[i];auto& b=rows.data[j];
  if(a.source>=0x10000&&(a.source&0xf0000)==(b.source&0xf0000)&&same_item(a,b)){a.source&=0xf0000;a.teams|=b.teams;for(unsigned n=j+1;n<rows.count;n++)rows.data[n-1]=rows.data[n];--rows.count;}else ++j;
 }
}
template<class Presets> inline bool retain_pending_agents(Rows& rows,unsigned pending,const Presets& presets) {
 for(unsigned team=2;team<=3;team++)if(pending&(1u<<team))for(const auto& p:presets)if(p.enabled&&(p.desired.flags&2u)&&(p.desired.teams&(1u<<team))) {
  auto previous=p.desired;previous.source=0x30000u+team;previous.teams=1u<<team;if(!rows.add(previous))return false;break;
 }
 merge_teams(rows);return true;
}
inline bool decode(const Raw& raw,Rows& out) {
 out={};
 for(unsigned w=1;w<raw.records.size();w++) {
  const auto& r=raw.records[w];if(!record(r))return false;
  if(w!=42&&w!=59&&r.enabled&&r.paint&&!out.add(finish(r,int(w),w)))return false;
 }
 for(unsigned side=0;side<2;side++) {
  const unsigned team=side+2,mask=1u<<team;
  const int knife_slot=team==2?59:42;const auto& r=raw.records[knife_slot];
  if(raw.knife_on[side]) {
   if(raw.knife_model[side]<0||unsigned(raw.knife_model[side])>=std::size(knives))return false;
   // Model customization is independent of the native finish's origin weapon.
   Spec s=finish(r,knives[raw.knife_model[side]],0x10000u+team,mask);if(!r.enabled){s.paint=0;s.flags&=~4u;}if(!out.add(s))return false;
  }else if(r.enabled&&r.paint&&!out.add(finish(r,knife_slot,0x10000u+team,mask)))return false;
  if(raw.glove_on[side]) {
   if(raw.glove_model[side]<5027||raw.glove_model[side]>5035||raw.glove_paint[side]<0||raw.glove_paint[side]>65535)return false;
   Spec s{};s.weapon=raw.glove_model[side];s.paint=raw.glove_paint[side];s.source=0x20000u+team;s.teams=mask;s.flags=1;s.rarity=6;if(!out.add(s))return false;
  }
  if(raw.agent_on[side]&&raw.agent_model[side]<-1)return false;
  if(raw.agent_on[side]&&raw.agent_model[side]>0) {
   if(raw.agent_model[side]<=0||raw.agent_model[side]>65535)return false;
   Spec s{};s.weapon=raw.agent_model[side];s.paint=0;s.source=0x30000u+team;s.teams=mask;s.flags=2;s.rarity=6;if(!out.add(s))return false;
  }
 }
 merge_teams(out);return true;
}
}
