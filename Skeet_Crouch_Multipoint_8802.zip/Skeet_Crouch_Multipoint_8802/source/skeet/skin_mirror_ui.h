#pragma once
#include "skin_mirror.h"
#include "skin_native_client.h"
#include "local_loadout_client.h"
namespace skin_mirror_ui {
static skin_mirror::Mirror mirror;
static DWORD sampled=0,checked=0;static bool started=false,checked_once=false;
static void* native_tab(){auto* menu=context?context->Menu:nullptr;return menu&&menu->Tabs.size()==9?menu->Tabs[SKINS]:nullptr;}
static void enrich(local_inventory::Spec& s) {
 if(s.flags&2u)s.rarity=6;
 else if(s.weapon==42||s.weapon==59||(s.weapon>=500&&s.weapon<600))s.rarity=6;
 else if(const auto* row=inventory_ui::skin_info(s.weapon,s.paint))s.rarity=unsigned(row->rarity);
 else if(const auto* row=skin_rarity::entry(s.paint))s.rarity=unsigned(row->rarity);
 // Name tags are an inline extension, not part of the original 16-byte record.
 if(auto* e=inventory_ui::edit(s.weapon);e&&e->named)std::strcpy(s.name,e->name);
}
static bool selection(local_inventory::Spec& out,bool& enabled) {
 enabled=false;auto* tab=native_tab();skin_native_state::Raw raw{};if(!skin_native_client::read(tab,raw))return false;
 const unsigned key=skin_native_client::active_source(tab);if(!key)return false;
 const int slot=key>=0x10000?(key==0x10002?59:42):int(key);if(slot<1||slot>64||!skin_native_state::record(raw.records[slot]))return false;
 const auto& r=raw.records[slot];int weapon=slot;unsigned teams=0;
 enabled=r.enabled&&r.paint>0;
 if(key>=0x10000) {
  const unsigned side=key==0x10002?0:1;teams=1u<<(side+2);
  if(raw.knife_on[side]){if(raw.knife_model[side]<0||unsigned(raw.knife_model[side])>=std::size(skin_native_state::knives))return false;weapon=skin_native_state::knives[raw.knife_model[side]];enabled=true;}
 }
 out=skin_native_state::finish(r,weapon,key,teams);if(!r.enabled){out.paint=0;out.flags&=~4u;}enrich(out);return local_inventory::valid(out);
}
static bool snapshot(skin_native_state::Rows& rows) {
 skin_native_state::Raw raw{};if(!skin_native_client::read(native_tab(),raw))return false;const unsigned pending=agent_inventory_client::normalize(native_tab(),raw);if(!skin_native_state::decode(raw,rows))return false;
 // Keep the last owned agent per side while an incremental schema lookup is
 // pending. Other weapons still reconcile immediately after a config load.
 if(!skin_native_state::retain_pending_agents(rows,pending,mirror.presets))return false;
 for(auto& s:rows.data)if(s.source)enrich(s);return true;
}
static void capture(CMenu* menu) {
 if(!context||context->Menu!=menu)return;
 skin_native_state::Rows rows{};if(snapshot(rows))mirror.reconcile(rows,GetTickCount());
 if(menu->CurrentTab==SKINS&&(menu->MenuStatus&MenuOpened)){local_inventory::Spec spec{};bool enabled=false;if(selection(spec,enabled))inventory_ui::select(spec);}
}
static void frame_impl(CMenu* menu) {
 skin::after_change=&capture;inventory_ui::on_edit=&capture;
 if(!menu||!context||context->Menu!=menu)return;const DWORD now=GetTickCount();auto& inv=inventory_ui::inventory;
 if(!checked_once||DWORD(now-checked)>=1000) {
  checked=now;checked_once=true;local_inventory::Session next{};
  if(!local_inventory_client::session(next)){started=false;return;}
  if(!(next==inv.current)){local_inventory_client::restore_all_palettes();agent_inventory_client::reset();inv.items={};inv.current=next;mirror.changed_session(next);}
  mirror.heal(inv,local_inventory_client::api,now);started=true;
 }
 if(!started||!inv.current.inventory)return;
 agent_inventory_client::step();
 static unsigned named_at=0,named_epoch=0;static bool named_once=false;
 if(!named_once||named_epoch!=inventory_ui::name_epoch||DWORD(now-named_at)>=250) {
  named_at=now;named_epoch=inventory_ui::name_epoch;named_once=true;local_weapon_names::Request requests[96]{};unsigned count=0;
  for(const auto& e:inventory_ui::edits)if(e.weapon&&e.named){requests[count].weapon=e.weapon;std::strcpy(requests[count++].name,e.name);}
  if(count)local_weapon_names::apply(requests,count);
 }
 if(DWORD(now-sampled)>=100){sampled=now;capture(menu);}
 if(mirror.tick(inv,local_inventory_client::api,local_loadout_client::api,true,now))inventory_ui::report(mirror.status);
}
static void frame(CMenu* menu){try{frame_impl(menu);}catch(...){inventory_ui::report("Skinchanger synchronization unavailable");}}
}
