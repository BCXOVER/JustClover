#pragma once
#include <atomic>
namespace motion_settings {
inline constexpr int interpolation=1;
inline constexpr int interpolation_gap=8;
// Native UI writes its own int; scan workers consume this atomic snapshot.
inline std::atomic<int> extrapolation{1};
inline constexpr int extrapolation_ticks=8;
}
