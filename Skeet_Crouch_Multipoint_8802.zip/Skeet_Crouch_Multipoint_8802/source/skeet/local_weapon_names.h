#pragma once
#include "local_client_interfaces.h"
namespace local_weapon_names {
using local_inventory_client::memory;using local_inventory_client::read32;using local_inventory_client::pointer;
struct Request {int weapon=0;char name[129]{};};
inline bool layout() {
 using namespace local_inventory_client;if(!ready())return false;
 struct Field {unsigned rva,value;};constexpr Field fields[]={{0x60c00,0x2d90},{0x5fe9e,0x40},{0x621ab,0x1ea},{0x62524,0x27c},{0x62542,0xa1}};
 for(const auto& f:fields)if(base[f.rva]!=0xc7||base[f.rva+1]!=5||read32(base,f.rva+6)!=f.value)return false;
 return base[0x1e2543]==0x6a&&base[0x1e2544]==64&&base[0x1e254e]==0x68&&read32(base,0x1e254f)==0x2e08&&base[0x1e46e0]==0x68&&read32(base,0x1e46e1)==0x14c;
}
inline unsigned apply(const Request* requests,unsigned count) {
 if(!requests||!count||count>96||!layout())return 0;
 auto* engine=local_client_interfaces::core_interface(0x4346a514);auto* entities=local_client_interfaces::core_interface(0x4346a890);
 auto* get_local=local_client_interfaces::method(engine,12);auto* get_entity=local_client_interfaces::method(entities,3);auto* get_handle=local_client_interfaces::method(entities,4);
 if(!get_local||!get_entity||!get_handle)return 0;
 using Local=int(__thiscall*)(void*);using Entity=void*(__thiscall*)(void*,unsigned);
 const int index=reinterpret_cast<Local>(get_local)(engine);if(index<1||index>64)return 0;
 auto* player=reinterpret_cast<Entity>(get_entity)(entities,unsigned(index));if(!memory(player,0x2f08))return 0;
 unsigned changed=0;
 for(unsigned h=0;h<64;h++) {
  const auto handle=read32(player,0x2e08+h*4);if(!handle||handle==0xffffffffu)continue;
  auto* weapon=reinterpret_cast<Entity>(get_handle)(entities,handle);if(!memory(weapon,0x30ed,true))continue;
  const unsigned owner=read32(weapon,0x14c);if(!owner||owner==0xffffffffu||reinterpret_cast<Entity>(get_handle)(entities,owner)!=player)continue;
  const auto id=*reinterpret_cast<const unsigned short*>(static_cast<unsigned char*>(weapon)+0x2fba);
  for(unsigned r=0;r<count;r++)if(requests[r].weapon==id&&local_inventory::valid_name(requests[r].name)) {
   auto* target=static_cast<char*>(weapon)+0x304c;char value[161]{};std::memcpy(value,requests[r].name,std::strlen(requests[r].name)+1);
   if(std::memcmp(target,value,sizeof(value))){std::memcpy(target,value,sizeof(value));++changed;}break;
  }
 }
 return changed;
}
}
