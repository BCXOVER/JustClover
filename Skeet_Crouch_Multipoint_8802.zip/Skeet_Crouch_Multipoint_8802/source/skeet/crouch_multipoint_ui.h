#pragma once
// Included in cs2_visuals after the native UI API has been resolved.
namespace crouch_ui {
static PElement control=nullptr;
static int value=1;
static void __fastcall changed(void*,void*) {
    value=value?1:0;
    crouch_multipoint::enabled.store(value,std::memory_order_relaxed);
}
static void frame(CMenu* menu) {
    if(!menu||menu->Tabs.size()<=RAGE||!native.check||!native.insert)return;
    auto* tab=menu->Tabs[RAGE];if(!tab)return;
    Child* other=nullptr;
    for(auto* child:tab->Childs) {
        if(!child)continue;
        wchar_t name[128]{};native_ui_names::decode(child->Name.get(),name,std::size(name));
        if(eq(name,L"Other")) {other=child;break;}
    }
    if(!other)return;
    // Lua/config may rebuild objects. Compare live addresses before touching
    // any old control; never dereference an object no longer owned by the UI.
    if(control)for(auto* e:other->Elements)if(e==control) {changed(nullptr,nullptr);return;}
    control=nullptr;
    auto* p=static_cast<Checkbox*>(native.allocate(sizeof(Checkbox)));if(!p)return;
    const int previous=crouch_multipoint::enabled.load(std::memory_order_relaxed);
    native.check(p,other,L"Crouch multipoint",&value);value=previous?1:0;
    p->Calls.emplace_back(nullptr,&changed);native.insert(other,false,p);
    control=reinterpret_cast<PElement>(p);
    std::rotate(other->Elements.begin(),other->Elements.end()-1,other->Elements.end());
    auto** table=*reinterpret_cast<void***>(other);
    reinterpret_cast<NativeLayout>(table[8])(other);
    changed(nullptr,nullptr);
}
}
