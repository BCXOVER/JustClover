#pragma once
// Customization lives in the existing Weapon skin pane. No inventory page.
namespace inventory_ui {
using local_inventory::Spec;
struct Weapon {int id;const wchar_t* name;};
inline constexpr Weapon weapons[]={
 {1,L"Desert Eagle"},{2,L"Dual Berettas"},{3,L"Five-SeveN"},{4,L"Glock-18"},{7,L"AK-47"},{8,L"AUG"},{9,L"AWP"},{10,L"FAMAS"},{11,L"G3SG1"},{13,L"Galil AR"},{14,L"M249"},{16,L"M4A4"},{17,L"MAC-10"},{19,L"P90"},{23,L"MP5-SD"},{24,L"UMP-45"},{25,L"XM1014"},{26,L"PP-Bizon"},{27,L"MAG-7"},{28,L"Negev"},{29,L"Sawed-Off"},{30,L"Tec-9"},{32,L"P2000"},{33,L"MP7"},{34,L"MP9"},{35,L"Nova"},{36,L"P250"},{38,L"SCAR-20"},{39,L"SG 553"},{40,L"SSG 08"},{60,L"M4A1-S"},{61,L"USP-S"},{63,L"CZ75-Auto"},{64,L"R8 Revolver"},
 {500,L"Bayonet"},{503,L"Classic Knife"},{505,L"Flip Knife"},{506,L"Gut Knife"},{507,L"Karambit"},{508,L"M9 Bayonet"},{509,L"Huntsman Knife"},{512,L"Falchion Knife"},{514,L"Bowie Knife"},{515,L"Butterfly Knife"},{516,L"Shadow Daggers"},{517,L"Paracord Knife"},{518,L"Survival Knife"},{519,L"Ursus Knife"},{520,L"Navaja Knife"},{521,L"Nomad Knife"},{522,L"Stiletto Knife"},{523,L"Talon Knife"},{525,L"Skeleton Knife"},
 {5027,L"Bloodhound Gloves"},{5030,L"Sport Gloves"},{5031,L"Driver Gloves"},{5032,L"Hand Wraps"},{5033,L"Moto Gloves"},{5034,L"Specialist Gloves"},{5035,L"Hydra Gloves"}};

static local_inventory::Inventory inventory{};
static bool owns(Child*){return false;}
static bool opened(){return false;}
static const char* status="";
static void report(const char* text){status=text;}
static const inventory_catalog::Skin* skin_info(int w,int p){for(const auto& s:inventory_catalog::skins)if(s.weapon==w&&s.paint==p)return &s;return nullptr;}
struct Edit {int weapon=0;bool named=false;char name[129]{};};
static Edit edits[96]{};
static Textbox* tag=nullptr;
static PElement controls[7]{};
static VecCol colors[4]{};
static int active_weapon=0,active_paint=0;
static bool binding=false,palette_available=false,palette_pending=false;
static wchar_t tag_observed[64]{};static unsigned tag_observed_length=0,tag_changed=0,name_epoch=0;
static bool tag_dirty=false,tag_display_pending=false;static char tag_display[129]{};
static unsigned palette_checked=0;
static int pending_kit=0;static unsigned pending_colors[4]{},palette_changed=0;
static void(*on_edit)(CMenu*)=nullptr;
static bool(*palette_access)(int,unsigned*,int)=&local_inventory_client::palette;
static Edit* edit(int weapon){for(auto& e:edits)if(e.weapon==weapon)return &e;for(auto& e:edits)if(!e.weapon){e.weapon=weapon;return &e;}return nullptr;}
static bool live(Child* child) {
 if(!child||!tag)return false;
 for(auto* own:controls){if(!own)return false;bool found=false;for(auto* e:child->Elements)if(e==own){found=true;break;}if(!found)return false;}
 return true;
}
static void display_name(const char* value) {
 if(value!=tag_display)std::strcpy(tag_display,value);tag_display_pending=true;
 auto* child=skin::panes[skin_menu_design::Weapon].child;if(!live(child))return;
 auto* lock=reinterpret_cast<volatile LONG*>(reinterpret_cast<char*>(tag)+0x60);
 if(InterlockedCompareExchange(lock,1,0)!=0)return;
 const int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,tag_display,-1,tag->Text,64);
 if(n>0)tag->Length=n-1;else {tag->Length=0;tag->Text[0]=0;}
 tag_observed_length=unsigned(tag->Length);std::memcpy(tag_observed,tag->Text,(tag_observed_length+1)*2);tag_dirty=false;tag_display_pending=false;InterlockedExchange(lock,0);
}
static void flush_tag();
static void select(Spec& spec) {
 if(active_weapon&&(active_weapon!=spec.weapon||active_paint!=spec.paint))flush_tag();
 auto* e=edit(spec.weapon);if(e&&e->named)std::strcpy(spec.name,e->name);else if(e)std::strcpy(e->name,spec.name);
 const bool changed=active_weapon!=spec.weapon||active_paint!=spec.paint;
 active_weapon=spec.weapon;active_paint=spec.paint;
 binding=true;if(changed)display_name(spec.name);
 const unsigned now=GetTickCount();
 if(changed||(!palette_available&&now-palette_checked>=1000)){palette_checked=now;unsigned values[4]{};palette_available=palette_access(spec.paint,values,0);if(palette_available)for(int i=0;i<4;i++){colors[i].set(values[i]);auto* c=skin::panes[skin_menu_design::Weapon].child;if(live(c))controls[3+i]->GetAs<CPicker>()->OnConfigLoad();}}
 binding=false;
}
static void refresh_native(bool name) {
 skin::View* target=nullptr;
 for(unsigned i=0;i<skin::view_count;i++){auto& v=skin::views[i];if(v.pane!=&skin::panes[skin_menu_design::Weapon]||v.type!=(name?UiTextbox:UiListbox))continue;if(target)return;target=&v;}
 if(!target)return;
 if(name)std::memcpy(reinterpret_cast<char*>(target->proxy)+0x64,reinterpret_cast<char*>(tag)+0x64,132);
 skin::changed(target,nullptr);
}
static bool read_tag(wchar_t (&text)[64],unsigned& length) {
 if(!tag)return false;auto* lock=reinterpret_cast<volatile LONG*>(reinterpret_cast<char*>(tag)+0x60);
 if(InterlockedCompareExchange(lock,1,0)!=0)return false;
 const int n=tag->Length;const bool valid=n>=0&&n<=63;
 if(valid){length=unsigned(n);std::memcpy(text,tag->Text,length*2);text[length]=0;}
 InterlockedExchange(lock,0);return valid;
}
static void commit_tag(const wchar_t* text) {
 char utf8[129]{};
 if(!WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,text,-1,utf8,129,nullptr,nullptr)||!local_inventory::valid_name(utf8)){report("Name tag must contain at most 32 characters");return;}
 if(auto* e=edit(active_weapon)) {
  if(e->named&&!std::strcmp(e->name,utf8))return;
  std::strcpy(e->name,utf8);e->named=true;++name_epoch;if(on_edit&&context)on_edit(context->Menu);
 }
}
static void flush_tag() {
 if(binding||tag_display_pending||!active_weapon||!live(skin::panes[skin_menu_design::Weapon].child))return;
 wchar_t text[64]{};unsigned n=0;if(!read_tag(text,n))return;
 if(tag_dirty||n!=tag_observed_length||std::memcmp(text,tag_observed,n*2)){tag_dirty=false;commit_tag(text);}
}
static void poll_tag() {
 if(binding||!active_weapon)return;if(tag_display_pending){display_name(tag_display);return;}wchar_t text[64]{};unsigned length=0;if(!read_tag(text,length))return;
 const unsigned now=GetTickCount();
 if(length!=tag_observed_length||std::memcmp(text,tag_observed,length*2)) {
  tag_observed_length=length;std::memcpy(tag_observed,text,(length+1)*2);tag_changed=now;tag_dirty=true;
 }
 if(tag_dirty&&unsigned(now-tag_changed)>=300){tag_dirty=false;commit_tag(text);}
}
static void __fastcall edited(void* arg,void*) {
 if(binding||tag_display_pending||!context||context->Menu->CurrentTab!=SKINS||!skin::attached||!live(skin::panes[skin_menu_design::Weapon].child)||!active_weapon)return;
 const auto kind=reinterpret_cast<std::uintptr_t>(arg);
 if(kind==1) {
  wchar_t text[64]{};unsigned length=0;if(!read_tag(text,length))return;
  tag_observed_length=length;std::memcpy(tag_observed,text,(length+1)*2);tag_dirty=false;commit_tag(text);
 }else if(kind==2&&palette_available) {
  pending_kit=active_paint;for(int i=0;i<4;i++)pending_colors[i]=colors[i].pack();palette_changed=GetTickCount();palette_pending=true;
 }
}
static void inline_position(skin::Pane& pane) {
 if(pane.index!=skin_menu_design::Weapon||!live(pane.child))return;
 auto* c=pane.child;const int inset=int(20*scale()),w=std::max(1,c->Size.x-2*inset),bottom=c->Size.y-int(20*scale());
 const auto place=[&](PElement e,int x,int y,int width,int height){auto* h=e->GetAs<Checkbox>();h->Pos={x,y};native_layout_state::size(reinterpret_cast<Button*>(e),width,height,scale());};
 place(controls[0],inset,bottom-int(90*scale()),w,int(16*scale()));
 place(controls[1],inset,bottom-int(69*scale()),w,int(24*scale()));
 place(controls[2],inset,bottom-int(31*scale()),std::max(1,w-int(100*scale())),int(18*scale()));
 for(int i=0;i<4;i++)place(controls[3+i],inset+w-int((4-i)*23*scale()),bottom-int(29*scale()),int(18*scale()),int(12*scale()));
 for(auto* own:controls){auto* h=own->GetAs<Checkbox>();h->Header.Flags.Visible=true;h->Header.Flags.Editable=active_weapon>0;}
 for(int i=3;i<7;i++)controls[i]->GetAs<Checkbox>()->Header.Flags.Editable=active_weapon>0&&palette_available;
}
static void create(Child* child) {
 // Rebuild only our live controls, never the native proxies or stale addresses.
 for(auto* own:controls)if(own)for(auto it=child->Elements.begin();it!=child->Elements.end();++it)if(*it==own){bool source=false;for(unsigned i=0;i<skin::view_count;i++)source|=skin::views[i].proxy==own;if(!source){own->GetAs<Checkbox>()->Calls.clear();destroy(own);child->Elements.erase(it);}break;}
 tag=nullptr;for(auto& e:controls)e=nullptr;
 const auto label=[&](const wchar_t* name){auto* p=native.allocate(sizeof(Label));if(!p)throw std::bad_alloc();native.label(p,child,name);native.insert(child,false,p);return static_cast<PElement>(p);};
 controls[0]=label(L"Name tag");
 tag=static_cast<Textbox*>(native.allocate(sizeof(Textbox)));if(!tag)throw std::bad_alloc();skin::text_ctor(tag,child);native.insert(child,false,tag);controls[1]=reinterpret_cast<PElement>(tag);tag->Calls.emplace_back(reinterpret_cast<void*>(1),&edited);
 controls[2]=label(L"Skin colors");
 for(int i=0;i<4;i++) {
  auto* p=static_cast<CPicker*>(native.allocate(sizeof(CPicker)));if(!p)throw std::bad_alloc();native.picker(p,child,&colors[i]);native.insert(child,true,p);controls[3+i]=reinterpret_cast<PElement>(p);p->Calls.emplace_back(reinterpret_cast<void*>(2),&edited);
 }
 skin::pane_layout(child,nullptr);
}
static void frame(CMenu* menu) {
 skin::after_layout=&inline_position;
 try {
  // Commit the last color edit even if the user immediately closes the menu.
  if(palette_pending&&unsigned(GetTickCount()-palette_changed)>=75) {
   palette_pending=false;
   if(palette_access(pending_kit,pending_colors,1)) {
    for(const auto& item:inventory.items)if(item.object&&item.spec.paint==pending_kit&&local_inventory_client::contains(inventory.current,item.object,item.id))local_inventory_client::notify(inventory.current,1,item.object);
    if(menu&&skin::attached&&menu->CurrentTab==SKINS&&(menu->MenuStatus&MenuOpened)&&active_paint==pending_kit&&live(skin::panes[skin_menu_design::Weapon].child))refresh_native(false);
   }else report("Selected skin palette is unavailable");
  }
  if(skin::attached&&live(skin::panes[skin_menu_design::Weapon].child))poll_tag();
  if(!menu||!skin::attached||menu->CurrentTab!=SKINS||!(menu->MenuStatus&MenuOpened))return;
  auto* child=skin::panes[skin_menu_design::Weapon].child;if(!child)return;
  if(!live(child)){create(child);if(auto* e=edit(active_weapon))display_name(e->name);}
  inline_position(skin::panes[skin_menu_design::Weapon]);poll_tag();
 }catch(...){report("Skin customization controls unavailable");}
}
}
