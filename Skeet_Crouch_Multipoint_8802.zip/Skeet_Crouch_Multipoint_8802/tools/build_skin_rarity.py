#!/usr/bin/env python3
"""Generate facts from a pinned legacy CS:GO item schema and localizations.
Inputs are local files. Does not access a game process or network.
"""
from pathlib import Path
import re,json,hashlib,sys
ROOT=Path(__file__).resolve().parents[1]
def kv(raw):
    text=raw.decode('utf-16') if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else raw.decode('utf-8-sig')
    tokens=re.findall(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*.*?\*/|[{}]|[^\s{}"]+',text,re.S)
    tokens=[t for t in tokens if not t.startswith(('//','/*','['))]
    pos=0
    def string(t):
        if t.startswith('"'):return re.sub(r'\\(["\\])',r'\1',t[1:-1])
        return t
    def merge(dst,src):
        for k,v in src.items():
            if k in dst and isinstance(dst[k],dict) and isinstance(v,dict):merge(dst[k],v)
            else:dst[k]=v
    def block(end=False):
        nonlocal pos
        out={}
        while pos<len(tokens):
            t=tokens[pos];pos+=1
            if t=='}':assert end;return out
            key=string(t);assert pos<len(tokens)
            value=tokens[pos];pos+=1
            value=block(True) if value=='{' else string(value)
            merge(out,{key:value})
        assert not end;return out
    return block()
def generate(folder):
    src=folder/'items_game_2023_08.txt';game=kv(src.read_bytes())['items_game']
    locs=[]
    for lang in ['english','russian']:
        langkv=kv((folder/f'csgo_{lang}.txt').read_bytes())
        root=next(iter(langkv.values()));tokens=root.get('Tokens',root.get('tokens',{}))
        locs.append({k.casefold():v for k,v in tokens.items()})
    rarity_values={k:int(v['value']) for k,v in game['rarities'].items()}
    rows=[];aliases={};alias_ids={};colors={}
    def resolved(obj,seen=frozenset()):
        result={}
        for parent in obj.get('prefab','').split():
            if parent in game['prefabs'] and parent not in seen:result.update(resolved(game['prefabs'][parent],seen|{parent}))
        result.update(obj);return result
    weapon_tiers={int(i):rarity_values.get(resolved(item).get('item_rarity','common'),1)
        for i,item in game['items'].items() if i.isdecimal()}
    variants={}
    for composite in game['alternate_icons2']['weapon_icons']:
        if not composite.isdecimal():continue
        value=int(composite);weapon=value>>16;paint=(value&0xffff)>>2
        if weapon in weapon_tiers:variants.setdefault(paint,set()).add((weapon,weapon_tiers[weapon]))
    for name,r in game['rarities'].items():
        value=int(r['value']);color=game['colors'][r['color']]['hex_color'];colors[value]=color
    for ident,kit in game['paint_kits'].items():
        if not ident.isdecimal() or not isinstance(kit,dict):continue
        tier=rarity_values.get(game['paint_kits_rarity'].get(kit.get('name',''),''),0)
        if not 1<=tier<=7:continue
        tag=kit.get('description_tag','').lstrip('#')
        names={kit.get('name',''),tag,'#'+tag}
        for loc in locs:
            if loc.get(tag.casefold()):names.add(loc[tag.casefold()])
        names.discard('')
        pairs=sorted({(weapon,min(base+tier-1,7 if tier==7 else 6)) for weapon,base in variants.get(int(ident),set())})
        final_tiers={rarity for weapon,rarity in pairs}
        final=next(iter(final_tiers)) if len(final_tiers)==1 else 0
        rows.append({'id':int(ident),'rarity':final,'paint_rarity':tier,'weapon_variants':pairs,'names':sorted(names)})
        for nm in names:
            aliases.setdefault(nm,set()).add(final);alias_ids.setdefault(nm,set()).add(int(ident))
    rows.sort(key=lambda r:r['id']);assert len({r['id'] for r in rows})==len(rows)
    def wide(n):return 'L'+json.dumps(n,ensure_ascii=False)
    out=['#pragma once','#include <cstdint>','namespace skin_rarity_data {',
         'struct Entry {int id;unsigned char rarity;};','inline constexpr Entry entries[]={']
    out+=['{%d,%d},'%(r['id'],r['rarity']) for r in rows];out+=['};','struct Alias {const wchar_t* name;unsigned char rarity;int id;unsigned first,count;};','inline constexpr Alias aliases[]={']
    flattened=[]
    for n,v in sorted(aliases.items()):
        ids=sorted(alias_ids[n]);first=len(flattened);flattened.extend(ids)
        out.append('{%s,%d,%d,%d,%d},'%(wide(n),next(iter(v)) if len(v)==1 else 0,ids[0] if len(ids)==1 else -1,first,len(ids)))
    out+=['};','inline constexpr int alias_paints[]={',','.join(map(str,flattened))]

    out+=['};','struct IdAlias {int id;const wchar_t* name;};','inline constexpr IdAlias id_aliases[]={']
    out += ['{%d,%s},'%(r['id'],wide(n)) for r in rows for n in r['names']]
    out+=['};','struct Variant {int paint,weapon;unsigned char rarity;};','inline constexpr Variant variants[]={']
    out+=['{%d,%d,%d},'%(r['id'],weapon,tier) for r in rows for weapon,tier in r['weapon_variants']]
    colors[0]='#808080'
    out+=['};','inline constexpr std::uint32_t colors[]={']
    for i in range(8):
        hex_=colors.get(i,'#808080').lstrip('#');r,g,b=bytes.fromhex(hex_)
        out.append('0x%08xU,'%(r|(g<<8)|(b<<16)|0xff000000))
    out+=['};','}']
    target=ROOT/'source/skeet/skin_rarity_data.h';target.write_text('\n'.join(out)+'\n')
    meta={'source_repository':'SteamDatabase/GameTracking-CS2','source_commit':'e63fc7fdb8dfb4f1873f0db214c0cc16613d5beb',
        'schema_path':'csgo/scripts/items/items_game.txt','schema_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
        'paint_kits':len(rows),'weapon_variants':sum(len(r['weapon_variants']) for r in rows),'context_dependent_paint_kits':sum(r['rarity']==0 for r in rows),'aliases':len(aliases),'ambiguous_aliases':sum(len(v)>1 for v in aliases.values()),
        'unknown_rarity_policy':'neutral grey; do not guess from an ordinal or an ambiguous name',
        'colors':colors,'rows':rows}
    (ROOT/'data/skin_rarity_catalog.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
    print({k:v for k,v in meta.items() if k not in ['rows','colors']})
if __name__=='__main__':generate(Path(sys.argv[1]))
