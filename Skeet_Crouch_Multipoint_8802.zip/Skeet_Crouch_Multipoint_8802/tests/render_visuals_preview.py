#!/usr/bin/env python3
"""Schematic of production geometry/icons; native widgets are illustrations.
This is not a captured game frame and is not pixel-match validation.
"""
from pathlib import Path
import json,subprocess
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build'
subprocess.run([str(BUILD/'visuals_plan'),str(BUILD/'visuals_preview_layout.json')],check=True)
plan=json.loads((BUILD/'visuals_preview_layout.json').read_text())
S=2;W=2110;H=660
image=Image.new('RGB',(W*S,H*S),(33,33,33));draw=ImageDraw.Draw(image)
fonts=Path('/usr/share/fonts/truetype/dejavu')
def font(n=9,bold=False):return ImageFont.truetype(str(fonts/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),n*S)
def rect(x,y,w,h,c,outline=None):draw.rectangle((x*S,y*S,(x+w)*S-1,(y+h)*S-1),fill=c,outline=outline,width=S)
def text(x,y,t,c=(200,200,200),n=9,bold=False):draw.text((x*S,y*S),t,fill=c,font=font(n,bold))
accent=(157,196,43);gray=(90,90,90)
def checkbox(x,y,label,enabled=False,color=None):
    rect(x,y+3,6,6,accent if enabled else (67,67,67),outline=(26,26,26));text(x+18,y,label)
    if color:rect(x+196,y+3,15,7,color)
def combo(x,y,label,value):
    text(x,y,label);rect(x,y+16,174,18,(32,32,32),outline=(8,8,8));text(x+7,y+19,value,(167,167,167),8);text(x+160,y+18,'v',(135,135,135),8)
def panel(ox,oy,index):
    r=plan['panels'][index];x,y,w,h=r;x+=ox;y+=oy
    rect(x,y,w,h,(23,23,23),outline=(41,41,41));title=['Enemy ESP','Enemy models','Team ESP','Team models','Other ESP','Colored models','Effects','View','HUD','Danger Zone items'][index]
    rect(x+9,y-3,len(title)*6+8,8,(23,23,23));text(x+13,y-6,title,n=9,bold=True);return x+20,y+17
for column,(cat,label) in enumerate([(0,'ENEMY'),(3,'VIEW / HUD'),(2,'WORLD')]):
    ox=20+column*695;oy=50;text(ox,18,label,(212,212,212),11,True)
    rect(ox,oy,660,560,(12,12,12),outline=(78,78,78));rect(ox+5,oy+5,72,550,(10,10,10))
    for i,t in enumerate(['R','AA','L','V','M','S','P','C','LUA']):
        y=oy+37+54*i
        if i==3:rect(ox+6,y-12,70,46,(23,23,23),outline=(40,40,40))
        text(ox+29,y,t,(220,220,220) if i==3 else gray,12,True)
    rect(ox+76,oy+5,1,550,(37,37,37))
    for x in range(650):
        t=x/649;r=int(55+130*t);g=int(155-85*min(t*2,1)+110*max(t*2-1,0));b=int(205*(1-t));rect(ox+5+x,oy+4,1,1,(r,g,b))
    x,y,w,h=plan['category'];rect(ox+x,oy+y,w,h,(23,23,23),outline=(41,41,41));text(ox+x+13,oy+y-6,'Category',n=9,bold=True)
    for kind,x,y,w,h,color in plan['scenes'][cat]:
        a=(color>>24)&255
        c=tuple((((color>>(8*i))&255)*a+23*(255-a)+127)//255 for i in range(3))
        if kind==0:rect(ox+x,oy+y,w,h,c)
        elif kind==1:draw.line(((ox+x)*S,(oy+y)*S,(ox+w)*S,(oy+h)*S),fill=c,width=S)
    if cat==0:
        x,y=panel(ox,oy,0);combo(x,y,'Activation type','Always on');y+=48
        for i,t in enumerate(['Bounding box','Health bar','Name','Dormant','Flags','Skeleton','Weapon icon','Weapon text','Ammo','Distance','Off-screen arrow','Visualize aimbot','Bullet tracers']):checkbox(x,y+20*i,t,t in ['Health bar','Name'],(200,200,200) if i in [0,2] else None)
        x,y=panel(ox,oy,1)
        for i,t in enumerate(['Player','Player through walls','Glow','Shadow','On shot']):checkbox(x,y+20*i,t,False,[(156,202,38),(62,130,186),(171,91,119),(197,197,197),(146,161,135)][i])
    elif cat==3:
        x,y=panel(ox,oy,7)
        for i,t in enumerate(['Force third person (alive)','Force third person (dead)','Override FOV','Override zoom FOV','Instant scope','Visual recoil adjustment','Local player','Local player fake','Local transparency','Hands','Weapon viewmodel','Free look']):checkbox(x,y+24*i,t,t in ['Instant scope'])
        x,y=panel(ox,oy,8)
        for i,t in enumerate(['Feature indicators','Spectators','Remove scope overlay','Inaccuracy overlay','Recoil overlay','Penetration crosshair','Crosshair','Persistent kill feed','Hit marker','Hit marker sound','Radar']):checkbox(x,y+24*i,t,t in ['Feature indicators','Penetration crosshair'])
    else:
        x,y=panel(ox,oy,4);combo(x,y,'Dropped weapons','Icon, text');y+=50
        for i,t in enumerate(['Grenades','Bomb','Grenade trajectory','Grenade trajectory (hit)','Grenade proximity warning','Hostages']):checkbox(x,y+22*i,t,True)
        x,y=panel(ox,oy,5)
        for i,t in enumerate(['Ragdolls','Weapons','Disable model occlusion','Shadow','Props']):checkbox(x,y+22*i,t,t in ['Shadow','Props'])
        x,y=panel(ox,oy,6)
        for i,t in enumerate(['Remove flashbang effects','Remove smoke grenades','Remove fog','Remove skybox','Transparent walls','Transparent props','Brightness adjustment']):checkbox(x,y+23*i,t,i<3)
text(20,629,'SCHEMATIC PREVIEW: production panel geometry and category icons; widgets illustrated. Not an in-game screenshot.',(150,150,150),10)
path=ROOT/'Visuals_layout_preview.png';image.save(path);print(path)
# Close-up of the actual production coverage commands.
icons=Image.new('RGB',(800,140),(23,23,23));painter=ImageDraw.Draw(icons)
for kind,x,y,w,h,color in plan['scenes'][0][1:]:
    a=(color>>24)&255
    c=tuple((((color>>(8*i))&255)*a+23*(255-a)+127)//255 for i in range(3))
    x=(x-plan['category'][0])*2;y=(y-plan['category'][1])*2
    if kind==0:painter.rectangle((x,y,x+w*2-1,y+h*2-1),fill=c)
painter.text((20,116),'Production icon preview; not an in-game screenshot.',font=font(8),fill=(140,140,140))
icons.save(ROOT/'Visuals_icons_preview.png')
