#include "../source/skeet/body_preference_patch.h"
#include <array>
#include <vector>
#include <fstream>
#include <iterator>
#include <cassert>
#include <iostream>
using namespace body_preference;
int main(int argc,char**argv) {
    unsigned cases=0;
    for(unsigned hp:{1u,35u,100u,101u,1000u})for(unsigned damage:{0u,34u,35u,99u,100u,101u,1000u})
    for(unsigned hit:{1u,2u,3u,4u,6u,7u})for(unsigned flags:{0u,8u,16u})for(unsigned fire:{0u,0x400u}) {
        std::array<unsigned char,0x200> job{};std::array<unsigned char,3*point_size> points{};
        put(job.data(),8,hp);put(job.data(),0,flags);
        put(points.data(),0x24,6);put(points.data(),0x1c,80);put(points.data(),0x34,0x14);
        put(points.data()+point_size,0x24,hit);put(points.data()+point_size,0x1c,damage);put(points.data()+point_size,0x34,0x14);
        const auto before=job;const unsigned char* selected=points.data();
        const bool expected=(hit==2||hit==3)&&damage>=hp&&flags==0&&fire;
        assert(promote(job.data(),points.data(),points.size(),selected,0xff,fire)==expected);
        if(expected) {
            assert(selected==points.data()+point_size&&u32(job.data(),0)==8);
            assert(!std::memcmp(job.data()+0x44,points.data(),point_size));
            for(unsigned i=0;i<job.size();i++)if(i>=4&&(i<0x44||i>=0x7c))assert(job[i]==before[i]);
        }else assert(before==job&&selected==points.data());
        cases++;
    }
    std::array<unsigned char,0x200> job{};std::array<unsigned char,2*point_size> points{};
    put(job.data(),8,100);put(points.data(),0x24,7);put(points.data(),0x1c,80);put(points.data(),0x34,4);
    put(points.data()+point_size,0x24,2);put(points.data()+point_size,0x1c,100);put(points.data()+point_size,0x34,3);
    const unsigned char* selected=points.data();
    assert(!promote(job.data(),points.data(),points.size(),selected,0xff,0x400)); // Lower native priority is preserved.
    assert(!promote(job.data(),points.data(),points.size()-1,selected,0xff,0x400));
    selected=points.data()+1;assert(!promote(job.data(),points.data(),points.size(),selected,0xff,0x400));
    selected=points.data();put(points.data()+point_size,0x34,4);put(points.data()+point_size,0,0x7fc00000);
    assert(!promote(job.data(),points.data(),points.size(),selected,0xff,0x400));
    if(argc>1) {
        std::ifstream f(argv[1],std::ios::binary);std::vector<unsigned char> image((std::istreambuf_iterator<char>(f)),{});
        body_preference_patch::Plan p{};assert(body_preference_patch::make(image.data(),image.size(),0x50000000,0x12345678,p));
        if(argc>2){std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<const char*>(&p),sizeof(p));}
        image[body_preference_patch::site]^=1;assert(!body_preference_patch::make(image.data(),image.size(),0x50000000,0x12345678,p));
    }
    std::cout<<cases+4<<" lethal torso selection / eligibility cases passed\n";
}
