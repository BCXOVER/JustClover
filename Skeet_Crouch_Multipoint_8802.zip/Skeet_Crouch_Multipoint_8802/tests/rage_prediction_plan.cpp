#include "../source/skeet/rage_prediction_patch.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <cassert>
int main(int argc,char** argv) {
    assert(argc==5);std::ifstream in(argv[1],std::ios::binary);
    std::vector<unsigned char> image((std::istreambuf_iterator<char>(in)),{});
    rage_prediction_patch::Plan p{};
    assert(rage_prediction_patch::make(image.data(),image.size(),std::stoul(argv[3],nullptr,0),std::stoul(argv[4],nullptr,0),p));
    for(unsigned i=0;i<sizeof(rage_prediction_patch::original);i++) {
        auto wrong=image;wrong[rage_prediction_patch::site+i]^=1;rage_prediction_patch::Plan rejected{};
        assert(!rage_prediction_patch::make(wrong.data(),wrong.size(),0,0,rejected));
    }
    std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<const char*>(&p),sizeof(p));
}
