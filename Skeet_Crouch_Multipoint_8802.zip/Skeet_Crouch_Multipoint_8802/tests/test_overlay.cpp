#include "../source/skeet/overlay_patch.h"
#include <algorithm>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <vector>
#include <sys/mman.h>
#include <unistd.h>

static int checks = 0;
static void require(bool value) {
    ++checks;
    if (!value) throw std::runtime_error("Overlay test failed at check " + std::to_string(checks));
}
int main(int argc, char** argv) {
    using namespace overlay_patch;
    constexpr std::size_t n = sizeof(return_pattern) / sizeof(int);
    std::vector<std::uint8_t> signature;
    for (int value : return_pattern) signature.push_back(value < 0 ? 0x55 : value);
    require(find(nullptr, 0, return_pattern).count == 0);
    require(find(signature.data(), n - 1, return_pattern).count == 0);
    auto r = find(signature.data(), n, return_pattern);
    require(r.count == 1 && r.offset == 0);
    std::vector<std::uint8_t> data(41, 0x90);
    data.insert(data.end(), signature.begin(), signature.end());
    r = find(data.data(), data.size(), return_pattern);
    require(r.count == 1 && r.offset == 41); // Last possible offset is included.
    data.insert(data.end(), signature.begin(), signature.end());
    require(find(data.data(), data.size(), return_pattern).count == 2);
    for (int modrm : {0x5f, 0x7b, 0x83, 0xff}) {
        signature[n-2] = modrm;
        require(find(signature.data(), n, return_pattern).count == 1);
    }
    signature[0] ^= 1;
    require(find(signature.data(), n, return_pattern).count == 0);
    signature[0] ^= 1;
    const auto page = static_cast<std::size_t>(sysconf(_SC_PAGESIZE));
    auto* guard = static_cast<std::uint8_t*>(mmap(nullptr, 2*page, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0));
    require(guard != MAP_FAILED);
    require(mprotect(guard + page, page, PROT_NONE) == 0);
    std::copy(signature.begin(), signature.end(), guard + page - n);
    require(find(guard + page - n, n, return_pattern).count == 1);
    require(find(guard + page - 1, 1, return_pattern).count == 0);
    munmap(guard, 2*page);
    std::vector<std::uint8_t> image(0x2fc000, 0);
    require(!patch_calls(nullptr, image.size()));
    require(!patch_calls(image.data(), 0x741be));
    image[0x741a7] = image[0x741bc] = 0xff;
    image[0x741a8] = image[0x741bd] = 0x50;
    image[0x741a9] = 0x24; image[0x741be] = 0x29;
    require(!patch_calls(image.data(), image.size()));
    require(image[0x741a9] == 0x24); // No partial writes on a failed second call.
    image[0x741be] = 0x28;
    require(patch_calls(image.data(), image.size()));
    require(image[0x741a9] == 0x28 && image[0x741be] == 0x2c);
    require(patch_calls(image.data(), image.size())); // Idempotent.
    image[0x741a9] = 0x24;
    require(!patch_calls(image.data(), image.size())); // Mixed versions rejected.
    for (const char* name : {"skeet.bin", "skeet_cv.bin"}) {
        std::string path = (argc > 1 ? argv[1] : ".") + std::string("/source/skeet/Binary/") + name;
        std::ifstream file(path, std::ios::binary);
        require(file.good());
        std::vector<std::uint8_t> bytes((std::istreambuf_iterator<char>(file)), {});
        require(bytes.size() == 0x2fc000);
        auto before = bytes;
        require(patch_calls(bytes.data(), bytes.size()));
        std::size_t differences = 0;
        for (std::size_t i = 0; i < bytes.size(); ++i) if (before[i] != bytes[i]) {
            require(i == 0x741a9 || i == 0x741be); ++differences;
        }
        require(differences == 2);
    }
    std::cout << checks << " overlay checks passed (including both supplied image variants).\n";
}
