"""One native checkbox in Rage/Other, model changes and Lua object replacement."""
def check_prediction_ui(ns,feature="prediction"):
    caption="Extropolate" if feature=="prediction" else "Crouch multipoint"
    other_feature="crouch" if feature=="prediction" else "prediction"
    globals().update(ns)
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');api_base=0x140000
    u.mem_map(api_base,0x1000);u.mem_map(0x500000,0x100000)
    menu,tabs,rage,children,other,elements,api,vt,old=[MEM+0x10000+i*0x1000 for i in range(9)]
    store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs,rage)
    store(u,rage+0x70,children);store(u,rage+0x74,children+4);store(u,children,other)
    store(u,other,vt);store(u,vt+32,api_base+0x300)
    data='Other'.encode('utf-16le');store(u,other+0x38,other+0x300);u.mem_write(other+0x300,struct.pack('<HH',0,len(data))+data)
    store(u,other+0x80,elements);store(u,other+0x84,elements+4);store(u,other+0x88,elements+256);store(u,elements,old)
    allocations=[];checks=[];layouts=[]
    def mock(u,a,size,user):
        if not api_base<=a<api_base+0x1000:return
        sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);this=u.reg_read(UC_X86_REG_ECX);cleanup=4;result=0
        if a==api_base+0x100:
            result=0x500000+len(allocations)*0x1000;allocations.append((result,this));u.mem_write(result,bytes(0x1000))
        elif a==api_base+0x140:
            parent,name,value=[word(u,sp+i) for i in [4,8,12]];assert parent==other and wide(u,name) in ['Extropolate','Crouch multipoint']
            store(u,this+0x5c,value);store(u,value,0);checks.append(this);result=this;cleanup=16
        elif a==api_base+0x220:
            assert this==other and word(u,sp+4)==0;end=word(u,this+0x84);store(u,end,word(u,sp+8));store(u,this+0x84,end+4);cleanup=12
        elif a==api_base+0x300:assert this==other;layouts.append(this)
        else:raise AssertionError(hex(a))
        u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,mock)
    store(u,api,api_base+0x100);store(u,api+8,api_base+0x140);store(u,api+36,api_base+0x220)
    call(u,exp('prediction_ui_setup_probe'),[api]);call(u,exp(feature+'_ui_frame_probe'),[menu])
    assert len(checks)==1 and len(layouts)==1 and word(u,elements)==checks[0] and word(u,elements+4)==old,(checks,layouts,hex(word(u,elements)),hex(word(u,elements+4)),allocations)
    assert call(u,exp(feature+'_ui_value_probe'))==1;cases=1
    for value in [0,1,0,1,0]:
        control=checks[0];store(u,word(u,control+0x5c),value)
        calls=word(u,control+0x40);callback=word(u,calls+4)
        call(u,callback,[],word(u,calls),0)
        assert call(u,exp(feature+'_ui_value_probe'))==value
        assert call(u,exp(other_feature+'_ui_value_probe'))==1
        call(u,exp(feature+'_ui_frame_probe'),[menu]);assert len(checks)==1 and len(layouts)==1;cases+=1
    # Remove native object, unmap storage, and rebuild: no stale dereference;
    # the new constructor must preserve the user's OFF state.
    store(u,elements,old);store(u,other+0x84,elements+4);u.mem_unmap(checks[0],0x1000)
    call(u,exp(feature+'_ui_frame_probe'),[menu]);assert len(checks)==2 and len(layouts)==2
    assert word(u,word(u,checks[-1]+0x5c))==0 and call(u,exp(feature+'_ui_value_probe'))==0;cases+=1
    for i in range(20):call(u,exp(feature+'_ui_frame_probe'),[menu])
    assert len(checks)==2 and word(u,other+0x84)==elements+8;cases+=1
    call(u,exp(other_feature+'_ui_frame_probe'),[menu])
    assert len(checks)==3 and word(u,other+0x84)==elements+12
    assert call(u,exp(feature+'_ui_value_probe'))==0 and call(u,exp(other_feature+'_ui_value_probe'))==1
    call(u,exp(feature+'_ui_frame_probe'),[menu]);assert len(checks)==3
    cases+=1
    return cases
