#include <windows.h>
#include "../source/skeet/motion_patch.h"
#include "../source/skeet/rage_prediction_patch.h"
extern "C" {
__declspec(dllexport) unsigned char prediction_buffer[motion_records::record_size]{};
__declspec(dllexport) void prediction_initialize(unsigned sweep) {
    motion_patch::api={nullptr,reinterpret_cast<motion_records::Sweep>(sweep)};
    rage_prediction_patch::tls_slot=9;
}
__declspec(dllexport) void prediction_toggle(int on){motion_settings::extrapolation.store(on,std::memory_order_relaxed);}
__declspec(dllexport) void __fastcall prediction_bridge(void* frame){rage_prediction_patch::bridge(frame);}
__declspec(dllexport) int prediction_prepare(void* job,void* actor,const void* history,int on,int horizon,float now,int upper) {
    return rage_prediction::prepare(job,actor,history,{1,1,8,on,horizon},{1.f/64,now/64,0,upper},motion_patch::api,prediction_buffer);
}
}
