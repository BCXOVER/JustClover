#!/usr/bin/env python3
"""Bounded x86 fixtures: real Rage worker prolog, production bridge and forecast.
Engine hull tests are substituted, not an in-game accuracy benchmark.
"""
from pathlib import Path
import os,sys,subprocess,json,hashlib,struct,math
import pefile
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
from record_fixture import *
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR','/workspace/skeet-motion-bt-8802/.cache/global')
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++17','-O2','-shared','-Wl,--image-base,0x30000000',str(ROOT/'tests/rage_prediction_probe.cpp'),'-o',str(BUILD/'rage_prediction_probe.dll')],env=env,check=True)
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/rage_prediction_plan.cpp'),'-o',str(BUILD/'rage_prediction_plan')],check=True)
PE=pefile.PE(str(BUILD/'rage_prediction_probe.dll'));PB=PE.OPTIONAL_HEADER.ImageBase
EXPORTS={s.name.decode():PB+s.address for s in PE.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def ex(name):return next(v for k,v in EXPORTS.items() if name==k or name in k)
JOB=MEM+0x10000;BUF=ex('prediction_buffer');SWEEP=STOP+0x500;FRAME=MEM+0x30000
plans={}
def call(u,entry,args=(),ecx=0):
    for i,v in enumerate([STOP,*args]):store(u,SP+i*4,v)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,ecx)
    run_until(u,entry,STOP,1500000);return u.reg_read(UC_X86_REG_EAX)
class Case:
    def __init__(self,records=None,flags=4,now=108,location=0x50000000):
        self.u=u=fixture();self.sweeps=[];self.wall=None;self.location=location
        self.records=records or [(100,100,0,0),(99,99,0,0),(98,98,0,0),(97,97,0,0)]
        u.mem_map(PB,PE.OPTIONAL_HEADER.SizeOfImage);u.mem_write(PB,PE.get_memory_mapped_image())
        if location not in plans:
            p=BUILD/f'rage_prediction_plan_{location:x}.bin'
            subprocess.run([str(BUILD/'rage_prediction_plan'),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(p),hex(location),hex(ex('prediction_bridge'))],check=True);plans[location]=p.read_bytes()
        u.mem_map(location,4096);u.mem_write(location,plans[location][:128]);u.mem_write(0x4335cd45,plans[location][128:])
        imports={}
        for lib in PE.DIRECTORY_ENTRY_IMPORT:
            for item in lib.imports:
                a=STOP+0x600+len(imports)*16;imports[a]=item.name.decode() if item.name else str(item.ordinal);store(u,item.address,a)
        def hook(u,a,size,user):
            if a!=SWEEP and a not in imports:return
            sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);cleanup=4;result=0
            if a==SWEEP:
                actor=word(u,sp+4);assert actor==ACTOR
                start=struct.unpack('<fff',u.mem_read(sp+8,12));end=struct.unpack('<fff',u.mem_read(sp+20,12));self.sweeps.append((start,end));result=int(self.wall is None or end[0]<self.wall)
            else:
                name=imports[a]
                if name=='TlsGetValue':assert word(u,sp+4)==9;result=BUF;cleanup=8
                elif name in ['memcpy','memmove']:
                    dst,src,n=[word(u,sp+i) for i in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)));result=dst
                elif name=='memcmp':
                    x,y,n=[word(u,sp+i) for i in [4,8,12]];result=0 if u.mem_read(x,n)==u.mem_read(y,n) else 1
                elif name=='memset':
                    dst,v,n=[word(u,sp+i) for i in [4,8,12]];u.mem_write(dst,bytes([v&255])*n);result=dst
                else:raise AssertionError(('unexpected import',name))
            u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
        u.hook_add(UC_HOOK_CODE,hook)
        for i,(t,x,y,z) in enumerate(self.records):
            p=NEW+i*0x2000;store(u,HISTORY+0x5dc+i*4,p);u.mem_write(p,b'\0'*0x10a0)
            store(u,p+0x4c,t);store(u,p+0x5c,flags);floats(u,p+0x30,x,y,z)
            for s in range(4):
                for b in range(19):floats(u,p+0x230+s*0x3a0+b*48,1,0,0,x+b*.1,0,1,0,y,0,0,1,z+b)
        store(u,HISTORY+0x5d8,len(self.records));store(u,HISTORY+0x5d4,0);floats(u,HISTORY+0x13c,*self.records[0][1:])
        store(u,JOB+4,3);u.mem_write(JOB+0xf0,bytes(u.mem_read(NEW,0x10a0)))
        self.original=bytes(u.mem_read(JOB,0x1190));self.history=bytes(u.mem_read(HISTORY,0x1000));self.raw=bytes(u.mem_read(NEW,0x8000))
        floats(u,MEM+0x2000,1/64);floats(u,MEM+0x2004,now/64);floats(u,CONTEXT+0x198,0);floats(u,0x43476928,0);store(u,0x43468230,200)
        store(u,FRAME+8,CONTEXT);store(u,FRAME+0x10,ACTOR);store(u,FRAME+0x1c,JOB)
        call(u,ex('prediction_initialize'),[SWEEP]);call(u,ex('prediction_toggle'),[1])
    def prepare(self,on=1,horizon=8,now=108,upper=108):return call(self.u,ex('prediction_prepare'),[JOB,ACTOR,HISTORY,on,horizon,fbits(now),upper])
    def untouched_history(self):
        assert bytes(self.u.mem_read(HISTORY,0x1000))==self.history
        assert bytes(self.u.mem_read(NEW,0x8000))==self.raw
    def unchanged(self):assert bytes(self.u.mem_read(JOB,0x1190))==self.original;self.untouched_history()
checks=0
for sets in [4,0x84]:
    c=Case(flags=sets);assert c.prepare()==8;checks+=1
    for s in range(4 if sets&0x80 else 1):
        for b in range(19):
            for off,delta in [(12,8),(28,0),(44,0)]:
                addr=0x230+s*0x3a0+b*48+off
                assert abs(scalar(c.u,JOB+0xf0+addr)-scalar(c.u,NEW+addr)-delta)<1e-5;checks+=1
    assert word(c.u,JOB+0x13c)==108;assert c.u.mem_read(JOB,0xf0)==c.original[:0xf0];c.untouched_history()
for on,horizon,now,upper,expect in [(0,8,108,108,0),(1,0,108,108,0),(1,99,108,108,8),(1,8,104,108,4),(1,8,108,103,3),(1,8,99,108,0),(1,8,108,100,0)]:
    c=Case();assert c.prepare(on,horizon,now,upper)==expect;checks+=1
    if not expect:c.unchanged()
c=Case();c.wall=105;assert c.prepare()==4;assert word(c.u,JOB+0x13c)==104;assert len(c.sweeps)<=36;checks+=1
for mutate in ['older','matrix','stopped','teleport','nan','reverse','missing','yaw','stale','count']:
    c=Case();u=c.u
    if mutate=='older':store(u,JOB+0x13c,99)
    elif mutate=='matrix':floats(u,JOB+0x320+12,123)
    elif mutate=='stopped':store(u,NEW+0x5c,0x204);store(u,JOB+0x14c,0x204)
    elif mutate=='teleport':floats(u,NEW+0x30,1000,0,0)
    elif mutate=='nan':floats(u,NEW+0x230,float('nan'))
    elif mutate=='reverse':floats(u,OLD+0x30,102,0,0)
    elif mutate=='missing':store(u,HISTORY+0x5d8,2)
    elif mutate=='yaw':floats(u,OLD+0x28,90)
    elif mutate=='stale':floats(u,HISTORY+0x13c,101,0,0)
    elif mutate=='count':store(u,HISTORY+0x5d8,33)
    before=bytes(u.mem_read(JOB,0x1190));n=c.prepare()
    if mutate=='yaw':assert n==1  # long path refused; one-tick short fallback
    else:assert n==0 and bytes(u.mem_read(JOB,0x1190))==before
    checks+=1
# Production bridge, actual patched worker prolog, return address and ABI.
abi=0
for location in [0x10000000,0x50000000,0xf0000000]:
    for on in [0,1]:
        c=Case(location=location);u=c.u;call(u,ex('prediction_toggle'),[on])
        # Enter immediately before native prolog. It allocates its own 0x80a8 frame.
        stack=SP;args=[STOP,CONTEXT,0,ACTOR,0,0,JOB,0,0]
        for i,v in enumerate(args):store(u,stack+i*4,v)
        regs=[UC_X86_REG_EAX,UC_X86_REG_ECX,UC_X86_REG_EDX,UC_X86_REG_EBX,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP]
        for i,reg in enumerate(regs):u.reg_write(reg,0x123400+i*0x100)
        u.reg_write(UC_X86_REG_ECX,CONTEXT);u.reg_write(UC_X86_REG_ESP,stack);u.reg_write(UC_X86_REG_EFLAGS,0x202)
        for i in range(8):u.reg_write(UC_X86_REG_XMM0+i,0x0123456789abcdef+i)
        run_until(u,0x4335cd37,0x4335cd45)
        before={reg:u.reg_read(reg) for reg in regs};before.update({UC_X86_REG_EFLAGS:u.reg_read(UC_X86_REG_EFLAGS)})
        native_sp=u.reg_read(UC_X86_REG_ESP)
        run_until(u,0x4335cd45,0x4335cd4f,1500000)
        assert u.reg_read(UC_X86_REG_ESP)==native_sp
        for reg,v in before.items():assert u.reg_read(reg)==(JOB if reg==UC_X86_REG_EDI else v),(reg,hex(u.reg_read(reg)),hex(v))
        assert word(u,native_sp+0x80)==CONTEXT
        for i in range(8):assert u.reg_read(UC_X86_REG_XMM0+i)==0x0123456789abcdef+i
        assert word(u,JOB+0x13c)==(108 if on else 100)
        c.untouched_history();abi+=1
report={'passed':True,'forecast_checks':checks,'native_worker_prolog_abi_cases':abi,'core_sha256':hashlib.sha256(IMAGE).hexdigest(),'horizon_ticks':8,'translation_cap_units':64,'minimum_samples':3,'long_forecast_minimum_samples':4,'collision_sweep_each_tick':True,'native_time_window_preserved':True,'historical_ring_never_modified':True,'off_preserves_native_job':True,'game_tested':False,'scope':__doc__}
(BUILD/'rage_prediction_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
