#!/usr/bin/env python3
"""Schematic: production panel geometry, illustrated original native widgets."""
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
plan=json.loads((ROOT/'build/skin_menu_layout.json').read_text())
S=2;im=Image.new('RGB',(660*S,690*S),(12,12,12));d=ImageDraw.Draw(im)
def rect(x,y,w,h,c):d.rectangle((x*S,y*S,(x+w)*S-1,(y+h)*S-1),fill=c)
def text(x,y,t,c=(190,190,190),size=9,bold=False):
    f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',size*S)
    d.text((x*S,y*S),t,font=f,fill=c)
def check(x,y,label,on=True):
    rect(x,y+3,6,6,(151,193,38) if on else (65,65,65));text(x+18,y,label)
for x in range(650):
    t=x/649;rect(5+x,3,1,1,(int(55+140*t),int(150-80*min(1,t*2)+110*max(0,t*2-1)),int(205*(1-t))))
rect(78,5,1,630,(40,40,40))
for i,t in enumerate(['R','AA','L','V','M','SK','P','CFG','Lua']):
    if i==5:rect(5,20+i*61,72,52,(24,24,24))
    text(28,38+i*61,t,(230,230,230) if i==5 else (90,90,90),12,True)
for i,(x,y,w,h) in enumerate(plan['panels']):
    rect(x,y,w,h,(42,42,42));rect(x+1,y+1,w-2,h-2,(23,23,23));label=['Model customization','Weapon skin','Settings'][i]
    rect(x+8,y-4,len(label)*6+7,10,(23,23,23));text(x+12,y-6,label,size=9,bold=True)
x,y,_,_=plan['panels'][0];x+=20;y+=20;check(x,y,'Player model');y+=20
rect(x+18,y,180,40,(33,33,33));text(x+29,y+3,'Little Kev');text(x+29,y+18,'The Professionals',(115,115,115),8)
y+=42
for i,n in enumerate(['Little Kev','Getaway Sally','Number K','Sir Bloody Silent Darryl','Sir Bloody Skullhead Darryl','Sir Bloody Darryl Royale','Sir Bloody Miami Darryl','Safecracker Voltzmann']):
    rect(x+18,y+i*32,180,32,(30,30,30));rect(x+25,y+i*32+8,3,3,(145,80,170));text(x+32,y+i*32+3,n,(151,193,38) if i==0 else (190,190,190),8,i==0);text(x+32,y+i*32+16,'The Professionals',(110,110,110),8)
x,y,_,_=plan['panels'][2];check(x+20,y+20,'Filter by weapon')
x,y,w,h=plan['panels'][1];x+=20;y+=20
check(x,y,'Enabled');check(x,y+20,'StatTrak',False);text(x+18,y+42,'Quality');rect(x+18,y+63,w-55,4,(151,193,38));text(x+74,y+60,'100%',size=8)
text(x+18,y+79,'Seed');rect(x+18,y+99,w-55,4,(70,70,70));text(x+85,y+96,'0',size=8);check(x,y+114,'Apply to both teams')
y+=137;rect(x+18,y,w-58,330,(30,30,30));text(x+25,y+3,'Search...',(95,95,95),8)
for i,n in enumerate(['Autotronic','Black Laminate','Blue Steel','Boreal Forest','Bright Water','Case Hardened','Crimson Web','Damascus Steel','Doppler','Doppler','Doppler','Doppler','Fade','Forest DDPAT','Freehand','Gamma Doppler','Gamma Doppler','Tiger Tooth']):
    yy=y+23+i*15;rect(x+25,yy+4,3,3,(180,82,82));text(x+34,yy,n,(151,193,38) if i==8 else (190,190,190),8,i==8)
text(x+18,y+345,'Name tag',size=8)
rect(x+18,y+362,w-58,24,(29,29,29));text(x+23,y+367,'My skin',size=8)
text(x+18,y+402,'Skin colors',size=8)
for i,c in enumerate([(170,65,70),(75,120,180),(190,155,90),(110,90,160)]):rect(x+w-135+i*23,y+403,18,12,c)
text(12,654,'SCHEMATIC: panel geometry from code; widgets illustrated.',(135,135,135),9)
text(12,670,'Not an in-game screenshot. Original sidebar icons are preserved.',(135,135,135),9)
p=ROOT/'Skinchanger_layout_preview.png';im.save(p);print(p)
