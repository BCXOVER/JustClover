"""Native renderer depth ABI regression check."""
def check_renderer_depth(ns):
    globals().update(ns)
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');renderer,vt=MEM+0x70000,MEM+0x71000
    store(u,renderer,vt);store(u,vt+30*4,0x433cfd53);store(u,vt+29*4,0x433b360e)
    depth_calls=[]
    def command(u,a,size,user):
        if a!=0x433ab0fa:return
        sp=u.reg_read(UC_X86_REG_ESP);assert u.reg_read(UC_X86_REG_ECX)==renderer
        assert u.reg_read(UC_X86_REG_EDX)==15 and word(u,sp+4)==4
        depth_calls.append(True);u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+8)
    u.hook_add(UC_HOOK_CODE,command)
    for depth in [0.,.01,.35,.99,1.]:
        bits=fbits(depth);store(u,renderer+0x7c,bits)
        assert call(u,exp('renderer_depth_probe'),[renderer])==bits
        store(u,renderer+0x7c,fbits(.66))
        assert call(u,exp('renderer_set_depth_probe'),[renderer,bits])==bits
    assert len(depth_calls)==5
    return 10
