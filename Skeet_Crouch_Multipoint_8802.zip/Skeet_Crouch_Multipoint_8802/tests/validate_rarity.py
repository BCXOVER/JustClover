#!/usr/bin/env python3
"""Cross-check compiled catalog queries against the pinned schema facts."""
from pathlib import Path
import subprocess,json
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build'
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/skin_rarity_probe.cpp'),'-o',str(BUILD/'skin_rarity_probe')],check=True)
path=BUILD/'skin_rarity_results.txt'
subprocess.run([str(BUILD/'skin_rarity_probe'),str(path)],check=True)
cat=json.loads((ROOT/'data/skin_rarity_catalog.json').read_text());rows=cat['rows']
actual=[list(map(int,line.split())) for line in path.read_text().splitlines()];assert len(actual)==len(rows)
for row,record in zip(rows,actual):
    ident,tier,color=record;assert ident==row['id'] and tier==row['rarity']
    r,g,b=bytes.fromhex(cat['colors'][str(tier)].lstrip('#'))
    assert color==r|(g<<8)|(b<<16)|0xff000000
report={'passed':True,'catalog_paint_kits':len(rows),'weapon_variants':cat['weapon_variants'],
    'context_dependent_paint_kits':cat['context_dependent_paint_kits'],'source_commit':cat['source_commit'],
    'source_schema_sha256':cat['schema_sha256'],'source':'Valve legacy item schema via SteamDatabase GameTracking',
    'ordinal_names_validated':True,'unknown_or_ambiguous_color':'neutral grey','selected_markers_keep_rarity_color':True,'game_tested':False}
(BUILD/'rarity_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
