#include "../source/skeet/scan_patch.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 4) return 2;
    std::ifstream input(argv[1], std::ios::binary);
    std::vector<std::uint8_t> image((std::istreambuf_iterator<char>(input)), {});
    if (!scan_patch::matches_original(image.data(), image.size()) ||
        !scan_patch::compatible_sites(image.data(), image.size())) return 3;
    for (auto offset : {scan_patch::guard_call, scan_patch::threshold_call,
                        std::size_t(0x200e9), std::size_t(0x20172), std::size_t(0x200c8)}) {
        image[offset] ^= 1;
        if (scan_patch::compatible_sites(image.data(), image.size()) ||
            scan_patch::matches_original(image.data(), image.size())) return 4;
        image[offset] ^= 1;
    }
    const auto plan = scan_patch::make_plan(
        static_cast<std::uint32_t>(std::stoul(argv[3], nullptr, 0)), 0x20b000, 0x20b004);
    static_assert(sizeof(plan) == 139);
    std::ofstream output(argv[2], std::ios::binary);
    output.write(reinterpret_cast<const char*>(&plan), sizeof(plan));
    if (!output) return 5;
    std::cout << "Core identity and 5 incompatible-site rejection cases passed.\n";
}
