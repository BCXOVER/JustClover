43398f25 push     ebp
43398f26 mov      ebp, esp
43398f28 and      esp, 0xfffffff8
43398f2b sub      esp, 0x20
43398f2e push     esi
43398f2f mov      esi, ecx
43398f31 mov      dword ptr [esp + 0x18], edx
43398f35 push     edi
43398f36 xor      edi, edi
43398f38 cmp      dword ptr [esi + 0xd8], 0x40
43398f3f jne      0x43398f6f
43398f41 test     byte ptr [esi + 0x7c], 6
43398f45 movss    xmm3, dword ptr [0x4346f99c]
43398f4d movss    dword ptr [esp + 0x14], xmm3
43398f53 je       0x43398f5f
43398f55 movss    xmm0, dword ptr [0x4346f044]
43398f5d jmp      0x43398f67
43398f5f movss    xmm0, dword ptr [0x4346fa5c]
43398f67 mov      ecx, edi
43398f69 mov      dword ptr [esp + 0x18], edi
43398f6d jmp      0x43398f8f
43398f6f movss    xmm3, dword ptr [esi + 0xd0]
43398f77 mov      ecx, dword ptr [esi + 0xb0]
43398f7d movss    xmm0, dword ptr [esi + 0xc4]
43398f85 movss    dword ptr [esp + 0x14], xmm3
43398f8b mov      dword ptr [esp + 0x18], ecx
43398f8f mov      eax, dword ptr [ebp + 0x10]
43398f92 add      eax, 8
43398f95 movss    dword ptr [esp + 0xc], xmm0
43398f9b mov      dword ptr [esp + 0x10], eax
43398f9f movzx    eax, byte ptr [edi + 0x4346fc50]
43398fa6 mov      edx, ecx
43398fa8 movss    xmm2, dword ptr [esi + 0x100]
43398fb0 movaps   xmm1, xmm0
43398fb3 push     1
43398fb5 push     ecx
43398fb6 mov      ecx, dword ptr [esi + 0xd8]
43398fbc movaps   xmm0, xmm3
43398fbf push     eax
43398fc0 call     0x433adb4f
43398fc5 mov      eax, dword ptr [esp + 0x10]
43398fc9 add      edi, 4
43398fcc mov      ecx, dword ptr [esp + 0x1c]
43398fd0 movss    dword ptr [esp + 0x20], xmm0
43398fd6 movss    dword ptr [esp + 0x24], xmm1
43398fdc movq     xmm0, qword ptr [ecx]
43398fe0 movq     qword ptr [eax - 8], xmm0
43398fe5 movss    xmm1, dword ptr [ecx + 8]
43398fea mov      ecx, dword ptr [ebp + 8]
43398fed movss    dword ptr [eax], xmm1
43398ff1 movss    xmm1, dword ptr [ecx + 4]
43398ff6 movss    xmm2, dword ptr [ecx + 8]
43398ffb movss    xmm0, dword ptr [ecx]
43398fff mulss    xmm0, dword ptr [esp + 0x20]
43399005 mov      ecx, dword ptr [ebp + 0xc]
43399008 mulss    xmm1, dword ptr [esp + 0x20]
4339900e addss    xmm0, dword ptr [eax - 8]
43399013 mulss    xmm2, dword ptr [esp + 0x20]
43399019 addss    xmm1, dword ptr [eax - 4]
4339901e addss    xmm2, dword ptr [eax]
43399022 movss    dword ptr [eax - 8], xmm0
43399027 movss    dword ptr [eax - 4], xmm1
4339902c movss    dword ptr [eax], xmm2
43399030 movss    xmm3, dword ptr [ecx]
43399034 movss    xmm4, dword ptr [ecx + 4]
43399039 mulss    xmm3, dword ptr [esp + 0x24]
4339903f movss    xmm5, dword ptr [ecx + 8]
43399044 mulss    xmm4, dword ptr [esp + 0x24]
4339904a mov      ecx, dword ptr [esp + 0x18]
4339904e mulss    xmm5, dword ptr [esp + 0x24]
43399054 addss    xmm3, xmm0
43399058 addss    xmm4, xmm1
4339905c addss    xmm5, xmm2
43399060 movaps   xmm2, xmm3
43399063 mulss    xmm2, xmm2
43399067 movaps   xmm0, xmm4
4339906a mulss    xmm0, xmm0
4339906e movaps   xmm1, xmm5
43399071 mulss    xmm1, xmm1
43399075 addss    xmm2, xmm0
43399079 addss    xmm2, xmm1
4339907d movss    xmm1, dword ptr [0x43470514]
43399085 movaps   xmm0, xmm2
43399088 sqrtss   xmm0, xmm0
4339908c addss    xmm0, dword ptr [0x43472108]
43399094 divss    xmm1, xmm0
43399098 movss    xmm0, dword ptr [esp + 0xc]
4339909e mulss    xmm3, xmm1
433990a2 mulss    xmm4, xmm1
433990a6 mulss    xmm5, xmm1
433990aa movss    dword ptr [eax - 8], xmm3
433990af movss    xmm3, dword ptr [esp + 0x14]
433990b5 movss    dword ptr [eax - 4], xmm4
433990ba movss    dword ptr [eax], xmm5
433990be add      eax, 0xc
433990c1 mov      dword ptr [esp + 0x10], eax
433990c5 cmp      edi, 0x80
433990cb jb       0x43398f9f
433990d1 pop      edi
433990d2 pop      esi
433990d3 mov      esp, ebp
433990d5 pop      ebp
433990d6 ret      0xc
