433f54d5 push     ebp
433f54d6 mov      ebp, esp
433f54d8 and      esp, 0xfffffff0
433f54db sub      esp, 0x388
433f54e1 mov      eax, dword ptr [ebp + 0xc]
433f54e4 xor      edx, edx
433f54e6 push     esi
433f54e7 push     edi
433f54e8 mov      edi, 0x96
433f54ed mov      dword ptr [esp + 0x20], ecx
433f54f1 mov      esi, dword ptr [eax + 4]
433f54f4 mov      eax, esi
433f54f6 div      edi
433f54f8 mov      dword ptr [esp + 0x50], edi
433f54fc mov      edi, edx
433f54fe mov      dword ptr [esp + 0x7c], esi
433f5502 imul     eax, edi, 0x53c
433f5508 add      eax, dword ptr [ecx + 0x3c]
433f550b cmp      byte ptr [0x43467224], 0
433f5512 mov      dword ptr [esp + 0x8c], eax
433f5519 jne      0x433f552c
433f551b cmp      byte ptr [0x4346a740], 0
433f5522 jne      0x433f552c
433f5524 or       dword ptr [eax], 0xffffffff
433f5527 jmp      0x433f8c33
433f552c mov      eax, dword ptr [ebp + 0xc]
433f552f cmp      dword ptr [eax + 8], 0x7f7fffff
433f5536 je       0x433f8bfb
433f553c mov      esi, dword ptr [ebp + 8]
433f553f test     esi, esi
433f5541 jne      0x433f554f
433f5543 mov      dword ptr [0xb7940ac4], eax
433f5548 cmpsd    dword ptr [esi], dword ptr es:[edi]
433f5549 jp       0x433f556d
433f554b jo       0x433f55aa
433f554d adc      edx, ecx
433f554f mov      eax, dword ptr [0x43468354]
433f5554 mov      eax, dword ptr [eax]
433f5556 xor      eax, dword ptr [0x4346852c]
433f555c xor      eax, 0x66146802
433f5561 mov      dword ptr [esp + 0x94], eax
433f5568 movss    xmm0, dword ptr [eax + esi]
433f556d movss    dword ptr [esp + 0x148], xmm0
433f5576 test     esi, esi
433f5578 jne      0x433f5586
433f557a cmpsb    byte ptr [esi], byte ptr es:[edi]
433f557b mov      edx, 0x47f64b95
433f5580 dec      esi
433f5581 inc      ebx
433f5582 out      dx, eax
433f5583 sub      al, 0xb6
433f5585 wait     
433f5586 mov      eax, dword ptr [0x434679cc]
433f558b mov      eax, dword ptr [eax]
433f558d xor      eax, dword ptr [0x43467164]
433f5593 xor      eax, 0xa5bd68
433f5598 add      eax, esi
433f559a mov      dword ptr [esp + 0x144], eax
433f55a1 mov      al, byte ptr [eax]
433f55a3 mov      byte ptr [esp + 0x72], al
433f55a7 test     esi, esi
433f55a9 jne      0x433f55b7
433f55aa or       al, 2
433f55ab add      ch, byte ptr [ecx - 0x7b]
433f55ac imul     eax, dword ptr [ebp + 0xf4bcc2b], 0x7c933b7d
433f55ae sub      ecx, esp
433f55b0 dec      ebx
433f55b6 fisub    word ptr [ecx + 0x43468ee4]
433f55b7 mov      eax, dword ptr [0x43468ee4]
433f55bc mov      eax, dword ptr [eax]
433f55be xor      eax, dword ptr [0x4346853c]
433f55c4 xor      eax, 0x52899df3
433f55c9 add      eax, esi
433f55cb mov      dword ptr [esp + 0x13c], eax
433f55d2 mov      eax, dword ptr [eax]
433f55d4 mov      dword ptr [esp + 0x140], eax
433f55db test     esi, esi
433f55dd jne      0x433f55eb
433f55df adc      bl, dh
433f55e1 sti      
433f55eb mov      eax, dword ptr [0x434682b8]
433f55f0 mov      ecx, dword ptr [eax]
433f55f2 xor      ecx, dword ptr [0x43467d90]
433f55f8 mov      eax, dword ptr [0x4346794c]
433f55fd xor      ecx, 0x1bae1168
433f5603 xor      eax, 0xc429e1bf
433f5608 jmp      0x433f560c
433f560a mov      eax, edx
433f560c mov      edx, dword ptr [eax + 0x1c]
433f560f cmp      eax, edx
433f5611 jne      0x433f560a
433f5613 movss    xmm0, dword ptr [eax + 0x2c]
433f5618 movss    dword ptr [esp + 0x6c], xmm0
433f561e xor      dword ptr [esp + 0x6c], eax
433f5622 movss    xmm0, dword ptr [ecx + esi]
433f5627 mulss    xmm0, dword ptr [esp + 0x6c]
433f562d mov      eax, dword ptr [esp + 0x94]
433f5634 test     esi, esi
433f5636 jne      0x433f5657
433f5638 stosd    dword ptr es:[edi], eax
433f5639 rcl      byte ptr [ebx + 8], 0x36
433f563d push     ecx
433f563e int3     
433f5657 movss    dword ptr [eax + esi], xmm0
433f565c mov      eax, dword ptr [0x43468354]
433f5661 mov      ecx, dword ptr [esp + 0x20]
433f5665 imul     edx, edi, 0x4c
433f5668 lea      edi, [esp + 0x164]
433f566f mov      eax, dword ptr [eax]
433f5671 xor      eax, dword ptr [0x4346852c]
433f5677 mov      ecx, dword ptr [ecx + 0x40]
433f567a xor      eax, 0x66146802
433f567f mov      eax, dword ptr [eax + esi]
433f5682 mov      dword ptr [edx + ecx + 0xc], eax
433f5686 lea      edx, [esp + 0x164]
433f568d mov      eax, dword ptr [ebp + 0xc]
433f5690 mov      ecx, dword ptr [eax + 4]
433f5693 lea      esi, [eax + 0xc]
433f5696 movsd    dword ptr es:[edi], dword ptr [esi]
433f5697 movsd    dword ptr es:[edi], dword ptr [esi]
433f5698 movsd    dword ptr es:[edi], dword ptr [esi]
433f5699 call     0x43384c9e
433f569e mov      edx, dword ptr [ebp + 8]
433f56a1 test     edx, edx
433f56a3 jne      0x433f56b1
433f56a5 jmp      0x433f56bc
433f56b1 mov      eax, dword ptr [0x43467f4c]
433f56b6 mov      edi, dword ptr [esp + 0x8c]
433f56bc add      bl, dh
433f56bd movss    xmm0, dword ptr [0x43476b3c]
433f56be movups   xmm0, xmmword ptr [0x43476b3c]
433f56c5 mov      eax, dword ptr [eax]
433f56c7 xor      eax, dword ptr [0x4346a8b0]
433f56cd xor      eax, 0x3d52a1a7
433f56d2 mov      eax, dword ptr [eax + edx]
433f56d5 mov      dword ptr [esp + 0x4c], eax
433f56d9 movss    dword ptr [edi + 0x1f0], xmm0
433f56e1 test     eax, eax
433f56e3 je       0x433f5725
433f56e5 movss    xmm0, dword ptr [esp + 0x164]
433f56ee mov      ecx, dword ptr [esp + 0x7c]
433f56f2 push     0x348
433f56f7 push     eax
433f56f8 movss    dword ptr [edi + 0x1e8], xmm0
433f5700 lea      eax, [edi + 0x1f4]
433f5706 movss    xmm0, dword ptr [esp + 0x170]
433f570f push     eax
433f5710 mov      dword ptr [edi], ecx
433f5712 movss    dword ptr [edi + 0x1ec], xmm0
433f571a call     0x774fd4a0
433f571f mov      edx, dword ptr [ebp + 8]
433f5722 add      esp, 0xc
433f5725 lea      esi, [esp + 0x164]
433f572c lea      edi, [esp + 0xd0]
433f5733 movsd    dword ptr es:[edi], dword ptr [esi]
433f5734 movsd    dword ptr es:[edi], dword ptr [esi]
433f5735 movsd    dword ptr es:[edi], dword ptr [esi]
433f5736 mov      dword ptr [esp + 0x7c], 0xfcae0001
433f573e mov      eax, dword ptr [esp + 0x7c]
433f5742 mov      ecx, dword ptr [edx]
433f5744 ror      eax, 3
433f5747 rol      eax, 0x12
433f574a bswap    eax
433f574c neg      eax
433f574e bswap    eax
433f5750 mov      ecx, dword ptr [eax + ecx]
433f5753 mov      dword ptr [esp + 0x1ec], ecx
433f575a call     0x433e533f
433f575f mov      edi, eax
433f5761 lea      esi, [esp + 0xd0]
433f5768 movsd    dword ptr es:[edi], dword ptr [esi]
433f5769 movsd    dword ptr es:[edi], dword ptr [esi]
433f576a movsd    dword ptr es:[edi], dword ptr [esi]
433f576b mov      esi, dword ptr [esp + 0x4c]
433f576f mov      edi, dword ptr [ebp + 8]
433f5772 test     esi, esi
433f5774 je       0x433f8b27
433f577a lea      ecx, [edi + 8]
433f577d mov      eax, dword ptr [ecx]
433f577f call     dword ptr [eax + 0x28]
433f5782 test     eax, eax
433f5784 jne      0x433f5792
433f5786 retf     
433f5792 mov      ecx, eax
433f5794 call     0x433b8a2b
433f5799 mov      ecx, dword ptr [0x4346a660]
433f579f mov      dword ptr [esp + 0xc], eax
433f57a3 mov      eax, dword ptr [ecx]
433f57a5 xor      eax, dword ptr [0x434679e0]
433f57ab xor      eax, 0xb538bba5
433f57b0 add      eax, edi
433f57b2 mov      dword ptr [esp + 0x54], eax
433f57b6 mov      eax, dword ptr [eax + 0xc]
433f57b9 mov      dword ptr [esp + 0x58], eax
433f57bd mov      eax, dword ptr [0x43467eb8]
433f57c2 mov      dword ptr [esp + 0x138], eax
433f57c9 movss    xmm0, dword ptr [eax]
433f57cd mov      eax, dword ptr [0x43468fd0]
433f57d2 movss    dword ptr [esp + 0x7c], xmm0
433f57d8 mov      eax, dword ptr [eax]
433f57da xor      eax, dword ptr [0x43467c70]
433f57e0 xor      eax, 0xf58e6118
433f57e5 add      eax, edi
433f57e7 mov      dword ptr [esp + 0x130], eax
433f57ee mov      ecx, dword ptr [eax]
433f57f0 mov      eax, dword ptr [0x43468fec]
433f57f5 mov      dword ptr [esp + 0x134], ecx
433f57fc mov      eax, dword ptr [eax]
433f57fe xor      eax, dword ptr [0x4346a3c4]
433f5804 xor      eax, 0xa2a8247f
433f5809 add      eax, edi
433f580b mov      dword ptr [esp + 0x12c], eax
433f5812 movss    xmm0, dword ptr [eax]
433f5816 mov      eax, dword ptr [0x43467a74]
433f581b movss    dword ptr [esp + 0x128], xmm0
433f5824 mov      eax, dword ptr [eax]
433f5826 xor      eax, dword ptr [0x434678c0]
433f582c xor      eax, 0xcd812654
433f5831 mov      ecx, dword ptr [eax + edi]
433f5834 cmp      ecx, -1
433f5837 jne      0x433f5840
433f5839 and      dword ptr [esp + 0x60], 0
433f583e jmp      0x433f585b
433f5840 mov      eax, dword ptr [0x4346a890]
433f5845 push     ecx
433f5846 mov      eax, dword ptr [eax]
433f5848 mov      edx, dword ptr [eax + 0x10]
433f584b mov      eax, esp
433f584d mov      dword ptr [eax], ecx
433f584f mov      ecx, dword ptr [0x4346a890]
433f5855 call     edx
433f5857 mov      dword ptr [esp + 0x60], eax
433f585b cmp      byte ptr [ebp + 0x18], 0
433f585f mov      byte ptr [esp + 0x5f], 0
433f5864 mov      dword ptr [esp + 0xe8], 0x4346dc8c
433f586f je       0x433f758d
433f5875 mov      eax, dword ptr [ebp + 0xc]
433f5878 mov      eax, dword ptr [eax + 4]
433f587b mov      dword ptr [esp + 0x34], eax
433f587f lea      edx, [eax - 1]
433f5882 mov      eax, dword ptr [esp + 0x20]
433f5886 mov      dword ptr [esp + 0x28], edx
433f588a mov      eax, dword ptr [eax + 0x38]
433f588d mov      eax, dword ptr [eax]
433f588f inc      eax
433f5890 mov      dword ptr [esp + 0x14], eax
433f5894 cmp      edx, eax
433f5896 jl       0x433f593b
433f589c mov      eax, dword ptr [0x4346a894]
433f58a1 mov      ecx, dword ptr [eax + 0xf0]
433f58a7 mov      dword ptr [esp + 0x18], ecx
433f58ab mov      eax, edx
433f58ad xor      edx, edx
433f58af div      dword ptr [esp + 0x50]
433f58b3 mov      eax, edx
433f58b5 mov      edx, dword ptr [esp + 0x28]
433f58b9 mov      dword ptr [esp + 0x1c], eax
433f58bd imul     eax, eax, 0x64
433f58c0 add      eax, ecx
433f58c2 xor      ecx, ecx
433f58c4 cmp      dword ptr [eax + 4], edx
433f58c7 cmove    ecx, eax
433f58ca test     ecx, ecx
433f58cc je       0x433f5928
433f58ce cmp      dword ptr [ecx + 8], 0x7f7fffff
433f58d5 jge      0x433f5928
433f58d7 mov      eax, dword ptr [esp + 0x20]
433f58db imul     ecx, dword ptr [esp + 0x1c], 0x4c
433f58e0 mov      eax, dword ptr [eax + 0x40]
433f58e3 cmp      dword ptr [ecx + eax], edx
433f58e6 jne      0x433f758d
433f58ec imul     eax, dword ptr [esp + 0x1c], 0x53c
433f58f4 mov      ecx, dword ptr [esp + 0x20]
433f58f8 add      eax, dword ptr [ecx + 0x3c]
433f58fb cmp      dword ptr [eax], edx
433f58fd jne      0x433f5928
433f58ff cmp      byte ptr [eax + 0x1f8], 0
433f5906 jne      0x433f758d
433f590c cmp      dword ptr [eax + 0x254], edi
433f5912 jne      0x433f758d
433f5918 mov      ecx, dword ptr [esp + 0x60]
433f591c cmp      dword ptr [eax + 0x258], ecx
433f5922 jne      0x433f758d
433f5928 mov      ecx, dword ptr [esp + 0x18]
433f592c dec      edx
433f592d mov      dword ptr [esp + 0x28], edx
433f5931 cmp      edx, dword ptr [esp + 0x14]
433f5935 jge      0x433f58ab
433f593b push     0xd
433f593d pop      esi
433f593e cmp      dword ptr [esp + 0x58], esi
433f5942 jl       0x433f598a
433f5944 mov      eax, dword ptr [esp + 0x54]
433f5948 mov      ecx, dword ptr [esp + 0xc]
433f594c add      ecx, 0x468
433f5952 mov      edx, dword ptr [eax]
433f5954 add      edx, 0x18
433f5957 mov      eax, dword ptr [ecx]
433f5959 lea      ecx, [ecx + 0x1c]
433f595c mov      dword ptr [edx - 4], eax
433f595f mov      eax, dword ptr [ecx - 0x18]
433f5962 mov      dword ptr [edx], eax
433f5964 lea      edx, [edx + 0x38]
433f5967 mov      eax, dword ptr [ecx - 0x14]
433f596a mov      dword ptr [edx - 0x34], eax
433f596d mov      eax, dword ptr [ecx - 0x10]
433f5970 mov      dword ptr [edx - 0x30], eax
433f5973 mov      eax, dword ptr [ecx - 0xc]
433f5976 mov      dword ptr [edx - 0x2c], eax
433f5979 mov      eax, dword ptr [ecx - 8]
433f597c mov      dword ptr [edx - 0x28], eax
433f597f mov      eax, dword ptr [ecx - 4]
433f5982 mov      dword ptr [edx - 0x24], eax
433f5985 sub      esi, 1
433f5988 jne      0x433f5957
433f598a mov      eax, dword ptr [0x4346a8e4]
433f598f mov      ecx, dword ptr [ebp + 8]
433f5992 mov      esi, dword ptr [eax]
433f5994 xor      esi, dword ptr [0x434688cc]
433f599a mov      eax, dword ptr [0x43468d30]
433f599f xor      esi, 0x36375c23
433f59a5 add      esi, edi
433f59a7 lea      edi, [esp + 0x194]
433f59ae movsd    dword ptr es:[edi], dword ptr [esi]
433f59af movsd    dword ptr es:[edi], dword ptr [esi]
433f59b0 movsd    dword ptr es:[edi], dword ptr [esi]
433f59b1 mov      esi, dword ptr [eax]
433f59b3 lea      edi, [esp + 0x1b0]
433f59ba mov      eax, dword ptr [0x434679f8]
433f59bf xor      esi, dword ptr [0x43468ed4]
433f59c5 xor      esi, 0x2a671b42
433f59cb add      esi, ecx
433f59cd mov      eax, dword ptr [eax]
433f59cf xor      eax, dword ptr [0x434675f8]
433f59d5 xor      eax, 0x3309c0cf
433f59da movsd    dword ptr es:[edi], dword ptr [esi]
433f59db movss    xmm0, dword ptr [eax + ecx]
433f59e0 mov      eax, dword ptr [0x43467dd4]
433f59e5 movsd    dword ptr es:[edi], dword ptr [esi]
433f59e6 movss    dword ptr [esp + 0x98], xmm0
433f59ef mov      eax, dword ptr [eax]
433f59f1 xor      eax, dword ptr [0x4346a52c]
433f59f7 xor      eax, 0xfb7e3404
433f59fc movsd    dword ptr es:[edi], dword ptr [esi]
433f59fd movss    dword ptr [esp + 0x1ac], xmm0
433f5a06 movss    xmm0, dword ptr [eax + ecx]
433f5a0b mov      eax, dword ptr [0x434688d0]
433f5a10 movss    dword ptr [esp + 0x9c], xmm0
433f5a19 movss    dword ptr [esp + 0x1a8], xmm0
433f5a22 mov      eax, dword ptr [eax]
433f5a24 xor      eax, dword ptr [0x43468c24]
433f5a2a xor      eax, 0xe2fbe695
433f5a2f mov      eax, dword ptr [eax + ecx]
433f5a32 mov      dword ptr [esp + 0x84], eax
433f5a39 mov      dword ptr [esp + 0x1a0], eax
433f5a40 mov      eax, dword ptr [0x434678a4]
433f5a45 mov      eax, dword ptr [eax]
433f5a47 xor      eax, dword ptr [0x4346905c]
433f5a4d xor      eax, 0xac7f2913
433f5a52 movzx    eax, byte ptr [eax + ecx]
433f5a56 mov      dword ptr [esp + 0x1a4], eax
433f5a5d mov      eax, dword ptr [0x43468c40]
433f5a62 mov      eax, dword ptr [eax]
433f5a64 xor      eax, dword ptr [0x43468db8]
433f5a6a xor      eax, 0x7090d8dd
433f5a6f mov      al, byte ptr [eax + ecx]
433f5a72 mov      byte ptr [esp + 0x71], al
433f5a76 mov      byte ptr [esp + 0x1c9], al
433f5a7d mov      eax, dword ptr [0x43468da4]
433f5a82 mov      eax, dword ptr [eax]
433f5a84 xor      eax, dword ptr [0x434684ec]
433f5a8a xor      eax, 0xcacaeecc
433f5a8f mov      al, byte ptr [eax + ecx]
433f5a92 mov      byte ptr [esp + 0x7b], al
433f5a96 mov      byte ptr [esp + 0x1ca], al
433f5a9d mov      eax, dword ptr [0x4346a7e0]
433f5aa2 mov      eax, dword ptr [eax]
433f5aa4 xor      eax, dword ptr [0x43468c34]
433f5aaa xor      eax, 0xa15c3105
433f5aaf mov      al, byte ptr [eax + ecx]
433f5ab2 mov      byte ptr [esp + 0x73], al
433f5ab6 mov      byte ptr [esp + 0x1cb], al
433f5abd mov      eax, dword ptr [0x43468c88]
433f5ac2 mov      eax, dword ptr [eax]
433f5ac4 xor      eax, dword ptr [0x4346a3ac]
433f5aca xor      eax, 0xae838771
433f5acf movss    xmm0, dword ptr [eax + ecx]
433f5ad4 mov      eax, dword ptr [0x434682a8]
433f5ad9 movss    dword ptr [esp + 0x64], xmm0
433f5adf movss    dword ptr [esp + 0x1bc], xmm0
433f5ae8 mov      eax, dword ptr [eax]
433f5aea xor      eax, dword ptr [0x43467960]
433f5af0 xor      eax, 0xd4248210
433f5af5 mov      eax, dword ptr [eax + ecx]
433f5af8 mov      dword ptr [esp + 0x3c], eax
433f5afc mov      dword ptr [esp + 0x1c0], eax
433f5b03 mov      eax, dword ptr [0x43468914]
433f5b08 mov      esi, dword ptr [esp + 0x20]
433f5b0c mov      eax, dword ptr [eax]
433f5b0e xor      eax, dword ptr [0x4346a528]
433f5b14 xor      eax, 0xa3abbb09
433f5b19 mov      eax, dword ptr [eax + ecx]
433f5b1c mov      dword ptr [esp + 0x40], eax
433f5b20 mov      dword ptr [esp + 0x1c4], eax
433f5b27 mov      eax, dword ptr [0x43468bd4]
433f5b2c mov      eax, dword ptr [eax]
433f5b2e xor      eax, dword ptr [0x4346a678]
433f5b34 xor      eax, 0x7501cb91
433f5b39 mov      al, byte ptr [eax + ecx]
433f5b3c mov      byte ptr [esp + 0x4b], al
433f5b40 mov      byte ptr [esp + 0x1c8], al
433f5b47 mov      eax, dword ptr [esp + 0xc]
433f5b4b movss    xmm0, dword ptr [eax + 0x118]
433f5b53 mov      eax, dword ptr [esi + 0x38]
433f5b56 movss    dword ptr [esp + 0x6c], xmm0
433f5b5c movss    xmm0, dword ptr [0x43476b3c]
433f5b64 movss    dword ptr [esp + 0x90], xmm0
433f5b6d mov      edi, dword ptr [eax]
433f5b6f jmp      0x433f7363
433f5b74 xor      edx, edx
433f5b76 mov      ecx, 0x96
433f5b7b mov      eax, edi
433f5b7d div      ecx
433f5b7f imul     eax, edx, 0x64
433f5b82 mov      dword ptr [esp + 0x2c], eax
433f5b86 mov      eax, dword ptr [0x4346a894]
433f5b8b mov      ecx, dword ptr [esp + 0x2c]
433f5b8f add      ecx, dword ptr [eax + 0xf0]
433f5b95 mov      eax, ecx
433f5b97 mov      dword ptr [esp + 0x2c], ecx
433f5b9b mov      ecx, dword ptr [ebp + 8]
433f5b9e cmp      dword ptr [eax + 8], 0x7f7fffff
433f5ba5 je       0x433f7363
433f5bab imul     eax, edx, 0x53c
433f5bb1 add      eax, dword ptr [esi + 0x3c]
433f5bb4 mov      dword ptr [esp + 0x28], eax
433f5bb8 cmp      dword ptr [eax], edi
433f5bba jne      0x433f7363
433f5bc0 mov      eax, dword ptr [0x4346a338]
433f5bc5 lea      edi, [esp + 0x250]
433f5bcc imul     ecx, edx, 0x4c
433f5bcf mov      edx, dword ptr [ebp + 8]
433f5bd2 add      ecx, dword ptr [esi + 0x40]
433f5bd5 mov      dword ptr [esp + 0xc], ecx
433f5bd9 movd     xmm0, dword ptr [ecx + 8]
433f5bde lea      esi, [ecx + 0x14]
433f5be1 cvtdq2ps xmm0, xmm0
433f5be4 mulss    xmm0, dword ptr [eax]
433f5be8 mov      eax, dword ptr [0x43467b04]
433f5bed movss    dword ptr [eax + 0x10], xmm0
433f5bf2 movsd    dword ptr es:[edi], dword ptr [esi]
433f5bf3 mov      eax, dword ptr [0x434670a0]
433f5bf8 movsd    dword ptr es:[edi], dword ptr [esi]
433f5bf9 movsd    dword ptr es:[edi], dword ptr [esi]
433f5bfa mov      edi, dword ptr [eax]
433f5bfc lea      esi, [esp + 0x250]
433f5c03 xor      edi, dword ptr [0x4346900c]
433f5c09 xor      edi, 0x7a2d60c1
433f5c0f add      edi, edx
433f5c11 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c12 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c13 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c14 mov      eax, dword ptr [0x4346a8e4]
433f5c19 lea      esi, [ecx + 0x14]
433f5c1c lea      edi, [esp + 0x260]
433f5c23 add      ecx, 0x30
433f5c26 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c27 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c28 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c29 mov      edi, dword ptr [eax]
433f5c2b lea      esi, [esp + 0x260]
433f5c32 xor      edi, dword ptr [0x434688cc]
433f5c38 xor      edi, 0x36375c23
433f5c3e add      edi, edx
433f5c40 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c41 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c42 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c43 mov      eax, dword ptr [0x434670e0]
433f5c48 lea      edi, [esp + 0x270]
433f5c4f mov      esi, ecx
433f5c51 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c52 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c53 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c54 mov      edi, dword ptr [eax]
433f5c56 lea      esi, [esp + 0x270]
433f5c5d xor      edi, dword ptr [0x43467d28]
433f5c63 xor      edi, 0x4e66bb34
433f5c69 add      edi, edx
433f5c6b movsd    dword ptr es:[edi], dword ptr [esi]
433f5c6c movsd    dword ptr es:[edi], dword ptr [esi]
433f5c6d movsd    dword ptr es:[edi], dword ptr [esi]
433f5c6e mov      eax, dword ptr [0x43468d30]
433f5c73 lea      edi, [esp + 0x280]
433f5c7a mov      esi, ecx
433f5c7c movsd    dword ptr es:[edi], dword ptr [esi]
433f5c7d movsd    dword ptr es:[edi], dword ptr [esi]
433f5c7e movsd    dword ptr es:[edi], dword ptr [esi]
433f5c7f mov      edi, dword ptr [eax]
433f5c81 lea      esi, [esp + 0x280]
433f5c88 xor      edi, dword ptr [0x43468ed4]
433f5c8e xor      edi, 0x2a671b42
433f5c94 add      edi, edx
433f5c96 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c97 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c98 movsd    dword ptr es:[edi], dword ptr [esi]
433f5c99 mov      eax, dword ptr [0x434670cc]
433f5c9e lea      edi, [esp + 0x230]
433f5ca5 mov      esi, ecx
433f5ca7 movsd    dword ptr es:[edi], dword ptr [esi]
433f5ca8 movsd    dword ptr es:[edi], dword ptr [esi]
433f5ca9 movsd    dword ptr es:[edi], dword ptr [esi]
433f5caa mov      edi, dword ptr [eax]
433f5cac lea      esi, [esp + 0x230]
433f5cb3 xor      edi, dword ptr [0x43468bcc]
433f5cb9 xor      edi, 0xa9ee6062
433f5cbf add      edi, edx
433f5cc1 movsd    dword ptr es:[edi], dword ptr [esi]
433f5cc2 movsd    dword ptr es:[edi], dword ptr [esi]
433f5cc3 movsd    dword ptr es:[edi], dword ptr [esi]
433f5cc4 mov      eax, dword ptr [0x434679f8]
433f5cc9 mov      edx, dword ptr [esp + 0xc]
433f5ccd mov      esi, dword ptr [ebp + 8]
433f5cd0 mov      edi, dword ptr [esp + 0x60]
433f5cd4 mov      eax, dword ptr [eax]
433f5cd6 xor      eax, dword ptr [0x434675f8]
433f5cdc movss    xmm0, dword ptr [edx + 0x2c]
433f5ce1 xor      eax, 0x3309c0cf
433f5ce6 movss    dword ptr [eax + esi], xmm0
433f5ceb mov      eax, dword ptr [0x43467dd4]
433f5cf0 movss    xmm0, dword ptr [edx + 0x28]
433f5cf5 mov      eax, dword ptr [eax]
433f5cf7 xor      eax, dword ptr [0x4346a52c]
433f5cfd xor      eax, 0xfb7e3404
433f5d02 movss    dword ptr [eax + esi], xmm0
433f5d07 mov      eax, dword ptr [0x434688d0]
433f5d0c mov      ecx, dword ptr [edx + 0x20]
433f5d0f mov      eax, dword ptr [eax]
433f5d11 xor      eax, dword ptr [0x43468c24]
433f5d17 xor      eax, 0xe2fbe695
433f5d1c mov      dword ptr [eax + esi], ecx
433f5d1f mov      eax, dword ptr [0x434678a4]
433f5d24 mov      cl, byte ptr [edx + 0x24]
433f5d27 mov      eax, dword ptr [eax]
433f5d29 xor      eax, dword ptr [0x4346905c]
433f5d2f xor      eax, 0xac7f2913
433f5d34 mov      byte ptr [eax + esi], cl
433f5d37 mov      eax, dword ptr [0x43468c40]
433f5d3c mov      cl, byte ptr [edx + 0x49]
433f5d3f mov      eax, dword ptr [eax]
433f5d41 xor      eax, dword ptr [0x43468db8]
433f5d47 xor      eax, 0x7090d8dd
433f5d4c mov      byte ptr [eax + esi], cl
433f5d4f mov      eax, dword ptr [0x43468da4]
433f5d54 mov      cl, byte ptr [edx + 0x4a]
433f5d57 mov      eax, dword ptr [eax]
433f5d59 xor      eax, dword ptr [0x434684ec]
433f5d5f xor      eax, 0xcacaeecc
433f5d64 mov      byte ptr [eax + esi], cl
433f5d67 mov      eax, dword ptr [0x4346a7e0]
433f5d6c mov      cl, byte ptr [edx + 0x4b]
433f5d6f mov      eax, dword ptr [eax]
433f5d71 xor      eax, dword ptr [0x43468c34]
433f5d77 xor      eax, 0xa15c3105
433f5d7c mov      byte ptr [eax + esi], cl
433f5d7f mov      eax, dword ptr [0x43468c88]
433f5d84 movss    xmm0, dword ptr [edx + 0x3c]
433f5d89 mov      eax, dword ptr [eax]
433f5d8b xor      eax, dword ptr [0x4346a3ac]
433f5d91 xor      eax, 0xae838771
433f5d96 movss    dword ptr [eax + esi], xmm0
433f5d9b mov      eax, dword ptr [0x434682a8]
433f5da0 mov      ecx, dword ptr [edx + 0x40]
433f5da3 mov      eax, dword ptr [eax]
433f5da5 xor      eax, dword ptr [0x43467960]
433f5dab xor      eax, 0xd4248210
433f5db0 mov      dword ptr [eax + esi], ecx
433f5db3 mov      eax, dword ptr [0x43468914]
433f5db8 mov      ecx, dword ptr [edx + 0x44]
433f5dbb mov      eax, dword ptr [eax]
433f5dbd xor      eax, dword ptr [0x4346a528]
433f5dc3 xor      eax, 0xa3abbb09
433f5dc8 mov      dword ptr [eax + esi], ecx
433f5dcb mov      eax, dword ptr [0x43468bd4]
433f5dd0 mov      cl, byte ptr [edx + 0x48]
433f5dd3 mov      eax, dword ptr [eax]
433f5dd5 xor      eax, dword ptr [0x4346a678]
433f5ddb xor      eax, 0x7501cb91
433f5de0 mov      byte ptr [eax + esi], cl
433f5de3 mov      ecx, edi
433f5de5 call     0x43340a83
433f5dea dec      eax
433f5deb cmp      byte ptr [esp + 0x5f], 0
433f5df0 mov      dword ptr [esp + 0x1c], eax
433f5df4 jne      0x433f5eb9
433f5dfa xor      edx, edx
433f5dfc lea      eax, [edi - 1]
433f5dff mov      ecx, 0x96
433f5e04 div      ecx
433f5e06 mov      eax, dword ptr [esp + 0x20]
433f5e0a imul     ecx, edx, 0x53c
433f5e10 add      ecx, dword ptr [eax + 0x3c]
433f5e13 lea      eax, [edi - 1]
433f5e16 cmp      dword ptr [ecx], eax
433f5e18 jne      0x433f5e32
433f5e1a mov      eax, dword ptr [0x434679cc]
433f5e1f mov      cl, byte ptr [ecx + 4]
433f5e22 mov      eax, dword ptr [eax]
433f5e24 xor      eax, dword ptr [0x43467164]
433f5e2a xor      eax, 0xa5bd68
433f5e2f mov      byte ptr [eax + esi], cl
433f5e32 mov      eax, dword ptr [esp + 0x28]
433f5e36 mov      edi, dword ptr [esp + 0x4c]
433f5e3a add      eax, 0x1f4
433f5e3f push     0x348
433f5e44 push     eax
433f5e45 push     edi
433f5e46 mov      byte ptr [esp + 0x6b], 1
433f5e4b call     0x774fd4a0
433f5e50 mov      ecx, dword ptr [esp + 0x60]
433f5e54 add      esp, 0xc
433f5e57 cmp      dword ptr [ecx + 0xc], 7
433f5e5b jle      0x433f5e95
433f5e5d mov      eax, dword ptr [ecx]
433f5e5f mov      eax, dword ptr [eax + 0x1a0]
433f5e65 mov      dword ptr [edi + 0x19c], eax
433f5e6b mov      eax, dword ptr [ecx]
433f5e6d mov      eax, dword ptr [eax + 0x1a8]
433f5e73 mov      dword ptr [edi + 0x190], eax
433f5e79 mov      eax, dword ptr [ecx]
433f5e7b mov      eax, dword ptr [eax + 0x1b4]
433f5e81 mov      dword ptr [edi + 0x198], eax
433f5e87 mov      eax, dword ptr [ecx]
433f5e89 mov      eax, dword ptr [eax + 0x17c]
433f5e8f mov      dword ptr [edi + 0x98], eax
433f5e95 mov      eax, dword ptr [esp + 0x28]
433f5e99 movss    xmm0, dword ptr [eax + 0x1f0]
433f5ea1 ucomiss  xmm0, dword ptr [0x43472244]
433f5ea8 lahf     
433f5ea9 test     ah, 0x44
433f5eac jnp      0x433f5ee7
433f5eae movss    dword ptr [esp + 0x90], xmm0
433f5eb7 jmp      0x433f5ee7
433f5eb9 mov      eax, dword ptr [esp + 0x28]
433f5ebd movss    xmm0, dword ptr [0x43476b3c]
433f5ec5 push     0x348
433f5eca mov      dword ptr [eax], edi
433f5ecc mov      edi, dword ptr [esp + 0x50]
433f5ed0 movss    dword ptr [eax + 0x1f0], xmm0
433f5ed8 add      eax, 0x1f4
433f5edd push     edi
433f5ede push     eax
433f5edf call     0x774fd4a0
433f5ee4 add      esp, 0xc
433f5ee7 mov      eax, dword ptr [0x43468fec]
433f5eec movss    xmm0, dword ptr [esp + 0x6c]
433f5ef2 mov      eax, dword ptr [eax]
433f5ef4 xor      eax, dword ptr [0x4346a3c4]
433f5efa xor      eax, 0xa2a8247f
433f5eff movss    dword ptr [eax + esi], xmm0
433f5f04 mov      eax, dword ptr [esp + 0xc]
433f5f08 movss    xmm0, dword ptr [esp + 0x6c]
433f5f0e movss    dword ptr [0x43476b40], xmm0
433f5f16 cmp      byte ptr [eax + 4], 0
433f5f1a je       0x433f60a2
433f5f20 mov      ecx, edi
433f5f22 call     0x434011c8
433f5f27 mov      byte ptr [edi + 0x10b], 1
433f5f2e mov      eax, dword ptr [0x4346a660]
433f5f33 mov      eax, dword ptr [eax]
433f5f35 xor      eax, dword ptr [0x434679e0]
433f5f3b xor      eax, 0xb538bba5
433f5f40 cmp      dword ptr [eax + esi + 0xc], 4
433f5f45 jle      0x433f60a2
433f5f4b mov      ecx, dword ptr [esp + 0x20]
433f5f4f push     0x3d9
433f5f54 push     4
433f5f56 push     esi
433f5f57 call     0x433b1a8f
433f5f5c mov      dword ptr [esp + 0x18], eax
433f5f60 cmp      eax, 1
433f5f63 jle      0x433f5fc2
433f5f65 mov      ecx, dword ptr [0x4346a660]
433f5f6b mov      ecx, dword ptr [ecx]
433f5f6d xor      ecx, dword ptr [0x434679e0]
433f5f73 xor      ecx, 0xb538bba5
433f5f79 mov      edx, dword ptr [ecx + esi]
433f5f7c add      edx, 0xe0
433f5f82 mov      dword ptr [esp + 0x38], edx
433f5f86 je       0x433f60a2
433f5f8c and      dword ptr [edx + 0x2c], 0
433f5f90 and      dword ptr [edx + 0x20], 0
433f5f94 mov      dword ptr [edx + 0x18], eax
433f5f97 mov      dword ptr [esp + 0x14], 0xb19efc7e
433f5f9f mov      eax, dword ptr [esp + 0x14]
433f5fa3 mov      ecx, dword ptr [esi]
433f5fa5 xor      eax, 0x4765d17e
433f5faa ror      eax, 0x19
433f5fad xor      eax, 0x7d968300
433f5fb2 mov      ecx, dword ptr [eax + ecx + 1]
433f5fb6 mov      dword ptr [esp + 0x214], ecx
433f5fbd jmp      0x433f608f
433f5fc2 mov      eax, dword ptr [esp + 0x20]
433f5fc6 push     dword ptr [eax + 0xec]
433f5fcc lea      eax, [esp + 0x294]
433f5fd3 push     0x40
433f5fd5 push     eax
433f5fd6 call     0x774fdef0
433f5fdb mov      al, byte ptr [edi + 0x32b]
433f5fe1 add      esp, 0xc
433f5fe4 test     al, 1
433f5fe6 je       0x433f6007
433f5fe8 mov      eax, dword ptr [esp + 0x20]
433f5fec push     dword ptr [eax + 0x4c]
433f5fef lea      eax, [esp + 0x294]
433f5ff6 push     0x40
433f5ff8 push     eax
433f5ff9 call     0x774fdd00
433f5ffe mov      al, byte ptr [edi + 0x32b]
433f6004 add      esp, 0xc
433f6007 test     al, 2
433f6009 je       0x433f6024
433f600b mov      eax, dword ptr [esp + 0x20]
433f600f push     dword ptr [eax + 0x5c]
433f6012 lea      eax, [esp + 0x294]
433f6019 push     0x40
433f601b push     eax
433f601c call     0x774fdd00
433f6021 add      esp, 0xc
433f6024 lea      edx, [esp + 0x290]
433f602b mov      ecx, esi
433f602d call     0x433df1a9
433f6032 mov      dword ptr [esp + 0x18], eax
433f6036 cmp      eax, 1
433f6039 jle      0x433f60a2
433f603b mov      ecx, dword ptr [0x4346a660]
433f6041 mov      ecx, dword ptr [ecx]
433f6043 xor      ecx, dword ptr [0x434679e0]
433f6049 xor      ecx, 0xb538bba5
433f604f mov      edx, dword ptr [ecx + esi]
433f6052 add      edx, 0xe0
433f6058 mov      dword ptr [esp + 0x38], edx
433f605c je       0x433f60a2
433f605e and      dword ptr [edx + 0x2c], 0
433f6062 and      dword ptr [edx + 0x20], 0
433f6066 mov      dword ptr [edx + 0x18], eax
433f6069 mov      dword ptr [esp + 0x14], 0xb19efc7e
433f6071 mov      eax, dword ptr [esp + 0x14]
433f6075 mov      ecx, dword ptr [esi]
433f6077 xor      eax, 0x4765d17e
433f607c ror      eax, 0x19
433f607f xor      eax, 0x7d968300
433f6084 mov      ecx, dword ptr [eax + ecx + 1]
433f6088 mov      dword ptr [esp + 0x218], ecx
433f608f push     dword ptr [esp + 0x18]
433f6093 push     edx
433f6094 mov      edx, esi
433f6096 call     0x433e533f
433f609b mov      eax, dword ptr [esp + 0x38]
433f609f fstp     dword ptr [eax + 0x28]
433f60a2 mov      ecx, dword ptr [0x43475ab4]
433f60a8 mov      eax, dword ptr [0x43475ab0]
433f60ad mov      edx, dword ptr [esp + 0x1c]
433f60b1 cmp      eax, ecx
433f60b3 je       0x433f60d7
433f60b5 mov      edi, eax
433f60b7 mov      esi, ecx
433f60b9 mov      ecx, dword ptr [edi]
433f60bb push     edx
433f60bc mov      edx, dword ptr [esp + 0x64]
433f60c0 mov      eax, dword ptr [ecx]
433f60c2 mov      eax, dword ptr [eax + 8]
433f60c5 call     eax
433f60c7 add      edi, 4
433f60ca mov      edx, eax
433f60cc cmp      edi, esi
433f60ce jne      0x433f60b9
433f60d0 mov      esi, dword ptr [ebp + 8]
433f60d3 mov      edi, dword ptr [esp + 0x4c]
433f60d7 mov      eax, dword ptr [0x4346a338]
433f60dc mov      ecx, esi
433f60de movd     xmm0, edx
433f60e2 mov      edx, dword ptr [esp + 0x2c]
433f60e6 cvtdq2ps xmm0, xmm0
433f60e9 mulss    xmm0, dword ptr [eax]
433f60ed mov      eax, dword ptr [0x43467eb8]
433f60f2 movss    dword ptr [eax], xmm0
433f60f6 call     0x433800f5
433f60fb mov      eax, dword ptr [esp + 0xc]
433f60ff mov      ecx, dword ptr [esp + 0x2c]
433f6103 movss    xmm0, dword ptr [eax + 0xc]
433f6108 mov      eax, dword ptr [0x43468354]
433f610d mov      eax, dword ptr [eax]
433f610f xor      eax, dword ptr [0x4346852c]
433f6115 xor      eax, 0x66146802
433f611a movss    dword ptr [eax + esi], xmm0
433f611f mov      eax, dword ptr [0x43468fd0]
433f6124 mov      eax, dword ptr [eax]
433f6126 xor      eax, dword ptr [0x43467c70]
433f612c xor      eax, 0xf58e6118
433f6131 mov      dword ptr [eax + esi], ecx
433f6134 mov      al, byte ptr [edi + 0x109]
433f613a movss    xmm0, dword ptr [edi + 0x110]
433f6142 mov      byte ptr [esp + 0xbc], al
433f6149 mov      eax, dword ptr [0x4346a660]
433f614e movss    dword ptr [esp + 0x10c], xmm0
433f6157 mov      eax, dword ptr [eax]
433f6159 xor      eax, dword ptr [0x434679e0]
433f615f xor      eax, 0xb538bba5
433f6164 cmp      dword ptr [eax + esi + 0xc], 3
433f6169 jle      0x433f6d13
433f616f mov      eax, dword ptr [eax + esi]
433f6172 lea      edi, [esp + 0xd0]
433f6179 mov      dword ptr [esp + 0x30], eax
433f617d add      eax, 0xa8
433f6182 mov      dword ptr [esp + 0x74], eax
433f6186 mov      eax, dword ptr [0x4346a8e4]
433f618b mov      byte ptr [esp + 0x70], 0
433f6190 mov      esi, dword ptr [eax]
433f6192 xor      esi, dword ptr [0x434688cc]
433f6198 xor      esi, 0x36375c23
433f619e add      esi, dword ptr [ebp + 8]
433f61a1 movsd    dword ptr es:[edi], dword ptr [esi]
433f61a2 movsd    dword ptr es:[edi], dword ptr [esi]
433f61a3 movsd    dword ptr es:[edi], dword ptr [esi]
433f61a4 movss    xmm1, dword ptr [esp + 0xd0]
433f61ad movss    xmm0, dword ptr [esp + 0xd4]
433f61b6 mulss    xmm1, xmm1
433f61ba mulss    xmm0, xmm0
433f61be addss    xmm1, xmm0
433f61c2 movaps   xmm0, xmm1
433f61c5 movss    xmm1, dword ptr [0x43470474]
433f61cd sqrtss   xmm0, xmm0
433f61d1 movss    dword ptr [esp + 0x244], xmm0
433f61da call     0x43367633
433f61df mov      eax, dword ptr [0x43467b04]
433f61e4 mov      edi, dword ptr [esp + 0x4c]
433f61e8 movss    dword ptr [esp + 0x1c], xmm0
433f61ee xorps    xmm0, xmm0
433f61f1 movss    xmm1, dword ptr [eax + 0x10]
433f61f6 subss    xmm1, dword ptr [edi + 0x6c]
433f61fb call     0x4332fc35
433f6200 mov      eax, dword ptr [0x43467a74]
433f6205 mov      esi, dword ptr [ebp + 8]
433f6208 movss    dword ptr [esp + 0x24], xmm0
433f620e mov      eax, dword ptr [eax]
433f6210 xor      eax, dword ptr [0x434678c0]
433f6216 xor      eax, 0xcd812654
433f621b mov      ecx, dword ptr [eax + esi]
433f621e cmp      ecx, -1
433f6221 je       0x433f62b7
433f6227 mov      eax, dword ptr [0x4346a890]
433f622c push     ecx
433f622d mov      eax, dword ptr [eax]
433f622f mov      edx, dword ptr [eax + 0x10]
433f6232 mov      eax, esp
433f6234 mov      dword ptr [eax], ecx
433f6236 mov      ecx, dword ptr [0x4346a890]
433f623c call     edx
433f623e mov      edx, eax
433f6240 mov      dword ptr [esp + 0x18], edx
433f6244 test     edx, edx
433f6246 je       0x433f62b7
433f6248 mov      dword ptr [esp + 0x14], 0xc606305
433f6250 mov      eax, dword ptr [esp + 0x14]
433f6254 mov      ecx, dword ptr [edx]
433f6256 rol      eax, 0x1e
433f6259 mov      ecx, dword ptr [eax + ecx - 0x431811d9]
433f6260 mov      dword ptr [esp + 0x21c], ecx
433f6267 call     0x433e533f
433f626c movss    xmm1, dword ptr [0x43470000]
433f6274 fstp     dword ptr [esp + 0x14]
433f6278 movss    xmm0, dword ptr [esp + 0x14]
433f627e comiss   xmm0, xmm1
433f6281 jbe      0x433f62bf
433f6283 mov      edx, dword ptr [esp + 0x18]
433f6287 mov      dword ptr [esp + 0x14], 0xc606305
433f628f mov      eax, dword ptr [esp + 0x14]
433f6293 rol      eax, 0x1e
433f6296 mov      ecx, dword ptr [edx]
433f6298 mov      ecx, dword ptr [eax + ecx - 0x431811d9]
433f629f mov      dword ptr [esp + 0x220], ecx
433f62a6 call     0x433e533f
433f62ab fstp     dword ptr [esp + 0x14]
433f62af movss    xmm1, dword ptr [esp + 0x14]
433f62b5 jmp      0x433f62bf
433f62b7 movss    xmm1, dword ptr [0x43470474]
433f62bf movss    xmm2, dword ptr [esp + 0x1c]
433f62c5 movaps   xmm0, xmm1
433f62c8 mulss    xmm0, dword ptr [0x43470830]
433f62d0 mov      eax, dword ptr [0x434679f8]
433f62d5 mulss    xmm1, dword ptr [0x43472144]
433f62dd divss    xmm2, xmm0
433f62e1 mov      eax, dword ptr [eax]
433f62e3 xor      eax, dword ptr [0x434675f8]
433f62e9 xor      eax, 0x3309c0cf
433f62ee movss    xmm0, dword ptr [esp + 0x1c]
433f62f4 divss    xmm0, xmm1
433f62f8 movss    xmm7, dword ptr [0x43470514]
433f6300 xorps    xmm1, xmm1
433f6303 movss    xmm4, dword ptr [esp + 0x24]
433f6309 movaps   xmm6, xmm1
433f630c mulss    xmm4, dword ptr [0x43472708]
433f6314 movss    dword ptr [esp + 0x18], xmm0
433f631a movss    xmm0, dword ptr [edi + 0x11c]
433f6322 movss    dword ptr [esp + 0xc], xmm0
433f6328 movss    xmm0, dword ptr [eax + esi]
433f632d addss    xmm0, dword ptr [edi + 0xa8]
433f6335 movss    dword ptr [esp + 0xa0], xmm2
433f633e movss    xmm2, dword ptr [edi + 0xa4]
433f6346 movaps   xmm3, xmm0
433f6349 maxss    xmm3, xmm6
433f634d minss    xmm3, xmm7
433f6351 movaps   xmm5, xmm3
433f6354 movss    dword ptr [esp + 0x124], xmm3
433f635d subss    xmm5, xmm2
433f6361 comiss   xmm5, xmm4
433f6364 jbe      0x433f636c
433f6366 addss    xmm2, xmm4
433f636a jmp      0x433f6384
433f636c movaps   xmm0, xmm4
433f636f xorps    xmm0, xmmword ptr [0x434703d0]
433f6376 comiss   xmm0, xmm5
433f6379 jbe      0x433f6381
433f637b subss    xmm2, xmm4
433f637f jmp      0x433f6384
433f6381 movaps   xmm2, xmm3
433f6384 movaps   xmm0, xmm2
433f6387 maxss    xmm0, xmm6
433f638b minss    xmm0, xmm7
433f638f movups   xmmword ptr [esp + 0x170], xmm0
433f6397 movss    dword ptr [esp + 0xe4], xmm0
433f63a0 movss    xmm0, dword ptr [esp + 0x1c]
433f63a6 comiss   xmm0, xmm1
433f63a9 ja       0x433f63b7
433f63ab comiss   xmm1, dword ptr [edi + 0x104]
433f63b2 setae    al
433f63b5 jmp      0x433f63bb
433f63b7 mov      al, byte ptr [esp + 0x70]
433f63bb cmp      byte ptr [edi + 0x138], 0
433f63c2 jne      0x433f64fc
433f63c8 test     al, al
433f63ca je       0x433f64fc
433f63d0 cmp      byte ptr [edi + 0x108], 0
433f63d7 je       0x433f64fc
433f63dd cmp      byte ptr [edi + 0x128], 0
433f63e4 jne      0x433f64fc
433f63ea cmp      byte ptr [edi + 0x109], 0
433f63f1 jne      0x433f64fc
433f63f7 movss    xmm0, dword ptr [0x4346fa58]
433f63ff comiss   xmm0, dword ptr [edi + 0x2ac]
433f6406 jbe      0x433f64fc
433f640c mov      eax, dword ptr [esp + 0x20]
433f6410 push     dword ptr [eax + 0xcc]
433f6416 lea      eax, [esp + 0x2d4]
433f641d push     0x40
433f641f push     eax
433f6420 call     0x774fdef0
433f6425 add      esp, 0xc
433f6428 test     byte ptr [edi + 0x32b], 2
433f642f je       0x433f644a
433f6431 mov      eax, dword ptr [esp + 0x20]
433f6435 push     dword ptr [eax + 0x7c]
433f6438 lea      eax, [esp + 0x2d4]
433f643f push     0x40
433f6441 push     eax
433f6442 call     0x774fdd00
433f6447 add      esp, 0xc
433f644a mov      eax, dword ptr [esp + 0x20]
433f644e push     dword ptr [eax + 0xdc]
433f6454 lea      eax, [esp + 0x2d4]
433f645b push     0x40
433f645d push     eax
433f645e call     0x774fdd00
433f6463 add      esp, 0xc
433f6466 lea      edx, [esp + 0x2d0]
433f646d mov      ecx, esi
433f646f call     0x433df1a9
433f6474 mov      dword ptr [esp + 0x38], eax
433f6478 cmp      eax, 1
433f647b jle      0x433f64fc
433f647d mov      ecx, dword ptr [0x4346a660]
433f6483 mov      ecx, dword ptr [ecx]
433f6485 xor      ecx, dword ptr [0x434679e0]
433f648b xor      ecx, 0xb538bba5
433f6491 mov      edx, dword ptr [ecx + esi]
433f6494 add      edx, 0xa8
433f649a mov      dword ptr [esp + 0x10], edx
433f649e je       0x433f64f5
433f64a0 and      dword ptr [edx + 0x2c], 0
433f64a4 and      dword ptr [edx + 0x20], 0
433f64a8 push     dword ptr [esp + 0x38]
433f64ac mov      dword ptr [edx + 0x18], eax
433f64af mov      dword ptr [esp + 0x18], 0xb19efc7e
433f64b7 mov      eax, dword ptr [esp + 0x18]
433f64bb mov      ecx, dword ptr [esi]
433f64bd xor      eax, 0x4765d17e
433f64c2 ror      eax, 0x19
433f64c5 xor      eax, 0x7d968300
433f64ca push     edx
433f64cb mov      edx, esi
433f64cd mov      ecx, dword ptr [eax + ecx + 1]
433f64d1 mov      dword ptr [esp + 0x250], ecx
433f64d8 call     0x433e533f
433f64dd mov      eax, dword ptr [esp + 0x10]
433f64e1 movss    xmm0, dword ptr [esp + 0xe4]
433f64ea movups   xmmword ptr [esp + 0x170], xmm0
433f64f2 fstp     dword ptr [eax + 0x28]
433f64f5 mov      byte ptr [edi + 0x138], 1
433f64fc mov      eax, dword ptr [0x4346a364]
433f6501 test     eax, eax
433f6503 je       0x433f66f6
433f6509 mov      ecx, dword ptr [esp + 0x30]
433f650d push     dword ptr [ecx + 0xc0]
433f6513 mov      ecx, esi
433f6515 call     eax
433f6517 cmp      eax, 0x3d4
433f651c je       0x433f6529
433f651e cmp      eax, 0x3d3
433f6523 jne      0x433f66f6
433f6529 cmp      byte ptr [edi + 0x138], 0
433f6530 je       0x433f665a
433f6536 movss    xmm0, dword ptr [0x4346dd4c]
433f653e comiss   xmm0, dword ptr [esp + 0x18]
433f6543 jb       0x433f665a
433f6549 movss    xmm2, dword ptr [esp + 0x24]
433f654f xorps    xmm1, xmm1
433f6552 comiss   xmm1, xmm2
433f6555 mov      ecx, dword ptr [esp + 0x30]
433f6559 jae      0x433f6631
433f655f movss    xmm3, dword ptr [ecx + 0xd0]
433f6567 movaps   xmm0, xmm3
433f656a andps    xmm0, xmmword ptr [0x43470340]
433f6571 comiss   xmm1, xmm0
433f6574 jae      0x433f65c8
433f6576 mulss    xmm2, xmm3
433f657a movss    xmm3, dword ptr [0x43470514]
433f6582 addss    xmm2, dword ptr [ecx + 0xd4]
433f658a comiss   xmm2, xmm3
433f658d jb       0x433f6597
433f658f movss    xmm2, dword ptr [0x4346f660]
433f6597 cvttss2si eax, xmm2
433f659b movd     xmm0, eax
433f659f cvtdq2ps xmm0, xmm0
433f65a2 subss    xmm2, xmm0
433f65a6 comiss   xmm2, xmm1
433f65a9 jb       0x433f65b6
433f65ab comiss   xmm2, xmm3
433f65ae jbe      0x433f65ba
433f65b0 subss    xmm2, xmm3
433f65b4 jmp      0x433f65ba
433f65b6 addss    xmm2, xmm3
433f65ba movss    dword ptr [ecx + 0xd4], xmm2
433f65c2 movss    xmm2, dword ptr [esp + 0x24]
433f65c8 mov      eax, dword ptr [0x4346a598]
433f65cd test     eax, eax
433f65cf je       0x433f6631
433f65d1 movss    xmm0, dword ptr [ecx + 0xc8]
433f65d9 xor      edx, edx
433f65db push     3
433f65dd mov      ecx, edi
433f65df movss    dword ptr [esp + 0x18], xmm0
433f65e5 call     eax
433f65e7 mov      ecx, dword ptr [esp + 0x30]
433f65eb xorps    xmm1, xmm1
433f65ee movss    xmm1, xmm0
433f65f2 xorps    xmm2, xmm2
433f65f5 movaps   xmm0, xmm2
433f65f8 movss    xmm2, dword ptr [esp + 0x24]
433f65fe maxss    xmm1, xmm0
433f6602 movss    xmm0, dword ptr [0x43470514]
433f660a minss    xmm1, xmm0
433f660e movss    dword ptr [esp + 0x1d0], xmm1
433f6617 movss    dword ptr [ecx + 0xc8], xmm1
433f661f subss    xmm1, dword ptr [esp + 0x14]
433f6625 divss    xmm1, xmm2
433f6629 movss    dword ptr [ecx + 0xcc], xmm1
433f6631 movss    xmm0, dword ptr [ecx + 0xd0]
433f6639 mulss    xmm0, xmm2
433f663d addss    xmm0, dword ptr [ecx + 0xd4]
433f6645 comiss   xmm0, dword ptr [0x4346f660]
433f664c setb     al
433f664f mov      byte ptr [edi + 0x138], al
433f6655 jmp      0x433f66fc
433f665a mov      ecx, dword ptr [esp + 0x30]
433f665e xorps    xmm3, xmm3
433f6661 movss    xmm2, dword ptr [esp + 0x24]
433f6667 xorps    xmm1, xmm1
433f666a mulss    xmm2, dword ptr [0x4346fd78]
433f6672 mov      byte ptr [edi + 0x138], 0
433f6679 movss    xmm4, dword ptr [ecx + 0xc8]
433f6681 subss    xmm3, xmm4
433f6685 comiss   xmm3, xmm2
433f6688 jbe      0x433f6693
433f668a movaps   xmm0, xmm4
433f668d addss    xmm0, xmm2
433f6691 jmp      0x433f66ae
433f6693 movaps   xmm0, xmm2
433f6696 xorps    xmm0, xmmword ptr [0x434703d0]
433f669d comiss   xmm0, xmm3
433f66a0 jbe      0x433f66ab
433f66a2 movaps   xmm0, xmm4
433f66a5 subss    xmm0, xmm2
433f66a9 jmp      0x433f66ae
433f66ab xorps    xmm0, xmm0
433f66ae movss    xmm2, dword ptr [esp + 0x24]
433f66b4 movaps   xmm3, xmm0
433f66b7 movaps   xmm0, xmm1
433f66ba ucomiss  xmm2, xmm1
433f66bd maxss    xmm3, xmm0
433f66c1 movss    xmm0, dword ptr [0x43470514]
433f66c9 lahf     
433f66ca minss    xmm3, xmm0
433f66ce movss    dword ptr [esp + 0x1d4], xmm3
433f66d7 movss    dword ptr [ecx + 0xc8], xmm3
433f66df test     ah, 0x44
433f66e2 jnp      0x433f66ff
433f66e4 subss    xmm3, xmm4
433f66e8 divss    xmm3, xmm2
433f66ec movss    dword ptr [ecx + 0xcc], xmm3
433f66f4 jmp      0x433f66ff
433f66f6 movss    xmm2, dword ptr [esp + 0x24]
433f66fc xorps    xmm1, xmm1
433f66ff movss    xmm0, dword ptr [0x43470514]
433f6707 comiss   xmm0, dword ptr [edi + 0xec]
433f670e jb       0x433f6d13
433f6714 cmp      byte ptr [edi + 0x108], 0
433f671b je       0x433f6d13
433f6721 cmp      byte ptr [edi + 0x128], 0
433f6728 jne      0x433f6d13
433f672e cmp      byte ptr [edi + 0x109], 0
433f6735 jne      0x433f6d13
433f673b comiss   xmm2, xmm1
433f673e jbe      0x433f6d13
433f6744 mov      eax, dword ptr [esp + 0x2c]
433f6748 movss    xmm0, dword ptr [edi + 0x80]
433f6750 movss    xmm4, dword ptr [0x43471f88]
433f6758 movaps   xmm2, xmm0
433f675b movss    dword ptr [esp + 0x14], xmm0
433f6761 movss    xmm3, dword ptr [eax + 0x10]
433f6766 movss    xmm0, dword ptr [0x43470574]
433f676e ucomiss  xmm3, xmm3
433f6771 maxss    xmm2, xmm0
433f6775 movss    dword ptr [esp + 0x10], xmm3
433f677b movaps   xmm0, xmm4
433f677e lahf     
433f677f minss    xmm2, xmm0
433f6783 movss    dword ptr [esp + 0x14c], xmm2
433f678c movups   xmmword ptr [esp + 0xc0], xmm2
433f6794 test     ah, 0x44
433f6797 jnp      0x433f679e
433f6799 xorps    xmm3, xmm3
433f679c jmp      0x433f67ec
433f679e movss    xmm1, dword ptr [0x43470340]
433f67a6 movaps   xmm0, xmm3
433f67a9 andps    xmm0, xmm1
433f67ac comiss   xmm0, dword ptr [0x434725e4]
433f67b3 jbe      0x433f67f2
433f67b5 movaps   xmm0, xmm3
433f67b8 divss    xmm0, xmm4
433f67bc andps    xmm0, xmm1
433f67bf call     0x4341ad12
433f67c4 movss    xmm3, dword ptr [esp + 0x10]
433f67ca xorps    xmm2, xmm2
433f67cd mulss    xmm0, dword ptr [0x43471f88]
433f67d5 comiss   xmm2, xmm3
433f67d8 movups   xmm2, xmmword ptr [esp + 0xc0]
433f67e0 jbe      0x433f67e8
433f67e2 addss    xmm3, xmm0
433f67e6 jmp      0x433f67ec
433f67e8 subss    xmm3, xmm0
433f67ec movss    dword ptr [esp + 0x10], xmm3
433f67f2 movaps   xmm0, xmm3
433f67f5 subss    xmm0, xmm2
433f67f9 cvtss2sd xmm0, xmm0
433f67fd movsd    qword ptr [esp + 0x150], xmm0
433f6806 fld      qword ptr [esp + 0x150]
433f680d fld      qword ptr [0x4346f598]
433f6813 call     0x7750834a
433f6818 movss    xmm4, dword ptr [esp + 0x10]
433f681e comiss   xmm4, dword ptr [esp + 0xc0]
433f6826 fstp     dword ptr [esp + 0x38]
433f682a movss    xmm5, dword ptr [esp + 0x38]
433f6830 jbe      0x433f6845
433f6832 comiss   xmm5, dword ptr [0x434725e4]
433f6839 jb       0x433f685a
433f683b subss    xmm5, dword ptr [0x43471f88]
433f6843 jmp      0x433f685a
433f6845 movss    xmm0, dword ptr [0x434724b4]
433f684d comiss   xmm0, xmm5
433f6850 jb       0x433f685a
433f6852 addss    xmm5, dword ptr [0x43471f88]
433f685a movss    xmm6, dword ptr [esp + 0xa0]
433f6863 xorps    xmm2, xmm2
433f6866 movss    xmm3, dword ptr [0x43470514]
433f686e movaps   xmm1, xmm6
433f6871 movss    xmm6, dword ptr [0x43472c90]
433f6879 movaps   xmm7, xmm2
433f687c maxss    xmm1, xmm7
433f6880 movaps   xmm0, xmm3
433f6883 movups   xmmword ptr [esp + 0xa0], xmm0
433f688b minss    xmm1, xmm0
433f688f movss    xmm0, dword ptr [esp + 0xc]
433f6895 mulss    xmm0, dword ptr [0x4346ed98]
433f689d subss    xmm6, xmm0
433f68a1 movss    dword ptr [esp + 0x150], xmm1
433f68aa movups   xmm0, xmmword ptr [esp + 0x170]
433f68b2 comiss   xmm0, xmm2
433f68b5 subss    xmm6, xmm3
433f68b9 mulss    xmm6, xmm1
433f68bd addss    xmm6, xmm3
433f68c1 jbe      0x433f68fa
433f68c3 movss    xmm3, dword ptr [esp + 0x18]
433f68c9 movaps   xmm1, xmm3
433f68cc maxss    xmm1, xmm7
433f68d0 minss    xmm1, dword ptr [esp + 0xa0]
433f68d9 movss    dword ptr [esp + 0x160], xmm1
433f68e2 mulss    xmm1, xmm0
433f68e6 movss    xmm0, dword ptr [0x43472240]
433f68ee subss    xmm0, xmm6
433f68f2 mulss    xmm1, xmm0
433f68f6 addss    xmm6, xmm1
433f68fa movss    xmm1, dword ptr [edi + 0x338]
433f6902 mulss    xmm1, xmm6
433f6906 comiss   xmm5, xmm1
433f6909 jbe      0x433f692a
433f690b movss    xmm6, dword ptr [0x43470340]
433f6913 movaps   xmm0, xmm4
433f6916 andps    xmm1, xmm6
433f6919 subss    xmm0, xmm1
433f691d movaps   xmm1, xmm0
433f6920 movups   xmmword ptr [esp + 0xc0], xmm1
433f6928 jmp      0x433f6954
433f692a movss    xmm0, dword ptr [edi + 0x334]
433f6932 mulss    xmm0, xmm6
433f6936 movss    xmm6, dword ptr [0x43470340]
433f693e comiss   xmm0, xmm5
433f6941 jbe      0x433f694c
433f6943 andps    xmm0, xmm6
433f6946 addss    xmm0, xmm4
433f694a jmp      0x433f691d
433f694c movups   xmm1, xmmword ptr [esp + 0xc0]
433f6954 ucomiss  xmm1, xmm1
433f6957 lahf     
433f6958 test     ah, 0x44
433f695b jnp      0x433f6962
433f695d xorps    xmm1, xmm1
433f6960 jmp      0x433f69b4
433f6962 movaps   xmm0, xmm1
433f6965 andps    xmm0, xmm6
433f6968 comiss   xmm0, dword ptr [0x434725e4]
433f696f jbe      0x433f69b4
433f6971 movaps   xmm0, xmm1
433f6974 divss    xmm0, dword ptr [0x43471f88]
433f697c andps    xmm0, xmm6
433f697f call     0x4341ad12
433f6984 movups   xmm1, xmmword ptr [esp + 0xc0]
433f698c mulss    xmm0, dword ptr [0x43471f88]
433f6994 xorps    xmm2, xmm2
433f6997 comiss   xmm2, xmm1
433f699a movss    xmm4, dword ptr [esp + 0x10]
433f69a0 movss    xmm6, dword ptr [0x43470340]
433f69a8 jbe      0x433f69b0
433f69aa addss    xmm1, xmm0
433f69ae jmp      0x433f69b4
433f69b0 subss    xmm1, xmm0
433f69b4 movss    xmm0, dword ptr [esp + 0x1c]
433f69ba comiss   xmm0, dword ptr [0x43472980]
433f69c1 ja       0x433f6afc
433f69c7 movss    xmm0, dword ptr [esp + 0xd8]
433f69d0 movss    xmm3, dword ptr [0x434704a0]
433f69d8 andps    xmm0, xmm6
433f69db comiss   xmm0, xmm3
433f69de ja       0x433f6afc
433f69e4 movss    xmm4, dword ptr [esp + 0x24]
433f69ea movss    xmm0, dword ptr [0x43476b40]
433f69f2 mulss    xmm4, xmm3
433f69f6 comiss   xmm2, xmm4
433f69f9 movss    dword ptr [esp + 0x1c], xmm4
433f69ff jbe      0x433f6a0e
433f6a01 xorps    xmm4, xmmword ptr [0x434703d0]
433f6a08 movss    dword ptr [esp + 0x1c], xmm4
433f6a0e mulss    xmm0, dword ptr [0x4346dba4]
433f6a16 mulss    xmm1, dword ptr [0x4346dba4]
433f6a1e cvttss2si eax, xmm0
433f6a22 movzx    eax, ax
433f6a25 movd     xmm5, eax
433f6a29 cvttss2si eax, xmm1
433f6a2d cvtdq2ps xmm5, xmm5
433f6a30 movzx    eax, ax
433f6a33 movd     xmm1, eax
433f6a37 mulss    xmm5, dword ptr [0x434721a0]
433f6a3f cvtdq2ps xmm1, xmm1
433f6a42 movaps   xmm3, xmm5
433f6a45 movss    dword ptr [esp + 0x18], xmm5
433f6a4b mulss    xmm1, dword ptr [0x434721a0]
433f6a53 subss    xmm3, xmm1
433f6a57 movss    dword ptr [esp + 0x10], xmm1
433f6a5d ucomiss  xmm3, xmm3
433f6a60 movss    dword ptr [esp + 0xa0], xmm3
433f6a69 lahf     
433f6a6a test     ah, 0x44
433f6a6d jnp      0x433f6a74
433f6a6f xorps    xmm3, xmm3
433f6a72 jmp      0x433f6acb
433f6a74 movaps   xmm0, xmm3
433f6a77 andps    xmm0, xmm6
433f6a7a comiss   xmm0, dword ptr [0x434725e4]
433f6a81 jbe      0x433f6acb
433f6a83 movaps   xmm0, xmm3
433f6a86 divss    xmm0, dword ptr [0x43471f88]
433f6a8e andps    xmm0, xmm6
433f6a91 call     0x4341ad12
433f6a96 movss    xmm3, dword ptr [esp + 0xa0]
433f6a9f xorps    xmm2, xmm2
433f6aa2 comiss   xmm2, xmm3
433f6aa5 mulss    xmm0, dword ptr [0x43471f88]
433f6aad movss    xmm1, dword ptr [esp + 0x10]
433f6ab3 movss    xmm4, dword ptr [esp + 0x1c]
433f6ab9 movss    xmm5, dword ptr [esp + 0x18]
433f6abf jbe      0x433f6ac7
433f6ac1 addss    xmm3, xmm0
433f6ac5 jmp      0x433f6acb
433f6ac7 subss    xmm3, xmm0
433f6acb comiss   xmm3, xmm4
433f6ace jbe      0x433f6ad9
433f6ad0 addss    xmm1, xmm4
433f6ad4 jmp      0x433f6c0b
433f6ad9 movaps   xmm0, xmm4
433f6adc xorps    xmm0, xmmword ptr [0x434703d0]
433f6ae3 comiss   xmm0, xmm3
433f6ae6 jbe      0x433f6af1
433f6ae8 subss    xmm1, xmm4
433f6aec jmp      0x433f6c0b
433f6af1 movss    dword ptr [esp + 0x10], xmm5
433f6af7 jmp      0x433f6c19
433f6afc movss    xmm5, dword ptr [esp + 0xc]
433f6b02 mulss    xmm5, dword ptr [0x4346eeb0]
433f6b0a addss    xmm5, dword ptr [0x4346ee8c]
433f6b12 mulss    xmm5, dword ptr [esp + 0x24]
433f6b18 comiss   xmm2, xmm5
433f6b1b movss    dword ptr [esp + 0xc], xmm5
433f6b21 jbe      0x433f6b30
433f6b23 xorps    xmm5, xmmword ptr [0x434703d0]
433f6b2a movss    dword ptr [esp + 0xc], xmm5
433f6b30 mulss    xmm4, dword ptr [0x4346dba4]
433f6b38 mulss    xmm1, dword ptr [0x4346dba4]
433f6b40 cvttss2si eax, xmm4
433f6b44 movzx    eax, ax
433f6b47 movd     xmm4, eax
433f6b4b cvttss2si eax, xmm1
433f6b4f cvtdq2ps xmm4, xmm4
433f6b52 movzx    eax, ax
433f6b55 movd     xmm1, eax
433f6b59 mulss    xmm4, dword ptr [0x434721a0]
433f6b61 cvtdq2ps xmm1, xmm1
433f6b64 movaps   xmm3, xmm4
433f6b67 movss    dword ptr [esp + 0x18], xmm4
433f6b6d mulss    xmm1, dword ptr [0x434721a0]
433f6b75 subss    xmm3, xmm1
433f6b79 movss    dword ptr [esp + 0x10], xmm1
433f6b7f ucomiss  xmm3, xmm3
433f6b82 movss    dword ptr [esp + 0xa0], xmm3
433f6b8b lahf     
433f6b8c test     ah, 0x44
433f6b8f jnp      0x433f6b96
433f6b91 xorps    xmm3, xmm3
433f6b94 jmp      0x433f6bed
433f6b96 movaps   xmm0, xmm3
433f6b99 andps    xmm0, xmm6
433f6b9c comiss   xmm0, dword ptr [0x434725e4]
433f6ba3 jbe      0x433f6bed
433f6ba5 movaps   xmm0, xmm3
433f6ba8 divss    xmm0, dword ptr [0x43471f88]
433f6bb0 andps    xmm0, xmm6
433f6bb3 call     0x4341ad12
433f6bb8 movss    xmm3, dword ptr [esp + 0xa0]
433f6bc1 xorps    xmm2, xmm2
433f6bc4 comiss   xmm2, xmm3
433f6bc7 mulss    xmm0, dword ptr [0x43471f88]
433f6bcf movss    xmm1, dword ptr [esp + 0x10]
433f6bd5 movss    xmm5, dword ptr [esp + 0xc]
433f6bdb movss    xmm4, dword ptr [esp + 0x18]
433f6be1 jbe      0x433f6be9
433f6be3 addss    xmm3, xmm0
433f6be7 jmp      0x433f6bed
433f6be9 subss    xmm3, xmm0
433f6bed comiss   xmm3, xmm5
433f6bf0 jbe      0x433f6bf8
433f6bf2 addss    xmm1, xmm5
433f6bf6 jmp      0x433f6c0b
433f6bf8 movaps   xmm0, xmm5
433f6bfb xorps    xmm0, xmmword ptr [0x434703d0]
433f6c02 comiss   xmm0, xmm3
433f6c05 jbe      0x433f6c13
433f6c07 subss    xmm1, xmm5
433f6c0b movss    dword ptr [esp + 0x10], xmm1
433f6c11 jmp      0x433f6c19
433f6c13 movss    dword ptr [esp + 0x10], xmm4
433f6c19 movss    xmm0, dword ptr [esp + 0x14]
433f6c1f subss    xmm0, dword ptr [esp + 0x10]
433f6c25 cvtps2pd xmm0, xmm0
433f6c28 movsd    qword ptr [esp + 0xa0], xmm0
433f6c31 fld      qword ptr [esp + 0xa0]
433f6c38 fld      qword ptr [0x4346f598]
433f6c3e call     0x7750834a
433f6c43 movss    xmm0, dword ptr [esp + 0x14]
433f6c49 comiss   xmm0, dword ptr [esp + 0x10]
433f6c4e fstp     dword ptr [esp + 0x18]
433f6c52 movss    xmm0, dword ptr [esp + 0x18]
433f6c58 jbe      0x433f6c6d
433f6c5a comiss   xmm0, dword ptr [0x434725e4]
433f6c61 jb       0x433f6c82
433f6c63 subss    xmm0, dword ptr [0x43471f88]
433f6c6b jmp      0x433f6c82
433f6c6d movss    xmm1, dword ptr [0x434724b4]
433f6c75 comiss   xmm1, xmm0
433f6c78 jb       0x433f6c82
433f6c7a addss    xmm0, dword ptr [0x43471f88]
433f6c82 andps    xmm0, xmmword ptr [0x43470340]
433f6c89 divss    xmm0, dword ptr [esp + 0x24]
433f6c8f comiss   xmm0, dword ptr [0x4346f190]
433f6c96 jbe      0x433f6d13
433f6c98 mov      eax, dword ptr [esp + 0x2c]
433f6c9c mov      edx, 0x3d3
433f6ca1 mov      ecx, esi
433f6ca3 push     dword ptr [eax + 0x40]
433f6ca6 call     0x43387742
433f6cab cmp      eax, 1
433f6cae jle      0x433f6d13
433f6cb0 mov      ecx, dword ptr [esp + 0x30]
433f6cb4 push     eax
433f6cb5 push     dword ptr [esp + 0x78]
433f6cb9 mov      dword ptr [ecx + 0xc0], eax
433f6cbf mov      dword ptr [esp + 0xa8], 0xb19efc7e
433f6cca mov      edx, dword ptr [esp + 0xa8]
433f6cd1 mov      ecx, dword ptr [esi]
433f6cd3 xor      edx, 0x4765d17e
433f6cd9 ror      edx, 0x19
433f6cdc xor      edx, 0x7d968300
433f6ce2 mov      ecx, dword ptr [edx + ecx + 1]
433f6ce6 mov      edx, esi
433f6ce8 mov      dword ptr [esp + 0x1e0], ecx
433f6cef call     0x433e533f
433f6cf4 mov      eax, dword ptr [esp + 0x30]
433f6cf8 and      dword ptr [eax + 0xd4], 0
433f6cff and      dword ptr [eax + 0xc8], 0
433f6d06 fstp     dword ptr [eax + 0xd0]
433f6d0c mov      byte ptr [edi + 0x138], 1
433f6d13 mov      ecx, dword ptr [esp + 0x20]
433f6d17 push     edi
433f6d18 push     esi
433f6d19 call     0x433ebf17
433f6d1e mov      eax, dword ptr [0x43467eb8]
433f6d23 xorps    xmm0, xmm0
433f6d26 movss    xmm1, dword ptr [eax]
433f6d2a subss    xmm1, dword ptr [edi + 0x6c]
433f6d2f call     0x4332fc35
433f6d34 mov      eax, dword ptr [esp + 0x54]
433f6d38 mov      edx, dword ptr [eax]
433f6d3a mov      eax, dword ptr [0x43468fd0]
433f6d3f mov      dword ptr [esp + 0xc], edx
433f6d43 mov      eax, dword ptr [eax]
433f6d45 xor      eax, dword ptr [0x43467c70]
433f6d4b xor      eax, 0xf58e6118
433f6d50 mov      ecx, dword ptr [eax + esi]
433f6d53 test     ecx, ecx
433f6d55 je       0x433f6e01
433f6d5b mov      ecx, dword ptr [ecx + 4]
433f6d5e xor      edx, edx
433f6d60 mov      eax, ecx
433f6d62 div      dword ptr [esp + 0x50]
433f6d66 mov      eax, dword ptr [esp + 0x20]
433f6d6a cmp      dword ptr [eax + edx*4 + 0x404], ecx
433f6d71 mov      edx, dword ptr [esp + 0xc]
433f6d75 jne      0x433f6e01
433f6d7b mov      eax, dword ptr [0x4346a364]
433f6d80 mov      ecx, dword ptr [edx + 0x248]
433f6d86 test     eax, eax
433f6d88 je       0x433f6e01
433f6d8a push     ecx
433f6d8b mov      ecx, esi
433f6d8d call     eax
433f6d8f mov      edx, dword ptr [esp + 0xc]
433f6d93 mov      ecx, dword ptr [edx + 0x248]
433f6d99 mov      dword ptr [esp + 0xa0], ecx
433f6da0 cmp      eax, 0x3d7
433f6da5 je       0x433f6dae
433f6da7 cmp      eax, 0x3d6
433f6dac jne      0x433f6e01
433f6dae and      dword ptr [edx + 0x25c], 0
433f6db5 and      dword ptr [edx + 0x250], 0
433f6dbc push     dword ptr [esp + 0xa0]
433f6dc3 mov      dword ptr [esp + 0x78], 0xb19efc7e
433f6dcb mov      eax, dword ptr [esp + 0x78]
433f6dcf mov      ecx, dword ptr [esi]
433f6dd1 xor      eax, 0x4765d17e
433f6dd6 ror      eax, 0x19
433f6dd9 xor      eax, 0x7d968300
433f6dde mov      ecx, dword ptr [eax + ecx + 1]
433f6de2 lea      eax, [edx + 0x230]
433f6de8 push     eax
433f6de9 mov      edx, esi
433f6deb mov      dword ptr [esp + 0x1e4], ecx
433f6df2 call     0x433e533f
433f6df7 mov      edx, dword ptr [esp + 0xc]
433f6dfb fstp     dword ptr [edx + 0x258]
433f6e01 xor      ecx, ecx
433f6e03 cmp      dword ptr [edx + 0x248], ecx
433f6e09 jle      0x433f6e52
433f6e0b mov      eax, dword ptr [0x4346a598]
433f6e10 test     eax, eax
433f6e12 je       0x433f6e58
433f6e14 push     0xa
433f6e16 xor      edx, edx
433f6e18 mov      ecx, edi
433f6e1a call     eax
433f6e1c mov      eax, dword ptr [esp + 0xc]
433f6e20 xorps    xmm1, xmm1
433f6e23 movss    xmm1, xmm0
433f6e27 xorps    xmm2, xmm2
433f6e2a movaps   xmm0, xmm2
433f6e2d xor      ecx, ecx
433f6e2f maxss    xmm1, xmm0
433f6e33 movss    xmm0, dword ptr [0x43470514]
433f6e3b minss    xmm1, xmm0
433f6e3f movss    dword ptr [esp + 0x1e0], xmm1
433f6e48 movss    dword ptr [eax + 0x250], xmm1
433f6e50 jmp      0x433f6e58
433f6e52 and      dword ptr [edx + 0x250], ecx
433f6e58 cmp      dword ptr [esp + 0x58], 2
433f6e5d mov      eax, dword ptr [esp + 0x54]
433f6e61 mov      dword ptr [esp + 0x30], ecx
433f6e65 mov      dword ptr [esp + 0xc], ecx
433f6e69 mov      dword ptr [esp + 0x1c], ecx
433f6e6d mov      eax, dword ptr [eax]
433f6e6f mov      dword ptr [esp + 0x38], ecx
433f6e73 mov      dword ptr [esp + 0x18], ecx
433f6e77 mov      dword ptr [esp + 0x14], ecx
433f6e7b jle      0x433f6ed3
433f6e7d lea      ecx, [eax + 0x90]
433f6e83 movss    xmm0, dword ptr [ecx]
433f6e87 lea      edi, [eax + 0x9c]
433f6e8d movss    dword ptr [esp + 0x100], xmm0
433f6e96 lea      edx, [eax + 0x58]
433f6e99 movss    xmm0, dword ptr [edi]
433f6e9d movss    dword ptr [esp + 0xfc], xmm0
433f6ea6 movss    xmm0, dword ptr [edx]
433f6eaa mov      dword ptr [esp + 0x30], ecx
433f6eae lea      ecx, [eax + 0x64]
433f6eb1 movss    dword ptr [esp + 0xf8], xmm0
433f6eba movss    xmm0, dword ptr [ecx]
433f6ebe mov      dword ptr [esp + 0xc], edi
433f6ec2 mov      dword ptr [esp + 0x1c], edx
433f6ec6 mov      dword ptr [esp + 0x38], ecx
433f6eca movss    dword ptr [esp + 0xf4], xmm0
433f6ed3 cmp      dword ptr [esp + 0x58], 3
433f6ed8 jle      0x433f6f07
433f6eda lea      ecx, [eax + 0xc8]
433f6ee0 add      eax, 0xd4
433f6ee5 movss    xmm0, dword ptr [ecx]
433f6ee9 movss    dword ptr [esp + 0xf0], xmm0
433f6ef2 mov      dword ptr [esp + 0x18], ecx
433f6ef6 movss    xmm0, dword ptr [eax]
433f6efa mov      dword ptr [esp + 0x14], eax
433f6efe movss    dword ptr [esp + 0xec], xmm0
433f6f07 mov      eax, dword ptr [esp + 0x28]
433f6f0b mov      byte ptr [0x43475bd3], 1
433f6f12 movss    xmm1, dword ptr [eax + 0x1e8]
433f6f1a movss    xmm2, dword ptr [eax + 0x1ec]
433f6f22 mov      eax, dword ptr [0x43468fd0]
433f6f27 mov      ecx, dword ptr [eax]
433f6f29 xor      ecx, dword ptr [0x43467c70]
433f6f2f xor      ecx, 0xf58e6118
433f6f35 add      ecx, esi
433f6f37 mov      dword ptr [esp + 0xa0], ecx
433f6f3e mov      eax, dword ptr [ecx]
433f6f40 mov      dword ptr [esp + 0x74], eax
433f6f44 mov      eax, dword ptr [esp + 0x2c]
433f6f48 mov      dword ptr [ecx], eax
433f6f4a mov      eax, dword ptr [0x43467f4c]
433f6f4f mov      edi, dword ptr [eax]
433f6f51 xor      edi, dword ptr [0x4346a8b0]
433f6f57 mov      eax, dword ptr [esp + 0x4c]
433f6f5b xor      edi, 0x3d52a1a7
433f6f61 add      edi, esi
433f6f63 mov      ecx, eax
433f6f65 mov      esi, dword ptr [edi]
433f6f67 mov      dword ptr [edi], eax
433f6f69 call     0x433a0f80
433f6f6e mov      ecx, dword ptr [esp + 0xa0]
433f6f75 mov      eax, dword ptr [esp + 0x74]
433f6f79 mov      dword ptr [edi], esi
433f6f7b mov      byte ptr [0x43475bd3], 0
433f6f82 mov      dword ptr [ecx], eax
433f6f84 mov      eax, dword ptr [esp + 0x14]
433f6f88 test     eax, eax
433f6f8a je       0x433f6f99
433f6f8c movss    xmm0, dword ptr [esp + 0xec]
433f6f95 movss    dword ptr [eax], xmm0
433f6f99 mov      eax, dword ptr [esp + 0x18]
433f6f9d test     eax, eax
433f6f9f je       0x433f6fae
433f6fa1 movss    xmm0, dword ptr [esp + 0xf0]
433f6faa movss    dword ptr [eax], xmm0
433f6fae mov      eax, dword ptr [esp + 0x38]
433f6fb2 test     eax, eax
433f6fb4 je       0x433f6fc3
433f6fb6 movss    xmm0, dword ptr [esp + 0xf4]
433f6fbf movss    dword ptr [eax], xmm0
433f6fc3 mov      eax, dword ptr [esp + 0x1c]
433f6fc7 test     eax, eax
433f6fc9 je       0x433f6fd8
433f6fcb movss    xmm0, dword ptr [esp + 0xf8]
433f6fd4 movss    dword ptr [eax], xmm0
433f6fd8 mov      eax, dword ptr [esp + 0xc]
433f6fdc test     eax, eax
433f6fde je       0x433f6fed
433f6fe0 movss    xmm0, dword ptr [esp + 0xfc]
433f6fe9 movss    dword ptr [eax], xmm0
433f6fed mov      eax, dword ptr [esp + 0x30]
433f6ff1 test     eax, eax
433f6ff3 je       0x433f7002
433f6ff5 movss    xmm0, dword ptr [esp + 0x100]
433f6ffe movss    dword ptr [eax], xmm0
433f7002 cmp      dword ptr [esp + 0x58], 2
433f7007 mov      esi, dword ptr [esp + 0x4c]
433f700b jle      0x433f720c
433f7011 mov      eax, dword ptr [esp + 0x54]
433f7015 movss    xmm0, dword ptr [esi + 0xa4]
433f701d movss    xmm3, dword ptr [esi + 0x74]
433f7022 movss    dword ptr [esp + 0x14], xmm0
433f7028 mov      ecx, dword ptr [eax]
433f702a movss    dword ptr [esp + 0x38], xmm3
433f7030 mov      dword ptr [esp + 0xc], ecx
433f7034 mov      edx, dword ptr [ecx + 0x50]
433f7037 test     edx, edx
433f7039 jg       0x433f703f
433f703b and      dword ptr [ecx + 0x58], 0
433f703f cmp      dword ptr [ecx + 0x88], 0
433f7046 jg       0x433f704f
433f7048 and      dword ptr [ecx + 0x90], 0
433f704f movss    xmm0, dword ptr [ecx + 0x58]
433f7054 xorps    xmm2, xmm2
433f7057 comiss   xmm2, xmm0
433f705a movss    dword ptr [esp + 0x18], xmm0
433f7060 jb       0x433f70a8
433f7062 movss    xmm1, dword ptr [ecx + 0x90]
433f706a comiss   xmm2, xmm1
433f706d jae      0x433f711d
433f7073 mulss    xmm3, dword ptr [0x4346dd40]
433f707b xorps    xmm4, xmm4
433f707e subss    xmm4, xmm1
433f7082 comiss   xmm4, xmm3
433f7085 jbe      0x433f7090
433f7087 addss    xmm3, xmm1
433f708b jmp      0x433f7120
433f7090 movaps   xmm0, xmm3
433f7093 xorps    xmm0, xmmword ptr [0x434703d0]
433f709a comiss   xmm0, xmm4
433f709d jbe      0x433f711d
433f709f subss    xmm1, xmm3
433f70a3 movaps   xmm3, xmm1
433f70a6 jmp      0x433f7120
433f70a8 mov      eax, dword ptr [0x434678c8]
433f70ad test     eax, eax
433f70af jne      0x433f70b8
433f70b1 mov      eax, 0x4346dc8c
433f70b6 jmp      0x433f70c2
433f70b8 mov      ecx, dword ptr [ebp + 8]
433f70bb push     edx
433f70bc call     eax
433f70be test     eax, eax
433f70c0 je       0x433f70fb
433f70c2 mov      ecx, dword ptr [esp + 0x20]
433f70c6 push     dword ptr [ecx + 0x7c]
433f70c9 push     eax
433f70ca call     0x774fe670
433f70cf nop      
433f70d0 pop      ecx
433f70d1 pop      ecx
433f70d2 test     eax, eax
433f70d4 je       0x433f70fb
433f70d6 movss    xmm0, dword ptr [0x43470514]
433f70de xorps    xmm2, xmm2
433f70e1 movss    xmm1, dword ptr [esp + 0x14]
433f70e7 comiss   xmm1, xmm0
433f70ea jae      0x433f7119
433f70ec movaps   xmm3, xmm0
433f70ef subss    xmm3, xmm1
433f70f3 mulss    xmm3, dword ptr [esp + 0x18]
433f70f9 jmp      0x433f7113
433f70fb movss    xmm0, dword ptr [esp + 0x14]
433f7101 xorps    xmm2, xmm2
433f7104 comiss   xmm0, xmm2
433f7107 jbe      0x433f7119
433f7109 movss    xmm3, dword ptr [esp + 0x18]
433f710f mulss    xmm3, xmm0
433f7113 mov      ecx, dword ptr [esp + 0xc]
433f7117 jmp      0x433f7120
433f7119 mov      ecx, dword ptr [esp + 0xc]
433f711d xorps    xmm3, xmm3
433f7120 movss    xmm4, dword ptr [0x43470514]
433f7128 movaps   xmm1, xmm3
433f712b movss    xmm3, dword ptr [esp + 0x38]
433f7131 movaps   xmm0, xmm2
433f7134 comiss   xmm2, xmm3
433f7137 maxss    xmm1, xmm0
433f713b movaps   xmm0, xmm4
433f713e minss    xmm1, xmm0
433f7142 movss    dword ptr [esp + 0x104], xmm1
433f714b movss    dword ptr [ecx + 0x90], xmm1
433f7153 jae      0x433f7217
433f7159 movss    xmm1, dword ptr [ecx + 0x60]
433f715e movaps   xmm0, xmm1
433f7161 andps    xmm0, xmmword ptr [0x43470340]
433f7168 comiss   xmm2, xmm0
433f716b jae      0x433f71ab
433f716d mulss    xmm1, xmm3
433f7171 addss    xmm1, dword ptr [ecx + 0x64]
433f7176 comiss   xmm1, xmm4
433f7179 jb       0x433f7183
433f717b movss    xmm1, dword ptr [0x4346f660]
433f7183 cvttss2si eax, xmm1
433f7187 movd     xmm0, eax
433f718b cvtdq2ps xmm0, xmm0
433f718e subss    xmm1, xmm0
433f7192 comiss   xmm1, xmm2
433f7195 jb       0x433f71a2
433f7197 comiss   xmm1, xmm4
433f719a jbe      0x433f71a6
433f719c subss    xmm1, xmm4
433f71a0 jmp      0x433f71a6
433f71a2 addss    xmm1, xmm4
433f71a6 movss    dword ptr [ecx + 0x64], xmm1
433f71ab mov      eax, dword ptr [0x4346a598]
433f71b0 test     eax, eax
433f71b2 je       0x433f7217
433f71b4 movss    xmm0, dword ptr [ecx + 0x58]
433f71b9 xor      edx, edx
433f71bb push     1
433f71bd mov      ecx, esi
433f71bf movss    dword ptr [esp + 0x78], xmm0
433f71c5 call     eax
433f71c7 movss    xmm4, dword ptr [0x43470514]
433f71cf xorps    xmm1, xmm1
433f71d2 mov      eax, dword ptr [esp + 0xc]
433f71d6 movss    xmm1, xmm0
433f71da xorps    xmm2, xmm2
433f71dd movaps   xmm0, xmm2
433f71e0 maxss    xmm1, xmm0
433f71e4 movaps   xmm0, xmm4
433f71e7 minss    xmm1, xmm0
433f71eb movss    dword ptr [esp + 0x1e4], xmm1
433f71f4 movss    dword ptr [eax + 0x58], xmm1
433f71f9 subss    xmm1, dword ptr [esp + 0x74]
433f71ff divss    xmm1, dword ptr [esp + 0x38]
433f7205 movss    dword ptr [eax + 0x5c], xmm1
433f720a jmp      0x433f7217
433f720c movss    xmm4, dword ptr [0x43470514]
433f7214 xorps    xmm2, xmm2
433f7217 cmp      dword ptr [esp + 0x58], 0xb
433f721c jle      0x433f72ad
433f7222 mov      eax, dword ptr [esp + 0x54]
433f7226 mov      eax, dword ptr [eax]
433f7228 cmp      dword ptr [eax + 0x280], 0
433f722f jg       0x433f723a
433f7231 and      dword ptr [eax + 0x288], 0
433f7238 jmp      0x433f72ad
433f723a movss    xmm0, dword ptr [eax + 0x290]
433f7242 mulss    xmm0, dword ptr [esi + 0x74]
433f7247 addss    xmm0, dword ptr [eax + 0x294]
433f724f comiss   xmm0, dword ptr [0x4346f660]
433f7256 jae      0x433f72ad
433f7258 movss    xmm0, dword ptr [esi + 0xf4]
433f7260 movaps   xmm3, xmm2
433f7263 subss    xmm0, dword ptr [0x434728d0]
433f726b movaps   xmm2, xmm4
433f726e divss    xmm0, dword ptr [0x4346fd90]
433f7276 movaps   xmm1, xmm0
433f7279 movaps   xmm0, xmm4
433f727c maxss    xmm1, xmm3
433f7280 minss    xmm1, xmm2
433f7284 subss    xmm0, xmm1
433f7288 movss    dword ptr [esp + 0x1e8], xmm1
433f7291 movaps   xmm1, xmm0
433f7294 maxss    xmm1, xmm3
433f7298 minss    xmm1, xmm2
433f729c movss    dword ptr [esp + 0x108], xmm1
433f72a5 movss    dword ptr [eax + 0x288], xmm1
433f72ad mov      ecx, dword ptr [0x4346a8e4]
433f72b3 lea      edx, [esp + 0x6c]
433f72b7 mov      edi, dword ptr [esp + 0x4c]
433f72bb mov      eax, dword ptr [0x43467eb8]
433f72c0 push     0
433f72c2 mov      esi, dword ptr [ecx]
433f72c4 lea      ecx, [esp + 0x94]
433f72cb xor      esi, dword ptr [0x434688cc]
433f72d1 movss    xmm4, dword ptr [edi + 0x80]
433f72d9 xor      esi, 0x36375c23
433f72df mov      edi, dword ptr [ebp + 8]
433f72e2 movss    xmm3, dword ptr [eax]
433f72e6 mov      eax, dword ptr [esp + 0x30]
433f72ea movss    xmm2, dword ptr [esi + edi + 8]
433f72f0 mov      esi, dword ptr [esp + 0x50]
433f72f4 movss    xmm0, dword ptr [eax + 0x10]
433f72f9 movss    xmm1, dword ptr [esi + 0xec]
433f7301 call     0x4340bd50
433f7306 movss    xmm0, dword ptr [esp + 0x10c]
433f730f push     ecx
433f7310 mov      ecx, dword ptr [esp + 0x24]
433f7314 movss    dword ptr [esp], xmm0
433f7319 push     dword ptr [esp + 0xc0]
433f7320 push     esi
433f7321 push     edi
433f7322 call     0x43381e04
433f7327 push     edi
433f7328 mov      edi, dword ptr [esp + 0x2c]
433f732c lea      ecx, [edi + 0x14]
433f732f call     0x4341d38e
433f7334 mov      eax, dword ptr [esi + 0x80]
433f733a mov      ecx, dword ptr [ebp + 8]
433f733d mov      esi, dword ptr [esp + 0x20]
433f7341 mov      dword ptr [edi + 0x1e4], eax
433f7347 mov      eax, dword ptr [0x434679cc]
433f734c mov      eax, dword ptr [eax]
433f734e xor      eax, dword ptr [0x43467164]
433f7354 xor      eax, 0xa5bd68
433f7359 mov      al, byte ptr [eax + ecx]
433f735c mov      byte ptr [edi + 4], al
433f735f mov      edi, dword ptr [esp + 0x60]
433f7363 inc      edi
433f7364 mov      dword ptr [esp + 0x60], edi
433f7368 cmp      edi, dword ptr [esp + 0x34]
433f736c jl       0x433f5b74
433f7372 movd     xmm0, dword ptr [esp + 0x188]
433f737b lea      esi, [esp + 0x194]
433f7382 mov      eax, dword ptr [0x4346a338]
433f7387 cvtdq2ps xmm0, xmm0
433f738a mulss    xmm0, dword ptr [eax]
433f738e mov      eax, dword ptr [0x43467b04]
433f7393 movss    dword ptr [eax + 0x10], xmm0
433f7398 mov      eax, dword ptr [0x434670a0]
433f739d movss    xmm0, dword ptr [esp + 0x98]
433f73a6 mov      edi, dword ptr [eax]
433f73a8 xor      edi, dword ptr [0x4346900c]
433f73ae xor      edi, 0x7a2d60c1
433f73b4 add      edi, ecx
433f73b6 movsd    dword ptr es:[edi], dword ptr [esi]
433f73b7 movsd    dword ptr es:[edi], dword ptr [esi]
433f73b8 movsd    dword ptr es:[edi], dword ptr [esi]
433f73b9 mov      eax, dword ptr [0x4346a8e4]
433f73be lea      esi, [esp + 0x194]
433f73c5 mov      edi, dword ptr [eax]
433f73c7 xor      edi, dword ptr [0x434688cc]
433f73cd xor      edi, 0x36375c23
433f73d3 add      edi, ecx
433f73d5 movsd    dword ptr es:[edi], dword ptr [esi]
433f73d6 movsd    dword ptr es:[edi], dword ptr [esi]
433f73d7 movsd    dword ptr es:[edi], dword ptr [esi]
433f73d8 mov      eax, dword ptr [0x434670e0]
433f73dd lea      esi, [esp + 0x1b0]
433f73e4 mov      edi, dword ptr [eax]
433f73e6 xor      edi, dword ptr [0x43467d28]
433f73ec xor      edi, 0x4e66bb34
433f73f2 add      edi, ecx
433f73f4 movsd    dword ptr es:[edi], dword ptr [esi]
433f73f5 movsd    dword ptr es:[edi], dword ptr [esi]
433f73f6 movsd    dword ptr es:[edi], dword ptr [esi]
433f73f7 mov      eax, dword ptr [0x43468d30]
433f73fc lea      esi, [esp + 0x1b0]
433f7403 mov      edi, dword ptr [eax]
433f7405 xor      edi, dword ptr [0x43468ed4]
433f740b xor      edi, 0x2a671b42
433f7411 add      edi, ecx
433f7413 movsd    dword ptr es:[edi], dword ptr [esi]
433f7414 movsd    dword ptr es:[edi], dword ptr [esi]
433f7415 movsd    dword ptr es:[edi], dword ptr [esi]
433f7416 mov      eax, dword ptr [0x434670cc]
433f741b lea      esi, [esp + 0x1b0]
433f7422 mov      edi, dword ptr [eax]
433f7424 xor      edi, dword ptr [0x43468bcc]
433f742a xor      edi, 0xa9ee6062
433f7430 add      edi, ecx
433f7432 mov      ecx, dword ptr [esp + 0x84]
433f7439 movsd    dword ptr es:[edi], dword ptr [esi]
433f743a movsd    dword ptr es:[edi], dword ptr [esi]
433f743b movsd    dword ptr es:[edi], dword ptr [esi]
433f743c mov      eax, dword ptr [0x434679f8]
433f7441 mov      edi, dword ptr [ebp + 8]
433f7444 mov      eax, dword ptr [eax]
433f7446 xor      eax, dword ptr [0x434675f8]
433f744c xor      eax, 0x3309c0cf
433f7451 movss    dword ptr [eax + edi], xmm0
433f7456 mov      eax, dword ptr [0x43467dd4]
433f745b movss    xmm0, dword ptr [esp + 0x9c]
433f7464 mov      eax, dword ptr [eax]
433f7466 xor      eax, dword ptr [0x4346a52c]
433f746c xor      eax, 0xfb7e3404
433f7471 movss    dword ptr [eax + edi], xmm0
433f7476 mov      eax, dword ptr [0x434688d0]
433f747b mov      eax, dword ptr [eax]
433f747d xor      eax, dword ptr [0x43468c24]
433f7483 xor      eax, 0xe2fbe695
433f7488 mov      dword ptr [eax + edi], ecx
433f748b mov      eax, dword ptr [0x434678a4]
433f7490 mov      ecx, dword ptr [eax]
433f7492 xor      ecx, dword ptr [0x4346905c]
433f7498 mov      al, byte ptr [esp + 0x1a4]
433f749f xor      ecx, 0xac7f2913
433f74a5 mov      byte ptr [ecx + edi], al
433f74a8 mov      eax, dword ptr [0x43468c40]
433f74ad mov      cl, byte ptr [esp + 0x71]
433f74b1 mov      eax, dword ptr [eax]
433f74b3 xor      eax, dword ptr [0x43468db8]
433f74b9 xor      eax, 0x7090d8dd
433f74be mov      byte ptr [eax + edi], cl
433f74c1 mov      eax, dword ptr [0x43468da4]
433f74c6 mov      cl, byte ptr [esp + 0x7b]
433f74ca movss    xmm0, dword ptr [esp + 0x64]
433f74d0 mov      esi, dword ptr [esp + 0x4c]
433f74d4 mov      eax, dword ptr [eax]
433f74d6 xor      eax, dword ptr [0x434684ec]
433f74dc xor      eax, 0xcacaeecc
433f74e1 mov      byte ptr [eax + edi], cl
433f74e4 mov      eax, dword ptr [0x4346a7e0]
433f74e9 mov      cl, byte ptr [esp + 0x73]
433f74ed mov      eax, dword ptr [eax]
433f74ef xor      eax, dword ptr [0x43468c34]
433f74f5 xor      eax, 0xa15c3105
433f74fa mov      byte ptr [eax + edi], cl
433f74fd mov      eax, dword ptr [0x43468c88]
433f7502 mov      ecx, dword ptr [esp + 0x3c]
433f7506 mov      eax, dword ptr [eax]
433f7508 xor      eax, dword ptr [0x4346a3ac]
433f750e xor      eax, 0xae838771
433f7513 movss    dword ptr [eax + edi], xmm0
433f7518 mov      eax, dword ptr [0x434682a8]
433f751d movss    xmm0, dword ptr [esp + 0x7c]
433f7523 mov      eax, dword ptr [eax]
433f7525 xor      eax, dword ptr [0x43467960]
433f752b xor      eax, 0xd4248210
433f7530 mov      dword ptr [eax + edi], ecx
433f7533 mov      eax, dword ptr [0x43468914]
433f7538 mov      ecx, dword ptr [esp + 0x40]
433f753c mov      eax, dword ptr [eax]
433f753e xor      eax, dword ptr [0x4346a528]
433f7544 xor      eax, 0xa3abbb09
433f7549 mov      dword ptr [eax + edi], ecx
433f754c mov      eax, dword ptr [0x43468bd4]
433f7551 mov      cl, byte ptr [esp + 0x4b]
433f7555 mov      eax, dword ptr [eax]
433f7557 xor      eax, dword ptr [0x4346a678]
433f755d xor      eax, 0x7501cb91
433f7562 mov      byte ptr [eax + edi], cl
433f7565 mov      eax, dword ptr [0x43467eb8]
433f756a movss    dword ptr [eax], xmm0
433f756e movss    xmm0, dword ptr [esp + 0x90]
433f7577 movss    dword ptr [0x43476b3c], xmm0
433f757f movss    xmm0, dword ptr [esp + 0x6c]
433f7585 movss    dword ptr [0x43476b40], xmm0
433f758d mov      eax, dword ptr [0x434693d8]
433f7592 mov      ecx, dword ptr [0x43475ab4]
433f7598 mov      eax, dword ptr [eax]
433f759a xor      eax, dword ptr [0x43468bc4]
433f75a0 xor      eax, 0x3d10b94c
433f75a5 mov      edx, dword ptr [eax + edi]
433f75a8 mov      eax, dword ptr [0x43475ab0]
433f75ad cmp      eax, ecx
433f75af je       0x433f75d5
433f75b1 mov      esi, eax
433f75b3 mov      edi, ecx
433f75b5 mov      ecx, dword ptr [esi]
433f75b7 push     edx
433f75b8 mov      edx, dword ptr [ebp + 0xc]
433f75bb mov      eax, dword ptr [ecx]
433f75bd mov      edx, dword ptr [edx + 4]
433f75c0 mov      eax, dword ptr [eax + 8]
433f75c3 call     eax
433f75c5 add      esi, 4
433f75c8 mov      edx, eax
433f75ca cmp      esi, edi
433f75cc jne      0x433f75b5
433f75ce mov      edi, dword ptr [ebp + 8]
433f75d1 mov      esi, dword ptr [esp + 0x4c]
433f75d5 mov      eax, dword ptr [0x4346a338]
433f75da movd     xmm0, edx
433f75de xor      edx, edx
433f75e0 cvtdq2ps xmm0, xmm0
433f75e3 mulss    xmm0, dword ptr [eax]
433f75e7 mov      eax, dword ptr [0x43467eb8]
433f75ec movss    dword ptr [eax], xmm0
433f75f0 mov      eax, dword ptr [ebp + 0xc]
433f75f3 mov      ecx, dword ptr [eax + 4]
433f75f6 mov      eax, ecx
433f75f8 div      dword ptr [esp + 0x50]
433f75fc mov      eax, dword ptr [esp + 0x20]
433f7600 cmp      dword ptr [eax + edx*4 + 0x1ac], ecx
433f7607 jne      0x433f778f
433f760d mov      ecx, esi
433f760f call     0x434011c8
433f7614 mov      byte ptr [esi + 0x10b], 1
433f761b mov      eax, dword ptr [0x4346a660]
433f7620 mov      eax, dword ptr [eax]
433f7622 xor      eax, dword ptr [0x434679e0]
433f7628 xor      eax, 0xb538bba5
433f762d cmp      dword ptr [eax + edi + 0xc], 4
433f7632 jle      0x433f778f
433f7638 mov      ecx, dword ptr [esp + 0x20]
433f763c push     0x3d9
433f7641 push     4
433f7643 push     edi
433f7644 call     0x433b1a8f
433f7649 mov      dword ptr [esp + 0x3c], eax
433f764d cmp      eax, 1
433f7650 jle      0x433f76af
433f7652 mov      ecx, dword ptr [0x4346a660]
433f7658 mov      ecx, dword ptr [ecx]
433f765a xor      ecx, dword ptr [0x434679e0]
433f7660 xor      ecx, 0xb538bba5
433f7666 mov      edx, dword ptr [ecx + edi]
433f7669 add      edx, 0xe0
433f766f mov      dword ptr [esp + 0x64], edx
433f7673 je       0x433f778f
433f7679 and      dword ptr [edx + 0x2c], 0
433f767d and      dword ptr [edx + 0x20], 0
433f7681 mov      dword ptr [edx + 0x18], eax
433f7684 mov      dword ptr [esp + 0x40], 0xb19efc7e
433f768c mov      eax, dword ptr [esp + 0x40]
433f7690 mov      ecx, dword ptr [edi]
433f7692 xor      eax, 0x4765d17e
433f7697 ror      eax, 0x19
433f769a xor      eax, 0x7d968300
433f769f mov      ecx, dword ptr [eax + ecx + 1]
433f76a3 mov      dword ptr [esp + 0x24c], ecx
433f76aa jmp      0x433f777c
433f76af mov      eax, dword ptr [esp + 0x20]
433f76b3 push     dword ptr [eax + 0xec]
433f76b9 lea      eax, [esp + 0x314]
433f76c0 push     0x40
433f76c2 push     eax
433f76c3 call     0x774fdef0
433f76c8 mov      al, byte ptr [esi + 0x32b]
433f76ce add      esp, 0xc
433f76d1 test     al, 1
433f76d3 je       0x433f76f4
433f76d5 mov      eax, dword ptr [esp + 0x20]
433f76d9 push     dword ptr [eax + 0x4c]
433f76dc lea      eax, [esp + 0x314]
433f76e3 push     0x40
433f76e5 push     eax
433f76e6 call     0x774fdd00
433f76eb mov      al, byte ptr [esi + 0x32b]
433f76f1 add      esp, 0xc
433f76f4 test     al, 2
433f76f6 je       0x433f7711
433f76f8 mov      eax, dword ptr [esp + 0x20]
433f76fc push     dword ptr [eax + 0x5c]
433f76ff lea      eax, [esp + 0x314]
433f7706 push     0x40
433f7708 push     eax
433f7709 call     0x774fdd00
433f770e add      esp, 0xc
433f7711 lea      edx, [esp + 0x310]
433f7718 mov      ecx, edi
433f771a call     0x433df1a9
433f771f mov      dword ptr [esp + 0x3c], eax
433f7723 cmp      eax, 1
433f7726 jle      0x433f778f
433f7728 mov      ecx, dword ptr [0x4346a660]
433f772e mov      ecx, dword ptr [ecx]
433f7730 xor      ecx, dword ptr [0x434679e0]
433f7736 xor      ecx, 0xb538bba5
433f773c mov      edx, dword ptr [ecx + edi]
433f773f add      edx, 0xe0
433f7745 mov      dword ptr [esp + 0x64], edx
433f7749 je       0x433f778f
433f774b and      dword ptr [edx + 0x2c], 0
433f774f and      dword ptr [edx + 0x20], 0
433f7753 mov      dword ptr [edx + 0x18], eax
433f7756 mov      dword ptr [esp + 0x40], 0xb19efc7e
433f775e mov      eax, dword ptr [esp + 0x40]
433f7762 mov      ecx, dword ptr [edi]
433f7764 xor      eax, 0x4765d17e
433f7769 ror      eax, 0x19
433f776c xor      eax, 0x7d968300
433f7771 mov      ecx, dword ptr [eax + ecx + 1]
433f7775 mov      dword ptr [esp + 0x1f0], ecx
433f777c push     dword ptr [esp + 0x3c]
433f7780 push     edx
433f7781 mov      edx, edi
433f7783 call     0x433e533f
433f7788 mov      eax, dword ptr [esp + 0x64]
433f778c fstp     dword ptr [eax + 0x28]
433f778f mov      eax, dword ptr [0x434678f8]
433f7794 mov      eax, dword ptr [eax]
433f7796 cmp      dword ptr [esi + 0x70], eax
433f7799 jl       0x433f779f
433f779b dec      eax
433f779c mov      dword ptr [esi + 0x70], eax
433f779f mov      edx, dword ptr [ebp + 0xc]
433f77a2 mov      ecx, edi
433f77a4 call     0x433800f5
433f77a9 mov      eax, dword ptr [0x434682b8]
433f77ae mov      ecx, dword ptr [eax]
433f77b0 xor      ecx, dword ptr [0x43467d90]
433f77b6 mov      eax, dword ptr [0x4346794c]
433f77bb xor      ecx, 0x1bae1168
433f77c1 xor      eax, 0xc429e1bf
433f77c6 jmp      0x433f77ca
433f77c8 mov      eax, edx
433f77ca mov      edx, dword ptr [eax + 0x1c]
433f77cd cmp      eax, edx
433f77cf jne      0x433f77c8
433f77d1 movss    xmm0, dword ptr [eax + 0x2c]
433f77d6 movss    dword ptr [esp + 0x1c], xmm0
433f77dc xor      dword ptr [esp + 0x1c], eax
433f77e0 mov      eax, dword ptr [0x43468354]
433f77e5 movss    xmm0, dword ptr [esp + 0x1c]
433f77eb mulss    xmm0, dword ptr [ecx + edi]
433f77f0 mov      ecx, dword ptr [ebp + 0xc]
433f77f3 mov      eax, dword ptr [eax]
433f77f5 xor      eax, dword ptr [0x4346852c]
433f77fb xor      eax, 0x66146802
433f7800 movss    dword ptr [eax + edi], xmm0
433f7805 mov      eax, dword ptr [0x43468fd0]
433f780a mov      eax, dword ptr [eax]
433f780c xor      eax, dword ptr [0x43467c70]
433f7812 xor      eax, 0xf58e6118
433f7817 mov      dword ptr [eax + edi], ecx
433f781a mov      al, byte ptr [esi + 0x109]
433f7820 movss    xmm0, dword ptr [esi + 0x110]
433f7828 mov      byte ptr [esp + 0xbc], al
433f782f mov      eax, dword ptr [0x4346a660]
433f7834 movss    dword ptr [esp + 0x98], xmm0
433f783d mov      eax, dword ptr [eax]
433f783f xor      eax, dword ptr [0x434679e0]
433f7845 xor      eax, 0xb538bba5
433f784a cmp      dword ptr [eax + edi + 0xc], 3
433f784f jle      0x433f8410
433f7855 mov      eax, dword ptr [eax + edi]
433f7858 mov      dword ptr [esp + 0xc], eax
433f785c add      eax, 0xa8
433f7861 mov      dword ptr [esp + 0x9c], eax
433f7868 mov      eax, dword ptr [0x4346a8e4]
433f786d mov      byte ptr [esp + 0x4b], 0
433f7872 mov      esi, dword ptr [eax]
433f7874 xor      esi, dword ptr [0x434688cc]
433f787a xor      esi, 0x36375c23
433f7880 add      esi, edi
433f7882 lea      edi, [esp + 0xd0]
433f7889 movsd    dword ptr es:[edi], dword ptr [esi]
433f788a movsd    dword ptr es:[edi], dword ptr [esi]
433f788b movsd    dword ptr es:[edi], dword ptr [esi]
433f788c movss    xmm1, dword ptr [esp + 0xd0]
433f7895 movss    xmm0, dword ptr [esp + 0xd4]
433f789e mulss    xmm1, xmm1
433f78a2 mulss    xmm0, xmm0
433f78a6 addss    xmm1, xmm0
433f78aa movaps   xmm0, xmm1
433f78ad movss    xmm1, dword ptr [0x43470474]
433f78b5 sqrtss   xmm0, xmm0
433f78b9 movss    dword ptr [esp + 0x1f4], xmm0
433f78c2 call     0x43367633
433f78c7 mov      eax, dword ptr [0x43467b04]
433f78cc mov      esi, dword ptr [esp + 0x4c]
433f78d0 movss    dword ptr [esp + 0x1c], xmm0
433f78d6 xorps    xmm0, xmm0
433f78d9 movss    xmm1, dword ptr [eax + 0x10]
433f78de subss    xmm1, dword ptr [esi + 0x6c]
433f78e3 call     0x4332fc35
433f78e8 mov      eax, dword ptr [0x43467a74]
433f78ed mov      edi, dword ptr [ebp + 8]
433f78f0 movss    dword ptr [esp + 0x24], xmm0
433f78f6 mov      eax, dword ptr [eax]
433f78f8 xor      eax, dword ptr [0x434678c0]
433f78fe xor      eax, 0xcd812654
433f7903 mov      ecx, dword ptr [eax + edi]
433f7906 cmp      ecx, -1
433f7909 je       0x433f799f
433f790f mov      eax, dword ptr [0x4346a890]
433f7914 push     ecx
433f7915 mov      eax, dword ptr [eax]
433f7917 mov      edx, dword ptr [eax + 0x10]
433f791a mov      eax, esp
433f791c mov      dword ptr [eax], ecx
433f791e mov      ecx, dword ptr [0x4346a890]
433f7924 call     edx
433f7926 mov      edx, eax
433f7928 mov      dword ptr [esp + 0x3c], edx
433f792c test     edx, edx
433f792e je       0x433f799f
433f7930 mov      dword ptr [esp + 0x40], 0xc606305
433f7938 mov      eax, dword ptr [esp + 0x40]
433f793c mov      ecx, dword ptr [edx]
433f793e rol      eax, 0x1e
433f7941 mov      ecx, dword ptr [eax + ecx - 0x431811d9]
433f7948 mov      dword ptr [esp + 0x1f8], ecx
433f794f call     0x433e533f
433f7954 movss    xmm3, dword ptr [0x43470000]
433f795c fstp     dword ptr [esp + 0x40]
433f7960 movss    xmm0, dword ptr [esp + 0x40]
433f7966 comiss   xmm0, xmm3
433f7969 jbe      0x433f79a7
433f796b mov      edx, dword ptr [esp + 0x3c]
433f796f mov      dword ptr [esp + 0x40], 0xc606305
433f7977 mov      eax, dword ptr [esp + 0x40]
433f797b rol      eax, 0x1e
433f797e mov      ecx, dword ptr [edx]
433f7980 mov      ecx, dword ptr [eax + ecx - 0x431811d9]
433f7987 mov      dword ptr [esp + 0x1fc], ecx
433f798e call     0x433e533f
433f7993 fstp     dword ptr [esp + 0x40]
433f7997 movss    xmm3, dword ptr [esp + 0x40]
433f799d jmp      0x433f79a7
433f799f movss    xmm3, dword ptr [0x43470474]
433f79a7 movss    xmm1, dword ptr [esp + 0x1c]
433f79ad movaps   xmm0, xmm3
433f79b0 mulss    xmm0, dword ptr [0x43470830]
433f79b8 mov      eax, dword ptr [0x434679f8]
433f79bd mulss    xmm3, dword ptr [0x43472144]
433f79c5 divss    xmm1, xmm0
433f79c9 mov      eax, dword ptr [eax]
433f79cb xor      eax, dword ptr [0x434675f8]
433f79d1 xor      eax, 0x3309c0cf
433f79d6 movss    xmm0, dword ptr [esp + 0x1c]
433f79dc divss    xmm0, xmm3
433f79e0 movss    xmm7, dword ptr [0x43470514]
433f79e8 movss    xmm3, dword ptr [esi + 0xa4]
433f79f0 movss    xmm4, dword ptr [esp + 0x24]
433f79f6 mulss    xmm4, dword ptr [0x43472708]
433f79fe movss    dword ptr [esp + 0x14], xmm0
433f7a04 movss    xmm0, dword ptr [esi + 0x11c]
433f7a0c movss    dword ptr [esp + 0x30], xmm0
433f7a12 movss    xmm0, dword ptr [eax + edi]
433f7a17 addss    xmm0, dword ptr [esi + 0xa8]
433f7a1f movss    dword ptr [esp + 0x84], xmm1
433f7a28 xorps    xmm1, xmm1
433f7a2b movaps   xmm6, xmm1
433f7a2e movaps   xmm2, xmm0
433f7a31 maxss    xmm2, xmm6
433f7a35 minss    xmm2, xmm7
433f7a39 movaps   xmm5, xmm2
433f7a3c movss    dword ptr [esp + 0x110], xmm2
433f7a45 subss    xmm5, xmm3
433f7a49 comiss   xmm5, xmm4
433f7a4c jbe      0x433f7a54
433f7a4e addss    xmm3, xmm4
433f7a52 jmp      0x433f7a6c
433f7a54 movaps   xmm0, xmm4
433f7a57 xorps    xmm0, xmmword ptr [0x434703d0]
433f7a5e comiss   xmm0, xmm5
433f7a61 jbe      0x433f7a69
433f7a63 subss    xmm3, xmm4
433f7a67 jmp      0x433f7a6c
433f7a69 movaps   xmm3, xmm2
433f7a6c movaps   xmm0, xmm3
433f7a6f maxss    xmm0, xmm6
433f7a73 minss    xmm0, xmm7
433f7a77 movups   xmmword ptr [esp + 0x170], xmm0
433f7a7f movss    dword ptr [esp + 0x80], xmm0
433f7a88 movss    xmm0, dword ptr [esp + 0x1c]
433f7a8e comiss   xmm0, xmm1
433f7a91 ja       0x433f7a9f
433f7a93 comiss   xmm1, dword ptr [esi + 0x104]
433f7a9a setae    al
433f7a9d jmp      0x433f7aa3
433f7a9f mov      al, byte ptr [esp + 0x4b]
433f7aa3 cmp      byte ptr [esi + 0x138], 0
433f7aaa jne      0x433f7be4
433f7ab0 test     al, al
433f7ab2 je       0x433f7be4
433f7ab8 cmp      byte ptr [esi + 0x108], 0
433f7abf je       0x433f7be4
433f7ac5 cmp      byte ptr [esi + 0x128], 0
433f7acc jne      0x433f7be4
433f7ad2 cmp      byte ptr [esi + 0x109], 0
433f7ad9 jne      0x433f7be4
433f7adf movss    xmm0, dword ptr [0x4346fa58]
433f7ae7 comiss   xmm0, dword ptr [esi + 0x2ac]
433f7aee jbe      0x433f7be4
433f7af4 mov      eax, dword ptr [esp + 0x20]
433f7af8 push     dword ptr [eax + 0xcc]
433f7afe lea      eax, [esp + 0x354]
433f7b05 push     0x40
433f7b07 push     eax
433f7b08 call     0x774fdef0
433f7b0d add      esp, 0xc
433f7b10 test     byte ptr [esi + 0x32b], 2
433f7b17 je       0x433f7b32
433f7b19 mov      eax, dword ptr [esp + 0x20]
433f7b1d push     dword ptr [eax + 0x7c]
433f7b20 lea      eax, [esp + 0x354]
433f7b27 push     0x40
433f7b29 push     eax
433f7b2a call     0x774fdd00
433f7b2f add      esp, 0xc
433f7b32 mov      eax, dword ptr [esp + 0x20]
433f7b36 push     dword ptr [eax + 0xdc]
433f7b3c lea      eax, [esp + 0x354]
433f7b43 push     0x40
433f7b45 push     eax
433f7b46 call     0x774fdd00
433f7b4b add      esp, 0xc
433f7b4e lea      edx, [esp + 0x350]
433f7b55 mov      ecx, edi
433f7b57 call     0x433df1a9
433f7b5c mov      dword ptr [esp + 0x3c], eax
433f7b60 cmp      eax, 1
433f7b63 jle      0x433f7be4
433f7b65 mov      ecx, dword ptr [0x4346a660]
433f7b6b mov      ecx, dword ptr [ecx]
433f7b6d xor      ecx, dword ptr [0x434679e0]
433f7b73 xor      ecx, 0xb538bba5
433f7b79 mov      edx, dword ptr [ecx + edi]
433f7b7c add      edx, 0xa8
433f7b82 mov      dword ptr [esp + 0x64], edx
433f7b86 je       0x433f7bdd
433f7b88 and      dword ptr [edx + 0x2c], 0
433f7b8c and      dword ptr [edx + 0x20], 0
433f7b90 push     dword ptr [esp + 0x3c]
433f7b94 mov      dword ptr [edx + 0x18], eax
433f7b97 mov      dword ptr [esp + 0x44], 0xb19efc7e
433f7b9f mov      eax, dword ptr [esp + 0x44]
433f7ba3 mov      ecx, dword ptr [edi]
433f7ba5 xor      eax, 0x4765d17e
433f7baa ror      eax, 0x19
433f7bad xor      eax, 0x7d968300
433f7bb2 push     edx
433f7bb3 mov      edx, edi
433f7bb5 mov      ecx, dword ptr [eax + ecx + 1]
433f7bb9 mov      dword ptr [esp + 0x208], ecx
433f7bc0 call     0x433e533f
433f7bc5 mov      eax, dword ptr [esp + 0x64]
433f7bc9 movss    xmm0, dword ptr [esp + 0x80]
433f7bd2 movups   xmmword ptr [esp + 0x170], xmm0
433f7bda fstp     dword ptr [eax + 0x28]
433f7bdd mov      byte ptr [esi + 0x138], 1
433f7be4 mov      edx, dword ptr [0x4346a364]
433f7bea test     edx, edx
433f7bec je       0x433f7de2
433f7bf2 mov      eax, dword ptr [esp + 0xc]
433f7bf6 mov      ecx, edi
433f7bf8 push     dword ptr [eax + 0xc0]
433f7bfe call     edx
433f7c00 cmp      eax, 0x3d4
433f7c05 je       0x433f7c12
433f7c07 cmp      eax, 0x3d3
433f7c0c jne      0x433f7de2
433f7c12 cmp      byte ptr [esi + 0x138], 0
433f7c19 je       0x433f7d46
433f7c1f movss    xmm0, dword ptr [0x4346dd4c]
433f7c27 comiss   xmm0, dword ptr [esp + 0x14]
433f7c2c jb       0x433f7d46
433f7c32 movss    xmm3, dword ptr [esp + 0x24]
433f7c38 xorps    xmm1, xmm1
433f7c3b comiss   xmm1, xmm3
433f7c3e mov      ecx, dword ptr [esp + 0xc]
433f7c42 jae      0x433f7d1d
433f7c48 movss    xmm4, dword ptr [ecx + 0xd0]
433f7c50 movaps   xmm0, xmm4
433f7c53 andps    xmm0, xmmword ptr [0x43470340]
433f7c5a comiss   xmm1, xmm0
433f7c5d jae      0x433f7cb4
433f7c5f movaps   xmm2, xmm3
433f7c62 movss    xmm3, dword ptr [0x43470514]
433f7c6a mulss    xmm2, xmm4
433f7c6e addss    xmm2, dword ptr [ecx + 0xd4]
433f7c76 comiss   xmm2, xmm3
433f7c79 jb       0x433f7c83
433f7c7b movss    xmm2, dword ptr [0x4346f660]
433f7c83 cvttss2si eax, xmm2
433f7c87 movd     xmm0, eax
433f7c8b cvtdq2ps xmm0, xmm0
433f7c8e subss    xmm2, xmm0
433f7c92 comiss   xmm2, xmm1
433f7c95 jb       0x433f7ca2
433f7c97 comiss   xmm2, xmm3
433f7c9a jbe      0x433f7ca6
433f7c9c subss    xmm2, xmm3
433f7ca0 jmp      0x433f7ca6
433f7ca2 addss    xmm2, xmm3
433f7ca6 movss    xmm3, dword ptr [esp + 0x24]
433f7cac movss    dword ptr [ecx + 0xd4], xmm2
433f7cb4 mov      eax, dword ptr [0x4346a598]
433f7cb9 test     eax, eax
433f7cbb je       0x433f7d1d
433f7cbd movss    xmm0, dword ptr [ecx + 0xc8]
433f7cc5 xor      edx, edx
433f7cc7 push     3
433f7cc9 mov      ecx, esi
433f7ccb movss    dword ptr [esp + 0x44], xmm0
433f7cd1 call     eax
433f7cd3 mov      ecx, dword ptr [esp + 0xc]
433f7cd7 xorps    xmm1, xmm1
433f7cda movss    xmm3, dword ptr [esp + 0x24]
433f7ce0 movss    xmm1, xmm0
433f7ce4 xorps    xmm2, xmm2
433f7ce7 movaps   xmm0, xmm2
433f7cea maxss    xmm1, xmm0
433f7cee movss    xmm0, dword ptr [0x43470514]
433f7cf6 minss    xmm1, xmm0
433f7cfa movss    dword ptr [esp + 0x204], xmm1
433f7d03 movss    dword ptr [ecx + 0xc8], xmm1
433f7d0b subss    xmm1, dword ptr [esp + 0x40]
433f7d11 divss    xmm1, xmm3
433f7d15 movss    dword ptr [ecx + 0xcc], xmm1
433f7d1d movss    xmm0, dword ptr [ecx + 0xd0]
433f7d25 mulss    xmm0, xmm3
433f7d29 addss    xmm0, dword ptr [ecx + 0xd4]
433f7d31 comiss   xmm0, dword ptr [0x4346f660]
433f7d38 setb     al
433f7d3b mov      byte ptr [esi + 0x138], al
433f7d41 jmp      0x433f7de8
433f7d46 mov      ecx, dword ptr [esp + 0xc]
433f7d4a xorps    xmm2, xmm2
433f7d4d movss    xmm3, dword ptr [esp + 0x24]
433f7d53 xorps    xmm1, xmm1
433f7d56 mulss    xmm3, dword ptr [0x4346fd78]
433f7d5e mov      byte ptr [esi + 0x138], 0
433f7d65 movss    xmm4, dword ptr [ecx + 0xc8]
433f7d6d subss    xmm2, xmm4
433f7d71 comiss   xmm2, xmm3
433f7d74 jbe      0x433f7d7c
433f7d76 addss    xmm3, xmm4
433f7d7a jmp      0x433f7d9a
433f7d7c movaps   xmm0, xmm3
433f7d7f xorps    xmm0, xmmword ptr [0x434703d0]
433f7d86 comiss   xmm0, xmm2
433f7d89 jbe      0x433f7d97
433f7d8b movaps   xmm0, xmm4
433f7d8e subss    xmm0, xmm3
433f7d92 movaps   xmm3, xmm0
433f7d95 jmp      0x433f7d9a
433f7d97 xorps    xmm3, xmm3
433f7d9a movaps   xmm2, xmm3
433f7d9d movaps   xmm0, xmm1
433f7da0 movss    xmm3, dword ptr [esp + 0x24]
433f7da6 maxss    xmm2, xmm0
433f7daa movss    xmm0, dword ptr [0x43470514]
433f7db2 ucomiss  xmm3, xmm1
433f7db5 minss    xmm2, xmm0
433f7db9 lahf     
433f7dba movss    dword ptr [esp + 0x208], xmm2
433f7dc3 movss    dword ptr [ecx + 0xc8], xmm2
433f7dcb test     ah, 0x44
433f7dce jnp      0x433f7deb
433f7dd0 subss    xmm2, xmm4
433f7dd4 divss    xmm2, xmm3
433f7dd8 movss    dword ptr [ecx + 0xcc], xmm2
433f7de0 jmp      0x433f7deb
433f7de2 movss    xmm3, dword ptr [esp + 0x24]
433f7de8 xorps    xmm1, xmm1
433f7deb movss    xmm0, dword ptr [0x43470514]
433f7df3 comiss   xmm0, dword ptr [esi + 0xec]
433f7dfa jb       0x433f8410
433f7e00 cmp      byte ptr [esi + 0x108], 0
433f7e07 je       0x433f8410
433f7e0d cmp      byte ptr [esi + 0x128], 0
433f7e14 jne      0x433f8410
433f7e1a cmp      byte ptr [esi + 0x109], 0
433f7e21 jne      0x433f8410
433f7e27 comiss   xmm3, xmm1
433f7e2a jbe      0x433f8410
433f7e30 mov      eax, dword ptr [ebp + 0xc]
433f7e33 movss    xmm0, dword ptr [esi + 0x80]
433f7e3b movss    xmm4, dword ptr [0x43471f88]
433f7e43 movaps   xmm2, xmm0
433f7e46 movss    dword ptr [esp + 0x18], xmm0
433f7e4c movss    xmm3, dword ptr [eax + 0x10]
433f7e51 movss    xmm0, dword ptr [0x43470574]
433f7e59 ucomiss  xmm3, xmm3
433f7e5c maxss    xmm2, xmm0
433f7e60 movss    dword ptr [esp + 0x2c], xmm3
433f7e66 movaps   xmm0, xmm4
433f7e69 lahf     
433f7e6a minss    xmm2, xmm0
433f7e6e movaps   xmmword ptr [esp + 0xc0], xmm2
433f7e76 movss    dword ptr [esp + 0x114], xmm2
433f7e7f test     ah, 0x44
433f7e82 jnp      0x433f7e89
433f7e84 xorps    xmm3, xmm3
433f7e87 jmp      0x433f7eda
433f7e89 movss    xmm1, dword ptr [0x43470340]
433f7e91 movaps   xmm0, xmm3
433f7e94 andps    xmm0, xmm1
433f7e97 comiss   xmm0, dword ptr [0x434725e4]
433f7e9e jbe      0x433f7ee0
433f7ea0 movaps   xmm0, xmm3
433f7ea3 divss    xmm0, xmm4
433f7ea7 andps    xmm0, xmm1
433f7eaa call     0x4341ad12
433f7eaf movss    xmm3, dword ptr [esp + 0x2c]
433f7eb5 movaps   xmm1, xmm0
433f7eb8 mulss    xmm1, dword ptr [0x43471f88]
433f7ec0 xorps    xmm0, xmm0
433f7ec3 comiss   xmm0, xmm3
433f7ec6 movaps   xmm2, xmmword ptr [esp + 0xc0]
433f7ece jbe      0x433f7ed6
433f7ed0 addss    xmm3, xmm1
433f7ed4 jmp      0x433f7eda
433f7ed6 subss    xmm3, xmm1
433f7eda movss    dword ptr [esp + 0x2c], xmm3
433f7ee0 movaps   xmm0, xmm3
433f7ee3 subss    xmm0, xmm2
433f7ee7 cvtps2pd xmm0, xmm0
433f7eea movsd    qword ptr [esp + 0x118], xmm0
433f7ef3 fld      qword ptr [esp + 0x118]
433f7efa fld      qword ptr [0x4346f598]
433f7f00 call     0x7750834a
433f7f05 movss    xmm3, dword ptr [esp + 0x2c]
433f7f0b comiss   xmm3, dword ptr [esp + 0xc0]
433f7f13 fstp     dword ptr [esp + 0x34]
433f7f17 movss    xmm4, dword ptr [esp + 0x34]
433f7f1d jbe      0x433f7f32
433f7f1f comiss   xmm4, dword ptr [0x434725e4]
433f7f26 jb       0x433f7f47
433f7f28 subss    xmm4, dword ptr [0x43471f88]
433f7f30 jmp      0x433f7f47
433f7f32 movss    xmm0, dword ptr [0x434724b4]
433f7f3a comiss   xmm0, xmm4
433f7f3d jb       0x433f7f47
433f7f3f addss    xmm4, dword ptr [0x43471f88]
433f7f47 movss    xmm5, dword ptr [esp + 0x84]
433f7f50 xorps    xmm2, xmm2
433f7f53 movss    xmm6, dword ptr [0x43470514]
433f7f5b movaps   xmm1, xmm5
433f7f5e movss    xmm5, dword ptr [esp + 0x30]
433f7f64 movaps   xmm7, xmm2
433f7f67 movss    xmm3, dword ptr [0x43472c90]
433f7f6f maxss    xmm1, xmm7
433f7f73 movaps   xmm0, xmm6
433f7f76 movups   xmmword ptr [esp + 0x230], xmm0
433f7f7e minss    xmm1, xmm0
433f7f82 movaps   xmm0, xmm5
433f7f85 mulss    xmm0, dword ptr [0x4346ed98]
433f7f8d subss    xmm3, xmm0
433f7f91 movss    dword ptr [esp + 0x118], xmm1
433f7f9a movaps   xmm0, xmm3
433f7f9d movss    xmm3, dword ptr [esp + 0x2c]
433f7fa3 subss    xmm0, xmm6
433f7fa7 mulss    xmm0, xmm1
433f7fab movups   xmm1, xmmword ptr [esp + 0x170]
433f7fb3 addss    xmm0, xmm6
433f7fb7 comiss   xmm1, xmm2
433f7fba movss    dword ptr [esp + 0x28], xmm0
433f7fc0 jbe      0x433f8000
433f7fc2 movss    xmm6, dword ptr [esp + 0x14]
433f7fc8 movaps   xmm0, xmm6
433f7fcb movss    xmm6, dword ptr [0x43472240]
433f7fd3 subss    xmm6, dword ptr [esp + 0x28]
433f7fd9 maxss    xmm0, xmm7
433f7fdd minss    xmm0, dword ptr [esp + 0x230]
433f7fe6 movss    dword ptr [esp + 0x68], xmm0
433f7fec mulss    xmm0, xmm1
433f7ff0 mulss    xmm0, xmm6
433f7ff4 addss    xmm0, dword ptr [esp + 0x28]
433f7ffa movss    dword ptr [esp + 0x28], xmm0
433f8000 movss    xmm1, dword ptr [esi + 0x338]
433f8008 movss    xmm6, dword ptr [0x43470340]
433f8010 mulss    xmm1, xmm0
433f8014 comiss   xmm4, xmm1
433f8017 jbe      0x433f8030
433f8019 andps    xmm1, xmm6
433f801c movaps   xmm0, xmm3
433f801f subss    xmm0, xmm1
433f8023 movaps   xmm1, xmm0
433f8026 movaps   xmmword ptr [esp + 0xc0], xmm1
433f802e jmp      0x433f8054
433f8030 movss    xmm0, dword ptr [esi + 0x334]
433f8038 mulss    xmm0, dword ptr [esp + 0x28]
433f803e comiss   xmm0, xmm4
433f8041 jbe      0x433f804c
433f8043 andps    xmm0, xmm6
433f8046 addss    xmm0, xmm3
433f804a jmp      0x433f8023
433f804c movaps   xmm1, xmmword ptr [esp + 0xc0]
433f8054 ucomiss  xmm1, xmm1
433f8057 lahf     
433f8058 test     ah, 0x44
433f805b jnp      0x433f8062
433f805d xorps    xmm1, xmm1
433f8060 jmp      0x433f80ba
433f8062 movaps   xmm0, xmm1
433f8065 andps    xmm0, xmm6
433f8068 comiss   xmm0, dword ptr [0x434725e4]
433f806f jbe      0x433f80ba
433f8071 movaps   xmm0, xmm1
433f8074 divss    xmm0, dword ptr [0x43471f88]
433f807c andps    xmm0, xmm6
433f807f call     0x4341ad12
433f8084 movaps   xmm1, xmmword ptr [esp + 0xc0]
433f808c xorps    xmm2, xmm2
433f808f comiss   xmm2, xmm1
433f8092 mulss    xmm0, dword ptr [0x43471f88]
433f809a movss    xmm3, dword ptr [esp + 0x2c]
433f80a0 movss    xmm5, dword ptr [esp + 0x30]
433f80a6 movss    xmm6, dword ptr [0x43470340]
433f80ae jbe      0x433f80b6
433f80b0 addss    xmm1, xmm0
433f80b4 jmp      0x433f80ba
433f80b6 subss    xmm1, xmm0
433f80ba movss    xmm0, dword ptr [esp + 0x1c]
433f80c0 comiss   xmm0, dword ptr [0x43472980]
433f80c7 ja       0x433f81ff
433f80cd movss    xmm0, dword ptr [esp + 0xd8]
433f80d6 movss    xmm7, dword ptr [0x434704a0]
433f80de andps    xmm0, xmm6
433f80e1 comiss   xmm0, xmm7
433f80e4 ja       0x433f81ff
433f80ea movss    xmm4, dword ptr [esp + 0x24]
433f80f0 movss    xmm0, dword ptr [0x43476b40]
433f80f8 mulss    xmm4, xmm7
433f80fc comiss   xmm2, xmm4
433f80ff movss    dword ptr [esp + 0x1c], xmm4
433f8105 jbe      0x433f8114
433f8107 xorps    xmm4, xmmword ptr [0x434703d0]
433f810e movss    dword ptr [esp + 0x1c], xmm4
433f8114 movss    xmm3, dword ptr [0x4346dba4]
433f811c mulss    xmm0, xmm3
433f8120 mulss    xmm1, xmm3
433f8124 cvttss2si eax, xmm0
433f8128 movzx    eax, ax
433f812b movd     xmm5, eax
433f812f cvttss2si eax, xmm1
433f8133 cvtdq2ps xmm5, xmm5
433f8136 movzx    eax, ax
433f8139 movd     xmm1, eax
433f813d mulss    xmm5, dword ptr [0x434721a0]
433f8145 cvtdq2ps xmm1, xmm1
433f8148 movaps   xmm3, xmm5
433f814b movss    dword ptr [esp + 0x34], xmm5
433f8151 mulss    xmm1, dword ptr [0x434721a0]
433f8159 subss    xmm3, xmm1
433f815d movss    dword ptr [esp + 0x10], xmm1
433f8163 ucomiss  xmm3, xmm3
433f8166 movss    dword ptr [esp + 0x40], xmm3
433f816c lahf     
433f816d test     ah, 0x44
433f8170 jnp      0x433f8177
433f8172 xorps    xmm3, xmm3
433f8175 jmp      0x433f81ce
433f8177 movaps   xmm0, xmm3
433f817a andps    xmm0, xmm6
433f817d comiss   xmm0, dword ptr [0x434725e4]
433f8184 jbe      0x433f81ce
433f8186 movaps   xmm0, xmm3
433f8189 divss    xmm0, dword ptr [0x43471f88]
433f8191 andps    xmm0, xmm6
433f8194 call     0x4341ad12
433f8199 movss    xmm3, dword ptr [esp + 0x40]
433f819f movaps   xmm1, xmm0
433f81a2 mulss    xmm1, dword ptr [0x43471f88]
433f81aa xorps    xmm0, xmm0
433f81ad comiss   xmm0, xmm3
433f81b0 movss    xmm4, dword ptr [esp + 0x1c]
433f81b6 movss    xmm5, dword ptr [esp + 0x34]
433f81bc jbe      0x433f81c4
433f81be addss    xmm3, xmm1
433f81c2 jmp      0x433f81c8
433f81c4 subss    xmm3, xmm1
433f81c8 movss    xmm1, dword ptr [esp + 0x10]
433f81ce comiss   xmm3, xmm4
433f81d1 jbe      0x433f81dc
433f81d3 addss    xmm1, xmm4
433f81d7 jmp      0x433f8305
433f81dc movaps   xmm0, xmm4
433f81df xorps    xmm0, xmmword ptr [0x434703d0]
433f81e6 comiss   xmm0, xmm3
433f81e9 jbe      0x433f81f4
433f81eb subss    xmm1, xmm4
433f81ef jmp      0x433f8305
433f81f4 movss    dword ptr [esp + 0x10], xmm5
433f81fa jmp      0x433f8313
433f81ff mulss    xmm5, dword ptr [0x4346eeb0]
433f8207 addss    xmm5, dword ptr [0x4346ee8c]
433f820f mulss    xmm5, dword ptr [esp + 0x24]
433f8215 comiss   xmm2, xmm5
433f8218 movss    dword ptr [esp + 0x30], xmm5
433f821e jbe      0x433f822d
433f8220 xorps    xmm5, xmmword ptr [0x434703d0]
433f8227 movss    dword ptr [esp + 0x30], xmm5
433f822d mulss    xmm3, dword ptr [0x4346dba4]
433f8235 mulss    xmm1, dword ptr [0x4346dba4]
433f823d cvttss2si eax, xmm3
433f8241 movss    xmm3, dword ptr [0x434721a0]
433f8249 movzx    eax, ax
433f824c movd     xmm4, eax
433f8250 cvttss2si eax, xmm1
433f8254 cvtdq2ps xmm4, xmm4
433f8257 movzx    eax, ax
433f825a movd     xmm1, eax
433f825e cvtdq2ps xmm1, xmm1
433f8261 mulss    xmm4, xmm3
433f8265 mulss    xmm1, xmm3
433f8269 movaps   xmm3, xmm4
433f826c movss    dword ptr [esp + 0x34], xmm4
433f8272 subss    xmm3, xmm1
433f8276 movss    dword ptr [esp + 0x10], xmm1
433f827c ucomiss  xmm3, xmm3
433f827f movss    dword ptr [esp + 0x40], xmm3
433f8285 lahf     
433f8286 test     ah, 0x44
433f8289 jnp      0x433f8290
433f828b xorps    xmm3, xmm3
433f828e jmp      0x433f82e7
433f8290 movaps   xmm0, xmm3
433f8293 andps    xmm0, xmm6
433f8296 comiss   xmm0, dword ptr [0x434725e4]
433f829d jbe      0x433f82e7
433f829f movaps   xmm0, xmm3
433f82a2 divss    xmm0, dword ptr [0x43471f88]
433f82aa andps    xmm0, xmm6
433f82ad call     0x4341ad12
433f82b2 movss    xmm3, dword ptr [esp + 0x40]
433f82b8 movaps   xmm1, xmm0
433f82bb mulss    xmm1, dword ptr [0x43471f88]
433f82c3 xorps    xmm0, xmm0
433f82c6 comiss   xmm0, xmm3
433f82c9 movss    xmm5, dword ptr [esp + 0x30]
433f82cf movss    xmm4, dword ptr [esp + 0x34]
433f82d5 jbe      0x433f82dd
433f82d7 addss    xmm3, xmm1
433f82db jmp      0x433f82e1
433f82dd subss    xmm3, xmm1
433f82e1 movss    xmm1, dword ptr [esp + 0x10]
433f82e7 comiss   xmm3, xmm5
433f82ea jbe      0x433f82f2
433f82ec addss    xmm1, xmm5
433f82f0 jmp      0x433f8305
433f82f2 movaps   xmm0, xmm5
433f82f5 xorps    xmm0, xmmword ptr [0x434703d0]
433f82fc comiss   xmm0, xmm3
433f82ff jbe      0x433f830d
433f8301 subss    xmm1, xmm5
433f8305 movss    dword ptr [esp + 0x10], xmm1
433f830b jmp      0x433f8313
433f830d movss    dword ptr [esp + 0x10], xmm4
433f8313 movss    xmm0, dword ptr [esp + 0x18]
433f8319 subss    xmm0, dword ptr [esp + 0x10]
433f831f cvtps2pd xmm0, xmm0
433f8322 movsd    qword ptr [esp + 0x40], xmm0
433f8328 fld      qword ptr [esp + 0x40]
433f832c fld      qword ptr [0x4346f598]
433f8332 call     0x7750834a
433f8337 movss    xmm0, dword ptr [esp + 0x18]
433f833d comiss   xmm0, dword ptr [esp + 0x10]
433f8342 fstp     dword ptr [esp + 0x34]
433f8346 movss    xmm0, dword ptr [esp + 0x34]
433f834c jbe      0x433f8361
433f834e comiss   xmm0, dword ptr [0x434725e4]
433f8355 jb       0x433f8376
433f8357 subss    xmm0, dword ptr [0x43471f88]
433f835f jmp      0x433f8376
433f8361 movss    xmm1, dword ptr [0x434724b4]
433f8369 comiss   xmm1, xmm0
433f836c jb       0x433f8376
433f836e addss    xmm0, dword ptr [0x43471f88]
433f8376 andps    xmm0, xmmword ptr [0x43470340]
433f837d divss    xmm0, dword ptr [esp + 0x24]
433f8383 comiss   xmm0, dword ptr [0x4346f190]
433f838a jbe      0x433f8410
433f8390 mov      eax, dword ptr [ebp + 0xc]
433f8393 mov      edx, 0x3d3
433f8398 mov      ecx, edi
433f839a push     dword ptr [eax + 0x40]
433f839d call     0x43387742
433f83a2 mov      ecx, eax
433f83a4 mov      dword ptr [esp + 0x3c], ecx
433f83a8 cmp      ecx, 1
433f83ab jle      0x433f8410
433f83ad mov      eax, dword ptr [esp + 0xc]
433f83b1 push     dword ptr [esp + 0x3c]
433f83b5 push     dword ptr [esp + 0xa0]
433f83bc mov      dword ptr [eax + 0xc0], ecx
433f83c2 mov      dword ptr [esp + 0x48], 0xb19efc7e
433f83ca mov      edx, dword ptr [esp + 0x48]
433f83ce mov      ecx, dword ptr [edi]
433f83d0 xor      edx, 0x4765d17e
433f83d6 ror      edx, 0x19
433f83d9 xor      edx, 0x7d968300
433f83df mov      ecx, dword ptr [edx + ecx + 1]
433f83e3 mov      edx, edi
433f83e5 mov      dword ptr [esp + 0x214], ecx
433f83ec call     0x433e533f
433f83f1 mov      eax, dword ptr [esp + 0xc]
433f83f5 and      dword ptr [eax + 0xd4], 0
433f83fc and      dword ptr [eax + 0xc8], 0
433f8403 fstp     dword ptr [eax + 0xd0]
433f8409 mov      byte ptr [esi + 0x138], 1
433f8410 mov      ecx, dword ptr [esp + 0x20]
433f8414 push     esi
433f8415 push     edi
433f8416 call     0x433ebf17
433f841b mov      eax, dword ptr [0x43467eb8]
433f8420 xorps    xmm0, xmm0
433f8423 movss    xmm1, dword ptr [eax]
433f8427 subss    xmm1, dword ptr [esi + 0x6c]
433f842c call     0x4332fc35
433f8431 mov      eax, dword ptr [esp + 0x54]
433f8435 mov      edx, dword ptr [eax]
433f8437 mov      eax, dword ptr [0x43468fd0]
433f843c mov      dword ptr [esp + 0x28], edx
433f8440 mov      eax, dword ptr [eax]
433f8442 xor      eax, dword ptr [0x43467c70]
433f8448 xor      eax, 0xf58e6118
433f844d mov      ecx, dword ptr [eax + edi]
433f8450 test     ecx, ecx
433f8452 je       0x433f84f8
433f8458 mov      ecx, dword ptr [ecx + 4]
433f845b xor      edx, edx
433f845d mov      eax, ecx
433f845f div      dword ptr [esp + 0x50]
433f8463 mov      eax, dword ptr [esp + 0x20]
433f8467 cmp      dword ptr [eax + edx*4 + 0x404], ecx
433f846e mov      edx, dword ptr [esp + 0x28]
433f8472 jne      0x433f84f8
433f8478 mov      eax, dword ptr [0x4346a364]
433f847d mov      ecx, dword ptr [edx + 0x248]
433f8483 test     eax, eax
433f8485 je       0x433f84f8
433f8487 push     ecx
433f8488 mov      ecx, edi
433f848a call     eax
433f848c mov      edx, dword ptr [esp + 0x28]
433f8490 mov      ecx, dword ptr [edx + 0x248]
433f8496 mov      dword ptr [esp + 0x3c], ecx
433f849a cmp      eax, 0x3d7
433f849f je       0x433f84a8
433f84a1 cmp      eax, 0x3d6
433f84a6 jne      0x433f84f8
433f84a8 and      dword ptr [edx + 0x25c], 0
433f84af and      dword ptr [edx + 0x250], 0
433f84b6 push     dword ptr [esp + 0x3c]
433f84ba mov      dword ptr [esp + 0x44], 0xb19efc7e
433f84c2 mov      eax, dword ptr [esp + 0x44]
433f84c6 mov      ecx, dword ptr [edi]
433f84c8 xor      eax, 0x4765d17e
433f84cd ror      eax, 0x19
433f84d0 xor      eax, 0x7d968300
433f84d5 mov      ecx, dword ptr [eax + ecx + 1]
433f84d9 lea      eax, [edx + 0x230]
433f84df push     eax
433f84e0 mov      edx, edi
433f84e2 mov      dword ptr [esp + 0x218], ecx
433f84e9 call     0x433e533f
433f84ee mov      edx, dword ptr [esp + 0x28]
433f84f2 fstp     dword ptr [edx + 0x258]
433f84f8 xor      ecx, ecx
433f84fa cmp      dword ptr [edx + 0x248], ecx
433f8500 jle      0x433f8549
433f8502 mov      eax, dword ptr [0x4346a598]
433f8507 test     eax, eax
433f8509 je       0x433f854f
433f850b push     0xa
433f850d xor      edx, edx
433f850f mov      ecx, esi
433f8511 call     eax
433f8513 mov      eax, dword ptr [esp + 0x28]
433f8517 xorps    xmm1, xmm1
433f851a movss    xmm1, xmm0
433f851e xorps    xmm2, xmm2
433f8521 movaps   xmm0, xmm2
433f8524 xor      ecx, ecx
433f8526 maxss    xmm1, xmm0
433f852a movss    xmm0, dword ptr [0x43470514]
433f8532 minss    xmm1, xmm0
433f8536 movss    dword ptr [esp + 0x88], xmm1
433f853f movss    dword ptr [eax + 0x250], xmm1
433f8547 jmp      0x433f854f
433f8549 and      dword ptr [edx + 0x250], ecx
433f854f cmp      dword ptr [esp + 0x58], 2
433f8554 mov      dword ptr [esp + 0x2c], ecx
433f8558 mov      dword ptr [esp + 0xc], ecx
433f855c mov      dword ptr [esp + 0x60], ecx
433f8560 mov      dword ptr [esp + 0x18], ecx
433f8564 mov      dword ptr [esp + 0x14], ecx
433f8568 mov      dword ptr [esp + 0x34], ecx
433f856c jle      0x433f8613
433f8572 cmp      dword ptr [esp + 0x58], 3
433f8577 mov      eax, dword ptr [esp + 0x54]
433f857b mov      eax, dword ptr [eax]
433f857d lea      ecx, [eax + 0x90]
433f8583 movss    xmm5, dword ptr [ecx]
433f8587 lea      edx, [eax + 0x58]
433f858a movss    xmm3, dword ptr [edx]
433f858e mov      dword ptr [esp + 0x2c], ecx
433f8592 lea      ecx, [eax + 0x9c]
433f8598 movss    xmm4, dword ptr [ecx]
433f859c mov      dword ptr [esp + 0xc], ecx
433f85a0 lea      ecx, [eax + 0x64]
433f85a3 movss    xmm2, dword ptr [ecx]
433f85a7 movss    dword ptr [esp + 0x24], xmm5
433f85ad movss    dword ptr [esp + 0x30], xmm4
433f85b3 mov      dword ptr [esp + 0x60], edx
433f85b7 movss    dword ptr [esp + 0x28], xmm3
433f85bd mov      dword ptr [esp + 0x18], ecx
433f85c1 movss    dword ptr [esp + 0x38], xmm2
433f85c7 jle      0x433f85f9
433f85c9 mov      eax, dword ptr [esp + 0x54]
433f85cd mov      eax, dword ptr [eax]
433f85cf lea      edx, [eax + 0xc8]
433f85d5 movss    xmm2, dword ptr [edx]
433f85d9 lea      ecx, [eax + 0xd4]
433f85df movss    xmm1, dword ptr [ecx]
433f85e3 mov      dword ptr [esp + 0x14], edx
433f85e7 movss    dword ptr [esp + 0x50], xmm2
433f85ed mov      dword ptr [esp + 0x34], ecx
433f85f1 movss    dword ptr [esp + 0x1c], xmm1
433f85f7 jmp      0x433f8667
433f85f9 movss    xmm1, dword ptr [esp + 0x68]
433f85ff movss    dword ptr [esp + 0x1c], xmm1
433f8605 movss    xmm1, dword ptr [esp + 0x68]
433f860b movss    dword ptr [esp + 0x50], xmm1
433f8611 jmp      0x433f8667
433f8613 movss    xmm0, dword ptr [esp + 0x68]
433f8619 movss    dword ptr [esp + 0x1c], xmm0
433f861f movss    xmm0, dword ptr [esp + 0x68]
433f8625 movss    dword ptr [esp + 0x50], xmm0
433f862b movss    xmm0, dword ptr [esp + 0x88]
433f8634 movss    dword ptr [esp + 0x38], xmm0
433f863a movss    xmm0, dword ptr [esp + 0x88]
433f8643 movss    dword ptr [esp + 0x28], xmm0
433f8649 movss    xmm0, dword ptr [esp + 0x88]
433f8652 movss    dword ptr [esp + 0x30], xmm0
433f8658 movss    xmm0, dword ptr [esp + 0x88]
433f8661 movss    dword ptr [esp + 0x24], xmm0
433f8667 mov      eax, dword ptr [0x43468fec]
433f866c movss    xmm0, dword ptr [0x43476b40]
433f8674 mov      eax, dword ptr [eax]
433f8676 xor      eax, dword ptr [0x4346a3c4]
433f867c xor      eax, 0xa2a8247f
433f8681 add      eax, edi
433f8683 mov      dword ptr [esp + 0x84], eax
433f868a movss    xmm1, dword ptr [eax]
433f868e movss    dword ptr [eax], xmm0
433f8692 mov      eax, dword ptr [0x43468fd0]
433f8697 movss    dword ptr [esp + 0x64], xmm1
433f869d mov      eax, dword ptr [eax]
433f869f xor      eax, dword ptr [0x43467c70]
433f86a5 xor      eax, 0xf58e6118
433f86aa add      eax, edi
433f86ac mov      dword ptr [esp + 0x40], eax
433f86b0 mov      ecx, dword ptr [eax]
433f86b2 mov      dword ptr [esp + 0x3c], ecx
433f86b6 mov      ecx, dword ptr [ebp + 0xc]
433f86b9 mov      dword ptr [eax], ecx
433f86bb mov      eax, dword ptr [0x43467f4c]
433f86c0 mov      eax, dword ptr [eax]
433f86c2 xor      eax, dword ptr [0x4346a8b0]
433f86c8 xor      eax, 0x3d52a1a7
433f86cd mov      ecx, dword ptr [eax + edi]
433f86d0 test     ecx, ecx
433f86d2 je       0x433f86f9
433f86d4 mov      eax, dword ptr [0x43467eb8]
433f86d9 movss    xmm0, dword ptr [ecx + 0x6c]
433f86de movss    xmm1, dword ptr [eax]
433f86e2 ucomiss  xmm0, xmm1
433f86e5 lahf     
433f86e6 test     ah, 0x44
433f86e9 jp       0x433f86f9
433f86eb mov      eax, dword ptr [0x4346a338]
433f86f0 subss    xmm1, dword ptr [eax]
433f86f4 movss    dword ptr [ecx + 0x6c], xmm1
433f86f9 mov      eax, dword ptr [edi]
433f86fb mov      byte ptr [0x43475bd3], 1
433f8702 mov      ecx, dword ptr [eax - 8]
433f8705 mov      dword ptr [esp + 0x68], 0x89020664
433f870d mov      edx, dword ptr [esp + 0x68]
433f8711 mov      eax, dword ptr [ecx + 8]
433f8714 mov      ecx, edi
433f8716 lea      edx, [edx + 0x76fdf9a3]
433f871c ror      edx, 0x12
433f871f ror      edx, 7
433f8722 call     dword ptr [edx + eax]
433f8725 mov      eax, dword ptr [0x43467b24]
433f872a mov      byte ptr [0x43475bd3], 0
433f8731 test     eax, eax
433f8733 je       0x433f8738
433f8735 mov      byte ptr [eax], 0
433f8738 mov      eax, dword ptr [esp + 0x40]
433f873c mov      ecx, dword ptr [esp + 0x3c]
433f8740 movss    xmm0, dword ptr [esp + 0x64]
433f8746 mov      dword ptr [eax], ecx
433f8748 mov      eax, dword ptr [esp + 0x84]
433f874f movss    dword ptr [eax], xmm0
433f8753 mov      eax, dword ptr [esp + 0x34]
433f8757 test     eax, eax
433f8759 je       0x433f8765
433f875b movss    xmm0, dword ptr [esp + 0x1c]
433f8761 movss    dword ptr [eax], xmm0
433f8765 mov      eax, dword ptr [esp + 0x14]
433f8769 test     eax, eax
433f876b je       0x433f8777
433f876d movss    xmm0, dword ptr [esp + 0x50]
433f8773 movss    dword ptr [eax], xmm0
433f8777 mov      eax, dword ptr [esp + 0x18]
433f877b test     eax, eax
433f877d je       0x433f8789
433f877f movss    xmm0, dword ptr [esp + 0x38]
433f8785 movss    dword ptr [eax], xmm0
433f8789 mov      eax, dword ptr [esp + 0x60]
433f878d test     eax, eax
433f878f je       0x433f879b
433f8791 movss    xmm0, dword ptr [esp + 0x28]
433f8797 movss    dword ptr [eax], xmm0
433f879b mov      eax, dword ptr [esp + 0xc]
433f879f test     eax, eax
433f87a1 je       0x433f87ad
433f87a3 movss    xmm0, dword ptr [esp + 0x30]
433f87a9 movss    dword ptr [eax], xmm0
433f87ad mov      eax, dword ptr [esp + 0x2c]
433f87b1 test     eax, eax
433f87b3 je       0x433f87bf
433f87b5 movss    xmm0, dword ptr [esp + 0x24]
433f87bb movss    dword ptr [eax], xmm0
433f87bf mov      eax, dword ptr [esp + 0x58]
433f87c3 cmp      eax, 2
433f87c6 jle      0x433f89f9
433f87cc mov      eax, dword ptr [0x43467eb8]
433f87d1 movss    xmm0, dword ptr [esi + 0xa4]
433f87d9 movss    dword ptr [esp + 0x80], xmm0
433f87e2 movss    xmm0, dword ptr [eax]
433f87e6 mov      eax, dword ptr [esp + 0x54]
433f87ea subss    xmm0, dword ptr [esi + 0x6c]
433f87ef mov      ecx, dword ptr [eax]
433f87f1 mov      dword ptr [esp + 0x50], ecx
433f87f5 movss    dword ptr [esp + 0x14], xmm0
433f87fb mov      edx, dword ptr [ecx + 0x50]
433f87fe test     edx, edx
433f8800 jg       0x433f8806
433f8802 and      dword ptr [ecx + 0x58], 0
433f8806 cmp      dword ptr [ecx + 0x88], 0
433f880d jg       0x433f8816
433f880f and      dword ptr [ecx + 0x90], 0
433f8816 movss    xmm1, dword ptr [ecx + 0x58]
433f881b xorps    xmm2, xmm2
433f881e comiss   xmm2, xmm1
433f8821 movss    dword ptr [esp + 0x34], xmm1
433f8827 jb       0x433f8879
433f8829 movss    xmm1, dword ptr [ecx + 0x90]
433f8831 comiss   xmm2, xmm1
433f8834 jae      0x433f88f9
433f883a xorps    xmm4, xmm4
433f883d movaps   xmm3, xmm0
433f8840 mulss    xmm3, dword ptr [0x4346dd40]
433f8848 subss    xmm4, xmm1
433f884c comiss   xmm4, xmm3
433f884f jbe      0x433f885a
433f8851 addss    xmm3, xmm1
433f8855 jmp      0x433f88fc
433f885a movaps   xmm0, xmm3
433f885d xorps    xmm0, xmmword ptr [0x434703d0]
433f8864 comiss   xmm0, xmm4
433f8867 jbe      0x433f88f9
433f886d subss    xmm1, xmm3
433f8871 movaps   xmm3, xmm1
433f8874 jmp      0x433f88fc
433f8879 mov      eax, dword ptr [0x434678c8]
433f887e test     eax, eax
433f8880 je       0x433f8892
433f8882 push     edx
433f8883 mov      ecx, edi
433f8885 call     eax
433f8887 mov      dword ptr [esp + 0xe8], eax
433f888e test     eax, eax
433f8890 je       0x433f88d4
433f8892 mov      eax, dword ptr [esp + 0x20]
433f8896 push     dword ptr [eax + 0x7c]
433f8899 push     dword ptr [esp + 0xec]
433f88a0 call     0x774fe670
433f88a5 nop      
433f88a6 pop      ecx
433f88a7 pop      ecx
433f88a8 test     eax, eax
433f88aa je       0x433f88d4
433f88ac movss    xmm0, dword ptr [0x43470514]
433f88b4 xorps    xmm2, xmm2
433f88b7 movss    xmm1, dword ptr [esp + 0x80]
433f88c0 comiss   xmm1, xmm0
433f88c3 jae      0x433f88f5
433f88c5 movaps   xmm3, xmm0
433f88c8 subss    xmm3, xmm1
433f88cc mulss    xmm3, dword ptr [esp + 0x34]
433f88d2 jmp      0x433f88ef
433f88d4 movss    xmm0, dword ptr [esp + 0x80]
433f88dd xorps    xmm2, xmm2
433f88e0 comiss   xmm0, xmm2
433f88e3 jbe      0x433f88f5
433f88e5 movss    xmm3, dword ptr [esp + 0x34]
433f88eb mulss    xmm3, xmm0
433f88ef mov      ecx, dword ptr [esp + 0x50]
433f88f3 jmp      0x433f88fc
433f88f5 mov      ecx, dword ptr [esp + 0x50]
433f88f9 xorps    xmm3, xmm3
433f88fc movss    xmm4, dword ptr [0x43470514]
433f8904 movaps   xmm1, xmm3
433f8907 movss    xmm3, dword ptr [esp + 0x14]
433f890d movaps   xmm0, xmm2
433f8910 comiss   xmm2, xmm3
433f8913 maxss    xmm1, xmm0
433f8917 movaps   xmm0, xmm4
433f891a minss    xmm1, xmm0
433f891e movss    dword ptr [ecx + 0x90], xmm1
433f8926 jae      0x433f89d4
433f892c movss    xmm1, dword ptr [ecx + 0x60]
433f8931 movaps   xmm0, xmm1
433f8934 andps    xmm0, xmmword ptr [0x43470340]
433f893b comiss   xmm2, xmm0
433f893e jae      0x433f897e
433f8940 mulss    xmm1, xmm3
433f8944 addss    xmm1, dword ptr [ecx + 0x64]
433f8949 comiss   xmm1, xmm4
433f894c jb       0x433f8956
433f894e movss    xmm1, dword ptr [0x4346f660]
433f8956 cvttss2si eax, xmm1
433f895a movd     xmm0, eax
433f895e cvtdq2ps xmm0, xmm0
433f8961 subss    xmm1, xmm0
433f8965 comiss   xmm1, xmm2
433f8968 jb       0x433f8975
433f896a comiss   xmm1, xmm4
433f896d jbe      0x433f8979
433f896f subss    xmm1, xmm4
433f8973 jmp      0x433f8979
433f8975 addss    xmm1, xmm4
433f8979 movss    dword ptr [ecx + 0x64], xmm1
433f897e mov      eax, dword ptr [0x4346a598]
433f8983 test     eax, eax
433f8985 je       0x433f89d4
433f8987 movss    xmm0, dword ptr [ecx + 0x58]
433f898c xor      edx, edx
433f898e push     1
433f8990 mov      ecx, esi
433f8992 movss    dword ptr [esp + 0x6c], xmm0
433f8998 call     eax
433f899a movss    xmm4, dword ptr [0x43470514]
433f89a2 xorps    xmm1, xmm1
433f89a5 mov      eax, dword ptr [esp + 0x50]
433f89a9 movss    xmm1, xmm0
433f89ad xorps    xmm2, xmm2
433f89b0 movaps   xmm0, xmm2
433f89b3 maxss    xmm1, xmm0
433f89b7 movaps   xmm0, xmm4
433f89ba minss    xmm1, xmm0
433f89be movss    dword ptr [eax + 0x58], xmm1
433f89c3 subss    xmm1, dword ptr [esp + 0x68]
433f89c9 divss    xmm1, dword ptr [esp + 0x14]
433f89cf movss    dword ptr [eax + 0x5c], xmm1
433f89d4 mov      eax, dword ptr [esp + 0x58]
433f89d8 cmp      eax, 0xb
433f89db jle      0x433f8a64
433f89e1 mov      eax, dword ptr [esp + 0x54]
433f89e5 mov      eax, dword ptr [eax]
433f89e7 cmp      dword ptr [eax + 0x280], 0
433f89ee jg       0x433f8a06
433f89f0 and      dword ptr [eax + 0x288], 0
433f89f7 jmp      0x433f8a64
433f89f9 movss    xmm4, dword ptr [0x43470514]
433f8a01 xorps    xmm2, xmm2
433f8a04 jmp      0x433f89d8
433f8a06 movss    xmm0, dword ptr [eax + 0x290]
433f8a0e mulss    xmm0, dword ptr [esi + 0x74]
433f8a13 addss    xmm0, dword ptr [eax + 0x294]
433f8a1b comiss   xmm0, dword ptr [0x4346f660]
433f8a22 jae      0x433f8a64
433f8a24 movss    xmm1, dword ptr [esi + 0xf4]
433f8a2c movaps   xmm3, xmm2
433f8a2f subss    xmm1, dword ptr [0x434728d0]
433f8a37 movaps   xmm2, xmm4
433f8a3a divss    xmm1, dword ptr [0x4346fd90]
433f8a42 movaps   xmm0, xmm1
433f8a45 maxss    xmm0, xmm3
433f8a49 minss    xmm0, xmm2
433f8a4d subss    xmm4, xmm0
433f8a51 movaps   xmm0, xmm4
433f8a54 maxss    xmm0, xmm3
433f8a58 minss    xmm0, xmm2
433f8a5c movss    dword ptr [eax + 0x288], xmm0
433f8a64 mov      ecx, dword ptr [0x4346a8e4]
433f8a6a mov      edx, 0x43476b40
433f8a6f mov      edi, dword ptr [esp + 0x4c]
433f8a73 mov      eax, dword ptr [0x43467eb8]
433f8a78 push     1
433f8a7a mov      esi, dword ptr [ecx]
433f8a7c mov      ecx, 0x43476b3c
433f8a81 xor      esi, dword ptr [0x434688cc]
433f8a87 movss    xmm4, dword ptr [edi + 0x80]
433f8a8f xor      esi, 0x36375c23
433f8a95 mov      edi, dword ptr [ebp + 8]
433f8a98 movss    xmm3, dword ptr [eax]
433f8a9c mov      eax, dword ptr [ebp + 0xc]
433f8a9f movss    xmm2, dword ptr [esi + edi + 8]
433f8aa5 mov      esi, dword ptr [esp + 0x50]
433f8aa9 movss    xmm0, dword ptr [eax + 0x10]
433f8aae movss    xmm1, dword ptr [esi + 0xec]
433f8ab6 call     0x4340bd50
433f8abb movss    xmm0, dword ptr [esp + 0x98]
433f8ac4 push     ecx
433f8ac5 mov      ecx, dword ptr [esp + 0x24]
433f8ac9 movss    dword ptr [esp], xmm0
433f8ace push     dword ptr [esp + 0xc0]
433f8ad5 push     esi
433f8ad6 push     edi
433f8ad7 call     0x43381e04
433f8adc mov      eax, dword ptr [0x434688b4]
433f8ae1 movss    xmm0, dword ptr [esp + 0x128]
433f8aea mov      ecx, dword ptr [esp + 0x134]
433f8af1 mov      eax, dword ptr [eax]
433f8af3 xor      eax, dword ptr [0x4346a7d0]
433f8af9 xor      eax, 0x471e13c
433f8afe and      dword ptr [eax + edi], 0
433f8b02 mov      eax, dword ptr [esp + 0x12c]
433f8b09 movss    dword ptr [eax], xmm0
433f8b0d mov      eax, dword ptr [esp + 0x130]
433f8b14 movss    xmm0, dword ptr [esp + 0x7c]
433f8b1a mov      dword ptr [eax], ecx
433f8b1c mov      eax, dword ptr [esp + 0x138]
433f8b23 movss    dword ptr [eax], xmm0
433f8b27 mov      eax, dword ptr [0x434679cc]
433f8b2c mov      ecx, dword ptr [esp + 0x8c]
433f8b33 mov      eax, dword ptr [eax]
433f8b35 xor      eax, dword ptr [0x43467164]
433f8b3b xor      eax, 0xa5bd68
433f8b40 mov      al, byte ptr [eax + edi]
433f8b43 mov      byte ptr [ecx + 4], al
433f8b46 test     esi, esi
433f8b48 je       0x433f8b5f
433f8b4a mov      eax, dword ptr [esi + 0xec]
433f8b50 mov      dword ptr [ecx + 8], eax
433f8b53 mov      eax, dword ptr [esi + 0x80]
433f8b59 mov      dword ptr [ecx + 0x1e4], eax
433f8b5f movss    xmm0, dword ptr [0x43476b3c]
433f8b67 movss    dword ptr [ecx + 0xc], xmm0
433f8b6c movss    xmm0, dword ptr [0x43476b40]
433f8b74 movss    dword ptr [ecx + 0x10], xmm0
433f8b79 add      ecx, 0x14
433f8b7c push     edi
433f8b7d call     0x4341d38e
433f8b82 mov      eax, dword ptr [ebp + 0x10]
433f8b85 cmp      byte ptr [eax], 0
433f8b88 je       0x433f8bc7
433f8b8a mov      eax, dword ptr [0x434688d4]
433f8b8f lea      ecx, [esp + 0x224]
433f8b96 mov      esi, dword ptr [eax]
433f8b98 xor      esi, dword ptr [0x43469030]
433f8b9e xor      esi, 0xf8205eba
433f8ba4 add      esi, edi
433f8ba6 lea      edi, [esp + 0x224]
433f8bad movsd    dword ptr es:[edi], dword ptr [esi]
433f8bae movsd    dword ptr es:[edi], dword ptr [esi]
433f8baf movsd    dword ptr es:[edi], dword ptr [esi]
433f8bb0 call     0x433e9160
433f8bb5 mov      edi, 0x4347bd30
433f8bba lea      esi, [esp + 0x224]
433f8bc1 movsd    dword ptr es:[edi], dword ptr [esi]
433f8bc2 movsd    dword ptr es:[edi], dword ptr [esi]
433f8bc3 movsd    dword ptr es:[edi], dword ptr [esi]
433f8bc4 mov      edi, dword ptr [ebp + 8]
433f8bc7 mov      eax, dword ptr [esp + 0x13c]
433f8bce mov      ecx, dword ptr [esp + 0x140]
433f8bd5 movss    xmm0, dword ptr [esp + 0x148]
433f8bde mov      dword ptr [eax], ecx
433f8be0 mov      eax, dword ptr [esp + 0x144]
433f8be7 mov      cl, byte ptr [esp + 0x72]
433f8beb mov      byte ptr [eax], cl
433f8bed mov      eax, dword ptr [esp + 0x94]
433f8bf4 movss    dword ptr [eax + edi], xmm0
433f8bf9 jmp      0x433f8c33
433f8bfb xor      edx, edx
433f8bfd lea      eax, [esi - 1]
433f8c00 mov      ecx, 0x96
433f8c05 div      ecx
433f8c07 mov      eax, dword ptr [esp + 0x20]
433f8c0b imul     ecx, edx, 0x53c
433f8c11 add      ecx, dword ptr [eax + 0x3c]
433f8c14 lea      eax, [esi - 1]
433f8c17 cmp      dword ptr [ecx], eax
433f8c19 jne      0x433f8c33
433f8c1b mov      edi, dword ptr [esp + 0x8c]
433f8c22 push     0x53c
433f8c27 push     ecx
433f8c28 push     edi
433f8c29 call     0x774fd4a0
433f8c2e add      esp, 0xc
433f8c31 mov      dword ptr [edi], esi
433f8c33 pop      edi
433f8c34 pop      esi
433f8c35 mov      esp, ebp
433f8c37 pop      ebp
433f8c38 ret      0x14
