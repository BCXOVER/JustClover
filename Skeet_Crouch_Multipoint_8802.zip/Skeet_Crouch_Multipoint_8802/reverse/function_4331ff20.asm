4331ff20 xor      eax, eax
4331ff22 cmp      byte ptr [0x434684e0], al
4331ff28 je       0x4331ff34
4331ff2a cmp      byte ptr [0x43468d7c], al
4331ff30 setne    al
4331ff33 inc      eax
4331ff34 ret      
