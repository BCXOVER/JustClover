433c8c4d push     ebp
433c8c4e mov      ebp, esp
433c8c50 push     ecx
433c8c51 push     ebx
433c8c52 push     esi
433c8c53 push     edi
433c8c54 mov      edi, ecx
433c8c56 mov      dword ptr [ebp - 4], 0x7d06ec89
433c8c5d mov      eax, dword ptr [ebp - 4]
433c8c60 mov      ebx, edx
433c8c62 dec      eax
433c8c63 mov      edx, edi
433c8c65 xor      eax, 0x7d06ebbc
433c8c6a mov      ecx, dword ptr [edi]
433c8c6c mov      ecx, dword ptr [eax + ecx]
433c8c6f mov      dword ptr [ebp - 4], ecx
433c8c72 call     0x433e533f
433c8c77 mov      ecx, dword ptr [0x4346908c]
433c8c7d mov      esi, eax
433c8c7f mov      edx, edi
433c8c81 mov      ecx, dword ptr [ecx]
433c8c83 xor      ecx, dword ptr [0x43468ba0]
433c8c89 xor      ecx, 0x5c9f0fbb
433c8c8f mov      cx, word ptr [ecx + edi]
433c8c93 mov      word ptr [ebx], cx
433c8c96 mov      ecx, dword ptr [esi + 0x100]
433c8c9c mov      dword ptr [ebx + 4], ecx
433c8c9f mov      ecx, dword ptr [esi + 0x10c]
433c8ca5 mov      dword ptr [ebx + 8], ecx
433c8ca8 mov      eax, dword ptr [esi + 0x110]
433c8cae mov      dword ptr [ebx + 0xc], eax
433c8cb1 mov      dword ptr [ebp - 4], 0xe3852763
433c8cb8 mov      eax, dword ptr [ebp - 4]
433c8cbb mov      ecx, dword ptr [edi]
433c8cbd add      eax, 0x1c7af3bd
433c8cc2 ror      eax, 2
433c8cc5 mov      ecx, dword ptr [eax + ecx]
433c8cc8 mov      dword ptr [ebp - 4], ecx
433c8ccb call     0x433e533f
433c8cd0 fstp     dword ptr [ebx + 0x10]
433c8cd3 mov      dword ptr [ebp - 4], 0x289d6d8d
433c8cda mov      edx, edi
433c8cdc mov      eax, dword ptr [ebp - 4]
433c8cdf mov      ecx, dword ptr [edi]
433c8ce1 sub      ecx, eax
433c8ce3 mov      ecx, dword ptr [ecx + 0x289d7449]
433c8ce9 call     0x433e533f
433c8cee pop      edi
433c8cef movd     xmm0, eax
433c8cf3 cvtdq2ps xmm0, xmm0
433c8cf6 movss    dword ptr [ebx + 0x14], xmm0
433c8cfb mov      eax, dword ptr [esi + 0xfc]
433c8d01 pop      esi
433c8d02 mov      dword ptr [ebx + 0x18], eax
433c8d05 pop      ebx
433c8d06 leave    
433c8d07 ret      
