433658fa push     edx
433658fb call     0x4337fdd7
43365900 ret      
