4334c8ac push     esi
4334c8ad mov      esi, dword ptr [ecx + 0x70]
4334c8b0 push     edi
4334c8b1 mov      edi, dword ptr [ecx + 0x74]
4334c8b4 jmp      0x4334c8c0
4334c8b6 mov      ecx, dword ptr [esi]
4334c8b8 mov      eax, dword ptr [ecx]
4334c8ba call     dword ptr [eax + 0x14]
4334c8bd add      esi, 4
4334c8c0 cmp      esi, edi
4334c8c2 jne      0x4334c8b6
4334c8c4 pop      edi
4334c8c5 pop      esi
4334c8c6 ret      
