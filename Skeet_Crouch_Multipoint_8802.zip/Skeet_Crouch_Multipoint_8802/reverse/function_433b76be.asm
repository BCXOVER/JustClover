433b76be test     byte ptr [ecx], 0x80
433b76c1 mov      eax, dword ptr [ecx + 0xfc]
433b76c7 je       0x433b76ce
433b76c9 test     eax, eax
433b76cb je       0x433b76ce
433b76cd dec      eax
433b76ce cmp      dword ptr [ecx + 0x15c], eax
433b76d4 setl     al
433b76d7 ret      
