433cf2f5 mov      eax, dword ptr [ecx]
433cf2f7 jmp      dword ptr [eax + 0x14]
