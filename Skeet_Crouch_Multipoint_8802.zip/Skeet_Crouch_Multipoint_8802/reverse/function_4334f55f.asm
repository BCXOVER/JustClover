4334f55f push     ebp
4334f560 mov      ebp, esp
4334f562 and      esp, 0xfffffff0
4334f565 sub      esp, 0x7348
4334f56b mov      eax, dword ptr [0x434759c0]
4334f570 push     esi
4334f571 mov      esi, eax
4334f573 mov      dword ptr [esp + 0xa4], edx
4334f57a and      esi, 8
4334f57d and      eax, 0xfffeafe7
4334f582 shl      esi, 0xb
4334f585 or       esi, eax
4334f587 push     edi
4334f588 mov      edi, ecx
4334f58a mov      dword ptr [0x434759c0], esi
4334f590 mov      edx, dword ptr [edx + 0xc]
4334f593 xor      ecx, ecx
4334f595 mov      dword ptr [esp + 0x1c], edi
4334f599 mov      dword ptr [esp + 0x11c], edx
4334f5a0 test     edx, edx
4334f5a2 je       0x4334f663
4334f5a8 mov      eax, dword ptr [0x43467430]
4334f5ad mov      eax, dword ptr [eax]
4334f5af xor      eax, dword ptr [0x4346a718]
4334f5b5 xor      eax, 0xb8969256
4334f5ba cmp      byte ptr [eax + edx], cl
4334f5bd jne      0x4334f663
4334f5c3 mov      eax, dword ptr [ebp + 0xc]
4334f5c6 test     dword ptr [eax + 0x30], 0x2000
4334f5cd je       0x4334f657
4334f5d3 mov      eax, dword ptr [0x4346a60c]
4334f5d8 mov      eax, dword ptr [eax]
4334f5da xor      eax, dword ptr [0x434678a8]
4334f5e0 xor      eax, 0xca5ec698
4334f5e5 mov      dword ptr [esp + 0x6c], eax
4334f5e9 cmp      dword ptr [eax + edx], -1
4334f5ed je       0x4334f657
4334f5ef mov      dword ptr [esp + 0x120], 0xec78a13f
4334f5fa mov      eax, dword ptr [esp + 0x120]
4334f601 mov      ecx, dword ptr [edx]
4334f603 xor      eax, 0x2138e503
4334f608 add      eax, 0x1b4ec1b2
4334f60d rol      eax, 0x1d
4334f610 sub      ecx, eax
4334f612 mov      ecx, dword ptr [ecx - 0x22ee1967]
4334f618 mov      dword ptr [esp + 0x61c], ecx
4334f61f call     0x433e533f
4334f624 mov      edx, dword ptr [esp + 0x11c]
4334f62b mov      ecx, dword ptr [esp + 0x6c]
4334f62f cmp      dword ptr [ecx + edx], eax
4334f632 jge      0x4334f64f
4334f634 mov      eax, dword ptr [0x4346749c]
4334f639 xor      ecx, ecx
4334f63b mov      eax, dword ptr [eax]
4334f63d xor      eax, dword ptr [0x43468c14]
4334f643 xor      eax, 0x49c770ca
4334f648 cmp      dword ptr [eax + edx], ecx
4334f64b jg       0x4334f663
4334f64d jmp      0x4334f651
4334f64f xor      ecx, ecx
4334f651 mov      esi, dword ptr [0x434759c0]
4334f657 and      esi, 0xfffffeff
4334f65d mov      dword ptr [0x434759c0], esi
4334f663 mov      esi, dword ptr [esp + 0xa8]
4334f66a mov      eax, ecx
4334f66c mov      dword ptr [edi + 0x170], ecx
4334f672 mov      edx, dword ptr [esi]
4334f674 test     edx, 0x8000000
4334f67a je       0x4334f687
4334f67c push     0x20
4334f67e pop      eax
4334f67f mov      dword ptr [edi + 0x170], eax
4334f685 mov      edx, dword ptr [esi]
4334f687 test     edx, 0x4000
4334f68d jne      0x4334f6a7
4334f68f cmp      eax, 0x20
4334f692 jb       0x4334f6a2
4334f694 cmp      dword ptr [0x4346a4b0], 0
4334f69b jle      0x4334f6b0
4334f69d or       eax, 0x10
4334f6a0 jmp      0x4334f6aa
4334f6a2 cmp      dword ptr [edi + 0x24], ecx
4334f6a5 jmp      0x4334f69b
4334f6a7 or       eax, 4
4334f6aa mov      dword ptr [edi + 0x170], eax
4334f6b0 test     byte ptr [esi], 8
4334f6b3 je       0x4334f6c0
4334f6b5 or       eax, 0x200
4334f6ba mov      dword ptr [edi + 0x170], eax
4334f6c0 mov      eax, dword ptr [0x43469028]
4334f6c5 xor      eax, 0xefd12c6
4334f6ca jmp      0x4334f6ce
4334f6cc mov      eax, edx
4334f6ce mov      edx, dword ptr [eax + 0x1c]
4334f6d1 cmp      eax, edx
4334f6d3 jne      0x4334f6cc
4334f6d5 cmp      dword ptr [eax + 0x30], eax
4334f6d8 je       0x4334f6e4
4334f6da or       dword ptr [edi + 0x170], 0x400
4334f6e4 cmp      dword ptr [esi + 0xc], ecx
4334f6e7 je       0x43358507
4334f6ed cmp      byte ptr [0x43467224], 0
4334f6f4 movss    xmm0, dword ptr [0x43472244]
4334f6fc mov      eax, dword ptr [ebp + 0xc]
4334f6ff movss    dword ptr [esp + 0x2f0], xmm0
4334f708 movss    dword ptr [esp + 0x120], xmm0
4334f711 xorps    xmm0, xmm0
4334f714 mov      dword ptr [esp + 0x28], eax
4334f718 mov      eax, dword ptr [ebp + 8]
4334f71b mov      dword ptr [esp + 0x14], esi
4334f71f mov      dword ptr [esp + 0x11c], ecx
4334f726 mov      dword ptr [esp + 0x2ec], 0x96
4334f731 mov      dword ptr [esp + 0x114], 2
4334f73c mov      dword ptr [esp + 0x24], 1
4334f744 mov      dword ptr [esp + 0x5c], eax
4334f748 movss    dword ptr [esp + 0x2c], xmm0
4334f74e je       0x4334f9a9
4334f754 mov      eax, dword ptr [0x43467f48]
4334f759 mov      ecx, 0x43467f34
4334f75e mov      eax, dword ptr [eax*4 + 0x434721c4]
4334f765 call     eax
4334f767 test     al, al
4334f769 je       0x4334f9a7
4334f76f call     0x433df22c
4334f774 test     al, al
4334f776 je       0x4334f782
4334f778 mov      byte ptr [esp + 0x23], 0
4334f77d jmp      0x4334f9ad
4334f782 mov      ecx, esi
4334f784 cmp      dword ptr [ecx + 0xc], 0
4334f788 je       0x4334f778
4334f78a mov      eax, dword ptr [0x4346908c]
4334f78f mov      eax, dword ptr [eax]
4334f791 xor      eax, dword ptr [0x43468ba0]
4334f797 xor      eax, 0x5c9f0fbb
4334f79c add      eax, dword ptr [ecx + 0xc]
4334f79f mov      cx, word ptr [eax]
4334f7a2 call     0x433d24bb
4334f7a7 test     al, al
4334f7a9 je       0x4334f778
4334f7ab xor      eax, eax
4334f7ad inc      eax
4334f7ae test     byte ptr [0x434759c0], 0x40
4334f7b5 mov      byte ptr [esp + 0x23], al
4334f7b9 mov      eax, esi
4334f7bb je       0x4334f9af
4334f7c1 mov      ecx, dword ptr [eax + 0x15c]
4334f7c7 cmp      ecx, dword ptr [eax + 0xfc]
4334f7cd jl       0x4334f9a0
4334f7d3 test     ecx, ecx
4334f7d5 jle      0x4334f9a0
4334f7db mov      eax, dword ptr [edi + 0x1518]
4334f7e1 cmp      eax, ecx
4334f7e3 cmovl    ecx, eax
4334f7e6 and      dword ptr [esp + 0x9c], 0
4334f7ee test     ecx, ecx
4334f7f0 jle      0x4334f9ad
4334f7f6 mov      eax, dword ptr [0x4346a894]
4334f7fb mov      eax, dword ptr [eax + 0xf0]
4334f801 mov      dword ptr [esp + 0x6c], eax
4334f805 mov      eax, esi
4334f807 mov      edx, dword ptr [eax + 0xac]
4334f80d dec      edx
4334f80e mov      dword ptr [esp + 0xd8], edx
4334f815 mov      eax, edx
4334f817 mov      esi, 0x96
4334f81c xor      edx, edx
4334f81e div      esi
4334f820 push     0
4334f822 imul     eax, edx, 0x64
4334f825 mov      edx, dword ptr [esp + 0xdc]
4334f82c pop      esi
4334f82d add      eax, dword ptr [esp + 0x6c]
4334f831 cmp      dword ptr [eax + 4], edx
4334f834 cmove    esi, eax
4334f837 mov      eax, esi
4334f839 mov      dword ptr [esp + 0xd8], esi
4334f840 mov      esi, dword ptr [esp + 0x14]
4334f844 test     eax, eax
4334f846 je       0x4334f899
4334f848 cmp      dword ptr [eax + 8], 0x7f7fffff
4334f84f je       0x4334f899
4334f851 mov      eax, dword ptr [edi + 0x1514]
4334f857 add      eax, dword ptr [esp + 0x9c]
4334f85e and      eax, 0xf
4334f861 imul     eax, eax, 0x1f4
4334f867 cmp      dword ptr [eax + edi + 0x15c8], edx
4334f86e jne      0x4334f899
4334f870 movss    xmm0, dword ptr [eax + edi + 0x15a0]
4334f879 comiss   xmm0, dword ptr [esi + 0x84]
4334f880 jbe      0x4334f899
4334f882 lea      esi, [edi + 0x151c]
4334f888 add      esi, eax
4334f88a mov      eax, dword ptr [esp + 0xd8]
4334f891 mov      dword ptr [esp + 0x14], esi
4334f895 mov      dword ptr [esp + 0x28], eax
4334f899 mov      eax, dword ptr [esp + 0x9c]
4334f8a0 inc      eax
4334f8a1 dec      edx
4334f8a2 mov      dword ptr [esp + 0x9c], eax
4334f8a9 mov      dword ptr [esp + 0xd8], edx
4334f8b0 cmp      eax, ecx
4334f8b2 jl       0x4334f815
4334f8b8 mov      eax, dword ptr [esp + 0xa8]
4334f8bf cmp      esi, eax
4334f8c1 je       0x4334f9af
4334f8c7 mov      ecx, dword ptr [esi + 0xac]
4334f8cd call     0x4340310b
4334f8d2 mov      dword ptr [esp + 0x120], eax
4334f8d9 test     eax, eax
4334f8db je       0x4334f928
4334f8dd push     dword ptr [esp + 0x5c]
4334f8e1 lea      ecx, [eax + 0x14]
4334f8e4 call     0x4331ed0b
4334f8e9 mov      eax, dword ptr [esp + 0x120]
4334f8f0 and      dword ptr [esp + 0x3e4], 0
4334f8f8 movss    xmm0, dword ptr [eax + 0x1e4]
4334f900 and      dword ptr [esp + 0x3ec], 0
4334f908 mov      eax, dword ptr [0x434688c8]
4334f90d movss    dword ptr [esp + 0x3e8], xmm0
4334f916 test     eax, eax
4334f918 je       0x4334f928
4334f91a lea      ecx, [esp + 0x3e4]
4334f921 push     ecx
4334f922 mov      ecx, dword ptr [esp + 0x60]
4334f926 call     eax
4334f928 mov      ecx, dword ptr [esp + 0xa8]
4334f92f push     0x64
4334f931 mov      eax, dword ptr [ecx + 0xd4]
4334f937 mov      dword ptr [esi + 0xd4], eax
4334f93d and      dword ptr [esi + 0x18c], 0
4334f944 mov      eax, dword ptr [ecx + 0x144]
4334f94a mov      ecx, dword ptr [0x43467eb8]
4334f950 mov      dword ptr [esi + 0x144], eax
4334f956 mov      eax, dword ptr [0x4346a338]
4334f95b movss    xmm0, dword ptr [ecx]
4334f95f movss    dword ptr [esp + 0x124], xmm0
4334f968 movd     xmm0, dword ptr [esi + 0xc8]
4334f970 cvtdq2ps xmm0, xmm0
4334f973 mulss    xmm0, dword ptr [eax]
4334f977 pop      eax
4334f978 mov      edx, eax
4334f97a movss    dword ptr [ecx], xmm0
4334f97e mov      ecx, dword ptr [esp + 0x28]
4334f982 call     0x4333d6a2
4334f987 mov      dword ptr [esp + 0x11c], eax
4334f98e push     2
4334f990 pop      eax
4334f991 or       dword ptr [edi + 0x170], eax
4334f997 mov      eax, dword ptr [esp + 0xa8]
4334f99e jmp      0x4334f9af
4334f9a0 mov      byte ptr [esp + 0x23], 0
4334f9a5 jmp      0x4334f9af
4334f9a7 xor      ecx, ecx
4334f9a9 mov      byte ptr [esp + 0x23], cl
4334f9ad mov      eax, esi
4334f9af cmp      byte ptr [0x43467224], 0
4334f9b6 je       0x4334f9d7
4334f9b8 mov      edx, dword ptr [ebp + 0xc]
4334f9bb add      eax, 0x14
4334f9be mov      ecx, dword ptr [esp + 0x5c]
4334f9c2 push     eax
4334f9c3 mov      eax, dword ptr [esp + 0xac]
4334f9ca movss    xmm0, dword ptr [eax + 0x11c]
4334f9d2 call     0x4335ba8e
4334f9d7 cmp      byte ptr [esp + 0x23], 0
4334f9dc movss    xmm0, dword ptr [0x434703d0]
4334f9e4 movss    dword ptr [esp + 0xf0], xmm0
4334f9ed movss    xmm0, dword ptr [0x43470340]
4334f9f5 movss    dword ptr [esp + 0xb0], xmm0
4334f9fe movss    xmm0, dword ptr [0x43470514]
4334fa06 movss    dword ptr [esp + 0x68], xmm0
4334fa0c movss    xmm0, dword ptr [0x4346f908]
4334fa14 movss    dword ptr [esp + 0x168], xmm0
4334fa1d movss    xmm0, dword ptr [0x4346dd48]
4334fa25 movss    dword ptr [esp + 0xa4], xmm0
4334fa2e movss    xmm0, dword ptr [0x4346fdc0]
4334fa36 movss    dword ptr [esp + 0x110], xmm0
4334fa3f movss    xmm0, dword ptr [0x434725e4]
4334fa47 movss    dword ptr [esp + 0xec], xmm0
4334fa50 movss    xmm0, dword ptr [0x43471f88]
4334fa58 movss    dword ptr [esp + 0x8c], xmm0
4334fa61 movss    xmm0, dword ptr [0x43472108]
4334fa69 movss    dword ptr [esp + 0x94], xmm0
4334fa72 movss    xmm0, dword ptr [0x43470960]
4334fa7a movss    dword ptr [esp + 0x160], xmm0
4334fa7c adc      dword ptr [esp + 0x160], eax
4334fa83 je       0x43357733
4334fa89 mov      eax, dword ptr [esi + 0xc8]
4334fa8f mov      edx, dword ptr [esi + 0xc]
4334fa92 mov      dword ptr [esp + 0xe4], eax
4334fa99 lea      eax, [edi - 8]
4334fa9c mov      dword ptr [esp + 0xa0], eax
4334faa3 test     edx, edx
4334faa5 jne      0x4334fab3
4334faa7 fisubr   word ptr [ebx - 0x70577bfd]
4334faad bound    esi, qword ptr [ebp + 9]
4334fab0 rcr      dword ptr [edx + ebx - 0x5f], 0xc
4334fab3 mov      eax, dword ptr [0x4346a60c]
4334fab5 cmpsb    byte ptr [esi], byte ptr es:[edi]
4334fab6 inc      esi
4334fab7 inc      ebx
4334fab8 xor      ecx, ecx
4334faba mov      eax, dword ptr [eax]
4334fabc xor      eax, dword ptr [0x434678a8]
4334fac2 xor      eax, 0xca5ec698
4334fac7 cmp      dword ptr [eax + edx], ecx
4334faca jne      0x4334fb0e
4334facc test     edx, edx
4334face jne      0x4334fadc
4334fad0 js       0x4334faa5
4334fad2 int1     
4334fad3 and      eax, 0xab4cb6b9
4334fad8 ja       0x4334fa7c
4334fada mov      dl, 0xca
4334fadc mov      eax, dword ptr [0x4346749c]
4334fae1 mov      eax, dword ptr [eax]
4334fae3 xor      eax, dword ptr [0x43468c14]
4334fae9 xor      eax, 0x49c770ca
4334faee cmp      dword ptr [eax + edx], ecx
4334faf1 jle      0x433576f0
4334faf7 mov      ecx, dword ptr [esp + 0x28]
4334fafb mov      eax, dword ptr [ecx + 0x30]
4334fafe and      eax, 0xfffffffe
4334fb01 or       eax, 0x2000
4334fb06 mov      dword ptr [ecx + 0x30], eax
4334fb09 jmp      0x433576f0
4334fb0e mov      eax, dword ptr [esi + 8]
4334fb11 cmp      byte ptr [eax], cl
4334fb13 je       0x4334fb31
4334fb15 call     0x4331ff20
4334fb1a xor      ecx, ecx
4334fb1c inc      ecx
4334fb1d cmp      eax, ecx
4334fb1f jne      0x4334fb34
4334fb21 cmp      dword ptr [esi + 0x18c], ecx
4334fb27 jge      0x4334fb34
4334fb29 mov      dword ptr [esi + 0x18c], ecx
4334fb2f jmp      0x4334fb34
4334fb31 xor      ecx, ecx
4334fb33 inc      ecx
4334fb34 xor      eax, eax
4334fb36 cmp      dword ptr [esi + 0xd8], 0x40
4334fb3d mov      byte ptr [esp + 0x23], al
4334fb41 jne      0x4334fb4c
4334fb43 test     byte ptr [esi], 0x40
4334fb46 mov      byte ptr [esp + 0x22], cl
4334fb4a jne      0x4334fb50
4334fb4c mov      byte ptr [esp + 0x22], al
4334fb50 xor      ecx, ecx
4334fb52 mov      dword ptr [esp + 0xe0], eax
4334fb59 mov      word ptr [esp + 0x19e], cx
4334fb61 lea      ecx, [esp + 0x810]
4334fb68 call     0x43402ba2
4334fb6d mov      eax, dword ptr [esi]
4334fb6f xor      edx, edx
4334fb71 movss    xmm0, dword ptr [0x43472240]
4334fb79 shr      eax, 0xa
4334fb7c mov      dword ptr [esp + 0xd8], eax
4334fb83 mov      byte ptr [esp + 0x98], dl
4334fb8a mov      byte ptr [esp + 0x83], dl
4334fb91 mov      byte ptr [esp + 0x33], dl
4334fb95 movss    dword ptr [esp + 0x90], xmm0
4334fb9e cmp      byte ptr [0x43468d7c], dl
4334fba4 je       0x4334fbd0
4334fba6 cmp      dword ptr [esi + 0x15c], edx
4334fbac je       0x4334fbd0
4334fbae mov      eax, dword ptr [0x43475b2c]
4334fbb3 mov      ecx, dword ptr [0x434759c4]
4334fbb9 cmp      ecx, dword ptr [eax]
4334fbbb jle      0x4334fbc9
4334fbbd cmp      ecx, dword ptr [esi + 0xac]
4334fbc3 jl       0x4334fd18
4334fbc9 mov      eax, dword ptr [esp + 0xd8]
4334fbd0 test     dword ptr [esi], 0x800
4334fbd6 je       0x4334fbdc
4334fbd8 mov      eax, dword ptr [esi]
4334fbda shr      eax, 1
4334fbdc xor      ecx, ecx
4334fbde inc      ecx
4334fbdf and      al, cl
4334fbe1 cmp      dword ptr [esi + 0x1d4], 2
4334fbe8 mov      dword ptr [esp + 0x98], eax
4334fbef jne      0x4334fc2f
4334fbf1 test     dword ptr [esi], 0x40000000
4334fbf7 jne      0x4334fc2f
4334fbf9 mov      byte ptr [esp + 0x98], dl
4334fc00 mov      byte ptr [esp + 0x83], dl
4334fc07 xor      eax, eax
4334fc09 inc      eax
4334fc0a cmp      dword ptr [esi + 0xd8], 0x40
4334fc11 je       0x4334fd18
4334fc17 xor      ecx, ecx
4334fc19 inc      ecx
4334fc1a test     dword ptr [esi], 0x4000000
4334fc20 je       0x4334fd1b
4334fc26 mov      byte ptr [esp + 0x33], al
4334fc2a jmp      0x4334fd1b
4334fc2f test     al, al
4334fc31 jne      0x4334fd0f
4334fc37 mov      byte ptr [esp + 0x98], dl
4334fc3e cmp      byte ptr [0x434684e0], dl
4334fc44 je       0x4334fc07
4334fc46 mov      ecx, dword ptr [esi + 0xc]
4334fc49 test     ecx, ecx
4334fc4b jne      0x4334fc59
4334fc4d wait     
4334fc4e or       al, 0x80
4334fc51 jle      0x4334fc86
4334fc53 cmpsd    dword ptr [esi], dword ptr es:[edi]
4334fc54 add      eax, 0xb6040cca
4334fc59 mov      eax, dword ptr [0x43467a50]
4334fc5e mov      eax, dword ptr [eax]
4334fc60 xor      eax, dword ptr [0x4346a458]
4334fc66 xor      eax, 0xf71ce331
4334fc6b movss    xmm1, dword ptr [eax + ecx]
4334fc70 mov      ecx, dword ptr [esp + 0x5c]
4334fc74 test     ecx, ecx
4334fc76 jne      0x4334fc84
4334fc78 imul     edx, dword ptr [edi - 0x5d], 0xa5740a99
4334fc7f mov      word ptr [ebx - 0x5e3384f8], ss
4334fc84 mov      eax, dword ptr [0x4346a80c]
4334fc85 or       al, 0xa8
4334fc86 test     al, 0x46
4334fc87 inc      esi
4334fc88 inc      ebx
4334fc89 mov      eax, dword ptr [eax]
4334fc8b xor      eax, dword ptr [0x43469208]
4334fc91 xor      eax, 0xde530a8b
4334fc96 movss    xmm0, dword ptr [eax + ecx]
4334fc9b call     0x4332fc35
4334fca0 mov      esi, dword ptr [0x4346a338]
4334fca6 xorps    xmm1, xmm1
4334fca9 mov      byte ptr [esp + 0x98], 0
4334fcb1 divss    xmm0, dword ptr [esi]
4334fcb5 cvtss2si edx, xmm0
4334fcb9 movss    xmm1, xmm0
4334fcbd xorps    xmm0, xmm0
4334fcc0 cvtsi2ss xmm0, edx
4334fcc4 comiss   xmm1, xmm0
4334fcc7 seta     al
4334fcca movzx    ecx, al
4334fccd mov      eax, dword ptr [0x43467eb8]
4334fcd2 movss    xmm0, dword ptr [eax]
4334fcd6 divss    xmm0, dword ptr [esi]
4334fcda mov      esi, dword ptr [esp + 0x14]
4334fcde addss    xmm0, dword ptr [esp + 0x90]
4334fce7 cvttss2si eax, xmm0
4334fceb sub      edx, eax
4334fced xor      eax, eax
4334fcef add      ecx, edx
4334fcf1 inc      eax
4334fcf2 xor      edx, edx
4334fcf4 cmp      ecx, eax
4334fcf6 jne      0x4334fc0a
4334fcfc mov      byte ptr [esp + 0x83], al
4334fd03 mov      byte ptr [esp + 0x98], dl
4334fd0a jmp      0x4334fc0a
4334fd0f mov      byte ptr [esp + 0x83], dl
4334fd16 jmp      0x4334fd1b
4334fd18 xor      ecx, ecx
4334fd1a inc      ecx
4334fd1b mov      eax, dword ptr [esi + 0x1a0]
4334fd21 mov      dword ptr [esp + 0x38], eax
4334fd25 mov      eax, dword ptr [esi + 0xd8]
4334fd2b mov      dword ptr [esp + 0xd0], eax
4334fd32 mov      eax, dword ptr [esi + 0xc]
4334fd35 mov      dword ptr [esp + 0x6c], eax
4334fd39 mov      eax, dword ptr [edi + 0xec]
4334fd3f test     eax, eax
4334fd41 cmove    eax, ecx
4334fd44 mov      ecx, dword ptr [0x434691cc]
4334fd4a cmp      byte ptr [0x43468f78], 0
4334fd51 mov      dword ptr [esp + 0x178], eax
4334fd58 mov      eax, edx
4334fd5a cmovne   eax, ecx
4334fd5d mov      dword ptr [esp + 0x17c], ecx
4334fd64 mov      dword ptr [esp + 0x180], eax
4334fd6b mov      ecx, 0x434678e0
4334fd70 mov      eax, dword ptr [0x434678f4]
4334fd75 mov      eax, dword ptr [eax*4 + 0x434721c4]
4334fd7c call     eax
4334fd7e test     al, al
4334fd80 je       0x4334fda1
4334fd82 mov      eax, dword ptr [esp + 0x180]
4334fd89 or       eax, dword ptr [esp + 0x17c]
4334fd90 and      dword ptr [esp + 0x17c], 0
4334fd98 mov      dword ptr [esp + 0x180], eax
4334fd9f jmp      0x4334fe0b
4334fda1 mov      eax, dword ptr [0x43467030]
4334fda6 test     eax, eax
4334fda8 je       0x4334fe04
4334fdaa mov      ecx, dword ptr [esp + 0x17c]
4334fdb1 mov      edx, ecx
4334fdb3 and      edx, eax
4334fdb5 mov      eax, ecx
4334fdb7 je       0x4334fdd8
4334fdb9 mov      ecx, edx
4334fdbb not      ecx
4334fdbd and      ecx, eax
4334fdbf mov      eax, dword ptr [esp + 0x180]
4334fdc6 or       eax, edx
4334fdc8 mov      dword ptr [esp + 0x17c], ecx
4334fdcf mov      dword ptr [esp + 0x180], eax
4334fdd6 jmp      0x4334fddf
4334fdd8 mov      eax, dword ptr [esp + 0x180]
4334fddf test     dword ptr [0x43467030], 0x200
4334fde9 je       0x4334fe0b
4334fdeb mov      edx, 0xfffffdff
4334fdf0 and      ecx, edx
4334fdf2 and      eax, edx
4334fdf4 mov      dword ptr [esp + 0x17c], ecx
4334fdfb mov      dword ptr [esp + 0x180], eax
4334fe02 jmp      0x4334fe0b
4334fe04 mov      eax, dword ptr [esp + 0x180]
4334fe0b test     dword ptr [edi + 0x170], 0x400
4334fe15 jne      0x4334fe35
4334fe17 cmp      byte ptr [0x43467d70], 0
4334fe1e je       0x4334fe35
4334fe20 test     byte ptr [0x4346a8d0], 8
4334fe27 je       0x4334fe35
4334fe29 push     2
4334fe2b pop      ecx
4334fe2c or       eax, ecx
4334fe2e mov      dword ptr [esp + 0x180], eax
4334fe35 mov      eax, dword ptr [edi + 0xc4]
4334fe3b movss    xmm0, dword ptr [0x43472738]
4334fe43 movss    dword ptr [esp + 0x22c], xmm0
4334fe4c cmp      eax, 0x18
4334fe4f jne      0x4334fe59
4334fe51 movss    xmm0, dword ptr [esp + 0x68]
4334fe57 jmp      0x4334fe76
4334fe59 movss    xmm2, dword ptr [esp + 0x168]
4334fe62 movd     xmm1, eax
4334fe66 cvtdq2ps xmm1, xmm1
4334fe69 mulss    xmm1, xmm2
4334fe6d subss    xmm1, xmm2
4334fe71 call     0x43367633
4334fe76 mov      eax, dword ptr [0x43469424]
4334fe7b mov      ecx, 0x43469410
4334fe80 and      dword ptr [esp + 0x188], 0
4334fe88 movss    dword ptr [esp + 0x184], xmm0
4334fe91 mov      eax, dword ptr [eax*4 + 0x434721c4]
4334fe98 call     eax
4334fe9a test     al, al
4334fe9c je       0x4334feab
4334fe9e mov      eax, dword ptr [edi + 0xd8]
4334fea4 mov      dword ptr [esp + 0x188], eax
4334feab mov      eax, dword ptr [edi + 0x60]
4334feae mov      dword ptr [esp + 0x18c], eax
4334feb5 test     byte ptr [edi + 0x170], 0x20
4334febc je       0x4334fec8
4334febe movd     xmm0, dword ptr [0x4346a4b0]
4334fec6 jmp      0x4334fecd
4334fec8 movd     xmm0, dword ptr [edi + 0x24]
4334fecd cvtdq2ps xmm0, xmm0
4334fed0 mulss    xmm0, dword ptr [esp + 0x168]
4334fed9 movss    dword ptr [esp + 0x190], xmm0
4334fee2 movd     xmm0, dword ptr [edi + 0x38]
4334fee7 cvtdq2ps xmm0, xmm0
4334feea mulss    xmm0, dword ptr [0x43470528]
4334fef0 inc      edi
4334fef1 inc      ebx
4334fef2 call     0x7750a770
4334fef7 mov      al, byte ptr [0x43468f78]
4334fefc mov      byte ptr [esp + 0x198], al
4334ff03 mov      al, byte ptr [0x43467d70]
4334ff08 push     0x1f
4334ff0a mov      byte ptr [esp + 0x19d], al
4334ff11 pop      eax
4334ff12 movss    dword ptr [esp + 0x194], xmm0
4334ff1b cmp      dword ptr [esp + 0xd0], eax
4334ff22 jne      0x4334ff8b
4334ff24 mov      eax, dword ptr [esp + 0x18c]
4334ff2b push     0x69
4334ff2d pop      ecx
4334ff2e cmp      eax, ecx
4334ff30 cmovl    eax, ecx
4334ff33 mov      ecx, dword ptr [esp + 0x6c]
4334ff37 mov      dword ptr [esp + 0x18c], eax
4334ff3e xor      eax, eax
4334ff40 inc      eax
4334ff41 mov      byte ptr [esp + 0x199], al
4334ff48 test     ecx, ecx
4334ff4a jne      0x4334ff58
4334ff4c dec      esi
4334ff4d push     0x4d
4334ff51 xchg     ecx, edi
4334ff53 je       0x4334fef0
4334ff55 push     es
4334ff56 fld      xword ptr [ecx + 0x20]
4334ff58 mov      eax, dword ptr [0x4346a620]
4334ff5a cmpsb    byte ptr [esi], byte ptr es:[edi]
4334ff5b inc      esi
4334ff5c inc      ebx
4334ff5d mov      edx, dword ptr [esp + 0x188]
4334ff64 mov      eax, dword ptr [eax]
4334ff66 xor      eax, dword ptr [0x434671e4]
4334ff6c xor      eax, 0xd2563274
4334ff71 movss    xmm0, dword ptr [eax + ecx]
4334ff76 xor      eax, eax
4334ff78 comiss   xmm0, dword ptr [0x434702dc]
4334ff7f cmova    edx, eax
4334ff82 mov      dword ptr [esp + 0x188], edx
4334ff89 jmp      0x4334ff92
4334ff8b mov      edx, dword ptr [esp + 0x188]
4334ff92 mov      ecx, dword ptr [esp + 0x38]
4334ff96 xor      eax, eax
4334ff98 inc      eax
4334ff99 test     al, cl
4334ff9b mov      eax, dword ptr [esp + 0x178]
4334ffa2 push     2
4334ffa4 cmovne   eax, dword ptr [esp + 0x28]
4334ffa9 mov      dword ptr [esp + 0x17c], eax
4334ffb0 pop      eax
4334ffb1 test     al, cl
4334ffb3 je       0x4334ffc2
4334ffb5 and      edx, 0xfffffdff
4334ffbb mov      dword ptr [esp + 0x188], edx
4334ffc2 test     cl, 0x10
4334ffc5 je       0x4334ffd2
4334ffc7 and      dword ptr [esp + 0x17c], 0xfffffdff
4334ffd2 test     cl, 8
4334ffd5 je       0x4334ffe4
4334ffd7 and      edx, 0xffffff3f
4334ffdd mov      dword ptr [esp + 0x188], edx
4334ffe4 test     cl, 4
4334ffe7 je       0x4334fff3
4334ffe9 and      edx, 0xffffffcf
4334ffec mov      dword ptr [esp + 0x188], edx
4334fff3 mov      al, byte ptr [edi + 0x100]
4334fff9 xor      ecx, ecx
4334fffb mov      byte ptr [esp + 0x19a], al
43350002 mov      al, byte ptr [edi + 0x164]
43350008 mov      byte ptr [esp + 0x19b], al
4335000f mov      byte ptr [esp + 0x19d], cl
43350016 test     dword ptr [edi + 0x170], 0x400
43350020 je       0x43350056
43350022 push     0x1f
43350024 pop      eax
43350025 cmp      dword ptr [esp + 0xd0], eax
4335002c je       0x43350056
4335002e push     2
43350030 pop      eax
43350031 and      dword ptr [esp + 0x17c], eax
43350038 and      dword ptr [esp + 0x180], eax
4335003f and      edx, eax
43350041 mov      dword ptr [esp + 0x188], edx
43350048 mov      byte ptr [esp + 0x199], cl
4335004f mov      byte ptr [esp + 0x19b], cl
43350056 mov      byte ptr [esp + 0x19c], cl
4335005d cmp      byte ptr [edi + 0x74], cl
43350060 je       0x4335009e
43350062 lea      ecx, [edi + 0x88]
43350068 mov      eax, dword ptr [ecx + 0x14]
4335006b mov      eax, dword ptr [eax*4 + 0x434721c4]
43350072 call     eax
43350074 xor      edx, edx
43350076 test     al, al
43350078 je       0x4335009a
4335007a inc      edx
4335007b xor      ecx, ecx
4335007d mov      byte ptr [esp + 0x19c], dl
43350084 mov      eax, dword ptr [edi + 0xb0]
4335008a mov      dword ptr [esp + 0x18c], eax
43350091 mov      byte ptr [esp + 0x19a], cl
43350098 jmp      0x433500a1
4335009a xor      ecx, ecx
4335009c jmp      0x433500a0
4335009e xor      edx, edx
433500a0 inc      edx
433500a1 test     byte ptr [edi + 0x170], 0x10
433500a8 je       0x433502cc
433500ae mov      eax, dword ptr [edi + 0x1bc]
433500b4 cmp      eax, dword ptr [esi + 0xac]
433500ba je       0x433502cc
433500c0 cmp      byte ptr [esi + 0x124], 4
433500c7 jne      0x433501fa
433500cd cmp      dword ptr [esi + 0x19c], edx
433500d3 jle      0x433501fa
433500d9 add      edi, 0x1114
433500df mov      dword ptr [esp + 0x64], ecx
433500e3 mov      eax, ecx
433500e5 mov      dword ptr [esp + 0x9c], edi
433500ec mov      ecx, dword ptr [esi + 0x19c]
433500f2 cdq      
433500f3 and      edx, 3
433500f6 mov      edi, dword ptr [esp + 0x14]
433500fa push     ecx
433500fb lea      esi, [edx + eax]
433500fe movss    xmm2, dword ptr [edi + 0x100]
43350106 sar      esi, 2
43350109 mov      eax, esi
4335010b movss    xmm1, dword ptr [edi + 0xc4]
43350113 cdq      
43350114 idiv     ecx
43350116 mov      eax, dword ptr [esp + 0x68]
4335011a movss    xmm0, dword ptr [edi + 0xd0]
43350122 push     edx
43350123 mov      edx, dword ptr [edi + 0xb0]
43350129 movzx    ecx, byte ptr [eax + 0x4346fc50]
43350130 push     ecx
43350131 mov      ecx, dword ptr [edi + 0xd8]
43350137 call     0x433adb4f
4335013c mov      ecx, dword ptr [esp + 0x9c]
43350143 movss    dword ptr [esp + 0x40], xmm0
43350149 mov      eax, dword ptr [esp + 0x40]
4335014d movss    dword ptr [esp + 0x44], xmm1
43350153 mov      dword ptr [ecx - 0x400], eax
43350159 mov      eax, dword ptr [esp + 0x44]
4335015d mov      dword ptr [ecx - 0x3fc], eax
43350163 mov      eax, esi
43350165 mov      ecx, dword ptr [edi + 0x19c]
4335016b mov      esi, edi
4335016d cdq      
4335016e idiv     ecx
43350170 movss    xmm0, dword ptr [edi + 0xd0]
43350178 mov      eax, dword ptr [esp + 0x64]
4335017c movss    xmm1, dword ptr [esi + 0x160]
43350184 movss    xmm2, dword ptr [esi + 0x100]
4335018c subss    xmm1, xmm0
43350190 push     ecx
43350191 movzx    eax, byte ptr [eax + 0x4346fc50]
43350198 mov      ecx, dword ptr [esi + 0xd8]
4335019e push     edx
4335019f mov      edx, dword ptr [esi + 0xb0]
433501a5 push     eax
433501a6 call     0x433adb4f
433501ab mov      ecx, dword ptr [esp + 0x9c]
433501b2 movss    dword ptr [esp + 0xc8], xmm0
433501bb mov      eax, dword ptr [esp + 0xc8]
433501c2 movss    dword ptr [esp + 0xcc], xmm1
433501cb mov      dword ptr [ecx], eax
433501cd mov      eax, dword ptr [esp + 0xcc]
433501d4 mov      dword ptr [ecx + 4], eax
433501d7 add      ecx, 8
433501da mov      eax, dword ptr [esp + 0x64]
433501de inc      eax
433501df mov      dword ptr [esp + 0x9c], ecx
433501e6 mov      dword ptr [esp + 0x64], eax
433501ea cmp      eax, 0x80
433501ef jb       0x433500ec
433501f5 jmp      0x433502bc
433501fa lea      eax, [edi + 0x1114]
43350200 mov      dword ptr [esp + 0x9c], ecx
43350207 mov      edi, eax
43350209 movzx    edx, byte ptr [ecx + 0x4346fc50]
43350210 mov      ecx, esi
43350212 call     0x4339ef31
43350217 movss    dword ptr [esp + 0x40], xmm0
4335021d mov      eax, dword ptr [esp + 0x40]
43350221 mov      dword ptr [edi - 0x400], eax
43350227 movss    dword ptr [esp + 0x44], xmm1
4335022d mov      eax, dword ptr [esp + 0x44]
43350231 mov      dword ptr [edi - 0x3fc], eax
43350237 xor      eax, eax
43350239 movss    xmm0, dword ptr [esi + 0xd0]
43350241 inc      eax
43350242 movss    xmm1, dword ptr [esi + 0x160]
4335024a movss    xmm2, dword ptr [esi + 0x100]
43350252 subss    xmm1, xmm0
43350256 mov      edx, dword ptr [esi + 0xb0]
4335025c mov      ecx, dword ptr [esi + 0xd8]
43350262 push     eax
43350263 mov      eax, dword ptr [esp + 0xa0]
4335026a push     0
4335026c movzx    eax, byte ptr [eax + 0x4346fc50]
43350273 push     eax
43350274 call     0x433adb4f
43350279 mov      ecx, dword ptr [esp + 0x9c]
43350280 movss    dword ptr [esp + 0xc8], xmm0
43350289 inc      ecx
4335028a mov      eax, dword ptr [esp + 0xc8]
43350291 mov      dword ptr [edi], eax
43350293 movss    dword ptr [esp + 0xcc], xmm1
4335029c mov      eax, dword ptr [esp + 0xcc]
433502a3 mov      dword ptr [edi + 4], eax
433502a6 add      edi, 8
433502a9 mov      dword ptr [esp + 0x9c], ecx
433502b0 cmp      ecx, 0x80
433502b6 jb       0x43350209
433502bc mov      edi, dword ptr [esp + 0x1c]
433502c0 mov      eax, dword ptr [esi + 0xac]
433502c6 mov      dword ptr [edi + 0x1bc], eax
433502cc lea      eax, [edi + 0x1c4]
433502d2 mov      ecx, eax
433502d4 mov      dword ptr [esp + 0x40], eax
433502d8 call     0x433e0a59
433502dd fld      dword ptr [0x43472240]
433502e3 lea      edi, [edi + 0x1ac]
433502e9 movss    xmm0, dword ptr [0x434704a0]
433502f1 xor      eax, eax
433502f3 stosd    dword ptr es:[edi], eax
433502f4 xor      edx, edx
433502f6 fstp     dword ptr [esp + 0xac]
433502fd fld      dword ptr [0x4346f014]
43350303 inc      edx
43350304 movss    dword ptr [esp + 0x9c], xmm0
4335030d movss    xmm0, dword ptr [0x43472980]
43350315 stosd    dword ptr es:[edi], eax
43350316 fstp     dword ptr [esp + 0xd0]
4335031d mov      dword ptr [esp + 0x6c], 0x7fffffff
43350325 movss    dword ptr [esp + 0x1b4], xmm0
4335032e stosd    dword ptr es:[edi], eax
4335032f mov      edi, dword ptr [esp + 0x1c]
43350333 mov      eax, 0x774cd0d0
43350338 mov      dword ptr [esp + 0xe8], eax
4335033f and      dword ptr [edi + 0x1b8], 0
43350346 cmp      dword ptr [edi + 0x4c], edx
43350349 jne      0x43351c37
4335034f test     byte ptr [edi + 0x170], 9
43350356 jne      0x43350364
43350358 xor      eax, eax
4335035a add      edi, 0x19c
43350360 stosd    dword ptr es:[edi], eax
43350361 stosd    dword ptr es:[edi], eax
43350362 stosd    dword ptr es:[edi], eax
43350363 stosd    dword ptr es:[edi], eax
43350364 mov      eax, dword ptr [esp + 0x14]
43350368 lea      edi, [esp + 0x890]
4335036f movss    xmm0, dword ptr [esp + 0x194]
43350378 lea      ecx, [esp + 0x890]
4335037f add      esi, 0x1a8
43350385 add      eax, 0xdc
4335038a mov      dword ptr [esp + 0xd4], eax
43350391 movss    xmm1, dword ptr [eax]
43350395 movss    xmm2, dword ptr [eax + 4]
4335039a movss    xmm3, dword ptr [eax + 8]
4335039f movsd    dword ptr es:[edi], dword ptr [esi]
433503a0 movsd    dword ptr es:[edi], dword ptr [esi]
433503a1 movsd    dword ptr es:[edi], dword ptr [esi]
433503a2 call     0x433ec805
433503a7 mov      dword ptr [esp + 0x18], eax
433503ab test     eax, eax
433503ad je       0x43354908
433503b3 push     0xa
433503b5 pop      ecx
433503b6 lea      esi, [esp + 0x178]
433503bd lea      edi, [esp + 0x124]
433503c4 rep movsd dword ptr es:[edi], dword ptr [esi]
433503c6 mov      esi, eax
433503c8 lea      ecx, [esi + 8]
433503cb mov      eax, dword ptr [ecx]
433503cd mov      dword ptr [esp + 0x108], ecx
433503d4 call     dword ptr [eax + 0x28]
433503d7 test     eax, eax
433503d9 jne      0x433503e7
433503db dec      ecx
433503dc adc      byte ptr [ebp - 0x1b27ef1b], bl
433503e2 test     eax, 0x912b442a
433503e7 mov      ecx, eax
433503e9 call     0x433b8a2b
433503ee mov      edi, dword ptr [esp + 0x14]
433503f2 lea      ecx, [esi + 8]
433503f5 mov      edx, dword ptr [esi + 8]
433503f8 mov      dword ptr [esp + 0x88], eax
433503ff movss    xmm0, dword ptr [edi + 0x160]
43350407 mov      eax, dword ptr [edi + 0xc]
4335040a movss    dword ptr [esp + 0xdc], xmm0
43350413 mov      dword ptr [esp + 0x54], eax
43350417 call     dword ptr [edx + 0x28]
4335041a mov      ecx, dword ptr [esp + 0x124]
43350421 mov      dword ptr [esp + 0x34], eax
43350425 mov      dword ptr [esp + 0x70], ecx
43350429 test     ecx, ecx
4335042b je       0x433504a8
4335042d test     eax, eax
4335042f jne      0x4335043d
43350431 pushal   
43350432 inc      esp
43350433 inc      edx
43350434 push     cs
43350435 loop     0x4335040e
43350437 jnp      0x4335043c
43350439 fcomp    st(2)
4335043b push     eax
4335043c ror      byte ptr [ebx - 0x7a181738], 1
4335043d mov      ecx, eax
4335043f call     0x433b8a2b
43350442 push     es
43350443 add      byte ptr [ebx + 0x5d8b8], al
43350444 cmp      dword ptr [eax + 0x5d8], 0
43350449 add      byte ptr [eax], al
4335044b je       0x433504a8
4335044d mov      ecx, dword ptr [0x4346db1c]
43350453 cmp      ecx, -1
43350456 je       0x43350496
43350458 mov      eax, dword ptr [0x4346a890]
4335045d push     ecx
4335045e mov      eax, dword ptr [eax]
43350460 mov      edx, dword ptr [eax + 0x10]
43350463 mov      eax, esp
43350465 mov      dword ptr [eax], ecx
43350467 mov      ecx, dword ptr [0x4346a890]
4335046d call     edx
4335046f cmp      eax, esi
43350471 jne      0x43350496
43350473 mov      edx, dword ptr [esp + 0x34]
43350477 and      edx, 0x3f
4335047a push     0x1f
4335047c mov      ecx, edx
4335047e shr      edx, 5
43350481 pop      eax
43350482 and      ecx, eax
43350484 xor      eax, eax
43350486 inc      eax
43350487 shl      eax, cl
43350489 mov      ecx, dword ptr [esp + 0x1c]
4335048d test     dword ptr [ecx + edx*4 + 0x1a4], eax
43350494 je       0x433504b5
43350496 xor      eax, eax
43350498 lea      ecx, [eax + 1]
4335049b mov      dword ptr [esp + 0x70], ecx
4335049f mov      dword ptr [esp + 0x124], ecx
433504a6 jmp      0x433504b5
433504a8 xor      eax, eax
433504aa mov      dword ptr [esp + 0x70], eax
433504ae mov      dword ptr [esp + 0x124], eax
433504b5 mov      eax, dword ptr [esp + 0x138]
433504bc mov      dword ptr [esp + 0x4c], eax
433504c0 cmp      eax, 0x64
433504c3 jl       0x433504fc
433504c5 mov      dword ptr [esp + 0x38], 0x6d2cfbd5
433504cd mov      edx, esi
433504cf mov      eax, dword ptr [esp + 0x38]
433504d3 mov      ecx, dword ptr [esi]
433504d5 inc      eax
433504d6 xor      eax, 0x4a674016
433504db mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
433504e2 mov      dword ptr [esp + 0x618], ecx
433504e9 call     0x433e533f
433504ee mov      ecx, dword ptr [esp + 0x4c]
433504f2 add      ecx, -0x64
433504f5 add      ecx, eax
433504f7 jmp      0x433506d3
433504fc test     eax, eax
433504fe jne      0x4335069e
43350504 mov      edx, dword ptr [esp + 0x54]
43350508 mov      dword ptr [esp + 0x38], 0xe3852753
43350510 mov      eax, dword ptr [esp + 0x38]
43350514 add      eax, 0x1c7af3bd
43350519 mov      ecx, dword ptr [edx]
4335051b ror      eax, 2
4335051e push     0
43350520 mov      ecx, dword ptr [eax + ecx]
43350523 mov      dword ptr [esp + 0x618], ecx
4335052a call     0x433e533f
4335052f mov      dword ptr [esp + 0x38], 0x6d2cfbd5
43350537 mov      edx, esi
43350539 mov      eax, dword ptr [esp + 0x38]
4335053d mov      ecx, dword ptr [esi]
4335053f inc      eax
43350540 xor      eax, 0x4a674016
43350545 fstp     dword ptr [esp + 0x24]
43350549 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
43350550 mov      dword ptr [esp + 0x610], ecx
43350557 call     0x433e533f
4335055c mov      esi, dword ptr [esp + 0x1c]
43350560 inc      eax
43350561 push     0xa
43350563 pop      ecx
43350564 cmp      eax, ecx
43350566 cmovg    ecx, eax
43350569 test     byte ptr [esi + 0x170], 4
43350570 movd     xmm0, ecx
43350574 cvtdq2ps xmm0, xmm0
43350577 mulss    xmm0, dword ptr [esp + 0x24]
4335057d movss    dword ptr [esp + 0x50], xmm0
43350583 jne      0x43350593
43350585 mulss    xmm0, dword ptr [0x4347268c]
4335058d movss    dword ptr [esp + 0x50], xmm0
43350593 mov      edx, dword ptr [esp + 0x54]
43350597 mov      dword ptr [esp + 0x38], 0x289d6d8d
4335059f mov      eax, dword ptr [esp + 0x38]
433505a3 mov      ecx, dword ptr [edx]
433505a5 sub      ecx, eax
433505a7 mov      ecx, dword ptr [ecx + 0x289d7449]
433505ad mov      dword ptr [esp + 0x60c], ecx
433505b4 call     0x433e533f
433505b9 movss    xmm0, dword ptr [esp + 0x50]
433505bf movd     xmm1, eax
433505c3 cvtdq2ps xmm1, xmm1
433505c6 subss    xmm1, dword ptr [esp + 0x68]
433505cc call     0x43367633
433505d1 movss    xmm1, dword ptr [esp + 0x68]
433505d7 call     0x4332fc35
433505dc addss    xmm0, dword ptr [esp + 0x90]
433505e5 mov      edx, dword ptr [esp + 0x18]
433505e9 mov      dword ptr [esp + 0x38], 0x6d2cfbd5
433505f1 cvttss2si eax, xmm0
433505f5 mov      dword ptr [esp + 0x4c], eax
433505f9 mov      dword ptr [esp + 0x138], eax
43350600 mov      eax, dword ptr [esp + 0x38]
43350604 mov      ecx, dword ptr [edx]
43350606 inc      eax
43350607 xor      eax, 0x4a674016
4335060c mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
43350613 mov      dword ptr [esp + 0x608], ecx
4335061a call     0x433e533f
4335061f mov      ecx, dword ptr [esp + 0x4c]
43350623 test     ecx, ecx
43350625 jg       0x43350631
43350627 mov      dword ptr [esp + 0x50], 0x7fffffff
4335062f jmp      0x4335064d
43350631 dec      eax
43350632 add      eax, ecx
43350634 cdq      
43350635 idiv     ecx
43350637 xor      edx, edx
43350639 inc      edx
4335063a cmp      eax, edx
4335063c mov      ecx, edx
4335063e cmovg    ecx, eax
43350641 mov      dword ptr [esp + 0x50], ecx
43350645 cmp      ecx, edx
43350647 jle      0x433506e2
4335064d mov      edx, dword ptr [esp + 0x18]
43350651 mov      dword ptr [esp + 0x38], 0x6d2cfbd5
43350659 mov      eax, dword ptr [esp + 0x38]
4335065d inc      eax
4335065e mov      ecx, dword ptr [edx]
43350660 xor      eax, 0x4a674016
43350665 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
4335066c mov      dword ptr [esp + 0x604], ecx
43350673 call     0x433e533f
43350678 cdq      
43350679 idiv     dword ptr [esp + 0x50]
4335067d push     3
4335067f shl      eax, 2
43350682 pop      ecx
43350683 cdq      
43350684 idiv     ecx
43350686 lea      ecx, [eax + 1]
43350689 cmp      ecx, dword ptr [esp + 0x4c]
4335068d jge      0x433506e2
4335068f mov      eax, ecx
43350691 mov      dword ptr [esp + 0x4c], eax
43350695 mov      dword ptr [esp + 0x138], eax
4335069c jmp      0x433506e2
4335069e mov      dword ptr [esp + 0x38], 0x6d2cfbd5
433506a6 mov      edx, esi
433506a8 mov      eax, dword ptr [esp + 0x38]
433506ac mov      ecx, dword ptr [esi]
433506ae inc      eax
433506af xor      eax, 0x4a674016
433506b4 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
433506bb mov      dword ptr [esp + 0x600], ecx
433506c2 call     0x433e533f
433506c7 mov      ecx, dword ptr [esp + 0x4c]
433506cb add      eax, 5
433506ce cmp      eax, ecx
433506d0 cmovl    ecx, eax
433506d3 mov      esi, dword ptr [esp + 0x1c]
433506d7 mov      dword ptr [esp + 0x138], ecx
433506de mov      dword ptr [esp + 0x4c], ecx
433506e2 mov      ecx, dword ptr [esp + 0x134]
433506e9 movss    xmm0, dword ptr [0x43472c90]
433506f1 mov      edx, dword ptr [esp + 0x128]
433506f8 mov      dword ptr [esp + 0x3c], ecx
433506fc mov      dword ptr [esp + 0x74], edx
43350700 movss    dword ptr [esp + 0x50], xmm0
43350706 test     ecx, ecx
43350708 je       0x43350b09
4335070e mov      eax, dword ptr [0x43467d78]
43350713 mov      ecx, dword ptr [esp + 0x18]
43350717 movss    xmm5, dword ptr [esp + 0x2c]
4335071d movss    xmm6, dword ptr [esp + 0x22c]
43350726 mov      eax, dword ptr [eax]
43350728 movaps   xmm4, xmm6
4335072b xor      eax, dword ptr [0x43467b80]
43350731 xor      eax, 0x1caaf0a8
43350736 test     byte ptr [esi + 0x170], 4
4335073d movss    xmm3, dword ptr [eax + ecx + 0xc]
43350743 movaps   xmm2, xmm3
43350746 subss    xmm2, xmm5
4335074a mulss    xmm2, dword ptr [0x434703c4]
43350752 subss    xmm4, xmm2
43350756 movss    dword ptr [esp + 0x64], xmm4
4335075c jne      0x4335077a
4335075e movaps   xmm1, xmm6
43350761 movaps   xmm0, xmm4
43350764 call     0x43367633
43350769 movss    xmm2, dword ptr [esp + 0x130]
43350772 movaps   xmm4, xmm0
43350775 jmp      0x43350aed
4335077a mov      eax, dword ptr [esi + 0xc4]
43350780 cmp      eax, 0x18
43350783 jne      0x43350a89
43350789 mov      eax, dword ptr [0x434670cc]
4335078e mov      esi, dword ptr [eax]
43350790 xor      esi, dword ptr [0x43468bcc]
43350796 xor      esi, 0xa9ee6062
4335079c add      esi, ecx
4335079e mov      ecx, dword ptr [0x43475808]
433507a4 mov      eax, dword ptr [ecx]
433507a6 call     dword ptr [eax + 0x28]
433507a9 movss    xmm0, dword ptr [esi]
433507ad movss    xmm1, dword ptr [esi + 4]
433507b2 movss    xmm2, dword ptr [esi + 8]
433507b7 subss    xmm2, dword ptr [eax + 8]
433507bc subss    xmm0, dword ptr [eax]
433507c0 subss    xmm1, dword ptr [eax + 4]
433507c5 mov      eax, dword ptr [0x43467d78]
433507ca mov      esi, dword ptr [esp + 0x1c]
433507ce mov      ecx, dword ptr [esp + 0x18]
433507d2 movss    dword ptr [esp + 0x60], xmm2
433507d8 mov      eax, dword ptr [eax]
433507da xor      eax, dword ptr [0x43467b80]
433507e0 xor      eax, 0x1caaf0a8
433507e5 add      eax, ecx
433507e7 test     dword ptr [esi + 0x170], 0x200
433507f1 mov      dword ptr [esp + 0x24], eax
433507f5 je       0x43350a22
433507fb mov      eax, dword ptr [0x43468ea4]
43350800 xor      eax, 0xfcd2da7a
43350805 jmp      0x43350809
43350807 mov      eax, edx
43350809 mov      edx, dword ptr [eax + 0x1c]
4335080c cmp      eax, edx
4335080e jne      0x43350807
43350810 cmp      dword ptr [eax + 0x30], eax
43350813 je       0x43350a22
43350819 call     0x433fd30d
4335081e mov      edx, dword ptr [esp + 0x18]
43350822 test     eax, eax
43350824 je       0x43350865
43350826 mov      ecx, dword ptr [eax]
43350828 mov      eax, dword ptr [0x43468240]
4335082d mov      eax, dword ptr [eax]
4335082f xor      eax, dword ptr [0x4346a84c]
43350835 xor      eax, 0xc2b6fb10
4335083a imul     eax, dword ptr [eax + edx], 0xc
4335083e add      eax, dword ptr [ecx + 0xb0]
43350844 add      eax, ecx
43350846 mov      dword ptr [esp + 0x38], eax
4335084a je       0x43350865
4335084c mov      ecx, dword ptr [esp + 0x38]
43350850 xor      eax, eax
43350852 cmp      dword ptr [ecx + 4], eax
43350855 je       0x43350865
43350857 mov      eax, dword ptr [ecx + 8]
4335085a add      eax, 0x44
4335085d add      eax, ecx
4335085f je       0x43350865
43350861 mov      ecx, dword ptr [eax]
43350863 jmp      0x43350868
43350865 or       ecx, 0xffffffff
43350868 mov      eax, dword ptr [0x43469064]
4335086d imul     ecx, ecx, 0x30
43350870 mov      eax, dword ptr [eax]
43350872 xor      eax, dword ptr [0x4346a484]
43350878 xor      eax, 0x17978090
4335087d add      ecx, dword ptr [eax + edx]
43350880 movss    xmm1, dword ptr [ecx]
43350884 movss    xmm0, dword ptr [ecx + 0x10]
43350889 movss    dword ptr [esp + 0x864], xmm0
43350892 mulss    xmm0, xmm0
43350896 movss    dword ptr [esp + 0x860], xmm1
4335089f mulss    xmm1, xmm1
433508a3 addss    xmm1, xmm0
433508a7 movaps   xmm0, xmm1
433508aa xorps    xmm1, xmm1
433508ad sqrtss   xmm0, xmm0
433508b1 movss    dword ptr [esp + 0x5fc], xmm0
433508ba cvtss2sd xmm1, xmm0
433508be movss    xmm0, dword ptr [ecx + 0x20]
433508c3 xorps    xmm0, xmmword ptr [esp + 0xf0]
433508cb cvtss2sd xmm0, xmm0
433508cf call     0x77509ee0
433508d4 xorps    xmm2, xmm2
433508d7 cvtsd2ss xmm2, xmm0
433508db mulss    xmm2, dword ptr [esp + 0xa4]
433508e4 addss    xmm2, dword ptr [esp + 0x110]
433508ed ucomiss  xmm2, xmm2
433508f0 movss    dword ptr [esp + 0x38], xmm2
433508f6 lahf     
433508f7 test     ah, 0x44
433508fa jnp      0x43350907
433508fc movss    xmm5, dword ptr [esp + 0x2c]
43350902 movaps   xmm2, xmm5
43350905 jmp      0x43350960
43350907 movss    xmm1, dword ptr [esp + 0xb0]
43350910 movaps   xmm0, xmm2
43350913 andps    xmm0, xmm1
43350916 comiss   xmm0, dword ptr [esp + 0xec]
4335091e jbe      0x4335095a
43350920 movaps   xmm0, xmm2
43350923 divss    xmm0, dword ptr [esp + 0x8c]
4335092c andps    xmm0, xmm1
4335092f call     0x4341ad12
43350934 movss    xmm2, dword ptr [esp + 0x38]
4335093a movss    xmm5, dword ptr [esp + 0x2c]
43350940 comiss   xmm5, xmm2
43350943 mulss    xmm0, dword ptr [esp + 0x8c]
4335094c jbe      0x43350954
4335094e addss    xmm2, xmm0
43350952 jmp      0x43350960
43350954 subss    xmm2, xmm0
43350958 jmp      0x43350960
4335095a movss    xmm5, dword ptr [esp + 0x2c]
43350960 movss    xmm1, dword ptr [0x43470378]
43350968 movaps   xmm0, xmm5
4335096b mov      eax, dword ptr [esp + 0x24]
4335096f subss    xmm2, xmm1
43350973 movaps   xmm3, xmm2
43350976 movss    xmm2, dword ptr [esp + 0x90]
4335097f maxss    xmm3, xmm0
43350983 movaps   xmm0, xmm1
43350986 minss    xmm3, xmm0
4335098a movss    xmm0, dword ptr [esp + 0x68]
43350990 movss    dword ptr [esp + 0x2cc], xmm3
43350999 divss    xmm3, xmm1
4335099d movss    xmm1, dword ptr [eax + 0xc]
433509a2 ucomiss  xmm1, xmm0
433509a5 lahf     
433509a6 test     ah, 0x44
433509a9 jnp      0x433509bb
433509ab subss    xmm0, xmm1
433509af subss    xmm0, xmm3
433509b3 mulss    xmm0, xmm2
433509b7 addss    xmm3, xmm0
433509bb movss    xmm0, dword ptr [esp + 0x60]
433509c1 comiss   xmm0, dword ptr [esp + 0x9c]
433509c9 movss    xmm1, dword ptr [0x434720d0]
433509d1 jbe      0x433509e2
433509d3 movaps   xmm0, xmm1
433509d6 subss    xmm0, xmm3
433509da mulss    xmm0, xmm2
433509de addss    xmm3, xmm0
433509e2 movss    xmm0, dword ptr [esp + 0x1b4]
433509eb movaps   xmm2, xmm3
433509ee movss    xmm4, dword ptr [esp + 0x64]
433509f4 maxss    xmm2, xmm0
433509f8 movaps   xmm0, xmm1
433509fb minss    xmm2, xmm0
433509ff ucomiss  xmm2, xmm2
43350a02 movss    dword ptr [esp + 0x30c], xmm2
43350a0b lahf     
43350a0c test     ah, 0x44
43350a0f jnp      0x43350aed
43350a15 movss    xmm2, dword ptr [0x4346fd8c]
43350a1d jmp      0x43350aed
43350a22 mulss    xmm1, xmm1
43350a26 mulss    xmm0, xmm0
43350a2a mulss    xmm2, xmm2
43350a2e addss    xmm0, xmm1
43350a32 xorps    xmm1, xmm1
43350a35 addss    xmm0, xmm2
43350a39 movss    xmm1, xmm0
43350a3d movss    xmm0, dword ptr [esp + 0x68]
43350a43 sqrtss   xmm1, xmm1
43350a47 movss    dword ptr [esp + 0x5f8], xmm1
43350a50 mulss    xmm1, dword ptr [esp + 0xdc]
43350a59 divss    xmm1, dword ptr [0x4346fd78]
43350a61 subss    xmm0, xmm1
43350a65 movss    xmm1, dword ptr [0x4346ed98]
43350a6d movaps   xmm2, xmm0
43350a70 movss    xmm0, dword ptr [esp + 0x50]
43350a76 maxss    xmm2, xmm1
43350a7a minss    xmm2, xmm0
43350a7e movss    dword ptr [esp + 0x5f4], xmm2
43350a87 jmp      0x43350abd
43350a89 dec      eax
43350a8a push     2
43350a8c movd     xmm1, eax
43350a90 cvtdq2ps xmm1, xmm1
43350a93 pop      eax
43350a94 mulss    xmm1, dword ptr [esp + 0x168]
43350a9d movaps   xmm2, xmm1
43350aa0 cmp      edx, eax
43350aa2 je       0x43350ac5
43350aa4 comiss   xmm3, dword ptr [0x434701c8]
43350aab jb       0x43350ac5
43350aad movss    xmm0, dword ptr [0x4346fd8c]
43350ab5 call     0x43367633
43350aba movaps   xmm2, xmm0
43350abd movss    xmm4, dword ptr [esp + 0x64]
43350ac3 jmp      0x43350aed
43350ac5 mov      eax, dword ptr [0x4346a8e4]
43350aca mov      eax, dword ptr [eax]
43350acc xor      eax, dword ptr [0x434688cc]
43350ad2 xor      eax, 0x36375c23
43350ad7 movss    xmm0, dword ptr [eax + ecx + 8]
43350add ucomiss  xmm0, xmm5
43350ae0 lahf     
43350ae1 test     ah, 0x44
43350ae4 jnp      0x43350aed
43350ae6 mulss    xmm1, xmm6
43350aea movaps   xmm2, xmm1
43350aed movaps   xmm1, xmm4
43350af0 movaps   xmm0, xmm2
43350af3 call     0x43367633
43350af8 mov      edx, dword ptr [esp + 0x74]
43350afc mov      ecx, dword ptr [esp + 0x3c]
43350b00 movss    dword ptr [esp + 0x130], xmm0
43350b09 mov      eax, dword ptr [0x434670cc]
43350b0e mov      eax, dword ptr [eax]
43350b10 xor      eax, dword ptr [0x43468bcc]
43350b16 xor      eax, 0xa9ee6062
43350b1b add      eax, dword ptr [esp + 0x18]
43350b1f movss    xmm1, dword ptr [eax]
43350b23 movss    xmm2, dword ptr [eax + 4]
43350b28 subss    xmm2, dword ptr [edi + 0x110]
43350b30 subss    xmm1, dword ptr [edi + 0x10c]
43350b38 movss    xmm0, dword ptr [eax + 8]
43350b3d subss    xmm0, dword ptr [edi + 0x114]
43350b45 mulss    xmm2, xmm2
43350b49 mulss    xmm1, xmm1
43350b4d mulss    xmm0, xmm0
43350b51 addss    xmm2, xmm1
43350b55 addss    xmm2, xmm0
43350b59 comiss   xmm2, dword ptr [0x43472b3c]
43350b60 jbe      0x43350b8c
43350b62 and      ecx, 0xfffffd0f
43350b68 mov      dword ptr [esp + 0x3c], ecx
43350b6c mov      dword ptr [esp + 0x134], ecx
43350b73 cmp      edx, 0x200
43350b79 je       0x43350b8c
43350b7b and      edx, 0xfffffdff
43350b81 mov      dword ptr [esp + 0x74], edx
43350b85 mov      dword ptr [esp + 0x128], edx
43350b8c comiss   xmm2, dword ptr [0x43472008]
43350b93 jbe      0x43350ba6
43350b95 and      ecx, 0xfffffdff
43350b9b mov      dword ptr [esp + 0x3c], ecx
43350b9f mov      dword ptr [esp + 0x134], ecx
43350ba6 mov      eax, dword ptr [0x4346a314]
43350bab mov      ecx, 0x4346a300
43350bb0 mov      eax, dword ptr [eax*4 + 0x434721c4]
43350bb7 call     eax
43350bb9 mov      byte ptr [esp + 0x5b], al
43350bbd mov      eax, dword ptr [esp + 0x34]
43350bc1 test     eax, eax
43350bc3 jne      0x43350bd1
43350bc5 dec      esp
43350bc6 inc      edi
43350bc7 insb     byte ptr es:[edi], dx
43350bc8 cmp      edx, esi
43350bca dec      esi
43350bcb xchg     ebp, eax
43350bcc retf     
43350bd1 mov      ecx, eax
43350bd3 call     0x433b8a2b
43350bd8 mov      ecx, eax
43350bda xor      edx, edx
43350bdc inc      edx
43350bdd mov      dword ptr [esp + 0x38], ecx
43350be1 mov      eax, dword ptr [ecx + 0xf8]
43350be7 test     eax, eax
43350be9 jle      0x43350c02
43350beb test     byte ptr [esi + 0x170], 9
43350bf2 mov      byte ptr [esp + 0x145], dl
43350bf9 jne      0x43350c02
43350bfb dec      eax
43350bfc mov      dword ptr [ecx + 0xf8], eax
43350c02 mov      eax, dword ptr [esp + 0x34]
43350c06 shl      eax, 5
43350c09 mov      dword ptr [esp + 0x34], eax
43350c0d mov      eax, dword ptr [eax + 0x4347be18]
43350c13 sub      eax, 1
43350c16 je       0x43350c34
43350c18 sub      eax, 1
43350c1b je       0x43350c2b
43350c1d sub      eax, 1
43350c20 jne      0x43350c3c
43350c22 mov      byte ptr [esp + 0x145], dl
43350c29 jmp      0x43350c43
43350c2b mov      byte ptr [esp + 0x145], dl
43350c32 jmp      0x43350c3c
43350c34 mov      byte ptr [esp + 0x145], 0
43350c3c cmp      byte ptr [esp + 0x5b], 0
43350c41 je       0x43350cae
43350c43 mov      ecx, dword ptr [esp + 0x54]
43350c47 test     ecx, ecx
43350c49 jne      0x43350c57
43350c4b test     eax, 0xcb65691d
43350c50 aam      0x32
43350c52 add      al, 0xad
43350c54 cmp      ch, byte ptr [esi + 0x2b]
43350c57 test     dword ptr [esi + 0x170], 0x400
43350c61 je       0x43350c7e
43350c63 mov      eax, dword ptr [0x4346908c]
43350c68 push     0x1f
43350c6a pop      edx
43350c6b mov      eax, dword ptr [eax]
43350c6d xor      eax, dword ptr [0x43468ba0]
43350c73 xor      eax, 0x5c9f0fbb
43350c78 cmp      word ptr [eax + ecx], dx
43350c7c jne      0x43350cae
43350c7e mov      edx, dword ptr [esp + 0x12c]
43350c85 mov      ecx, dword ptr [esp + 0x74]
43350c89 push     0xc
43350c8b pop      eax
43350c8c and      edx, eax
43350c8e and      ecx, eax
43350c90 mov      eax, edx
43350c92 mov      dword ptr [esp + 0x12c], edx
43350c99 or       eax, ecx
43350c9b push     0xc
43350c9d pop      eax
43350c9e cmove    ecx, eax
43350ca1 mov      dword ptr [esp + 0x74], ecx
43350ca5 mov      dword ptr [esp + 0x128], ecx
43350cac jmp      0x43350cb9
43350cae mov      ecx, dword ptr [esp + 0x74]
43350cb2 mov      edx, dword ptr [esp + 0x12c]
43350cb9 mov      eax, dword ptr [esp + 0x34]
43350cbd cmp      dword ptr [eax + 0x4347be1c], 0
43350cc4 je       0x43350ce5
43350cc6 cmp      dword ptr [eax + 0x4347be1c], 2
43350ccd jne      0x43350ce5
43350ccf or       edx, ecx
43350cd1 xor      ecx, ecx
43350cd3 mov      dword ptr [esp + 0x12c], edx
43350cda mov      dword ptr [esp + 0x74], ecx
43350cde mov      dword ptr [esp + 0x128], ecx
43350ce5 test     ecx, ecx
43350ce7 jne      0x43350cfa
43350ce9 test     edx, edx
43350ceb je       0x43350cfa
43350ced and      edx, 0xfffffdff
43350cf3 mov      dword ptr [esp + 0x12c], edx
43350cfa cmp      byte ptr [eax + 0x4347be0e], 0
43350d01 je       0x43350d97
43350d07 cmp      byte ptr [0x43468f78], 0
43350d0e je       0x43350d97
43350d14 mov      eax, ecx
43350d16 and      eax, 0xc
43350d19 cmp      al, 0xc
43350d1b jne      0x43350d97
43350d1d mov      eax, dword ptr [esp + 0x38]
43350d21 movss    xmm0, dword ptr [esp + 0x90]
43350d2a comiss   xmm0, dword ptr [eax + 0x51c]
43350d31 jbe      0x43350d97
43350d33 mov      eax, dword ptr [0x434688b0]
43350d38 mov      ecx, dword ptr [esp + 0x18]
43350d3c mov      eax, dword ptr [eax]
43350d3e xor      eax, dword ptr [0x4346a518]
43350d44 xor      eax, 0x8b5586f6
43350d49 cmp      dword ptr [eax + ecx], 2
43350d4d jne      0x43350d97
43350d4f mov      eax, dword ptr [0x434679f8]
43350d54 mov      eax, dword ptr [eax]
43350d56 xor      eax, dword ptr [0x434675f8]
43350d5c xor      eax, 0x3309c0cf
43350d61 movss    xmm0, dword ptr [eax + ecx]
43350d66 comiss   xmm0, dword ptr [esp + 0x50]
43350d6b jb       0x43350d97
43350d6d mov      eax, dword ptr [0x434688d0]
43350d72 mov      eax, dword ptr [eax]
43350d74 xor      eax, dword ptr [0x43468c24]
43350d7a xor      eax, 0xe2fbe695
43350d7f test     byte ptr [eax + ecx], 1
43350d83 je       0x43350d97
43350d85 mov      eax, dword ptr [esp + 0x3c]
43350d89 and      eax, 0xfffffff7
43350d8c mov      dword ptr [esp + 0x3c], eax
43350d90 mov      dword ptr [esp + 0x134], eax
43350d97 cmp      dword ptr [esp + 0x54], 0
43350d9c jne      0x43350daa
43350d9e popfd    
43350d9f adc      edx, dword ptr [ebx + 0x1b7b46f0]
43350da5 cmp      eax, 0xf7b8f893
43350daa test     dword ptr [esi + 0x170], 0x400
43350dab xchg     byte ptr [eax + 1], dh
43350dae add      byte ptr [eax], al
43350db0 add      byte ptr [eax + eax], al
43350db3 add      byte ptr [esp + ebx*2 - 0x5f], dh
43350db4 je       0x43350e12
43350db6 mov      eax, dword ptr [0x4346908c]
43350db7 mov      word ptr [eax + 0x7c8b4346], ss
43350dbb mov      edi, dword ptr [esp + 0x54]
43350dbd and      al, 0x54
43350dbf push     0x1f
43350dc1 pop      ecx
43350dc2 mov      eax, dword ptr [eax]
43350dc4 xor      eax, dword ptr [0x43468ba0]
43350dca xor      eax, 0x5c9f0fbb
43350dcf cmp      word ptr [eax + edi], cx
43350dd3 mov      edi, dword ptr [esp + 0x14]
43350dd7 mov      ecx, dword ptr [esp + 0x74]
43350ddb je       0x43350e12
43350ddd push     2
43350ddf pop      eax
43350de0 and      ecx, eax
43350de2 mov      byte ptr [esp + 0x145], 0
43350dea and      edx, eax
43350dec mov      dword ptr [esp + 0x128], ecx
43350df3 mov      eax, dword ptr [esp + 0x3c]
43350df7 push     2
43350df9 pop      ecx
43350dfa and      eax, ecx
43350dfc mov      dword ptr [esp + 0x12c], edx
43350e03 mov      dword ptr [esp + 0x134], eax
43350e0a mov      byte ptr [esp + 0x147], 0
43350e12 lea      ecx, [esp + 0x32c]
43350e19 call     0x43367f7b
43350e1e cmp      byte ptr [esp + 0x146], 0
43350e26 je       0x43351547
43350e2c test     dword ptr [edi], 0x400
43350e32 je       0x43351547
43350e38 push     3
43350e3a pop      eax
43350e3b test     byte ptr [esi + 0x170], al
43350e41 jne      0x43351547
43350e47 test     byte ptr [0x434759c0], 8
43350e4e jne      0x43351547
43350e54 mov      ecx, dword ptr [esp + 0x108]
43350e5b mov      eax, dword ptr [ecx]
43350e5d call     dword ptr [eax + 0x28]
43350e60 test     eax, eax
43350e62 jne      0x43350e70
43350e64 rcr      byte ptr [ecx - 0x6d], 0xf
43350e68 lodsd    eax, dword ptr [esi]
43350e69 push     ss
43350e6a mov      edi, 0x41bdf92b
43350e6f cli      
43350e70 mov      ecx, eax
43350e72 call     0x433b8a2b
43350e77 mov      ecx, eax
43350e79 cmp      dword ptr [ecx + 0x5d8], 0
43350e80 je       0x43351547
43350e86 test     dword ptr [edi], 0x8000000
43350e8c jne      0x43351547
43350e92 cmp      dword ptr [edi + 0xd8], 0x40
43350e99 jne      0x43350eaa
43350e9b xor      eax, eax
43350e9d inc      eax
43350e9e test     byte ptr [esi + 0x174], al
43350ea4 je       0x43351547
43350eaa test     dword ptr [edi], 0x102000
43350eb0 jne      0x43351547
43350eb6 test     dword ptr [edi], 0x40000
43350ebc je       0x43351547
43350ec2 test     dword ptr [edi], 0x4000
43350ec8 jne      0x43351547
43350ece movss    xmm0, dword ptr [0x4346eeb0]
43350ed6 comiss   xmm0, dword ptr [edi + 0xc0]
43350edd jbe      0x43350eec
43350edf test     dword ptr [edi + 0x44], 0x618
43350ee6 je       0x43351547
43350eec and      dword ptr [esp + 0x404], 0
43350ef4 mov      eax, 0x600400b
43350ef9 and      dword ptr [esp + 0x408], 0
43350f01 and      dword ptr [esp + 0x40c], 0
43350f09 and      dword ptr [esp + 0x410], 0
43350f11 and      dword ptr [esp + 0x414], 0
43350f19 and      dword ptr [esp + 0x1170], 0
43350f21 push     0x10a0
43350f26 mov      dword ptr [esp + 0x41c], eax
43350f2d mov      dword ptr [esp + 0x420], eax
43350f34 push     0x1f
43350f36 mov      dword ptr [esp + 0x408], 0x43470404
43350f41 mov      dword ptr [esp + 0x428], 0x3f800000
43350f4c mov      eax, dword ptr [ecx + 0x5d4]
43350f52 pop      edx
43350f53 and      eax, edx
43350f55 push     dword ptr [ecx + eax*4 + 0x5dc]
43350f5c lea      eax, [esp + 0x1178]
43350f63 push     eax
43350f64 call     0x774fd4a0
43350f69 mov      edx, dword ptr [esp + 0x24]
43350f6d lea      eax, [esp + 0x117c]
43350f74 add      esp, 0xc
43350f77 mov      ecx, edi
43350f79 push     eax
43350f7a call     0x43327659
43350f7f xor      eax, eax
43350f81 lea      ecx, [esp + 0xb68]
43350f88 inc      eax
43350f89 push     eax
43350f8a push     dword ptr [edi + 0xc]
43350f8d call     0x433eb28b
43350f92 movss    xmm0, dword ptr [esp + 0x11a0]
43350f9b lea      esi, [esp + 0x238]
43350fa2 mov      eax, dword ptr [0x43475808]
43350fa7 lea      edi, [esp + 0x630]
43350fae movss    dword ptr [esp + 0x238], xmm0
43350fb7 lea      ecx, [esp + 0xb68]
43350fbe movss    xmm0, dword ptr [esp + 0x11a4]
43350fc7 mov      edx, dword ptr [esp + 0xd4]
43350fce movss    dword ptr [esp + 0x23c], xmm0
43350fd7 movss    xmm0, dword ptr [esp + 0x1188]
43350fe0 mulss    xmm0, dword ptr [esp + 0x90]
43350fe9 push     ecx
43350fea lea      ecx, [esp + 0x404]
43350ff1 mov      dword ptr [esp + 0x7c], eax
43350ff5 push     ecx
43350ff6 addss    xmm0, dword ptr [esp + 0x11b0]
43350fff lea      ecx, [esp + 0x638]
43351006 push     ecx
43351007 mov      ecx, eax
43351009 movss    dword ptr [esp + 0x24c], xmm0
43351012 movsd    dword ptr es:[edi], dword ptr [esi]
43351013 movsd    dword ptr es:[edi], dword ptr [esi]
43351014 movsd    dword ptr es:[edi], dword ptr [esi]
43351015 call     0x43329d2b
4335101a cmp      dword ptr [esp + 0xbe8], 0
43351022 mov      esi, dword ptr [esp + 0x18]
43351026 je       0x43351541
4335102c mov      dword ptr [esp + 0x38], 0x6d2cfbd5
43351034 mov      edx, esi
43351036 mov      eax, dword ptr [esp + 0x38]
4335103a mov      ecx, dword ptr [esi]
4335103c inc      eax
4335103d xor      eax, 0x4a674016
43351042 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
43351049 mov      dword ptr [esp + 0x5f0], ecx
43351050 call     0x433e533f
43351055 push     3
43351057 mov      edi, eax
43351059 lea      ecx, [esp + 0xb6c]
43351060 pop      eax
43351061 push     eax
43351062 push     esi
43351063 mov      dword ptr [esp + 0x3c], edi
43351067 call     0x433e9ecd
4335106c mov      ecx, eax
4335106e mov      dword ptr [esp + 0x60], ecx
43351072 test     ecx, ecx
43351074 jg       0x43351080
43351076 mov      dword ptr [esp + 0x64], 0x7fffffff
4335107e jmp      0x4335109e
43351080 lea      eax, [edi - 1]
43351083 add      eax, ecx
43351085 cdq      
43351086 idiv     ecx
43351088 xor      edx, edx
4335108a inc      edx
4335108b cmp      eax, edx
4335108d mov      ecx, edx
4335108f cmovg    ecx, eax
43351092 mov      dword ptr [esp + 0x64], ecx
43351096 cmp      ecx, edx
43351098 jle      0x43351541
4335109e mov      edi, dword ptr [esp + 0x14]
433510a2 lea      eax, [esp + 0x260]
433510a9 push     0
433510ab push     eax
433510ac lea      edx, [esp + 0x274]
433510b3 lea      ecx, [edi + 0x118]
433510b9 call     0x43366128
433510be movss    xmm4, dword ptr [esp + 0x26c]
433510c7 movss    xmm5, dword ptr [esp + 0x270]
433510d0 movaps   xmm1, xmm4
433510d3 movss    xmm6, dword ptr [esp + 0x2c]
433510d9 movaps   xmm0, xmm5
433510dc mulss    xmm1, xmm4
433510e0 mov      eax, dword ptr [esp + 0x28]
433510e4 mulss    xmm0, xmm5
433510e8 mov      ecx, dword ptr [esp + 0x78]
433510ec movss    xmm2, dword ptr [esp + 0x260]
433510f5 movss    xmm3, dword ptr [esp + 0x264]
433510fe addss    xmm1, xmm0
43351102 movaps   xmm0, xmm6
43351105 mulss    xmm0, xmm6
43351109 addss    xmm1, xmm0
4335110d movaps   xmm0, xmm1
43351110 movss    xmm1, dword ptr [esp + 0x68]
43351116 sqrtss   xmm0, xmm0
4335111a movss    dword ptr [esp + 0x5ec], xmm0
43351123 addss    xmm0, dword ptr [esp + 0x94]
4335112c divss    xmm1, xmm0
43351130 movaps   xmm0, xmm3
43351133 mulss    xmm4, xmm1
43351137 mulss    xmm5, xmm1
4335113b mulss    xmm1, xmm6
4335113f mulss    xmm0, xmm3
43351143 movss    dword ptr [esp + 0x274], xmm1
4335114c movaps   xmm1, xmm2
4335114f mulss    xmm1, xmm2
43351153 movss    dword ptr [esp + 0x26c], xmm4
4335115c movss    dword ptr [esp + 0x270], xmm5
43351165 addss    xmm1, xmm0
43351169 movaps   xmm0, xmm6
4335116c mulss    xmm0, xmm6
43351170 addss    xmm1, xmm0
43351174 movaps   xmm0, xmm1
43351177 movss    xmm1, dword ptr [esp + 0x68]
4335117d sqrtss   xmm0, xmm0
43351181 movss    dword ptr [esp + 0x5e8], xmm0
4335118a addss    xmm0, dword ptr [esp + 0x94]
43351193 divss    xmm1, xmm0
43351197 mulss    xmm2, xmm1
4335119b mulss    xmm3, xmm1
4335119f mulss    xmm1, xmm6
433511a3 movss    dword ptr [esp + 0x260], xmm2
433511ac movss    dword ptr [esp + 0x264], xmm3
433511b5 movss    dword ptr [esp + 0x268], xmm1
433511be movss    xmm6, dword ptr [eax + 0x28]
433511c3 movss    xmm1, dword ptr [eax + 0x24]
433511c8 movaps   xmm7, xmm6
433511cb movaps   xmm0, xmm1
433511ce mulss    xmm7, xmm2
433511d2 mulss    xmm0, xmm4
433511d6 mulss    xmm6, xmm3
433511da mulss    xmm1, xmm5
433511de addss    xmm7, xmm0
433511e2 addss    xmm6, xmm1
433511e6 movss    dword ptr [esp + 0x50], xmm7
433511ec movss    dword ptr [esp + 0x84], xmm6
433511f5 call     0x4336961e
433511fa movss    xmm2, dword ptr [esp + 0x50]
43351200 movaps   xmm3, xmm0
43351203 movss    xmm1, dword ptr [esp + 0x84]
4335120c mulss    xmm2, xmm2
43351210 mulss    xmm1, xmm1
43351214 addss    xmm2, xmm1
43351218 movss    xmm1, dword ptr [esp + 0x2c]
4335121e mulss    xmm1, xmm1
43351222 addss    xmm2, xmm1
43351226 movaps   xmm0, xmm2
43351229 sqrtss   xmm0, xmm0
4335122d movss    dword ptr [esp + 0x5e4], xmm0
43351236 addss    xmm0, dword ptr [esp + 0x94]
4335123f divss    xmm3, xmm0
43351243 mov      edx, dword ptr [edi + 0xc]
43351246 mov      dword ptr [esp + 0x38], 0xe3852753
4335124e mov      eax, dword ptr [esp + 0x38]
43351252 add      eax, 0x1c7af3bd
43351257 movss    dword ptr [esp + 0x24], xmm3
4335125d mov      ecx, dword ptr [edx]
4335125f ror      eax, 2
43351262 push     0
43351264 mov      ecx, dword ptr [eax + ecx]
43351267 mov      dword ptr [esp + 0x5e4], ecx
4335126e call     0x433e533f
43351273 movss    xmm3, dword ptr [esp + 0x24]
43351279 lea      edx, [edi + 0xdc]
4335127f fmul     dword ptr [esp + 0xd0]
43351286 xor      ecx, ecx
43351288 movss    xmm0, dword ptr [edx]
4335128c movss    xmm4, dword ptr [esp + 0x50]
43351292 movss    xmm1, dword ptr [edx + 4]
43351297 movss    xmm2, dword ptr [edx + 8]
4335129c mulss    xmm4, xmm3
433512a0 or       dword ptr [esp + 0x934], 0xffffffff
433512a8 or       dword ptr [esp + 0x940], 0xffffffff
433512b0 fstp     dword ptr [esp + 0x48]
433512b4 mulss    xmm4, dword ptr [esp + 0x48]
433512ba mov      dword ptr [esp + 0x91c], 0x3f800000
433512c5 mov      word ptr [esp + 0x926], cx
433512cd mov      dword ptr [esp + 0x93c], ecx
433512d4 addss    xmm4, xmm0
433512d8 mov      dword ptr [esp + 0x710], ecx
433512df movss    xmm0, dword ptr [esp + 0x84]
433512e8 mulss    xmm0, xmm3
433512ec subss    xmm4, dword ptr [edx]
433512f0 mulss    xmm0, dword ptr [esp + 0x48]
433512f6 addss    xmm0, xmm1
433512fa movss    dword ptr [esp + 0x6e0], xmm4
43351303 movss    xmm1, dword ptr [esp + 0x2c]
43351309 mulss    xmm3, xmm1
4335130d mulss    xmm4, xmm4
43351311 mulss    xmm3, dword ptr [esp + 0x48]
43351317 subss    xmm0, dword ptr [edx + 4]
4335131c addss    xmm3, xmm2
43351320 movss    dword ptr [esp + 0x6e4], xmm0
43351329 mulss    xmm0, xmm0
4335132d subss    xmm3, dword ptr [edx + 8]
43351332 addss    xmm4, xmm0
43351336 movss    dword ptr [esp + 0x6e8], xmm3
4335133f mulss    xmm3, xmm3
43351343 addss    xmm4, xmm3
43351347 ucomiss  xmm4, xmm1
4335134a lahf     
4335134b test     ah, 0x44
4335134e jnp      0x4335135c
43351350 xor      eax, eax
43351352 inc      eax
43351353 mov      byte ptr [esp + 0x715], al
4335135a jmp      0x43351363
4335135c mov      byte ptr [esp + 0x715], cl
43351363 and      dword ptr [esp + 0x700], ecx
4335136a lea      eax, [esp + 0x8f0]
43351371 and      dword ptr [esp + 0x704], ecx
43351378 movss    xmm2, dword ptr [0x4346f1f0]
43351380 mov      byte ptr [esp + 0x714], cl
43351387 lea      ecx, [esp + 0x6d0]
4335138e mov      dword ptr [esp + 0x708], 0x40000000
43351399 movss    xmm0, dword ptr [edx]
4335139d subss    xmm0, xmm2
433513a1 push     eax
433513a2 xor      eax, eax
433513a4 movss    dword ptr [esp + 0x6d4], xmm0
433513ad movss    xmm0, dword ptr [edx + 4]
433513b2 subss    xmm0, xmm2
433513b6 movss    dword ptr [esp + 0x6d8], xmm0
433513bf movss    xmm0, dword ptr [edx + 8]
433513c4 lea      edx, [eax + 1]
433513c7 addss    xmm0, xmm1
433513cb mov      dword ptr [esp + 0x6f4], 0x41800000
433513d6 mov      dword ptr [esp + 0x6f8], 0x41800000
433513e1 mov      dword ptr [esp + 0x6fc], 0x80000000
433513ec movss    dword ptr [esp + 0x6dc], xmm0
433513f5 call     0x433f545e
433513fa mov      ecx, dword ptr [esp + 0x78]
433513fe lea      esi, [esp + 0x8fc]
43351405 lea      edi, [esp + 0x86c]
4335140c movsd    dword ptr es:[edi], dword ptr [esi]
4335140d lea      eax, [esp + 0xb68]
43351414 push     eax
43351415 lea      eax, [esp + 0x404]
4335141c push     eax
4335141d movsd    dword ptr es:[edi], dword ptr [esi]
4335141e lea      eax, [esp + 0x638]
43351425 push     eax
43351426 lea      edx, [esp + 0x878]
4335142d movsd    dword ptr es:[edi], dword ptr [esi]
4335142e call     0x43329d2b
43351433 mov      esi, dword ptr [esp + 0x18]
43351437 test     eax, eax
43351439 je       0x43351541
4335143f push     3
43351441 pop      eax
43351442 push     eax
43351443 push     esi
43351444 lea      ecx, [esp + 0xb70]
4335144b call     0x433e9ecd
43351450 mov      edi, eax
43351452 mov      dword ptr [esp + 0x50], edi
43351456 test     edi, edi
43351458 jle      0x43351541
4335145e mov      ecx, dword ptr [esp + 0x34]
43351462 lea      eax, [ecx - 1]
43351465 add      eax, edi
43351467 cdq      
43351468 idiv     edi
4335146a mov      edi, dword ptr [esp + 0x14]
4335146e xor      edx, edx
43351470 inc      edx
43351471 cmp      eax, edx
43351473 cmovg    edx, eax
43351476 mov      dword ptr [esp + 0x48], edx
4335147a cmp      dword ptr [esp + 0x64], edx
4335147e jle      0x4335154b
43351484 push     2
43351486 pop      eax
43351487 cmp      edx, eax
43351489 jl       0x433514a6
4335148b test     dword ptr [0x434759c0], 0x8000
43351495 je       0x433514a6
43351497 xor      eax, eax
43351499 inc      eax
4335149a cmp      dword ptr [edi + 0x1d4], eax
433514a0 je       0x4335154b
433514a6 mov      eax, ecx
433514a8 mov      dword ptr [esp + 0x38], ecx
433514ac cdq      
433514ad idiv     dword ptr [esp + 0x48]
433514b1 test     edx, edx
433514b3 je       0x433514bf
433514b5 mov      eax, dword ptr [esp + 0x48]
433514b9 sub      eax, edx
433514bb add      eax, ecx
433514bd jmp      0x433514c3
433514bf mov      eax, dword ptr [esp + 0x38]
433514c3 cdq      
433514c4 idiv     dword ptr [esp + 0x48]
433514c8 mov      edx, eax
433514ca cmp      edx, dword ptr [esp + 0x50]
433514ce cmovg    edx, dword ptr [esp + 0x50]
433514d3 xor      eax, eax
433514d5 inc      eax
433514d6 mov      dword ptr [esp + 0x24], edx
433514da cmp      dword ptr [edi + 0x1d4], eax
433514e0 jne      0x4335152f
433514e2 mov      edx, dword ptr [edi + 0xc]
433514e5 mov      dword ptr [esp + 0x38], 0x289d6d91
433514ed mov      eax, dword ptr [esp + 0x38]
433514f1 mov      ecx, dword ptr [edx]
433514f3 sub      ecx, eax
433514f5 mov      ecx, dword ptr [ecx + 0x289d7449]
433514fb mov      dword ptr [esp + 0x1b8], ecx
43351502 call     0x433e533f
43351507 test     al, al
43351509 je       0x4335152b
4335150b mov      eax, dword ptr [esp + 0x60]
4335150f mov      edx, dword ptr [esp + 0x50]
43351513 add      eax, edx
43351515 mov      ecx, dword ptr [esp + 0x34]
43351519 cmp      eax, ecx
4335151b jg       0x4335154b
4335151d xor      eax, eax
4335151f sub      ecx, edx
43351521 inc      eax
43351522 cmp      ecx, eax
43351524 mov      edx, eax
43351526 cmovg    edx, ecx
43351529 jmp      0x4335152f
4335152b mov      edx, dword ptr [esp + 0x24]
4335152f mov      eax, dword ptr [esp + 0x4c]
43351533 cmp      edx, eax
43351535 cmovg    eax, edx
43351538 mov      dword ptr [esp + 0x138], eax
4335153f jmp      0x4335154b
43351541 mov      edi, dword ptr [esp + 0x14]
43351545 jmp      0x4335154b
43351547 mov      esi, dword ptr [esp + 0x18]
4335154b and      dword ptr [esp + 0x34], 0
43351550 mov      eax, dword ptr [esp + 0x70]
43351554 test     eax, eax
43351556 je       0x43351754
4335155c push     dword ptr [eax*4 + 0x43474950]
43351563 mov      ecx, dword ptr [esp + 0x8c]
4335156a lea      eax, [esp + 0x330]
43351571 add      ecx, 0x5d4
43351577 mov      edx, esi
43351579 push     eax
4335157a mov      dword ptr [esp + 0x50], ecx
4335157e push     ecx
4335157f mov      ecx, edi
43351581 call     0x433aeba8
43351586 mov      ecx, dword ptr [esp + 0x32c]
4335158d mov      eax, dword ptr [esp + 0x330]
43351594 cmp      ecx, eax
43351596 je       0x433515cb
43351598 sub      eax, ecx
4335159a push     2
4335159c sar      eax, 2
4335159f pop      edx
433515a0 cmp      eax, edx
433515a2 jb       0x433515be
433515a4 push     0x433cdc5c
433515a9 push     4
433515ab push     eax
433515ac push     ecx
433515ad call     dword ptr [esp + 0xf8]
433515b4 mov      ecx, dword ptr [esp + 0x33c]
433515bb add      esp, 0x10
433515be mov      dword ptr [esp + 0x34], 4
433515c6 jmp      0x4335175b
433515cb mov      eax, dword ptr [esp + 0x88]
433515d2 cmp      dword ptr [eax + 0x5d8], 0
433515d9 je       0x43351c26
433515df mov      ecx, edi
433515e1 call     0x4337f00e
433515e6 mov      ecx, edi
433515e8 mov      esi, eax
433515ea call     0x4339438e
433515ef cmp      eax, esi
433515f1 mov      ecx, edi
433515f3 cmovl    eax, esi
433515f6 mov      dword ptr [esp + 0x60], eax
433515fa call     0x4337ea43
433515ff mov      edx, eax
43351601 xor      esi, esi
43351603 mov      eax, dword ptr [esp + 0x88]
4335160a mov      dword ptr [esp + 0x24], edx
4335160e cmp      dword ptr [eax + 0x5d8], esi
43351614 jbe      0x4335164f
43351616 mov      ecx, dword ptr [esp + 0x48]
4335161a mov      eax, dword ptr [ecx]
4335161c add      eax, esi
4335161e push     0x1f
43351620 pop      edi
43351621 and      eax, edi
43351623 mov      eax, dword ptr [ecx + eax*4 + 8]
43351627 test     dword ptr [eax + 0x5c], 0x200
4335162e mov      edi, dword ptr [eax + 0x4c]
43351631 mov      dword ptr [esp + 0x50], edi
43351635 mov      edi, dword ptr [esp + 0x14]
43351639 jne      0x4335165e
4335163b mov      eax, dword ptr [esp + 0x88]
43351642 inc      esi
43351643 cmp      esi, dword ptr [eax + 0x5d8]
43351649 mov      eax, dword ptr [ecx]
4335164b jb       0x4335161c
4335164d jmp      0x4335165e
4335164f mov      ecx, dword ptr [esp + 0x1b8]
43351656 mov      dword ptr [esp + 0x50], ecx
4335165a mov      ecx, dword ptr [esp + 0x48]
4335165e cmp      edx, dword ptr [esp + 0x50]
43351662 jl       0x43351c26
43351668 mov      eax, dword ptr [0x4346a660]
4335166d mov      esi, dword ptr [esp + 0x18]
43351671 movss    xmm0, dword ptr [0x43470418]
43351679 mov      eax, dword ptr [eax]
4335167b xor      eax, dword ptr [0x434679e0]
43351681 xor      eax, 0xb538bba5
43351686 mov      eax, dword ptr [eax + esi]
43351689 comiss   xmm0, dword ptr [eax + 0x178]
43351690 jbe      0x433516b0
43351692 mov      edx, dword ptr [esp + 0x88]
43351699 mov      ecx, esi
4335169b call     0x433e63fd
433516a0 test     al, al
433516a2 je       0x43351707
433516a4 xor      eax, eax
433516a6 inc      eax
433516a7 mov      byte ptr [esp + 0x145], al
433516ae jmp      0x43351707
433516b0 mov      eax, dword ptr [esp + 0x88]
433516b7 cmp      dword ptr [eax + 0x5d8], 0
433516be jne      0x433516c8
433516c0 mov      esi, dword ptr [eax + 0x168]
433516c6 jmp      0x433516d6
433516c8 mov      eax, dword ptr [ecx]
433516ca push     0x1f
433516cc pop      edx
433516cd and      eax, edx
433516cf mov      eax, dword ptr [ecx + eax*4 + 8]
433516d3 mov      esi, dword ptr [eax + 8]
433516d6 mov      ecx, dword ptr [0x4346a514]
433516dc mov      eax, dword ptr [ecx]
433516de call     dword ptr [eax + 0x38]
433516e1 mov      eax, dword ptr [0x43467b04]
433516e6 push     2
433516e8 pop      ecx
433516e9 fdiv     dword ptr [eax + 0x20]
433516ec fadd     dword ptr [esp + 0xac]
433516f3 fstp     dword ptr [esp + 0x38]
433516f7 cvttss2si eax, dword ptr [esp + 0x38]
433516fd sub      eax, esi
433516ff cmp      eax, ecx
43351701 jg       0x43351c26
43351707 mov      edx, dword ptr [esp + 0x24]
4335170b mov      esi, dword ptr [esp + 0x60]
4335170f cmp      edx, esi
43351711 jl       0x43351732
43351713 mov      ecx, dword ptr [esp + 0x48]
43351717 mov      eax, dword ptr [ecx]
43351719 and      eax, 0x1f
4335171c mov      eax, dword ptr [ecx + eax*4 + 8]
43351720 mov      eax, dword ptr [eax + 0x4c]
43351723 cmp      eax, esi
43351725 jge      0x4335172b
43351727 mov      edx, esi
43351729 jmp      0x43351732
4335172b cmp      eax, edx
4335172d cmovg    eax, edx
43351730 mov      edx, eax
43351732 lea      eax, [esp + 0x318]
43351739 mov      dword ptr [esp + 0x318], edx
43351740 push     eax
43351741 push     dword ptr [esp + 0x1bc]
43351748 lea      ecx, [esp + 0x334]
4335174f call     0x43419e0f
43351754 mov      ecx, dword ptr [esp + 0x32c]
4335175b mov      esi, dword ptr [esp + 0x1c]
4335175f cmp      ecx, dword ptr [esp + 0x330]
43351766 jne      0x433517fd
4335176c xor      eax, eax
4335176e inc      eax
4335176f test     byte ptr [esi + 0x170], al
43351775 jne      0x43351c26
4335177b mov      eax, dword ptr [esp + 0x88]
43351782 cmp      dword ptr [eax + 0x5d8], 0
43351789 je       0x43351c26
4335178f mov      ecx, edi
43351791 call     0x4337ea43
43351796 mov      ecx, edi
43351798 mov      dword ptr [esp + 0x38], eax
4335179c call     0x4339438e
433517a1 mov      ecx, dword ptr [esp + 0x38]
433517a5 mov      edx, eax
433517a7 cmp      ecx, edx
433517a9 jl       0x433517d4
433517ab mov      edi, dword ptr [esp + 0x88]
433517b2 mov      eax, dword ptr [edi + 0x5d4]
433517b8 and      eax, 0x1f
433517bb mov      eax, dword ptr [edi + eax*4 + 0x5dc]
433517c2 mov      eax, dword ptr [eax + 0x4c]
433517c5 cmp      eax, edx
433517c7 jge      0x433517cd
433517c9 mov      ecx, edx
433517cb jmp      0x433517d4
433517cd cmp      eax, ecx
433517cf cmovg    eax, ecx
433517d2 mov      ecx, eax
433517d4 lea      eax, [esp + 0x310]
433517db mov      dword ptr [esp + 0x310], ecx
433517e2 push     eax
433517e3 push     dword ptr [esp + 0x1bc]
433517ea lea      ecx, [esp + 0x334]
433517f1 call     0x43419e0f
433517f6 mov      ecx, dword ptr [esp + 0x32c]
433517fd mov      eax, dword ptr [esp + 0x70]
43351801 mov      edx, dword ptr [esp + 0x330]
43351808 sub      edx, ecx
4335180a sar      edx, 2
4335180d mov      eax, dword ptr [eax*4 + 0x43474950]
43351814 cmp      eax, edx
43351816 cmovb    edx, eax
43351819 and      dword ptr [esp + 0x64], 0
4335181e mov      dword ptr [esp + 0x24], edx
43351822 test     edx, edx
43351824 je       0x43351c26
4335182a imul     edi, dword ptr [esi + 0x1b8], 0x1190
43351834 mov      ecx, dword ptr [esp + 0x108]
4335183b add      edi, dword ptr [esi + 0x1c0]
43351841 mov      dword ptr [esp + 0x4c], edi
43351845 and      dword ptr [edi], 0
43351848 mov      eax, dword ptr [ecx]
4335184a call     dword ptr [eax + 0x28]
4335184d mov      edx, dword ptr [esp + 0x18]
43351851 mov      dword ptr [edi + 4], eax
43351854 mov      dword ptr [esp + 0x38], 0x6d2cfbd5
4335185c mov      eax, dword ptr [esp + 0x38]
43351860 mov      ecx, dword ptr [edx]
43351862 inc      eax
43351863 xor      eax, 0x4a674016
43351868 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
4335186f mov      dword ptr [esp + 0x174], ecx
43351876 call     0x433e533f
4335187b xor      ecx, ecx
4335187d inc      ecx
4335187e cmp      eax, ecx
43351880 jge      0x43351886
43351882 mov      eax, ecx
43351884 jmp      0x4335188e
43351886 push     0x64
43351888 pop      ecx
43351889 cmp      eax, ecx
4335188b cmovg    eax, ecx
4335188e mov      dword ptr [edi + 8], eax
43351891 lea      edx, [esp + 0x230]
43351898 or       dword ptr [esp + 0x234], 0xffffffff
433518a0 lea      ecx, [esp + 0x234]
433518a7 or       dword ptr [esp + 0x230], 0xffffffff
433518af call     0x4341f16e
433518b4 test     al, al
433518b6 je       0x433518de
433518b8 mov      eax, dword ptr [esp + 0x234]
433518bf cmp      eax, dword ptr [edi + 4]
433518c2 jne      0x433518de
433518c4 mov      eax, dword ptr [esp + 0x230]
433518cb mov      ecx, 0x3e8
433518d0 sub      dword ptr [edi + 8], eax
433518d3 mov      eax, dword ptr [edi + 8]
433518d6 test     eax, eax
433518d8 cmovle   eax, ecx
433518db mov      dword ptr [edi + 8], eax
433518de lea      ecx, [edi + 0xc]
433518e1 call     0x433318b5
433518e6 xor      edx, edx
433518e8 lea      esi, [esp + 0x124]
433518ef mov      dword ptr [edi + 0xb4], edx
433518f5 mov      dword ptr [edi + 0xb8], edx
433518fb add      edi, 0xbc
43351901 push     0xa
43351903 pop      ecx
43351904 rep movsd dword ptr es:[edi], dword ptr [esi]
43351906 mov      esi, dword ptr [esp + 0x4c]
4335190a mov      ecx, dword ptr [esp + 0x64]
4335190e mov      edi, dword ptr [esp + 0x14]
43351912 mov      dword ptr [esi + 0xe4], edx
43351918 mov      dword ptr [esi + 0xe8], edx
4335191e mov      eax, dword ptr [esp + 0x32c]
43351925 mov      eax, dword ptr [eax + ecx*4]
43351928 mov      ecx, edi
4335192a mov      dword ptr [esi + 0xb4], eax
43351930 mov      dword ptr [esp + 0x1a4], edx
43351937 mov      edx, dword ptr [esi + 4]
4335193a call     0x43383e62
4335193f test     al, al
43351941 jne      0x43351977
43351943 mov      edx, dword ptr [esp + 0x18]
43351947 lea      ecx, [esp + 0x1a4]
4335194e push     ecx
4335194f lea      eax, [esi + 0xf0]
43351955 mov      ecx, edi
43351957 push     eax
43351958 call     0x43387bce
4335195d mov      edx, esi
4335195f mov      esi, dword ptr [esp + 0x1c]
43351963 mov      eax, dword ptr [edx + 0x13c]
43351969 mov      dword ptr [edx + 0xb4], eax
4335196f or       dword ptr [edx], 4
43351972 jmp      0x43351a28
43351977 mov      esi, dword ptr [esp + 0x1c]
4335197b xor      edx, edx
4335197d inc      edx
4335197e mov      ecx, dword ptr [esi + 0x170]
43351984 mov      eax, ecx
43351986 not      eax
43351988 and      eax, edx
4335198a lea      eax, [eax*4 + 1]
43351991 mov      edx, eax
43351993 or       edx, 8
43351996 and      cl, 8
43351999 cmove    edx, eax
4335199c test     dword ptr [edi], 0x4000
433519a2 mov      dword ptr [esp + 0x38], edx
433519a6 mov      dword ptr [esp + 0x48], edx
433519aa jne      0x433519e8
433519ac mov      eax, dword ptr [0x4346db1c]
433519b1 cmp      eax, -1
433519b4 jne      0x433519c0
433519b6 mov      dword ptr [esp + 0x50], 0x1fff
433519be jmp      0x433519c7
433519c0 movzx    eax, ax
433519c3 mov      dword ptr [esp + 0x50], eax
433519c7 mov      ecx, dword ptr [esp + 0x108]
433519ce mov      dword ptr [esp + 0x48], edx
433519d2 mov      eax, dword ptr [ecx]
433519d4 call     dword ptr [eax + 0x28]
433519d7 cmp      eax, dword ptr [esp + 0x50]
433519db je       0x433519e8
433519dd mov      eax, dword ptr [esp + 0x38]
433519e1 and      eax, 0xfffffffe
433519e4 mov      dword ptr [esp + 0x48], eax
433519e8 mov      eax, dword ptr [esp + 0x4c]
433519ec lea      edx, [esp + 0x1a4]
433519f3 push     edx
433519f4 mov      edx, dword ptr [esp + 0x1c]
433519f8 lea      ecx, [eax + 0xf0]
433519fe push     ecx
433519ff push     dword ptr [esp + 0x50]
43351a03 mov      ecx, edi
43351a05 push     dword ptr [eax + 0xb4]
43351a0b call     0x4336c53b
43351a10 test     al, al
43351a12 jne      0x43351a24
43351a14 mov      eax, dword ptr [esp + 0x4c]
43351a18 or       dword ptr [eax + 0xb4], 0xffffffff
43351a1f jmp      0x43351c13
43351a24 mov      edx, dword ptr [esp + 0x4c]
43351a28 mov      eax, dword ptr [esp + 0x1a4]
43351a2f mov      ecx, dword ptr [esp + 0x34]
43351a33 mov      dword ptr [esp + 0x50], ecx
43351a37 mov      dword ptr [esp + 0x48], eax
43351a3b test     al, 0x40
43351a3d je       0x43351a65
43351a3f cmp      dword ptr [esp + 0x64], 0
43351a44 jne      0x43351c26
43351a4a xor      eax, eax
43351a4c or       ecx, 0x20
43351a4f inc      eax
43351a50 mov      dword ptr [esp + 0x50], ecx
43351a54 mov      byte ptr [edx + 0xdd], al
43351a5a mov      eax, dword ptr [esp + 0x1a4]
43351a61 mov      dword ptr [esp + 0x48], eax
43351a65 or       ecx, 8
43351a68 and      al, 0x10
43351a6a mov      eax, dword ptr [esp + 0x48]
43351a6e cmove    ecx, dword ptr [esp + 0x50]
43351a73 mov      dword ptr [esp + 0x3c], ecx
43351a77 or       dword ptr [esp + 0x3c], 0x10
43351a7c and      al, 0x20
43351a7e mov      eax, dword ptr [esp + 0x3c]
43351a82 cmove    eax, ecx
43351a85 cmp      byte ptr [edx + 0xdd], 0
43351a8c mov      dword ptr [esp + 0x3c], eax
43351a90 je       0x43351b39
43351a96 mov      eax, dword ptr [edx + 0xc0]
43351a9c or       eax, dword ptr [edx + 0xc4]
43351aa2 push     2
43351aa4 pop      ecx
43351aa5 test     cl, al
43351aa7 je       0x43351b39
43351aad xor      eax, eax
43351aaf test     byte ptr [0x4346a8d0], 2
43351ab6 mov      ecx, eax
43351ab8 je       0x43351adb
43351aba lea      esi, [edx + 0xf0]
43351ac0 test     esi, esi
43351ac2 mov      esi, dword ptr [esp + 0x1c]
43351ac6 je       0x43351adb
43351ac8 test     byte ptr [edx + 0x14c], 8
43351acf mov      edi, dword ptr [esp + 0x14]
43351ad3 cmovne   ecx, dword ptr [esp + 0x114]
43351adb test     byte ptr [0x4346a8d0], 4
43351ae2 je       0x43351afe
43351ae4 lea      esi, [edx + 0xf0]
43351aea test     esi, esi
43351aec mov      esi, dword ptr [esp + 0x1c]
43351af0 je       0x43351afe
43351af2 test     byte ptr [edx + 0x14c], 0x20
43351af9 je       0x43351afe
43351afb or       ecx, 4
43351afe test     byte ptr [0x4346a8d0], 8
43351b05 je       0x43351b25
43351b07 lea      edi, [edx + 0xf0]
43351b0d test     edi, edi
43351b0f mov      edi, dword ptr [esp + 0x14]
43351b13 je       0x43351b25
43351b15 test     byte ptr [edx + 0x14c], 0x80
43351b1c mov      esi, dword ptr [esp + 0x1c]
43351b20 je       0x43351b25
43351b22 or       ecx, 8
43351b25 mov      dword ptr [edx + 0xb8], ecx
43351b2b test     cl, 8
43351b2e je       0x43351b41
43351b30 or       dword ptr [edx + 0xc4], 2
43351b37 jmp      0x43351b41
43351b39 xor      eax, eax
43351b3b mov      dword ptr [edx + 0xb8], eax
43351b41 mov      ecx, dword ptr [edx + 0x14c]
43351b47 test     cl, cl
43351b49 js       0x43351b51
43351b4b mov      dword ptr [edx + 0xc4], eax
43351b51 and      dword ptr [edx + 0xc4], 0xfffffdff
43351b5b test     byte ptr [esp + 0x48], 0x70
43351b60 jne      0x43351b67
43351b62 test     cl, 0x20
43351b65 je       0x43351b6d
43351b67 mov      byte ptr [edx + 0xe1], al
43351b6d cmp      byte ptr [0x434683fc], 0
43351b74 je       0x43351be3
43351b76 lea      ecx, [esi + 0x1c4]
43351b7c call     0x4340c789
43351b81 test     al, al
43351b83 jne      0x43351bdf
43351b85 push     dword ptr [esp + 0x174]
43351b8c lea      ecx, [esi + 0x1c4]
43351b92 call     0x4340364b
43351b97 mov      ecx, eax
43351b99 test     ecx, ecx
43351b9b je       0x43351bdf
43351b9d lea      eax, [esi - 8]
43351ba0 mov      dword ptr [ecx], eax
43351ba2 mov      eax, dword ptr [esp + 0x28]
43351ba6 mov      dword ptr [ecx + 4], edi
43351ba9 mov      dword ptr [ecx + 8], eax
43351bac mov      eax, dword ptr [esp + 0x18]
43351bb0 mov      dword ptr [ecx + 0xc], eax
43351bb3 mov      eax, dword ptr [esp + 0x88]
43351bba mov      dword ptr [ecx + 0x10], eax
43351bbd mov      eax, dword ptr [esp + 0x3c]
43351bc1 mov      dword ptr [ecx + 0x14], eax
43351bc4 mov      eax, dword ptr [esp + 0x4c]
43351bc8 mov      dword ptr [ecx + 0x18], eax
43351bcb lea      eax, [esi + 0x1ac]
43351bd1 mov      dword ptr [ecx + 0x1c], eax
43351bd4 mov      eax, dword ptr [esi + 0x1b8]
43351bda mov      dword ptr [ecx + 0x20], eax
43351bdd jmp      0x43351c0d
43351bdf mov      edx, dword ptr [esp + 0x4c]
43351be3 push     dword ptr [esi + 0x1b8]
43351be9 lea      eax, [esi + 0x1ac]
43351bef push     eax
43351bf0 push     edx
43351bf1 push     dword ptr [esp + 0x48]
43351bf5 lea      ecx, [esi - 8]
43351bf8 push     dword ptr [esp + 0x98]
43351bff push     dword ptr [esp + 0x2c]
43351c03 push     dword ptr [esp + 0x40]
43351c07 push     edi
43351c08 call     0x4335cd37
43351c0d inc      dword ptr [esi + 0x1b8]
43351c13 mov      eax, dword ptr [esp + 0x64]
43351c17 inc      eax
43351c18 mov      dword ptr [esp + 0x64], eax
43351c1c cmp      eax, dword ptr [esp + 0x24]
43351c20 jb       0x4335182a
43351c26 lea      ecx, [esp + 0x32c]
43351c2d call     0x433cce8e
43351c32 jmp      0x4335473e
43351c37 mov      eax, dword ptr [0x43469300]
43351c3c mov      dword ptr [esp + 0x64], edx
43351c40 mov      ecx, dword ptr [eax]
43351c42 mov      eax, edx
43351c44 mov      dword ptr [esp + 0xc8], ecx
43351c4b cmp      ecx, edx
43351c4d jl       0x4335473e
43351c53 mov      ecx, dword ptr [esp + 0x174]
43351c5a movsd    xmm0, qword ptr [0x43472298]
43351c62 mov      dword ptr [esp + 0x170], ecx
43351c69 mov      ecx, dword ptr [esp + 0x174]
43351c70 mov      dword ptr [esp + 0x118], ecx
43351c77 mov      ecx, dword ptr [esp + 0x174]
43351c7e mov      dword ptr [esp + 0x10c], ecx
43351c85 mov      ecx, dword ptr [esp + 0x174]
43351c8c movsd    qword ptr [esp + 0x5a8], xmm0
43351c95 mov      dword ptr [esp + 0x38], ecx
43351c99 mov      ecx, eax
43351c9b call     0x433b8a2b
43351ca0 mov      ecx, dword ptr [0x4346a890]
43351ca6 push     dword ptr [esp + 0x64]
43351caa mov      dword ptr [esp + 0x8c], eax
43351cb1 mov      edx, dword ptr [ecx]
43351cb3 mov      edx, dword ptr [edx + 0xc]
43351cb6 call     edx
43351cb8 test     byte ptr [edi + 0x170], 9
43351cbf mov      dword ptr [esp + 0x18], eax
43351cc3 jne      0x43351ceb
43351cc5 mov      edx, dword ptr [esp + 0x64]
43351cc9 and      edx, 0x3f
43351ccc mov      ecx, edx
43351cce shr      ecx, 5
43351cd1 push     0x1f
43351cd3 pop      eax
43351cd4 and      edx, eax
43351cd6 mov      eax, dword ptr [edi + ecx*4 + 0x19c]
43351cdd btr      eax, edx
43351ce0 mov      dword ptr [edi + ecx*4 + 0x19c], eax
43351ce7 mov      eax, dword ptr [esp + 0x18]
43351ceb mov      ecx, eax
43351ced call     0x43358962
43351cf2 test     al, al
43351cf4 je       0x43354728
43351cfa mov      ecx, dword ptr [esp + 0x18]
43351cfb dec      esp
43351cfc and      al, 0x18
43351cfe test     ecx, ecx
43351d00 jne      0x43351d0e
43351d02 mov      ebp, 0xd40e8175
43351d07 daa      
43351d08 lock sbb dword ptr [ecx], ebp
43351d0b jl       0x43351cfb
43351d0d xchg     ecx, eax
43351d0e mov      eax, dword ptr [0x43468bd4]
43351d13 mov      eax, dword ptr [eax]
43351d15 xor      eax, dword ptr [0x4346a678]
43351d1b xor      eax, 0x7501cb91
43351d20 mov      al, byte ptr [eax + ecx]
43351d23 cmp      al, 8
43351d25 je       0x43354728
43351d2b cmp      al, 0xa
43351d2d je       0x43354728
43351d33 test     ecx, ecx
43351d35 jne      0x43351d43
43351d37 cmp      bh, byte ptr [ebx - 0x48]
43351d3a mov      dword ptr [ebx + ebx*4], edi
43351d3d fcmovu   st(0), st(0)
43351d40 cld      
43351d41 jo       0x43351d75
43351d43 mov      eax, dword ptr [0x434688d0]
43351d48 mov      eax, dword ptr [eax]
43351d4a xor      eax, dword ptr [0x43468c24]
43351d50 xor      eax, 0xe2fbe695
43351d55 test     byte ptr [eax + ecx], 0x40
43351d59 jne      0x43354728
43351d5f cmp      dword ptr [edi + 0x38], 0xb4
43351d66 lea      eax, [esi + 0xdc]
43351d6c movss    xmm0, dword ptr [esp + 0x194]
43351d75 movss    dword ptr [esp + 0x24], xmm0
43351d7b mov      dword ptr [esp + 0x84], eax
43351d82 je       0x43351e2d
43351d88 call     0x433849b5
43351d8d movaps   xmm3, xmm1
43351d90 movss    dword ptr [esp + 0x2f8], xmm1
43351d99 movaps   xmm5, xmm0
43351d9c movss    dword ptr [esp + 0x2f4], xmm0
43351da5 lea      eax, [esi + 0xdc]
43351dab movss    dword ptr [esp + 0x2fc], xmm2
43351db4 subss    xmm5, dword ptr [eax]
43351db8 subss    xmm3, dword ptr [eax + 4]
43351dbd movaps   xmm4, xmm2
43351dc0 subss    xmm4, dword ptr [eax + 8]
43351dc5 movaps   xmm1, xmm5
43351dc8 mulss    xmm1, xmm5
43351dcc movaps   xmm0, xmm3
43351dcf mulss    xmm0, xmm3
43351dd3 mulss    xmm5, dword ptr [esi + 0x1a8]
43351ddb addss    xmm1, xmm0
43351ddf movaps   xmm0, xmm4
43351de2 mulss    xmm0, xmm4
43351de6 addss    xmm1, xmm0
43351dea movss    xmm0, dword ptr [esi + 0x1b0]
43351df2 mulss    xmm0, xmm4
43351df6 movaps   xmm2, xmm1
43351df9 movss    xmm1, dword ptr [esi + 0x1ac]
43351e01 sqrtss   xmm2, xmm2
43351e05 mulss    xmm1, xmm3
43351e09 movss    dword ptr [esp + 0x5dc], xmm2
43351e12 addss    xmm1, xmm5
43351e16 addss    xmm1, xmm0
43351e1a movss    xmm0, dword ptr [esp + 0x24]
43351e20 divss    xmm1, xmm2
43351e24 comiss   xmm0, xmm1
43351e27 ja       0x43354728
43351e2d push     0xa
43351e2f pop      ecx
43351e30 lea      esi, [esp + 0x178]
43351e37 lea      edi, [esp + 0x124]
43351e3e rep movsd dword ptr es:[edi], dword ptr [esi]
43351e40 mov      edi, dword ptr [esp + 0x14]
43351e44 mov      esi, dword ptr [esp + 0x18]
43351e48 mov      eax, dword ptr [edi + 0xc]
43351e4b movss    xmm0, dword ptr [edi + 0x160]
43351e53 lea      ecx, [esi + 8]
43351e56 mov      dword ptr [esp + 0x70], eax
43351e5a mov      eax, dword ptr [ecx]
43351e5c movss    dword ptr [esp + 0xd4], xmm0
43351e65 mov      dword ptr [esp + 0x50], ecx
43351e69 call     dword ptr [eax + 0x28]
43351e6c mov      ecx, dword ptr [esp + 0x124]
43351e73 mov      dword ptr [esp + 0x54], eax
43351e77 mov      dword ptr [esp + 0x48], ecx
43351e7b test     ecx, ecx
43351e7d je       0x43351efe
43351e7f test     eax, eax
43351e81 jne      0x43351e8f
43351e83 jae      0x43351e56
43351e85 add      dword ptr [ecx], -0x12
43351e88 mov      esi, 0x5a3f7078
43351e8d pslld    mm1, qword ptr [ebx + 0x6b95e8c8]
43351e8f mov      ecx, eax
43351e91 call     0x433b8a2b
43351e94 push     es
43351e95 add      byte ptr [ebx + 0x5d8b8], al
43351e96 cmp      dword ptr [eax + 0x5d8], 0
43351e9b add      byte ptr [eax], al
43351e9d je       0x43351efe
43351e9f mov      ecx, dword ptr [0x4346db1c]
43351ea5 cmp      ecx, -1
43351ea8 jne      0x43351eae
43351eaa xor      eax, eax
43351eac jmp      0x43351ec5
43351eae mov      eax, dword ptr [0x4346a890]
43351eb3 push     ecx
43351eb4 mov      eax, dword ptr [eax]
43351eb6 mov      edx, dword ptr [eax + 0x10]
43351eb9 mov      eax, esp
43351ebb mov      dword ptr [eax], ecx
43351ebd mov      ecx, dword ptr [0x4346a890]
43351ec3 call     edx
43351ec5 cmp      eax, esi
43351ec7 jne      0x43351eec
43351ec9 mov      edx, dword ptr [esp + 0x54]
43351ecd and      edx, 0x3f
43351ed0 push     0x1f
43351ed2 mov      ecx, edx
43351ed4 shr      edx, 5
43351ed7 pop      eax
43351ed8 and      ecx, eax
43351eda xor      eax, eax
43351edc inc      eax
43351edd shl      eax, cl
43351edf mov      ecx, dword ptr [esp + 0x1c]
43351ee3 test     dword ptr [ecx + edx*4 + 0x1a4], eax
43351eea je       0x43351f0b
43351eec xor      eax, eax
43351eee lea      ecx, [eax + 1]
43351ef1 mov      dword ptr [esp + 0x48], ecx
43351ef5 mov      dword ptr [esp + 0x124], ecx
43351efc jmp      0x43351f0b
43351efe xor      eax, eax
43351f00 mov      dword ptr [esp + 0x48], eax
43351f04 mov      dword ptr [esp + 0x124], eax
43351f0b mov      eax, dword ptr [esp + 0x138]
43351f12 push     0x64
43351f14 pop      ecx
43351f15 mov      dword ptr [esp + 0x4c], eax
43351f19 cmp      eax, ecx
43351f1b jl       0x43351f54
43351f1d mov      dword ptr [esp + 0x24], 0x6d2cfbd5
43351f25 mov      edx, esi
43351f27 mov      eax, dword ptr [esp + 0x24]
43351f2b mov      ecx, dword ptr [esi]
43351f2d inc      eax
43351f2e xor      eax, 0x4a674016
43351f33 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
43351f3a mov      dword ptr [esp + 0x5d8], ecx
43351f41 call     0x433e533f
43351f46 mov      ecx, dword ptr [esp + 0x4c]
43351f4a add      ecx, -0x64
43351f4d add      ecx, eax
43351f4f jmp      0x43352127
43351f54 test     eax, eax
43351f56 jne      0x433520f2
43351f5c mov      edx, dword ptr [esp + 0x70]
43351f60 mov      dword ptr [esp + 0x24], 0xe3852753
43351f68 mov      eax, dword ptr [esp + 0x24]
43351f6c add      eax, 0x1c7af3bd
43351f71 mov      ecx, dword ptr [edx]
43351f73 ror      eax, 2
43351f76 push     0
43351f78 mov      ecx, dword ptr [eax + ecx]
43351f7b mov      dword ptr [esp + 0x5d8], ecx
43351f82 call     0x433e533f
43351f87 mov      dword ptr [esp + 0x24], 0x6d2cfbd5
43351f8f mov      edx, esi
43351f91 mov      eax, dword ptr [esp + 0x24]
43351f95 mov      ecx, dword ptr [esi]
43351f97 inc      eax
43351f98 xor      eax, 0x4a674016
43351f9d fstp     dword ptr [esp + 0x60]
43351fa1 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
43351fa8 mov      dword ptr [esp + 0x5d0], ecx
43351faf call     0x433e533f
43351fb4 mov      esi, dword ptr [esp + 0x1c]
43351fb8 inc      eax
43351fb9 push     0xa
43351fbb pop      ecx
43351fbc cmp      eax, ecx
43351fbe cmovg    ecx, eax
43351fc1 test     byte ptr [esi + 0x170], 4
43351fc8 movd     xmm0, ecx
43351fcc cvtdq2ps xmm0, xmm0
43351fcf mulss    xmm0, dword ptr [esp + 0x60]
43351fd5 movss    dword ptr [esp + 0x78], xmm0
43351fdb jne      0x43351feb
43351fdd mulss    xmm0, dword ptr [0x4347268c]
43351fe5 movss    dword ptr [esp + 0x78], xmm0
43351feb mov      edx, dword ptr [esp + 0x70]
43351fef mov      dword ptr [esp + 0x24], 0x289d6d8d
43351ff7 mov      eax, dword ptr [esp + 0x24]
43351ffb mov      ecx, dword ptr [edx]
43351ffd sub      ecx, eax
43351fff mov      ecx, dword ptr [ecx + 0x289d7449]
43352005 mov      dword ptr [esp + 0x5cc], ecx
4335200c call     0x433e533f
43352011 movss    xmm0, dword ptr [esp + 0x78]
43352017 movd     xmm1, eax
4335201b cvtdq2ps xmm1, xmm1
4335201e subss    xmm1, dword ptr [esp + 0x68]
43352024 call     0x43367633
43352029 movss    xmm1, dword ptr [esp + 0x68]
4335202f call     0x4332fc35
43352034 addss    xmm0, dword ptr [esp + 0x90]
4335203d mov      edx, dword ptr [esp + 0x18]
43352041 mov      dword ptr [esp + 0x24], 0x6d2cfbd5
43352049 cvttss2si eax, xmm0
4335204d mov      dword ptr [esp + 0x4c], eax
43352051 mov      dword ptr [esp + 0x138], eax
43352058 mov      eax, dword ptr [esp + 0x24]
4335205c mov      ecx, dword ptr [edx]
4335205e inc      eax
4335205f xor      eax, 0x4a674016
43352064 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
4335206b mov      dword ptr [esp + 0x5c8], ecx
43352072 call     0x433e533f
43352077 mov      ecx, dword ptr [esp + 0x4c]
4335207b test     ecx, ecx
4335207d jg       0x43352089
4335207f mov      dword ptr [esp + 0x78], 0x7fffffff
43352087 jmp      0x433520a5
43352089 dec      eax
4335208a add      eax, ecx
4335208c cdq      
4335208d idiv     ecx
4335208f xor      edx, edx
43352091 inc      edx
43352092 cmp      eax, edx
43352094 mov      ecx, edx
43352096 cmovg    ecx, eax
43352099 mov      dword ptr [esp + 0x78], ecx
4335209d cmp      ecx, edx
4335209f jle      0x43352136
433520a5 mov      edx, dword ptr [esp + 0x18]
433520a9 mov      dword ptr [esp + 0x24], 0x6d2cfbd5
433520b1 mov      eax, dword ptr [esp + 0x24]
433520b5 inc      eax
433520b6 mov      ecx, dword ptr [edx]
433520b8 xor      eax, 0x4a674016
433520bd mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
433520c4 mov      dword ptr [esp + 0x5c4], ecx
433520cb call     0x433e533f
433520d0 cdq      
433520d1 idiv     dword ptr [esp + 0x78]
433520d5 push     3
433520d7 shl      eax, 2
433520da cdq      
433520db pop      ecx
433520dc idiv     ecx
433520de inc      eax
433520df cmp      eax, dword ptr [esp + 0x4c]
433520e3 jge      0x43352136
433520e5 mov      dword ptr [esp + 0x4c], eax
433520e9 mov      dword ptr [esp + 0x138], eax
433520f0 jmp      0x43352136
433520f2 mov      dword ptr [esp + 0x24], 0x6d2cfbd5
433520fa mov      edx, esi
433520fc mov      eax, dword ptr [esp + 0x24]
43352100 mov      ecx, dword ptr [esi]
43352102 inc      eax
43352103 xor      eax, 0x4a674016
43352108 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
4335210f mov      dword ptr [esp + 0x5c0], ecx
43352116 call     0x433e533f
4335211b mov      ecx, dword ptr [esp + 0x4c]
4335211f add      eax, 5
43352122 cmp      eax, ecx
43352124 cmovl    ecx, eax
43352127 mov      esi, dword ptr [esp + 0x1c]
4335212b mov      dword ptr [esp + 0x138], ecx
43352132 mov      dword ptr [esp + 0x4c], ecx
43352136 mov      ecx, dword ptr [esp + 0x134]
4335213d mov      edx, dword ptr [esp + 0x128]
43352144 mov      dword ptr [esp + 0x34], ecx
43352148 mov      dword ptr [esp + 0x74], edx
4335214c test     ecx, ecx
4335214e je       0x4335256b
43352154 mov      eax, dword ptr [0x43467d78]
43352159 mov      ecx, dword ptr [esp + 0x18]
4335215d movss    xmm5, dword ptr [esp + 0x2c]
43352163 movss    xmm6, dword ptr [esp + 0x22c]
4335216c mov      eax, dword ptr [eax]
4335216e movaps   xmm4, xmm6
43352171 xor      eax, dword ptr [0x43467b80]
43352177 xor      eax, 0x1caaf0a8
4335217c test     byte ptr [esi + 0x170], 4
43352183 movss    xmm3, dword ptr [eax + ecx + 0xc]
43352189 movaps   xmm1, xmm3
4335218c subss    xmm1, xmm5
43352190 mulss    xmm1, dword ptr [0x434703c4]
43352198 subss    xmm4, xmm1
4335219c movss    dword ptr [esp + 0x3c], xmm4
433521a2 jne      0x433521c0
433521a4 movaps   xmm1, xmm6
433521a7 movaps   xmm0, xmm4
433521aa call     0x43367633
433521af movss    xmm2, dword ptr [esp + 0x130]
433521b8 movaps   xmm4, xmm0
433521bb jmp      0x4335254f
433521c0 mov      eax, dword ptr [esi + 0xc4]
433521c6 cmp      eax, 0x18
433521c9 jne      0x433524eb
433521cf mov      eax, dword ptr [0x434670cc]
433521d4 mov      esi, dword ptr [eax]
433521d6 xor      esi, dword ptr [0x43468bcc]
433521dc xor      esi, 0xa9ee6062
433521e2 add      esi, ecx
433521e4 mov      ecx, dword ptr [0x43475808]
433521ea mov      eax, dword ptr [ecx]
433521ec call     dword ptr [eax + 0x28]
433521ef movss    xmm1, dword ptr [esi]
433521f3 movss    xmm0, dword ptr [esi + 4]
433521f8 movss    xmm2, dword ptr [esi + 8]
433521fd subss    xmm2, dword ptr [eax + 8]
43352202 subss    xmm1, dword ptr [eax]
43352206 subss    xmm0, dword ptr [eax + 4]
4335220b mov      eax, dword ptr [0x43467d78]
43352210 mov      esi, dword ptr [esp + 0x1c]
43352214 mov      ecx, dword ptr [esp + 0x18]
43352218 movss    dword ptr [esp + 0xdc], xmm2
43352221 mov      eax, dword ptr [eax]
43352223 xor      eax, dword ptr [0x43467b80]
43352229 xor      eax, 0x1caaf0a8
4335222e add      eax, ecx
43352230 test     dword ptr [esi + 0x170], 0x200
4335223a mov      dword ptr [esp + 0x60], eax
4335223e je       0x4335247b
43352244 mov      eax, dword ptr [0x43468ea4]
43352249 xor      eax, 0xfcd2da7a
4335224e jmp      0x43352252
43352250 mov      eax, edx
43352252 mov      edx, dword ptr [eax + 0x1c]
43352255 cmp      eax, edx
43352257 jne      0x43352250
43352259 cmp      dword ptr [eax + 0x30], eax
4335225c je       0x4335247b
43352262 call     0x433fd30d
43352267 test     eax, eax
43352269 je       0x433522a6
4335226b mov      ecx, dword ptr [eax]
4335226d mov      eax, dword ptr [0x43468240]
43352272 mov      edx, dword ptr [esp + 0x18]
43352276 mov      eax, dword ptr [eax]
43352278 xor      eax, dword ptr [0x4346a84c]
4335227e xor      eax, 0xc2b6fb10
43352283 imul     edx, dword ptr [eax + edx], 0xc
43352287 add      edx, dword ptr [ecx + 0xb0]
4335228d add      edx, ecx
4335228f je       0x433522a6
43352291 xor      eax, eax
43352293 cmp      dword ptr [edx + 4], eax
43352296 je       0x433522a6
43352298 mov      eax, dword ptr [edx + 8]
4335229b add      eax, 0x44
4335229e add      eax, edx
433522a0 je       0x433522a6
433522a2 mov      ecx, dword ptr [eax]
433522a4 jmp      0x433522a9
433522a6 or       ecx, 0xffffffff
433522a9 mov      eax, dword ptr [0x43469064]
433522ae mov      edx, dword ptr [esp + 0x18]
433522b2 imul     ecx, ecx, 0x30
433522b5 mov      eax, dword ptr [eax]
433522b7 xor      eax, dword ptr [0x4346a484]
433522bd xor      eax, 0x17978090
433522c2 add      ecx, dword ptr [eax + edx]
433522c5 movss    xmm1, dword ptr [ecx]
433522c9 movss    xmm0, dword ptr [ecx + 0x10]
433522ce movss    dword ptr [esp + 0x87c], xmm0
433522d7 mulss    xmm0, xmm0
433522db movss    dword ptr [esp + 0x878], xmm1
433522e4 mulss    xmm1, xmm1
433522e8 addss    xmm1, xmm0
433522ec movaps   xmm0, xmm1
433522ef xorps    xmm1, xmm1
433522f2 sqrtss   xmm0, xmm0
433522f6 movss    dword ptr [esp + 0x5bc], xmm0
433522ff cvtss2sd xmm1, xmm0
43352303 movss    xmm0, dword ptr [ecx + 0x20]
43352308 xorps    xmm0, xmmword ptr [esp + 0xf0]
43352310 cvtss2sd xmm0, xmm0
43352314 call     0x77509ee0
43352319 xorps    xmm1, xmm1
4335231c cvtsd2ss xmm1, xmm0
43352320 mulss    xmm1, dword ptr [esp + 0xa4]
43352329 addss    xmm1, dword ptr [esp + 0x110]
43352332 ucomiss  xmm1, xmm1
43352335 movss    dword ptr [esp + 0x24], xmm1
4335233b lahf     
4335233c test     ah, 0x44
4335233f jnp      0x4335234c
43352341 movss    xmm5, dword ptr [esp + 0x2c]
43352347 movaps   xmm1, xmm5
4335234a jmp      0x433523a5
4335234c movss    xmm2, dword ptr [esp + 0xb0]
43352355 movaps   xmm0, xmm1
43352358 andps    xmm0, xmm2
4335235b comiss   xmm0, dword ptr [esp + 0xec]
43352363 jbe      0x4335239f
43352365 movaps   xmm0, xmm1
43352368 divss    xmm0, dword ptr [esp + 0x8c]
43352371 andps    xmm0, xmm2
43352374 call     0x4341ad12
43352379 movss    xmm1, dword ptr [esp + 0x24]
4335237f movss    xmm5, dword ptr [esp + 0x2c]
43352385 comiss   xmm5, xmm1
43352388 mulss    xmm0, dword ptr [esp + 0x8c]
43352391 jbe      0x43352399
43352393 addss    xmm1, xmm0
43352397 jmp      0x433523a5
43352399 subss    xmm1, xmm0
4335239d jmp      0x433523a5
4335239f movss    xmm5, dword ptr [esp + 0x2c]
433523a5 movss    xmm2, dword ptr [0x43470378]
433523ad xorps    xmm3, xmm3
433523b0 mov      eax, dword ptr [esp + 0x60]
433523b4 subss    xmm1, xmm2
433523b8 movaps   xmm0, xmm5
433523bb movss    xmm3, xmm1
433523bf movss    xmm1, dword ptr [eax + 0xc]
433523c4 maxss    xmm3, xmm0
433523c8 movaps   xmm0, xmm2
433523cb minss    xmm3, xmm0
433523cf movss    xmm0, dword ptr [esp + 0x68]
433523d5 ucomiss  xmm1, xmm0
433523d8 movss    dword ptr [esp + 0x31c], xmm3
433523e1 divss    xmm3, xmm2
433523e5 lahf     
433523e6 test     ah, 0x44
433523e9 jnp      0x43352406
433523eb subss    xmm0, xmm1
433523ef movss    xmm1, dword ptr [esp + 0x90]
433523f8 subss    xmm0, xmm3
433523fc mulss    xmm0, xmm1
43352400 addss    xmm3, xmm0
43352404 jmp      0x4335240f
43352406 movss    xmm1, dword ptr [esp + 0x90]
4335240f movss    xmm0, dword ptr [esp + 0xdc]
43352418 comiss   xmm0, dword ptr [esp + 0x9c]
43352420 jbe      0x43352436
43352422 movss    xmm0, dword ptr [0x434720d0]
4335242a subss    xmm0, xmm3
4335242e mulss    xmm0, xmm1
43352432 addss    xmm3, xmm0
43352436 movss    xmm0, dword ptr [esp + 0x1b4]
4335243f movaps   xmm2, xmm3
43352442 movss    xmm4, dword ptr [esp + 0x3c]
43352448 maxss    xmm2, xmm0
4335244c movss    xmm0, dword ptr [0x434720d0]
43352454 minss    xmm2, xmm0
43352458 ucomiss  xmm2, xmm2
4335245b movss    dword ptr [esp + 0x2e8], xmm2
43352464 lahf     
43352465 test     ah, 0x44
43352468 jnp      0x4335254f
4335246e movss    xmm2, dword ptr [0x4346fd8c]
43352476 jmp      0x4335254f
4335247b mulss    xmm1, xmm1
4335247f mulss    xmm0, xmm0
43352483 mulss    xmm2, xmm2
43352487 addss    xmm1, xmm0
4335248b xorps    xmm0, xmm0
4335248e addss    xmm1, xmm2
43352492 movss    xmm0, xmm1
43352496 movss    xmm1, dword ptr [esp + 0xd4]
4335249f sqrtss   xmm0, xmm0
433524a3 mulss    xmm1, xmm0
433524a7 movss    dword ptr [esp + 0x5b8], xmm0
433524b0 movss    xmm0, dword ptr [esp + 0x68]
433524b6 divss    xmm1, dword ptr [0x4346fd78]
433524be subss    xmm0, xmm1
433524c2 movaps   xmm1, xmm0
433524c5 movss    xmm0, dword ptr [0x4346ed98]
433524cd maxss    xmm1, xmm0
433524d1 movss    xmm0, dword ptr [0x43472c90]
433524d9 minss    xmm1, xmm0
433524dd movss    dword ptr [esp + 0x5b4], xmm1
433524e6 movaps   xmm2, xmm1
433524e9 jmp      0x4335251f
433524eb dec      eax
433524ec push     2
433524ee movd     xmm1, eax
433524f2 cvtdq2ps xmm1, xmm1
433524f5 pop      eax
433524f6 mulss    xmm1, dword ptr [esp + 0x168]
433524ff movaps   xmm2, xmm1
43352502 cmp      edx, eax
43352504 je       0x43352527
43352506 comiss   xmm3, dword ptr [0x434701c8]
4335250d jb       0x43352527
4335250f movss    xmm0, dword ptr [0x4346fd8c]
43352517 call     0x43367633
4335251c movaps   xmm2, xmm0
4335251f movss    xmm4, dword ptr [esp + 0x3c]
43352525 jmp      0x4335254f
43352527 mov      eax, dword ptr [0x4346a8e4]
4335252c mov      eax, dword ptr [eax]
4335252e xor      eax, dword ptr [0x434688cc]
43352534 xor      eax, 0x36375c23
43352539 movss    xmm0, dword ptr [eax + ecx + 8]
4335253f ucomiss  xmm0, xmm5
43352542 lahf     
43352543 test     ah, 0x44
43352546 jnp      0x4335254f
43352548 mulss    xmm1, xmm6
4335254c movaps   xmm2, xmm1
4335254f movaps   xmm1, xmm4
43352552 movaps   xmm0, xmm2
43352555 call     0x43367633
4335255a mov      edx, dword ptr [esp + 0x74]
4335255e mov      ecx, dword ptr [esp + 0x34]
43352562 movss    dword ptr [esp + 0x130], xmm0
4335256b mov      eax, dword ptr [0x434670cc]
43352570 mov      eax, dword ptr [eax]
43352572 xor      eax, dword ptr [0x43468bcc]
43352578 xor      eax, 0xa9ee6062
4335257d add      eax, dword ptr [esp + 0x18]
43352581 movss    xmm1, dword ptr [eax]
43352585 movss    xmm2, dword ptr [eax + 4]
4335258a subss    xmm2, dword ptr [edi + 0x110]
43352592 subss    xmm1, dword ptr [edi + 0x10c]
4335259a movss    xmm0, dword ptr [eax + 8]
4335259f subss    xmm0, dword ptr [edi + 0x114]
433525a7 mulss    xmm2, xmm2
433525ab mulss    xmm1, xmm1
433525af mulss    xmm0, xmm0
433525b3 addss    xmm2, xmm1
433525b7 addss    xmm2, xmm0
433525bb comiss   xmm2, dword ptr [0x43472b3c]
433525bf sub      eax, dword ptr [edi + 0x43]
433525c2 jbe      0x433525ee
433525c4 and      ecx, 0xfffffd0f
433525ca mov      dword ptr [esp + 0x34], ecx
433525ce mov      dword ptr [esp + 0x134], ecx
433525d5 cmp      edx, 0x200
433525db je       0x433525ee
433525dd and      edx, 0xfffffdff
433525e3 mov      dword ptr [esp + 0x74], edx
433525e7 mov      dword ptr [esp + 0x128], edx
433525ee comiss   xmm2, dword ptr [0x43472008]
433525f5 jbe      0x43352608
433525f7 and      ecx, 0xfffffdff
433525fd mov      dword ptr [esp + 0x34], ecx
43352601 mov      dword ptr [esp + 0x134], ecx
43352608 mov      eax, dword ptr [0x4346a314]
4335260d mov      ecx, 0x4346a300
43352612 mov      eax, dword ptr [eax*4 + 0x434721c4]
43352619 call     eax
4335261b mov      byte ptr [esp + 0x5b], al
4335261f mov      eax, dword ptr [esp + 0x54]
43352623 test     eax, eax
43352625 jne      0x43352633
43352627 pop      ecx
43352628 scasb    al, byte ptr es:[edi]
43352629 mov      byte ptr [0x6de6d022], al
4335262e dec      ebp
4335262f insb     byte ptr es:[edi], dx
43352630 jns      0x43352681
43352632 js       0x433525bf
43352633 mov      ecx, eax
43352634 enter    -0xe18, 0x63
43352635 call     0x433b8a2b
43352638 push     es
43352639 add      byte ptr [ebx + 0x42d233c8], cl
4335263a mov      ecx, eax
4335263c xor      edx, edx
4335263e inc      edx
4335263f mov      dword ptr [esp + 0x24], ecx
43352643 mov      eax, dword ptr [ecx + 0xf8]
43352649 test     eax, eax
4335264b jle      0x43352664
4335264d test     byte ptr [esi + 0x170], 9
43352654 mov      byte ptr [esp + 0x145], dl
4335265b jne      0x43352664
4335265d dec      eax
4335265e mov      dword ptr [ecx + 0xf8], eax
43352664 mov      eax, dword ptr [esp + 0x54]
43352668 shl      eax, 5
4335266b mov      dword ptr [esp + 0x54], eax
4335266f mov      eax, dword ptr [eax + 0x4347be18]
43352675 sub      eax, 1
43352678 je       0x43352696
4335267a sub      eax, 1
4335267d je       0x4335268d
4335267f sub      eax, 1
43352681 add      dword ptr [ebp + 0x1a], esi
43352682 jne      0x4335269e
43352684 mov      byte ptr [esp + 0x145], dl
4335268b jmp      0x433526a5
4335268d mov      byte ptr [esp + 0x145], dl
43352694 jmp      0x4335269e
43352696 mov      byte ptr [esp + 0x145], 0
4335269e cmp      byte ptr [esp + 0x5b], 0
433526a3 je       0x43352710
433526a5 mov      ecx, dword ptr [esp + 0x70]
433526a9 test     ecx, ecx
433526ab jne      0x433526b9
433526ad sub      eax, 0xe0cb77e3
433526b2 cmp      eax, 0xefd6440f
433526b7 xor      eax, 0x7086f7d8
433526b9 test     dword ptr [esi + 0x170], 0x400
433526bc add      dword ptr [eax], eax
433526be add      byte ptr [eax], al
433526c0 add      al, 0
433526c2 add      byte ptr [ebx + ebx - 0x5f], dh
433526c3 je       0x433526e0
433526c5 mov      eax, dword ptr [0x4346908c]
433526c6 mov      word ptr [eax + 0x1f6a4346], ss
433526ca push     0x1f
433526cc pop      edx
433526cd mov      eax, dword ptr [eax]
433526cf xor      eax, dword ptr [0x43468ba0]
433526d5 xor      eax, 0x5c9f0fbb
433526da cmp      word ptr [eax + ecx], dx
433526de jne      0x43352710
433526e0 mov      ecx, dword ptr [esp + 0x12c]
433526e7 mov      edx, dword ptr [esp + 0x74]
433526eb push     0xc
433526ed pop      eax
433526ee and      ecx, eax
433526f0 and      edx, eax
433526f2 mov      eax, ecx
433526f4 mov      dword ptr [esp + 0x12c], ecx
433526fb or       eax, edx
433526fd push     0xc
433526ff pop      eax
43352700 cmove    edx, eax
43352703 mov      dword ptr [esp + 0x74], edx
43352707 mov      dword ptr [esp + 0x128], edx
4335270e jmp      0x4335271b
43352710 mov      ecx, dword ptr [esp + 0x12c]
43352717 mov      edx, dword ptr [esp + 0x74]
4335271b mov      eax, dword ptr [esp + 0x54]
4335271f mov      dword ptr [esp + 0x3c], ecx
43352723 mov      eax, dword ptr [eax + 0x4347be1c]
43352729 test     eax, eax
4335272b je       0x4335274c
4335272d cmp      eax, 2
43352730 jne      0x4335274c
43352732 or       ecx, edx
43352734 xor      edx, edx
43352736 mov      dword ptr [esp + 0x3c], ecx
4335273a mov      dword ptr [esp + 0x12c], ecx
43352741 mov      dword ptr [esp + 0x74], edx
43352745 mov      dword ptr [esp + 0x128], edx
4335274c test     edx, edx
4335274e jne      0x43352765
43352750 test     ecx, ecx
43352752 je       0x43352765
43352754 and      ecx, 0xfffffdff
4335275a mov      dword ptr [esp + 0x3c], ecx
4335275e mov      dword ptr [esp + 0x12c], ecx
43352765 mov      eax, dword ptr [esp + 0x54]
43352769 cmp      byte ptr [eax + 0x4347be0e], 0
43352770 je       0x43352816
43352776 cmp      byte ptr [0x43468f78], 0
4335277d je       0x43352816
43352783 mov      eax, edx
43352785 and      eax, 0xc
43352788 cmp      al, 0xc
4335278a jne      0x43352816
43352790 mov      eax, dword ptr [esp + 0x24]
43352794 movss    xmm0, dword ptr [esp + 0x90]
4335279d comiss   xmm0, dword ptr [eax + 0x51c]
433527a4 jbe      0x43352816
433527a6 mov      eax, dword ptr [0x434688b0]
433527ab mov      edx, dword ptr [esp + 0x18]
433527af mov      eax, dword ptr [eax]
433527b1 xor      eax, dword ptr [0x4346a518]
433527b7 xor      eax, 0x8b5586f6
433527bc cmp      dword ptr [eax + edx], 2
433527c0 jne      0x43352812
433527c2 mov      eax, dword ptr [0x434679f8]
433527c7 mov      eax, dword ptr [eax]
433527c9 xor      eax, dword ptr [0x434675f8]
433527cf xor      eax, 0x3309c0cf
433527d4 movss    xmm0, dword ptr [eax + edx]
433527d9 comiss   xmm0, dword ptr [0x43472c90]
433527e0 jb       0x43352812
433527e2 mov      eax, dword ptr [0x434688d0]
433527e7 mov      eax, dword ptr [eax]
433527e9 xor      eax, dword ptr [0x43468c24]
433527ef xor      eax, 0xe2fbe695
433527f4 test     byte ptr [eax + edx], 1
433527f8 mov      edx, dword ptr [esp + 0x74]
433527fc je       0x43352816
433527fe mov      eax, dword ptr [esp + 0x34]
43352802 and      eax, 0xfffffff7
43352805 mov      dword ptr [esp + 0x34], eax
43352809 mov      dword ptr [esp + 0x134], eax
43352810 jmp      0x43352816
43352812 mov      edx, dword ptr [esp + 0x74]
43352816 cmp      dword ptr [esp + 0x70], 0
4335281b jne      0x43352829
4335281d pop      es
4335281e sub      byte ptr [edx + 0x1c51467b], dh
43352824 or       ch, byte ptr [eax - 0x8f5e593]
43352829 test     dword ptr [esi + 0x170], 0x400
4335282a xchg     byte ptr [eax + 1], dh
4335282d add      byte ptr [eax], al
4335282f add      byte ptr [eax + eax], al
43352832 add      byte ptr [esp - 0x5f], dh
43352833 je       0x43352899
43352835 mov      eax, dword ptr [0x4346908c]
43352836 mov      word ptr [eax + 0x7c8b4346], ss
4335283a mov      edi, dword ptr [esp + 0x70]
4335283c and      al, 0x70
4335283e push     0x1f
43352840 pop      esi
43352841 mov      eax, dword ptr [eax]
43352843 xor      eax, dword ptr [0x43468ba0]
43352849 xor      eax, 0x5c9f0fbb
4335284e cmp      word ptr [eax + edi], si
43352852 mov      edi, dword ptr [esp + 0x14]
43352856 mov      esi, dword ptr [esp + 0x1c]
4335285a je       0x43352899
4335285c push     2
4335285e pop      eax
4335285f and      ecx, eax
43352861 mov      byte ptr [esp + 0x145], 0
43352869 and      edx, eax
4335286b mov      dword ptr [esp + 0x3c], ecx
4335286f mov      eax, dword ptr [esp + 0x34]
43352873 push     2
43352875 mov      dword ptr [esp + 0x130], ecx
4335287c pop      ecx
4335287d and      eax, ecx
4335287f mov      dword ptr [esp + 0x74], edx
43352883 mov      dword ptr [esp + 0x128], edx
4335288a mov      dword ptr [esp + 0x134], eax
43352891 mov      byte ptr [esp + 0x147], 0
43352899 mov      edx, dword ptr [esi + 0x170]
4335289f test     dl, 9
433528a2 jne      0x433528cc
433528a4 mov      edx, dword ptr [esp + 0x64]
433528a8 and      edx, 0x3f
433528ab mov      ecx, edx
433528ad shr      ecx, 5
433528b0 push     0x1f
433528b2 pop      eax
433528b3 and      edx, eax
433528b5 mov      eax, dword ptr [esi + ecx*4 + 0x1a4]
433528bc btr      eax, edx
433528bf mov      dword ptr [esi + ecx*4 + 0x1a4], eax
433528c6 mov      edx, dword ptr [esi + 0x170]
433528cc cmp      byte ptr [esp + 0x147], 0
433528d4 je       0x433538bf
433528da mov      eax, dword ptr [esp + 0x3c]
433528de mov      ecx, dword ptr [esp + 0x74]
433528e2 mov      dword ptr [esp + 0x70], eax
433528e6 or       dword ptr [esp + 0x70], ecx
433528ea test     byte ptr [esp + 0x70], 8
433528ef je       0x433538bf
433528f5 test     dl, 3
433528f8 jne      0x433538bf
433528fe mov      edx, dword ptr [edi + 0xd8]
43352904 cmp      edx, 0x1f
43352907 je       0x433538bf
4335290d test     byte ptr [edi + 0x44], 2
43352911 jne      0x433538bf
43352917 test     dword ptr [edi], 0x40000
4335291d je       0x433538bf
43352923 cmp      edx, 0x40
43352926 jne      0x43352937
43352928 xor      edx, edx
4335292a inc      edx
4335292b test     byte ptr [esi + 0x174], dl
43352931 je       0x433538bf
43352937 test     dword ptr [edi], 0x102000
4335293d jne      0x433538bf
43352943 test     ecx, ecx
43352945 jne      0x4335294f
43352947 test     eax, eax
43352949 jne      0x433538bf
4335294f test     dword ptr [esp + 0x70], 0xfffffff3
43352957 je       0x433538bf
4335295d mov      ecx, dword ptr [esp + 0x18]
43352961 xor      eax, eax
43352963 or       dword ptr [esp + 0x534], 0xffffffff
4335296b or       dword ptr [esp + 0x540], 0xffffffff
43352973 mov      word ptr [esp + 0x526], ax
4335297b mov      dword ptr [esp + 0x53c], eax
43352982 lea      eax, [esp + 0x9fc]
43352989 push     eax
4335298a mov      dword ptr [esp + 0x520], 0x3f800000
43352995 call     0x4331e360
4335299a lea      ecx, [edi + 0xdc]
433529a0 xor      edx, edx
433529a2 movss    xmm2, dword ptr [ecx + 4]
433529a7 inc      edx
433529a8 movss    xmm1, dword ptr [ecx + 8]
433529ad movss    xmm0, dword ptr [ecx]
433529b1 movss    dword ptr [esp + 0x8a4], xmm2
433529ba movss    dword ptr [esp + 0x8a0], xmm0
433529c3 xorps    xmm0, xmm0
433529c6 movss    dword ptr [esp + 0x8a8], xmm1
433529cf movss    xmm3, dword ptr [eax]
433529d3 subss    xmm3, dword ptr [ecx]
433529d7 movss    dword ptr [esp + 0x8b0], xmm3
433529e0 movss    xmm2, dword ptr [eax + 4]
433529e5 subss    xmm2, dword ptr [ecx + 4]
433529ea mulss    xmm3, xmm3
433529ee movss    dword ptr [esp + 0x8b4], xmm2
433529f7 movss    xmm1, dword ptr [eax + 8]
433529fc subss    xmm1, dword ptr [ecx + 8]
43352a01 mulss    xmm2, xmm2
43352a05 xor      ecx, ecx
43352a07 mov      dword ptr [esp + 0x8e0], ecx
43352a0e movaps   xmmword ptr [esp + 0x8c0], xmm0
43352a16 movaps   xmmword ptr [esp + 0x8d0], xmm0
43352a1e movss    dword ptr [esp + 0x8b8], xmm1
43352a27 addss    xmm2, xmm3
43352a2b mulss    xmm1, xmm1
43352a2f mov      byte ptr [esp + 0x8e4], dl
43352a36 mov      byte ptr [esp + 0x8e5], dl
43352a3d addss    xmm2, xmm1
43352a41 ucomiss  xmm2, dword ptr [esp + 0x2c]
43352a46 lahf     
43352a47 test     ah, 0x44
43352a4a jp       0x43352a53
43352a4c mov      byte ptr [esp + 0x8e5], cl
43352a53 lea      eax, [esp + 0x4f0]
43352a5a push     eax
43352a5b lea      ecx, [esp + 0x8a4]
43352a62 call     0x433cc0f2
43352a67 movss    xmm7, dword ptr [esp + 0x68]
43352a6d comiss   xmm7, dword ptr [esp + 0x51c]
43352a75 ja       0x43352a8f
43352a77 cmp      byte ptr [esp + 0x526], 0
43352a7f jne      0x43352a8f
43352a81 cmp      byte ptr [esp + 0x527], 0
43352a89 je       0x433538bf
43352a8f lea      eax, [edi + 0x10c]
43352a95 movss    xmm2, dword ptr [eax + 8]
43352a9a movss    xmm0, dword ptr [eax]
43352a9e addss    xmm2, dword ptr [0x4346edd0]
43352aa6 movss    xmm1, dword ptr [eax + 4]
43352aab movss    dword ptr [esp + 0x1a8], xmm0
43352ab4 movss    dword ptr [esp + 0x1ac], xmm1
43352abd movss    dword ptr [esp + 0x1b0], xmm2
43352ac6 movss    xmm0, dword ptr [edi + 0xc0]
43352ace comiss   xmm0, dword ptr [0x4347259c]
43352ad5 seta     al
43352ad8 test     al, al
43352ada jne      0x43352b0f
43352adc test     byte ptr [edi + 0x44], 4
43352ae0 jne      0x433538bf
43352ae6 movss    xmm1, dword ptr [edi + 0x98]
43352aee comiss   xmm1, dword ptr [esp + 0x2c]
43352af3 jbe      0x433538bf
43352af9 movss    xmm0, dword ptr [edi + 0x1a4]
43352b01 comiss   xmm0, xmm1
43352b04 ja       0x43353190
43352b0a jmp      0x433538bf
43352b0f test     dword ptr [edi + 0x44], 0x618
43352b16 je       0x433538bf
43352b1c mov      eax, dword ptr [0x4346a8e4]
43352b21 mov      ecx, dword ptr [esp + 0x18]
43352b25 mov      eax, dword ptr [eax]
43352b27 xor      eax, dword ptr [0x434688cc]
43352b2d xor      eax, 0x36375c23
43352b32 movss    xmm0, dword ptr [eax + ecx + 4]
43352b38 movss    xmm1, dword ptr [eax + ecx]
43352b3d mulss    xmm0, xmm0
43352b41 mulss    xmm1, xmm1
43352b45 addss    xmm1, xmm0
43352b49 movaps   xmm0, xmm1
43352b4c sqrtss   xmm0, xmm0
43352b50 comiss   xmm0, dword ptr [0x4346f724]
43352b57 movss    dword ptr [esp + 0x5a0], xmm0
43352b60 jbe      0x43352c11
43352b66 movss    xmm6, dword ptr [eax + ecx + 4]
43352b6c movaps   xmm5, xmm7
43352b6f movss    xmm1, dword ptr [eax + ecx]
43352b74 movaps   xmm0, xmm6
43352b77 mulss    xmm0, xmm6
43352b7b mulss    xmm1, xmm1
43352b7f movss    xmm2, dword ptr [esp + 0x94]
43352b88 movss    xmm4, dword ptr [edi + 0x150]
43352b90 addss    xmm1, xmm0
43352b94 movss    xmm3, dword ptr [edi + 0x154]
43352b9c movaps   xmm0, xmm1
43352b9f movaps   xmm1, xmm4
43352ba2 sqrtss   xmm0, xmm0
43352ba6 mulss    xmm1, xmm4
43352baa movss    dword ptr [esp + 0x59c], xmm0
43352bb3 addss    xmm0, xmm2
43352bb7 divss    xmm5, xmm0
43352bbb movaps   xmm0, xmm3
43352bbe mulss    xmm0, xmm3
43352bc2 addss    xmm1, xmm0
43352bc6 movaps   xmm0, xmm1
43352bc9 sqrtss   xmm0, xmm0
43352bcd movss    dword ptr [esp + 0x67c], xmm0
43352bd6 addss    xmm0, xmm2
43352bda movaps   xmm2, xmm7
43352bdd divss    xmm2, xmm0
43352be1 movaps   xmm0, xmm5
43352be4 mulss    xmm5, dword ptr [eax + ecx]
43352be9 movaps   xmm1, xmm2
43352bec mulss    xmm0, xmm6
43352bf0 mulss    xmm1, xmm3
43352bf4 mulss    xmm2, xmm4
43352bf8 mulss    xmm1, xmm0
43352bfc mulss    xmm2, xmm5
43352c00 addss    xmm1, xmm2
43352c04 comiss   xmm1, dword ptr [0x4346f27c]
43352c0b jb       0x433538bf
43352c11 mov      eax, dword ptr [edi + 0xd8]
43352c17 cmp      eax, 9
43352c1a je       0x43352c2b
43352c1c cmp      eax, 0x28
43352c1f je       0x43352c2b
43352c21 movss    xmm0, dword ptr [0x43470430]
43352c29 jmp      0x43352c33
43352c2b movss    xmm0, dword ptr [0x4346ff74]
43352c33 push     0
43352c35 lea      eax, [esp + 0x218]
43352c3c movss    dword ptr [esp + 0x7c], xmm0
43352c42 push     eax
43352c43 lea      ecx, [edi + 0x20]
43352c46 lea      edx, [esp + 0x210]
43352c4d call     0x43366128
43352c52 movss    xmm4, dword ptr [esp + 0x210]
43352c5b movss    xmm7, dword ptr [esp + 0x2c]
43352c61 movss    xmm5, dword ptr [esp + 0x208]
43352c6a movss    xmm6, dword ptr [esp + 0x20c]
43352c73 ucomiss  xmm4, xmm7
43352c76 lahf     
43352c77 test     ah, 0x44
43352c7a jnp      0x43352ce3
43352c7c movaps   xmm1, xmm5
43352c7f movss    xmm4, dword ptr [esp + 0x68]
43352c85 movaps   xmm0, xmm6
43352c88 mulss    xmm1, xmm5
43352c8c mulss    xmm0, xmm6
43352c90 addss    xmm1, xmm0
43352c94 movaps   xmm0, xmm7
43352c97 mulss    xmm0, xmm7
43352c9b addss    xmm1, xmm0
43352c9f movaps   xmm0, xmm1
43352ca2 sqrtss   xmm0, xmm0
43352ca6 movss    dword ptr [esp + 0x670], xmm0
43352caf addss    xmm0, dword ptr [esp + 0x94]
43352cb8 divss    xmm4, xmm0
43352cbc mulss    xmm5, xmm4
43352cc0 mulss    xmm6, xmm4
43352cc4 mulss    xmm4, xmm7
43352cc8 movss    dword ptr [esp + 0x208], xmm5
43352cd1 movss    dword ptr [esp + 0x20c], xmm6
43352cda movss    dword ptr [esp + 0x210], xmm4
43352ce3 movss    xmm1, dword ptr [esp + 0x21c]
43352cec movss    xmm2, dword ptr [esp + 0x214]
43352cf5 movss    xmm3, dword ptr [esp + 0x218]
43352cfe ucomiss  xmm1, xmm7
43352d01 lahf     
43352d02 test     ah, 0x44
43352d05 jnp      0x43352d6e
43352d07 movaps   xmm1, xmm2
43352d0a movaps   xmm0, xmm3
43352d0d mulss    xmm1, xmm2
43352d11 mulss    xmm0, xmm3
43352d15 addss    xmm1, xmm0
43352d19 movaps   xmm0, xmm7
43352d1c mulss    xmm0, xmm7
43352d20 addss    xmm1, xmm0
43352d24 movaps   xmm0, xmm1
43352d27 movss    xmm1, dword ptr [esp + 0x68]
43352d2d sqrtss   xmm0, xmm0
43352d31 movss    dword ptr [esp + 0x620], xmm0
43352d3a addss    xmm0, dword ptr [esp + 0x94]
43352d43 divss    xmm1, xmm0
43352d47 mulss    xmm2, xmm1
43352d4b mulss    xmm3, xmm1
43352d4f mulss    xmm1, xmm7
43352d53 movss    dword ptr [esp + 0x214], xmm2
43352d5c movss    dword ptr [esp + 0x218], xmm3
43352d65 movss    dword ptr [esp + 0x21c], xmm1
43352d6e movss    xmm0, dword ptr [edi + 0x38]
43352d73 lea      esi, [edi + 0x10c]
43352d79 movss    xmm7, dword ptr [edi + 0x3c]
43352d7e xor      ecx, ecx
43352d80 mulss    xmm6, xmm0
43352d84 lea      edi, [esp + 0x1fc]
43352d8b movsd    dword ptr es:[edi], dword ptr [esi]
43352d8c mulss    xmm5, xmm0
43352d90 mov      eax, dword ptr [esp + 0x14]
43352d94 mulss    xmm0, xmm4
43352d98 movsd    dword ptr es:[edi], dword ptr [esi]
43352d99 mulss    xmm2, xmm7
43352d9d mov      edx, dword ptr [0x43468304]
43352da3 mulss    xmm3, xmm7
43352da7 movsd    dword ptr es:[edi], dword ptr [esi]
43352da8 mulss    xmm7, xmm1
43352dac addss    xmm2, xmm5
43352db0 lea      esi, [eax + 0x1b8]
43352db6 addss    xmm3, xmm6
43352dba movss    xmm6, dword ptr [esp + 0x204]
43352dc3 addss    xmm6, dword ptr [0x43470430]
43352dcb addss    xmm7, xmm0
43352dcf lea      edi, [esp + 0x378]
43352dd6 movsd    dword ptr es:[edi], dword ptr [esi]
43352dd7 movaps   xmm0, xmm3
43352dda mulss    xmm0, xmm3
43352dde movaps   xmm1, xmm7
43352de1 movss    dword ptr [esp + 0x60], xmm6
43352de7 mulss    xmm1, xmm7
43352deb movsd    dword ptr es:[edi], dword ptr [esi]
43352dec addss    xmm1, xmm0
43352df0 movaps   xmm0, xmm2
43352df3 mulss    xmm0, xmm2
43352df7 movsd    dword ptr es:[edi], dword ptr [esi]
43352df8 lea      esi, [eax + 0x1c4]
43352dfe mov      eax, dword ptr [0x43475808]
43352e03 lea      edi, [esp + 0x300]
43352e0a addss    xmm1, xmm0
43352e0e movsd    dword ptr es:[edi], dword ptr [esi]
43352e0f movsd    dword ptr es:[edi], dword ptr [esi]
43352e10 movaps   xmm0, xmm1
43352e13 movss    xmm1, dword ptr [esp + 0x78]
43352e19 sqrtss   xmm0, xmm0
43352e1d movsd    dword ptr es:[edi], dword ptr [esi]
43352e1e or       dword ptr [esp + 0x534], 0xffffffff
43352e26 or       dword ptr [esp + 0x540], 0xffffffff
43352e2e mov      dword ptr [esp + 0x51c], 0x3f800000
43352e39 mov      word ptr [esp + 0x526], cx
43352e41 mov      dword ptr [esp + 0x53c], ecx
43352e48 mov      dword ptr [esp + 0x3f0], 0x4346edc0
43352e53 mov      dword ptr [esp + 0x3f4], eax
43352e5a mov      dword ptr [esp + 0x3f8], 8
43352e65 mov      dword ptr [esp + 0x3fc], ecx
43352e6c mov      eax, dword ptr [edx]
43352e6e mov      esi, dword ptr [eax + 0x14]
43352e71 mov      dword ptr [esp + 0x760], ecx
43352e78 movss    dword ptr [esp + 0x624], xmm0
43352e81 addss    xmm0, dword ptr [esp + 0x94]
43352e8a divss    xmm1, xmm0
43352e8e movss    xmm0, dword ptr [esp + 0x308]
43352e97 subss    xmm0, dword ptr [0x43470430]
43352e9f mulss    xmm2, xmm1
43352ea3 mulss    xmm3, xmm1
43352ea7 mulss    xmm7, xmm1
43352eab movss    xmm1, dword ptr [esp + 0x200]
43352eb4 movss    dword ptr [esp + 0x24], xmm0
43352eba addss    xmm1, xmm3
43352ebe movss    dword ptr [esp + 0xdc], xmm2
43352ec7 movaps   xmm0, xmm6
43352eca addss    xmm2, dword ptr [esp + 0x1fc]
43352ed3 addss    xmm0, xmm7
43352ed7 movss    dword ptr [esp + 0xd4], xmm3
43352ee0 movss    dword ptr [esp + 0x78], xmm7
43352ee6 subss    xmm1, dword ptr [esp + 0x200]
43352eef subss    xmm2, dword ptr [esp + 0x1fc]
43352ef8 subss    xmm0, xmm6
43352efc movss    dword ptr [esp + 0x734], xmm1
43352f05 mulss    xmm1, xmm1
43352f09 movss    dword ptr [esp + 0x730], xmm2
43352f12 movss    dword ptr [esp + 0x738], xmm0
43352f1b mulss    xmm2, xmm2
43352f1f addss    xmm1, xmm2
43352f23 mulss    xmm0, xmm0
43352f27 addss    xmm1, xmm0
43352f2b ucomiss  xmm1, dword ptr [esp + 0x2c]
43352f30 lahf     
43352f31 test     ah, 0x44
43352f34 jnp      0x43352f42
43352f36 xor      eax, eax
43352f38 inc      eax
43352f39 mov      byte ptr [esp + 0x765], al
43352f40 jmp      0x43352f49
43352f42 mov      byte ptr [esp + 0x765], cl
43352f49 movss    xmm5, dword ptr [esp + 0x378]
43352f52 lea      eax, [esp + 0x4f0]
43352f59 movss    xmm1, dword ptr [esp + 0x304]
43352f62 mov      ecx, edx
43352f64 movss    xmm4, dword ptr [esp + 0x37c]
43352f6d movss    xmm2, dword ptr [esp + 0x300]
43352f76 subss    xmm1, xmm4
43352f7a movss    xmm0, dword ptr [esp + 0x24]
43352f80 subss    xmm2, xmm5
43352f84 movss    xmm3, dword ptr [esp + 0x380]
43352f8d subss    xmm0, xmm3
43352f91 addss    xmm5, dword ptr [esp + 0x300]
43352f9a mulss    xmm1, dword ptr [esp + 0x90]
43352fa3 push     eax
43352fa4 mulss    xmm2, dword ptr [esp + 0x94]
43352fad lea      eax, [esp + 0x3f4]
43352fb4 push     eax
43352fb5 mulss    xmm0, dword ptr [esp + 0x98]
43352fbe addss    xmm4, dword ptr [esp + 0x30c]
43352fc7 addss    xmm3, dword ptr [esp + 0x2c]
43352fcd movss    dword ptr [esp + 0x75c], xmm1
43352fd6 movss    dword ptr [esp + 0x760], xmm0
43352fdf mulss    xmm0, xmm0
43352fe3 mulss    xmm1, xmm1
43352fe7 movss    dword ptr [esp + 0x758], xmm2
43352ff0 mulss    xmm2, xmm2
43352ff4 addss    xmm1, xmm2
43352ff8 addss    xmm1, xmm0
43352ffc cvtps2pd xmm0, xmm1
43352fff movsd    xmm1, qword ptr [esp + 0x5b0]
43353008 comisd   xmm1, xmm0
4335300c movss    xmm0, dword ptr [esp + 0x98]
43353015 mulss    xmm5, xmm0
43353019 mulss    xmm4, xmm0
4335301d seta     byte ptr [esp + 0x76c]
43353025 xor      eax, eax
43353027 mulss    xmm3, xmm0
4335302b inc      eax
4335302c push     eax
4335302d movss    xmm0, dword ptr [esp + 0x208]
43353036 lea      eax, [esp + 0x72c]
4335303d addss    xmm0, xmm5
43353041 push     eax
43353042 movss    dword ptr [esp + 0x730], xmm0
4335304b movss    xmm0, dword ptr [esp + 0x210]
43353054 addss    xmm0, xmm4
43353058 movss    dword ptr [esp + 0x734], xmm0
43353061 movaps   xmm0, xmm6
43353064 addss    xmm0, xmm3
43353068 movss    dword ptr [esp + 0x738], xmm0
43353071 movss    xmm0, dword ptr [0x4346f858]
43353079 mulss    xmm5, xmm0
4335307d mulss    xmm4, xmm0
43353081 mulss    xmm3, xmm0
43353085 movss    dword ptr [esp + 0x750], xmm5
4335308e movss    dword ptr [esp + 0x754], xmm4
43353097 movss    dword ptr [esp + 0x758], xmm3
433530a0 call     esi
433530a2 movss    xmm0, dword ptr [esp + 0x51c]
433530ab movss    xmm1, dword ptr [esp + 0x68]
433530b1 comiss   xmm1, xmm0
433530b4 jbe      0x4335313b
433530ba cmp      byte ptr [esp + 0x527], 0
433530c2 jne      0x4335313b
433530c4 cmp      byte ptr [esp + 0x526], 0
433530cc jne      0x4335313b
433530ce movss    xmm0, dword ptr [esp + 0x4fc]
433530d7 subss    xmm0, dword ptr [esp + 0x1fc]
433530e0 mov      esi, dword ptr [esp + 0x84]
433530e7 addss    xmm0, dword ptr [esi]
433530eb movss    xmm1, dword ptr [esi + 4]
433530f0 movss    xmm2, dword ptr [esi + 8]
433530f5 movss    dword ptr [esp + 0x1a8], xmm0
433530fe movss    xmm0, dword ptr [esp + 0x500]
43353107 subss    xmm0, dword ptr [esp + 0x200]
43353110 addss    xmm0, xmm1
43353114 movss    dword ptr [esp + 0x1ac], xmm0
4335311d movss    xmm0, dword ptr [esp + 0x504]
43353126 subss    xmm0, dword ptr [esp + 0x60]
4335312c addss    xmm0, xmm2
43353130 movss    dword ptr [esp + 0x1b0], xmm0
43353139 jmp      0x4335318c
4335313b ucomiss  xmm0, xmm1
4335313e lahf     
4335313f test     ah, 0x44
43353142 jp       0x4335318c
43353144 mov      eax, dword ptr [esp + 0x84]
4335314b movss    xmm2, dword ptr [esp + 0xdc]
43353154 movss    xmm0, dword ptr [eax + 4]
43353159 movss    xmm1, dword ptr [eax + 8]
4335315e addss    xmm2, dword ptr [eax]
43353162 addss    xmm0, dword ptr [esp + 0xd4]
4335316b addss    xmm1, dword ptr [esp + 0x78]
43353171 movss    dword ptr [esp + 0x1a8], xmm2
4335317a movss    dword ptr [esp + 0x1ac], xmm0
43353183 movss    dword ptr [esp + 0x1b0], xmm1
4335318c mov      edi, dword ptr [esp + 0x14]
43353190 movzx    eax, byte ptr [0x4346a3e0]
43353197 lea      ecx, [esp + 0xe10]
4335319e push     eax
4335319f push     dword ptr [edi + 0xc]
433531a2 call     0x433eb28b
433531a7 mov      edi, dword ptr [esp + 0x18]
433531ab xor      eax, eax
433531ad mov      dword ptr [esp + 0x4ac], eax
433531b4 mov      ecx, edi
433531b6 mov      dword ptr [esp + 0x4b0], eax
433531bd mov      dword ptr [esp + 0x4b4], eax
433531c4 mov      dword ptr [esp + 0x4b8], eax
433531cb mov      dword ptr [esp + 0x4bc], eax
433531d2 mov      eax, 0x600400b
433531d7 mov      dword ptr [esp + 0x4c0], eax
433531de mov      dword ptr [esp + 0x4a8], 0x43470404
433531e9 mov      dword ptr [esp + 0x4c4], eax
433531f0 mov      dword ptr [esp + 0x4c8], 0x3f800000
433531fb call     0x433fd30d
43353200 test     eax, eax
43353202 je       0x43353238
43353204 mov      ecx, dword ptr [eax]
43353206 mov      eax, dword ptr [0x43468240]
4335320b mov      eax, dword ptr [eax]
4335320d xor      eax, dword ptr [0x4346a84c]
43353213 xor      eax, 0xc2b6fb10
43353218 imul     edx, dword ptr [eax + edi], 0xc
4335321c add      edx, dword ptr [ecx + 0xb0]
43353222 add      edx, ecx
43353224 je       0x43353238
43353226 cmp      dword ptr [edx + 4], 0
4335322a je       0x43353238
4335322c mov      eax, dword ptr [edx + 8]
4335322f add      eax, 0x198
43353234 add      eax, edx
43353236 jmp      0x4335323a
43353238 xor      eax, eax
4335323a mov      ecx, dword ptr [eax]
4335323c mov      dword ptr [esp + 0x78], eax
43353240 mov      eax, dword ptr [0x43469064]
43353245 imul     esi, ecx, 0x30
43353248 push     0x44
4335324a mov      eax, dword ptr [eax]
4335324c xor      eax, dword ptr [0x4346a484]
43353252 xor      eax, 0x17978090
43353257 add      esi, dword ptr [eax + edi]
4335325a lea      eax, [esp + 0x68c]
43353261 mov      edi, dword ptr [esp + 0x7c]
43353265 push     edi
43353266 push     eax
43353267 call     0x774fd4a0
4335326c movss    xmm0, dword ptr [edi + 8]
43353271 add      esp, 0xc
43353274 mulss    xmm0, dword ptr [esi]
43353278 xor      ecx, ecx
4335327a movss    xmm3, dword ptr [esi + 4]
4335327f mulss    xmm3, dword ptr [edi + 0xc]
43353284 addss    xmm3, xmm0
43353288 movss    xmm0, dword ptr [esi + 8]
4335328d mulss    xmm0, dword ptr [edi + 0x10]
43353292 addss    xmm3, xmm0
43353296 addss    xmm3, dword ptr [esi + 0xc]
4335329b movss    dword ptr [esp + 0x690], xmm3
433532a4 movss    xmm0, dword ptr [esi + 0x10]
433532a9 mulss    xmm0, dword ptr [edi + 8]
433532ae movss    xmm4, dword ptr [esi + 0x14]
433532b3 mulss    xmm4, dword ptr [edi + 0xc]
433532b8 movss    dword ptr [esp + 0x70], xmm3
433532be addss    xmm4, xmm0
433532c2 movss    xmm0, dword ptr [esi + 0x18]
433532c7 mulss    xmm0, dword ptr [edi + 0x10]
433532cc addss    xmm4, xmm0
433532d0 addss    xmm4, dword ptr [esi + 0x1c]
433532d5 movss    dword ptr [esp + 0x694], xmm4
433532de movss    xmm1, dword ptr [esi + 0x24]
433532e3 mulss    xmm1, dword ptr [edi + 0xc]
433532e8 movss    xmm0, dword ptr [esi + 0x20]
433532ed mulss    xmm0, dword ptr [edi + 8]
433532f2 movss    dword ptr [esp + 0x24], xmm4
433532f8 addss    xmm1, xmm0
433532fc movss    xmm0, dword ptr [esi + 0x28]
43353301 mulss    xmm0, dword ptr [edi + 0x10]
43353306 addss    xmm1, xmm0
4335330a addss    xmm1, dword ptr [esi + 0x2c]
4335330f movss    dword ptr [esp + 0x698], xmm1
43353318 movss    xmm0, dword ptr [esi]
4335331c mulss    xmm0, dword ptr [edi + 0x14]
43353321 movss    xmm7, dword ptr [esi + 4]
43353326 mulss    xmm7, dword ptr [edi + 0x18]
4335332b movss    dword ptr [esp + 0xd4], xmm1
43353334 addss    xmm7, xmm0
43353338 movss    xmm0, dword ptr [esi + 8]
4335333d mulss    xmm0, dword ptr [edi + 0x1c]
43353342 addss    xmm7, xmm0
43353346 addss    xmm7, dword ptr [esi + 0xc]
4335334b movss    dword ptr [esp + 0x69c], xmm7
43353354 movss    xmm0, dword ptr [esi + 0x10]
43353359 mulss    xmm0, dword ptr [edi + 0x14]
4335335e movss    xmm5, dword ptr [esi + 0x14]
43353363 mulss    xmm5, dword ptr [edi + 0x18]
43353368 movss    dword ptr [esp + 0x34], xmm7
4335336e addss    xmm5, xmm0
43353372 movss    xmm0, dword ptr [esi + 0x18]
43353377 mulss    xmm0, dword ptr [edi + 0x1c]
4335337c addss    xmm5, xmm0
43353380 addss    xmm5, dword ptr [esi + 0x1c]
43353385 movss    dword ptr [esp + 0x6a0], xmm5
4335338e movss    xmm0, dword ptr [esi + 0x20]
43353393 movss    xmm1, dword ptr [esi + 0x24]
43353398 mulss    xmm1, dword ptr [edi + 0x18]
4335339d mulss    xmm0, dword ptr [edi + 0x14]
433533a2 addss    xmm1, xmm0
433533a6 movss    xmm0, dword ptr [esi + 0x28]
433533ab mulss    xmm0, dword ptr [edi + 0x1c]
433533b0 addss    xmm1, xmm0
433533b4 addss    xmm1, dword ptr [esi + 0x2c]
433533b9 movss    dword ptr [esp + 0x108], xmm1
433533c2 movss    dword ptr [esp + 0x6a4], xmm1
433533cb movss    xmm0, dword ptr [esp + 0x90]
433533d4 movaps   xmm2, xmm7
433533d7 addss    xmm2, xmm3
433533db mov      dword ptr [esp + 0x54], ecx
433533df movaps   xmm6, xmm5
433533e2 movaps   xmm3, xmm1
433533e5 addss    xmm3, dword ptr [esp + 0xd4]
433533ee addss    xmm6, xmm4
433533f2 mulss    xmm2, xmm0
433533f6 mulss    xmm3, xmm0
433533fa subss    xmm2, dword ptr [esp + 0x1a8]
43353403 mulss    xmm6, xmm0
43353407 subss    xmm3, dword ptr [esp + 0x1b0]
43353410 subss    xmm6, dword ptr [esp + 0x1ac]
43353419 movaps   xmm1, xmm2
4335341c mulss    xmm1, xmm2
43353420 movaps   xmm0, xmm6
43353423 mulss    xmm0, xmm6
43353427 addss    xmm1, xmm0
4335342b movaps   xmm0, xmm3
4335342e mulss    xmm0, xmm3
43353432 addss    xmm1, xmm0
43353436 movaps   xmm0, xmm1
43353439 movss    xmm1, dword ptr [esp + 0x68]
4335343f sqrtss   xmm0, xmm0
43353443 movss    dword ptr [esp + 0x628], xmm0
4335344c addss    xmm0, dword ptr [esp + 0x94]
43353455 divss    xmm1, xmm0
43353459 movss    xmm0, dword ptr [esp + 0x2c]
4335345f movaps   xmm4, xmm1
43353462 mulss    xmm6, xmm1
43353466 mulss    xmm4, xmm2
4335346a mulss    xmm3, xmm1
4335346e ucomiss  xmm4, xmm0
43353471 lahf     
43353472 test     ah, 0x44
43353475 jp       0x433534ba
43353477 ucomiss  xmm6, xmm0
4335347a lahf     
4335347b test     ah, 0x44
4335347e jp       0x433534ba
43353480 and      dword ptr [esp + 0x3b4], ecx
43353487 lea      esi, [esp + 0x3b4]
4335348e and      dword ptr [esp + 0x3bc], ecx
43353495 movaps   xmm4, xmm0
43353498 mov      dword ptr [esp + 0x3b8], 0xbf800000
433534a3 movaps   xmm6, xmm0
433534a6 movss    dword ptr [esp + 0xdc], xmm0
433534af movss    dword ptr [esp + 0x60], xmm0
433534b5 jmp      0x43353555
433534ba mulss    xmm3, xmm0
433534be lea      esi, [esp + 0x350]
433534c5 movaps   xmm2, xmm6
433534c8 mulss    xmm6, xmm0
433534cc subss    xmm2, xmm3
433534d0 subss    xmm3, xmm4
433534d4 mulss    xmm4, xmm0
433534d8 movaps   xmm1, xmm2
433534db subss    xmm4, xmm6
433534df mulss    xmm1, xmm2
433534e3 movaps   xmm0, xmm3
433534e6 mulss    xmm0, xmm3
433534ea addss    xmm1, xmm0
433534ee movaps   xmm0, xmm4
433534f1 mulss    xmm0, xmm4
433534f5 addss    xmm1, xmm0
433534f9 movaps   xmm0, xmm1
433534fc movss    xmm1, dword ptr [esp + 0x68]
43353502 sqrtss   xmm0, xmm0
43353506 movss    dword ptr [esp + 0x62c], xmm0
4335350f addss    xmm0, dword ptr [esp + 0x94]
43353518 divss    xmm1, xmm0
4335351c mulss    xmm4, xmm1
43353520 mulss    xmm2, xmm1
43353524 mulss    xmm3, xmm1
43353528 movaps   xmm6, xmm4
4335352b movss    dword ptr [esp + 0x350], xmm2
43353534 movss    dword ptr [esp + 0x358], xmm4
4335353d movss    dword ptr [esp + 0x354], xmm3
43353546 movss    dword ptr [esp + 0xdc], xmm4
4335354f movss    dword ptr [esp + 0x60], xmm4
43353555 subss    xmm5, dword ptr [esp + 0x24]
4335355b movss    xmm3, dword ptr [esp + 0x108]
43353564 lea      edi, [esp + 0x238]
4335356b subss    xmm3, dword ptr [esp + 0xd4]
43353574 movsd    dword ptr es:[edi], dword ptr [esi]
43353575 movaps   xmm0, xmm7
43353578 subss    xmm0, dword ptr [esp + 0x70]
4335357e movaps   xmm1, xmm5
43353581 movsd    dword ptr es:[edi], dword ptr [esi]
43353582 movss    dword ptr [esp + 0x108], xmm3
4335358b movss    dword ptr [esp + 0x7c], xmm0
43353591 movsd    dword ptr es:[edi], dword ptr [esi]
43353592 movss    xmm2, dword ptr [esp + 0x23c]
4335359b movss    xmm7, dword ptr [esp + 0x238]
433535a4 mulss    xmm0, xmm7
433535a8 mulss    xmm1, xmm2
433535ac movss    dword ptr [esp + 0x24], xmm2
433535b2 addss    xmm1, xmm0
433535b6 movaps   xmm0, xmm3
433535b9 movss    xmm3, dword ptr [esp + 0x240]
433535c2 mulss    xmm0, xmm3
433535c6 addss    xmm1, xmm0
433535ca comiss   xmm1, dword ptr [esp + 0x2c]
433535cf jb       0x433535d9
433535d1 movss    xmm0, dword ptr [esp + 0x34]
433535d7 jmp      0x433535ee
433535d9 movss    xmm0, dword ptr [esp + 0x70]
433535df movss    xmm4, dword ptr [esp + 0xdc]
433535e8 movss    xmm6, dword ptr [esp + 0x60]
433535ee movss    dword ptr [esp + 0xd4], xmm0
433535f7 lea      ecx, [esp + 0x6a0]
433535fe mulss    xmm3, xmm3
43353602 lea      eax, [esp + 0x694]
43353609 cmovae   eax, ecx
4335360c lea      ecx, [esp + 0x6a4]
43353613 movaps   xmm0, xmm2
43353616 mulss    xmm0, xmm2
4335361a movss    xmm2, dword ptr [eax]
4335361e lea      eax, [esp + 0x698]
43353625 cmovae   eax, ecx
43353628 addss    xmm3, xmm0
4335362c movaps   xmm0, xmm7
4335362f mulss    xmm0, xmm7
43353633 movss    xmm1, dword ptr [eax]
43353637 addss    xmm3, xmm0
4335363b movaps   xmm0, xmm3
4335363e movss    xmm3, dword ptr [esp + 0x6b8]
43353647 sqrtss   xmm0, xmm0
4335364b movss    dword ptr [esp + 0x60], xmm3
43353651 divss    xmm3, xmm0
43353655 movss    dword ptr [esp + 0x654], xmm0
4335365e movaps   xmm0, xmm3
43353661 mulss    xmm0, xmm7
43353665 addss    xmm0, dword ptr [esp + 0xd4]
4335366e movss    dword ptr [esp + 0x46c], xmm0
43353677 movaps   xmm0, xmm3
4335367a mulss    xmm0, dword ptr [esp + 0x24]
43353680 mulss    xmm3, xmm4
43353684 addss    xmm0, xmm2
43353688 addss    xmm3, xmm1
4335368c movss    dword ptr [esp + 0x470], xmm0
43353695 movss    xmm0, dword ptr [esp + 0xf0]
4335369e movss    dword ptr [esp + 0x474], xmm3
433536a7 xorps    xmm7, xmm0
433536aa movss    xmm3, dword ptr [esp + 0x24]
433536b0 xorps    xmm6, xmm0
433536b3 xorps    xmm3, xmm0
433536b6 movss    xmm0, dword ptr [esp + 0x7c]
433536bc mulss    xmm0, xmm7
433536c0 mulss    xmm5, xmm3
433536c4 addss    xmm5, xmm0
433536c8 movaps   xmm0, xmm6
433536cb mulss    xmm0, dword ptr [esp + 0x108]
433536d4 addss    xmm5, xmm0
433536d8 comiss   xmm5, dword ptr [esp + 0x2c]
433536dd jae      0x433536eb
433536df movss    xmm0, dword ptr [esp + 0x70]
433536e5 movss    dword ptr [esp + 0x34], xmm0
433536eb movaps   xmm1, xmm7
433536ee movss    xmm4, dword ptr [esp + 0x60]
433536f4 movaps   xmm0, xmm3
433536f7 mulss    xmm1, xmm7
433536fb lea      ecx, [esp + 0x6a0]
43353702 mov      edi, dword ptr [esp + 0x78]
43353706 mulss    xmm0, xmm3
4335370a lea      eax, [esp + 0x694]
43353711 cmovae   eax, ecx
43353714 lea      ecx, [esp + 0x6a4]
4335371b push     2
4335371d addss    xmm1, xmm0
43353721 movaps   xmm0, xmm6
43353724 mulss    xmm0, xmm6
43353728 movss    xmm2, dword ptr [eax]
4335372c lea      eax, [esp + 0x69c]
43353733 cmovae   eax, ecx
43353736 addss    xmm1, xmm0
4335373a xorps    xmm0, xmm0
4335373d pop      ecx
4335373e mov      dword ptr [esp + 0x60], ecx
43353742 movss    xmm0, xmm1
43353746 movss    xmm1, dword ptr [eax]
4335374a sqrtss   xmm0, xmm0
4335374e lea      eax, [esp + 0x46c]
43353755 mov      dword ptr [esp + 0x24], eax
43353759 divss    xmm4, xmm0
4335375d movss    dword ptr [esp + 0x658], xmm0
43353766 movaps   xmm0, xmm4
43353769 mulss    xmm6, xmm4
4335376d mulss    xmm0, xmm7
43353771 addss    xmm6, xmm1
43353775 addss    xmm0, dword ptr [esp + 0x34]
4335377b movss    dword ptr [esp + 0x480], xmm6
43353784 movss    dword ptr [esp + 0x478], xmm0
4335378d movaps   xmm0, xmm4
43353790 mulss    xmm0, xmm3
43353794 addss    xmm0, xmm2
43353798 movss    dword ptr [esp + 0x47c], xmm0
433537a1 lea      ecx, [esp + 0xe10]
433537a8 push     ecx
433537a9 lea      ecx, [esp + 0x4ac]
433537b0 push     ecx
433537b1 mov      ecx, dword ptr [0x43475808]
433537b7 lea      edx, [esp + 0x1b0]
433537be push     eax
433537bf call     0x43329d2b
433537c4 cvttss2si eax, dword ptr [esp + 0xe18]
433537cd mov      esi, dword ptr [esp + 0x18]
433537d1 test     eax, eax
433537d3 je       0x433537f4
433537d5 push     dword ptr [edi + 4]
433537d8 lea      ecx, [esp + 0xe14]
433537df push     esi
433537e0 call     0x433e9ecd
433537e5 mov      ecx, dword ptr [esp + 0x54]
433537e9 cmp      ecx, eax
433537eb cmovl    ecx, eax
433537ee mov      dword ptr [esp + 0x54], ecx
433537f2 jmp      0x433537f8
433537f4 mov      ecx, dword ptr [esp + 0x54]
433537f8 mov      eax, dword ptr [esp + 0x24]
433537fc push     0xc
433537fe pop      edx
433537ff add      eax, edx
43353801 sub      dword ptr [esp + 0x60], 1
43353806 mov      dword ptr [esp + 0x24], eax
4335380a jne      0x433537a1
4335380c test     ecx, ecx
4335380e je       0x433538b7
43353814 mov      dword ptr [esp + 0x7c], 0x6d2cfbd5
4335381c mov      edx, esi
4335381e mov      eax, dword ptr [esp + 0x7c]
43353822 mov      ecx, dword ptr [esi]
43353824 inc      eax
43353825 xor      eax, 0x4a674016
4335382a mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
43353831 mov      dword ptr [esp + 0x65c], ecx
43353838 call     0x433e533f
4335383d mov      edi, dword ptr [esp + 0x14]
43353841 mov      edx, eax
43353843 mov      ecx, dword ptr [esp + 0x54]
43353847 cmp      dword ptr [edi + 0xd8], 0x28
4335384e je       0x43353865
43353850 xor      eax, eax
43353852 inc      eax
43353853 cmp      dword ptr [edi + 0x1d4], eax
43353859 jne      0x43353865
4335385b test     dword ptr [edi], 0x8000000
43353861 jne      0x43353865
43353863 sub      edx, ecx
43353865 mov      eax, dword ptr [esp + 0x4c]
43353869 cmp      eax, edx
4335386b mov      esi, dword ptr [esp + 0x1c]
4335386f cmovl    eax, edx
43353872 cmp      ecx, eax
43353874 jl       0x433538bf
43353876 test     dword ptr [esi + 0x170], 0x400
43353880 je       0x4335388d
43353882 push     0x1f
43353884 pop      eax
43353885 cmp      dword ptr [edi + 0xd8], eax
4335388b jne      0x433538af
4335388d mov      eax, dword ptr [esp + 0x3c]
43353891 mov      ecx, dword ptr [esp + 0x74]
43353895 push     0xc
43353897 pop      edx
43353898 and      eax, edx
4335389a and      ecx, edx
4335389c mov      dword ptr [esp + 0x12c], eax
433538a3 or       eax, ecx
433538a5 cmove    ecx, edx
433538a8 mov      dword ptr [esp + 0x128], ecx
433538af or       dword ptr [edi], 0x1000000
433538b5 jmp      0x433538bf
433538b7 mov      edi, dword ptr [esp + 0x14]
433538bb mov      esi, dword ptr [esp + 0x1c]
433538bf lea      ecx, [esp + 0x2a8]
433538c6 call     0x43367f7b
433538cb cmp      byte ptr [esp + 0x146], 0
433538d3 je       0x43354009
433538d9 test     dword ptr [edi], 0x400
433538da pop      es
433538db add      byte ptr [eax + eax], al
433538de add      byte ptr [edi], cl
433538df je       0x43354009
433538e0 test     byte ptr [edi + eax], ah
433538e3 add      byte ptr [eax], al
433538e5 push     3
433538e7 pop      eax
433538e8 test     byte ptr [esi + 0x170], al
433538ee jne      0x43354009
433538f4 test     byte ptr [0x434759c0], 8
433538fb jne      0x43354009
43353901 mov      ecx, dword ptr [esp + 0x50]
43353905 mov      eax, dword ptr [ecx]
43353907 call     dword ptr [eax + 0x28]
4335390a test     eax, eax
4335390c jne      0x4335391a
4335390e jge      0x433538da
43353910 and      al, byte ptr [0xd1267653]
43353916 mov      ecx, 0xc88bd7c8
4335391a mov      ecx, eax
4335391c call     0x433b8a2b
43353921 mov      edx, eax
43353923 xor      esi, esi
43353925 cmp      dword ptr [edx + 0x5d8], esi
4335392b je       0x43354009
43353931 test     dword ptr [edi], 0x8000000
43353937 jne      0x43354009
4335393d cmp      dword ptr [edi + 0xd8], 0x40
43353944 jne      0x43353959
43353946 mov      ecx, dword ptr [esp + 0x1c]
4335394a xor      eax, eax
4335394c inc      eax
4335394d test     byte ptr [ecx + 0x174], al
43353953 je       0x43354009
43353959 test     dword ptr [edi], 0x102000
4335395f jne      0x43354009
43353965 test     dword ptr [edi], 0x40000
4335396b je       0x43354009
43353971 test     dword ptr [edi], 0x4000
43353977 jne      0x43354009
4335397d movss    xmm0, dword ptr [0x4346eeb0]
43353985 comiss   xmm0, dword ptr [edi + 0xc0]
4335398c jbe      0x4335399b
4335398e test     dword ptr [edi + 0x44], 0x618
43353995 je       0x43354009
4335399b push     0x10a0
433539a0 mov      eax, 0x600400b
433539a5 mov      dword ptr [esp + 0x42c], esi
433539ac mov      dword ptr [esp + 0x440], eax
433539b3 mov      dword ptr [esp + 0x444], eax
433539ba push     0x1f
433539bc mov      dword ptr [esp + 0x434], esi
433539c3 mov      dword ptr [esp + 0x438], esi
433539ca mov      dword ptr [esp + 0x43c], esi
433539d1 mov      dword ptr [esp + 0x440], esi
433539d8 mov      dword ptr [esp + 0x42c], 0x43470404
433539e3 mov      dword ptr [esp + 0x44c], 0x3f800000
433539ee mov      dword ptr [esp + 0x2218], esi
433539f5 mov      eax, dword ptr [edx + 0x5d4]
433539fb pop      ecx
433539fc and      eax, ecx
433539fe push     dword ptr [edx + eax*4 + 0x5dc]
43353a05 lea      eax, [esp + 0x2218]
43353a0c push     eax
43353a0d call     0x774fd4a0
43353a12 mov      edx, dword ptr [esp + 0x24]
43353a16 lea      eax, [esp + 0x221c]
43353a1d add      esp, 0xc
43353a20 mov      ecx, edi
43353a22 push     eax
43353a23 call     0x43327659
43353a28 xor      eax, eax
43353a2a lea      ecx, [esp + 0xc28]
43353a31 inc      eax
43353a32 push     eax
43353a33 push     dword ptr [edi + 0xc]
43353a36 call     0x433eb28b
43353a3b movss    xmm0, dword ptr [esp + 0x2240]
43353a44 lea      esi, [esp + 0x1cc]
43353a4b mov      eax, dword ptr [0x43475808]
43353a50 lea      edi, [esp + 0x63c]
43353a57 movss    dword ptr [esp + 0x1cc], xmm0
43353a60 lea      ecx, [esp + 0xc28]
43353a67 movss    xmm0, dword ptr [esp + 0x2244]
43353a70 mov      edx, dword ptr [esp + 0x84]
43353a77 movss    dword ptr [esp + 0x1d0], xmm0
43353a80 movss    xmm0, dword ptr [esp + 0x2228]
43353a89 mulss    xmm0, dword ptr [esp + 0x90]
43353a92 push     ecx
43353a93 lea      ecx, [esp + 0x428]
43353a9a mov      dword ptr [esp + 0xe0], eax
43353aa1 push     ecx
43353aa2 addss    xmm0, dword ptr [esp + 0x2250]
43353aab lea      ecx, [esp + 0x644]
43353ab2 push     ecx
43353ab3 mov      ecx, eax
43353ab5 movss    dword ptr [esp + 0x1e0], xmm0
43353abe movsd    dword ptr es:[edi], dword ptr [esi]
43353abf movsd    dword ptr es:[edi], dword ptr [esi]
43353ac0 movsd    dword ptr es:[edi], dword ptr [esi]
43353ac1 call     0x43329d2b
43353ac6 cmp      dword ptr [esp + 0xca8], 0
43353ace mov      edi, dword ptr [esp + 0x18]
43353ad2 je       0x43354003
43353ad8 mov      dword ptr [esp + 0x7c], 0x6d2cfbd5
43353ae0 mov      edx, edi
43353ae2 mov      eax, dword ptr [esp + 0x7c]
43353ae6 mov      ecx, dword ptr [edi]
43353ae8 inc      eax
43353ae9 xor      eax, 0x4a674016
43353aee mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
43353af5 mov      dword ptr [esp + 0x660], ecx
43353afc call     0x433e533f
43353b01 push     3
43353b03 mov      esi, eax
43353b05 lea      ecx, [esp + 0xc2c]
43353b0c pop      eax
43353b0d push     eax
43353b0e push     edi
43353b0f mov      dword ptr [esp + 0x110], esi
43353b16 call     0x433e9ecd
43353b1b mov      ecx, eax
43353b1d mov      dword ptr [esp + 0x70], ecx
43353b21 test     ecx, ecx
43353b23 jg       0x43353b32
43353b25 mov      dword ptr [esp + 0xd4], 0x7fffffff
43353b30 jmp      0x43353b53
43353b32 lea      eax, [esi - 1]
43353b35 add      eax, ecx
43353b37 cdq      
43353b38 idiv     ecx
43353b3a xor      edx, edx
43353b3c inc      edx
43353b3d cmp      eax, edx
43353b3f mov      esi, edx
43353b41 cmovg    esi, eax
43353b44 mov      dword ptr [esp + 0xd4], esi
43353b4b cmp      esi, edx
43353b4d jle      0x43354003
43353b53 mov      edi, dword ptr [esp + 0x14]
43353b57 lea      eax, [esp + 0x1d8]
43353b5e push     0
43353b60 push     eax
43353b61 lea      edx, [esp + 0x1c8]
43353b68 lea      ecx, [edi + 0x118]
43353b6e call     0x43366128
43353b73 movss    xmm1, dword ptr [esp + 0x1c0]
43353b7c movss    xmm0, dword ptr [esp + 0x1c4]
43353b85 movss    xmm5, dword ptr [esp + 0x2c]
43353b8b mulss    xmm0, xmm0
43353b8f mov      eax, dword ptr [esp + 0x28]
43353b93 mulss    xmm1, xmm1
43353b97 mov      ecx, dword ptr [esp + 0xdc]
43353b9e addss    xmm1, xmm0
43353ba2 movaps   xmm0, xmm5
43353ba5 mulss    xmm0, xmm5
43353ba9 addss    xmm1, xmm0
43353bad movaps   xmm0, xmm1
43353bb0 movss    xmm1, dword ptr [esp + 0x68]
43353bb6 sqrtss   xmm0, xmm0
43353bba movss    dword ptr [esp + 0x664], xmm0
43353bc3 addss    xmm0, dword ptr [esp + 0x94]
43353bcc divss    xmm1, xmm0
43353bd0 movss    xmm0, dword ptr [esp + 0x1dc]
43353bd9 movaps   xmm2, xmm1
43353bdc mulss    xmm0, xmm0
43353be0 movaps   xmm3, xmm1
43353be3 mulss    xmm2, dword ptr [esp + 0x1c0]
43353bec mulss    xmm1, xmm5
43353bf0 mulss    xmm3, dword ptr [esp + 0x1c4]
43353bf9 movss    dword ptr [esp + 0x1c8], xmm1
43353c02 movss    xmm1, dword ptr [esp + 0x1d8]
43353c0b mulss    xmm1, xmm1
43353c0f movss    dword ptr [esp + 0x1c0], xmm2
43353c18 movss    dword ptr [esp + 0x1c4], xmm3
43353c21 addss    xmm1, xmm0
43353c25 movaps   xmm0, xmm5
43353c28 mulss    xmm0, xmm5
43353c2c addss    xmm1, xmm0
43353c30 movaps   xmm0, xmm1
43353c33 movss    xmm1, dword ptr [esp + 0x68]
43353c39 sqrtss   xmm0, xmm0
43353c3d movss    dword ptr [esp + 0x668], xmm0
43353c46 addss    xmm0, dword ptr [esp + 0x94]
43353c4f divss    xmm1, xmm0
43353c53 movaps   xmm0, xmm1
43353c56 movaps   xmm4, xmm1
43353c59 mulss    xmm0, dword ptr [esp + 0x1d8]
43353c62 mulss    xmm4, dword ptr [esp + 0x1dc]
43353c6b mulss    xmm1, xmm5
43353c6f movss    dword ptr [esp + 0x1d8], xmm0
43353c78 movss    dword ptr [esp + 0x1dc], xmm4
43353c81 movss    dword ptr [esp + 0x1e0], xmm1
43353c8a mulss    xmm0, dword ptr [eax + 0x28]
43353c8f mulss    xmm2, dword ptr [eax + 0x24]
43353c94 mulss    xmm4, dword ptr [eax + 0x28]
43353c99 mulss    xmm3, dword ptr [eax + 0x24]
43353c9e addss    xmm0, xmm2
43353ca2 addss    xmm4, xmm3
43353ca6 movss    dword ptr [esp + 0x24], xmm0
43353cac movss    dword ptr [esp + 0x60], xmm4
43353cb2 call     0x4336961e
43353cb7 movss    xmm2, dword ptr [esp + 0x24]
43353cbd movaps   xmm3, xmm0
43353cc0 movss    xmm1, dword ptr [esp + 0x60]
43353cc6 mulss    xmm2, xmm2
43353cca mov      edx, dword ptr [edi + 0xc]
43353ccd mulss    xmm1, xmm1
43353cd1 addss    xmm2, xmm1
43353cd5 movss    xmm1, dword ptr [esp + 0x2c]
43353cdb mulss    xmm1, xmm1
43353cdf addss    xmm2, xmm1
43353ce3 movaps   xmm0, xmm2
43353ce6 sqrtss   xmm0, xmm0
43353cea movss    dword ptr [esp + 0x66c], xmm0
43353cf3 addss    xmm0, dword ptr [esp + 0x94]
43353cfc mov      dword ptr [esp + 0x7c], 0xe3852753
43353d04 mov      eax, dword ptr [esp + 0x7c]
43353d08 divss    xmm3, xmm0
43353d0c movss    dword ptr [esp + 0x78], xmm3
43353d12 mov      ecx, dword ptr [edx]
43353d14 add      eax, 0x1c7af3bd
43353d19 ror      eax, 2
43353d1c push     0
43353d1e mov      ecx, dword ptr [eax + ecx]
43353d21 mov      dword ptr [esp + 0x678], ecx
43353d28 call     0x433e533f
43353d2d movss    xmm2, dword ptr [esp + 0x78]
43353d33 lea      edx, [edi + 0xdc]
43353d39 fmul     dword ptr [esp + 0xd0]
43353d40 movaps   xmm1, xmm2
43353d43 mulss    xmm1, dword ptr [esp + 0x24]
43353d49 movaps   xmm0, xmm2
43353d4c xor      ecx, ecx
43353d4e mulss    xmm0, dword ptr [esp + 0x60]
43353d54 movss    xmm3, dword ptr [esp + 0x2c]
43353d5a fstp     dword ptr [esp + 0x84]
43353d61 mulss    xmm1, dword ptr [esp + 0x84]
43353d6a mulss    xmm0, dword ptr [esp + 0x84]
43353d73 addss    xmm1, dword ptr [edx]
43353d77 mulss    xmm2, xmm3
43353d7b mulss    xmm2, dword ptr [esp + 0x84]
43353d84 movss    dword ptr [esp + 0x320], xmm1
43353d8d addss    xmm0, dword ptr [edx + 4]
43353d92 movss    dword ptr [esp + 0x324], xmm0
43353d9b addss    xmm2, dword ptr [edx + 8]
43353da0 or       dword ptr [esp + 0x98c], 0xffffffff
43353da8 or       dword ptr [esp + 0x998], 0xffffffff
43353db0 mov      dword ptr [esp + 0x974], 0x3f800000
43353dbb mov      word ptr [esp + 0x97e], cx
43353dc3 movss    dword ptr [esp + 0x328], xmm2
43353dcc mov      dword ptr [esp + 0x994], ecx
43353dd3 mov      dword ptr [esp + 0x7b0], ecx
43353dda subss    xmm1, dword ptr [edx]
43353dde movss    dword ptr [esp + 0x780], xmm1
43353de7 subss    xmm0, dword ptr [edx + 4]
43353dec mulss    xmm1, xmm1
43353df0 movss    dword ptr [esp + 0x784], xmm0
43353df9 subss    xmm2, dword ptr [edx + 8]
43353dfe mulss    xmm0, xmm0
43353e02 movss    dword ptr [esp + 0x788], xmm2
43353e0b addss    xmm1, xmm0
43353e0f mulss    xmm2, xmm2
43353e13 addss    xmm1, xmm2
43353e17 ucomiss  xmm1, xmm3
43353e1a lahf     
43353e1b test     ah, 0x44
43353e1e jnp      0x43353e2c
43353e20 xor      eax, eax
43353e22 inc      eax
43353e23 mov      byte ptr [esp + 0x7b5], al
43353e2a jmp      0x43353e33
43353e2c mov      byte ptr [esp + 0x7b5], cl
43353e33 and      dword ptr [esp + 0x7a0], ecx
43353e3a lea      eax, [esp + 0x948]
43353e41 and      dword ptr [esp + 0x7a4], ecx
43353e48 movss    xmm1, dword ptr [0x4346f1f0]
43353e50 mov      byte ptr [esp + 0x7b4], cl
43353e57 lea      ecx, [esp + 0x770]
43353e5e mov      dword ptr [esp + 0x7a8], 0x40000000
43353e69 movss    xmm0, dword ptr [edx]
43353e6d subss    xmm0, xmm1
43353e71 push     eax
43353e72 xor      eax, eax
43353e74 movss    dword ptr [esp + 0x774], xmm0
43353e7d movss    xmm0, dword ptr [edx + 4]
43353e82 subss    xmm0, xmm1
43353e86 movss    dword ptr [esp + 0x778], xmm0
43353e8f movss    xmm0, dword ptr [edx + 8]
43353e94 lea      edx, [eax + 1]
43353e97 addss    xmm0, xmm3
43353e9b mov      dword ptr [esp + 0x794], 0x41800000
43353ea6 mov      dword ptr [esp + 0x798], 0x41800000
43353eb1 mov      dword ptr [esp + 0x79c], 0x80000000
43353ebc movss    dword ptr [esp + 0x77c], xmm0
43353ec5 call     0x433f545e
43353eca mov      ecx, dword ptr [esp + 0xdc]
43353ed1 lea      esi, [esp + 0x954]
43353ed8 lea      edi, [esp + 0x320]
43353edf movsd    dword ptr es:[edi], dword ptr [esi]
43353ee0 lea      eax, [esp + 0xc28]
43353ee7 push     eax
43353ee8 lea      eax, [esp + 0x428]
43353eef push     eax
43353ef0 movsd    dword ptr es:[edi], dword ptr [esi]
43353ef1 lea      eax, [esp + 0x644]
43353ef8 push     eax
43353ef9 lea      edx, [esp + 0x32c]
43353f00 movsd    dword ptr es:[edi], dword ptr [esi]
43353f01 call     0x43329d2b
43353f06 mov      edi, dword ptr [esp + 0x18]
43353f0a test     eax, eax
43353f0c je       0x43354003
43353f12 push     3
43353f14 pop      eax
43353f15 push     eax
43353f16 push     edi
43353f17 lea      ecx, [esp + 0xc30]
43353f1e call     0x433e9ecd
43353f23 mov      ecx, eax
43353f25 mov      dword ptr [esp + 0x24], ecx
43353f29 test     ecx, ecx
43353f2b jle      0x43354003
43353f31 mov      edi, dword ptr [esp + 0x108]
43353f38 mov      esi, dword ptr [esp + 0x14]
43353f3c lea      eax, [edi - 1]
43353f3f add      eax, ecx
43353f41 cdq      
43353f42 idiv     ecx
43353f44 xor      edx, edx
43353f46 inc      edx
43353f47 cmp      eax, edx
43353f49 mov      ecx, edx
43353f4b cmovg    ecx, eax
43353f4e cmp      dword ptr [esp + 0xd4], ecx
43353f55 jle      0x4335400d
43353f5b push     2
43353f5d pop      eax
43353f5e cmp      ecx, eax
43353f60 jl       0x43353f7a
43353f62 test     dword ptr [0x434759c0], 0x8000
43353f6c je       0x43353f7a
43353f6e cmp      dword ptr [esi + 0x1d4], edx
43353f74 je       0x4335400d
43353f7a mov      eax, edi
43353f7c cdq      
43353f7d idiv     ecx
43353f7f test     edx, edx
43353f81 je       0x43353f8b
43353f83 mov      eax, ecx
43353f85 sub      eax, edx
43353f87 add      eax, edi
43353f89 jmp      0x43353f8d
43353f8b mov      eax, edi
43353f8d cdq      
43353f8e idiv     ecx
43353f90 cmp      eax, dword ptr [esp + 0x24]
43353f94 cmovg    eax, dword ptr [esp + 0x24]
43353f99 xor      ecx, ecx
43353f9b inc      ecx
43353f9c mov      dword ptr [esp + 0x60], eax
43353fa0 cmp      dword ptr [esi + 0x1d4], ecx
43353fa6 jne      0x43353ff1
43353fa8 mov      edx, dword ptr [esi + 0xc]
43353fab mov      dword ptr [esp + 0x7c], 0x289d6d91
43353fb3 mov      eax, dword ptr [esp + 0x7c]
43353fb7 mov      ecx, dword ptr [edx]
43353fb9 sub      ecx, eax
43353fbb mov      ecx, dword ptr [ecx + 0x289d7449]
43353fc1 mov      dword ptr [esp + 0x678], ecx
43353fc8 call     0x433e533f
43353fcd test     al, al
43353fcf je       0x43353fed
43353fd1 mov      eax, dword ptr [esp + 0x70]
43353fd5 mov      ecx, dword ptr [esp + 0x24]
43353fd9 add      eax, ecx
43353fdb cmp      eax, edi
43353fdd jg       0x4335400d
43353fdf sub      edi, ecx
43353fe1 xor      ecx, ecx
43353fe3 inc      ecx
43353fe4 cmp      edi, ecx
43353fe6 mov      eax, ecx
43353fe8 cmovg    eax, edi
43353feb jmp      0x43353ff1
43353fed mov      eax, dword ptr [esp + 0x60]
43353ff1 mov      ecx, dword ptr [esp + 0x4c]
43353ff5 cmp      eax, ecx
43353ff7 cmovg    ecx, eax
43353ffa mov      dword ptr [esp + 0x138], ecx
43354001 jmp      0x4335400d
43354003 mov      esi, dword ptr [esp + 0x14]
43354007 jmp      0x43354011
43354009 mov      esi, dword ptr [esp + 0x14]
4335400d mov      edi, dword ptr [esp + 0x18]
43354011 and      dword ptr [esp + 0x78], 0
43354016 mov      eax, dword ptr [esp + 0x48]
4335401a test     eax, eax
4335401c je       0x4335422b
43354022 push     dword ptr [eax*4 + 0x43474950]
43354029 mov      ecx, dword ptr [esp + 0x8c]
43354030 lea      eax, [esp + 0x2ac]
43354037 add      ecx, 0x5d4
4335403d mov      edx, edi
4335403f push     eax
43354040 mov      dword ptr [esp + 0x8c], ecx
43354047 push     ecx
43354048 mov      ecx, esi
4335404a call     0x433aeba8
4335404f mov      ecx, dword ptr [esp + 0x2a8]
43354056 mov      eax, dword ptr [esp + 0x2ac]
4335405d cmp      ecx, eax
4335405f je       0x43354094
43354061 sub      eax, ecx
43354063 push     2
43354065 sar      eax, 2
43354068 pop      edx
43354069 cmp      eax, edx
4335406b jb       0x43354087
4335406d push     0x433cdc5c
43354072 push     4
43354074 push     eax
43354075 push     ecx
43354076 call     dword ptr [esp + 0xf8]
4335407d mov      ecx, dword ptr [esp + 0x2b8]
43354084 add      esp, 0x10
43354087 mov      dword ptr [esp + 0x78], 4
4335408f jmp      0x43354232
43354094 mov      eax, dword ptr [esp + 0x88]
4335409b cmp      dword ptr [eax + 0x5d8], 0
433540a2 jne      0x433540b9
433540a4 lea      ecx, [esp + 0x2a8]
433540ab call     0x433cce8e
433540b0 mov      edi, dword ptr [esp + 0x1c]
433540b4 jmp      0x43354728
433540b9 mov      ecx, esi
433540bb call     0x4337f00e
433540c0 mov      ecx, dword ptr [esp + 0x14]
433540c4 mov      esi, eax
433540c6 call     0x4339438e
433540cb cmp      eax, esi
433540cd cmovl    eax, esi
433540d0 mov      esi, dword ptr [esp + 0x14]
433540d4 mov      ecx, esi
433540d6 mov      dword ptr [esp + 0x60], eax
433540da call     0x4337ea43
433540df mov      ecx, dword ptr [esp + 0x84]
433540e6 mov      edx, eax
433540e8 mov      eax, dword ptr [esp + 0x88]
433540ef xor      edi, edi
433540f1 mov      dword ptr [esp + 0x24], edx
433540f5 cmp      dword ptr [eax + 0x5d8], edi
433540fb jbe      0x43354132
433540fd mov      esi, dword ptr [ecx]
433540ff mov      edx, eax
43354101 lea      eax, [esi + edi]
43354104 and      eax, 0x1f
43354107 mov      eax, dword ptr [ecx + eax*4 + 8]
4335410b test     dword ptr [eax + 0x5c], 0x200
43354112 mov      ecx, dword ptr [eax + 0x4c]
43354115 mov      dword ptr [esp + 0x38], ecx
43354119 lea      ecx, [edx + 0x5d4]
4335411f jne      0x4335412a
43354121 inc      edi
43354122 cmp      edi, dword ptr [edx + 0x5d8]
43354128 jb       0x43354101
4335412a mov      esi, dword ptr [esp + 0x14]
4335412e mov      edx, dword ptr [esp + 0x24]
43354132 cmp      edx, dword ptr [esp + 0x38]
43354136 jl       0x433540a4
4335413c mov      eax, dword ptr [0x4346a660]
43354141 mov      edi, dword ptr [esp + 0x18]
43354145 movss    xmm0, dword ptr [0x43470418]
4335414d mov      eax, dword ptr [eax]
4335414f xor      eax, dword ptr [0x434679e0]
43354155 xor      eax, 0xb538bba5
4335415a mov      eax, dword ptr [eax + edi]
4335415d comiss   xmm0, dword ptr [eax + 0x178]
43354164 jbe      0x43354184
43354166 mov      edx, dword ptr [esp + 0x88]
4335416d mov      ecx, edi
4335416f call     0x433e63fd
43354174 test     al, al
43354176 je       0x433541db
43354178 xor      eax, eax
4335417a inc      eax
4335417b mov      byte ptr [esp + 0x145], al
43354182 jmp      0x433541db
43354184 mov      eax, dword ptr [esp + 0x88]
4335418b cmp      dword ptr [eax + 0x5d8], 0
43354192 jne      0x4335419c
43354194 mov      edi, dword ptr [eax + 0x168]
4335419a jmp      0x433541aa
4335419c mov      eax, dword ptr [ecx]
4335419e push     0x1f
433541a0 pop      edx
433541a1 and      eax, edx
433541a3 mov      eax, dword ptr [ecx + eax*4 + 8]
433541a7 mov      edi, dword ptr [eax + 8]
433541aa mov      ecx, dword ptr [0x4346a514]
433541b0 mov      eax, dword ptr [ecx]
433541b2 call     dword ptr [eax + 0x38]
433541b5 mov      eax, dword ptr [0x43467b04]
433541ba push     2
433541bc pop      ecx
433541bd fdiv     dword ptr [eax + 0x20]
433541c0 fadd     dword ptr [esp + 0xac]
433541c7 fstp     dword ptr [esp + 0x7c]
433541cb cvttss2si eax, dword ptr [esp + 0x7c]
433541d1 sub      eax, edi
433541d3 cmp      eax, ecx
433541d5 jg       0x433540a4
433541db mov      edx, dword ptr [esp + 0x24]
433541df mov      edi, dword ptr [esp + 0x60]
433541e3 cmp      edx, edi
433541e5 jl       0x43354209
433541e7 mov      ecx, dword ptr [esp + 0x84]
433541ee mov      eax, dword ptr [ecx]
433541f0 and      eax, 0x1f
433541f3 mov      eax, dword ptr [ecx + eax*4 + 8]
433541f7 mov      eax, dword ptr [eax + 0x4c]
433541fa cmp      eax, edi
433541fc jge      0x43354202
433541fe mov      edx, edi
43354200 jmp      0x43354209
43354202 cmp      eax, edx
43354204 cmovg    eax, edx
43354207 mov      edx, eax
43354209 lea      eax, [esp + 0x2d0]
43354210 mov      dword ptr [esp + 0x2d0], edx
43354217 push     eax
43354218 push     dword ptr [esp + 0x174]
4335421f lea      ecx, [esp + 0x2b0]
43354226 call     0x43419e0f
4335422b mov      ecx, dword ptr [esp + 0x2a8]
43354232 mov      edi, dword ptr [esp + 0x1c]
43354236 cmp      ecx, dword ptr [esp + 0x2ac]
4335423d jne      0x433542e1
43354243 xor      eax, eax
43354245 inc      eax
43354246 test     byte ptr [edi + 0x170], al
4335424c jne      0x4335471c
43354252 mov      eax, dword ptr [esp + 0x88]
43354259 cmp      dword ptr [eax + 0x5d8], 0
43354260 je       0x4335471c
43354266 mov      ecx, esi
43354268 call     0x4337ea43
4335426d mov      ecx, esi
4335426f mov      dword ptr [esp + 0x7c], eax
43354273 call     0x4339438e
43354278 mov      ecx, dword ptr [esp + 0x7c]
4335427c mov      edx, eax
4335427e cmp      ecx, edx
43354280 jl       0x433542b8
43354282 mov      eax, dword ptr [esp + 0x88]
43354289 push     0x1f
4335428b pop      edi
4335428c mov      eax, dword ptr [eax + 0x5d4]
43354292 and      eax, edi
43354294 mov      edi, dword ptr [esp + 0x88]
4335429b mov      eax, dword ptr [edi + eax*4 + 0x5dc]
433542a2 mov      edi, dword ptr [esp + 0x1c]
433542a6 mov      eax, dword ptr [eax + 0x4c]
433542a9 cmp      eax, edx
433542ab jge      0x433542b1
433542ad mov      ecx, edx
433542af jmp      0x433542b8
433542b1 cmp      eax, ecx
433542b3 cmovg    eax, ecx
433542b6 mov      ecx, eax
433542b8 lea      eax, [esp + 0x2d4]
433542bf mov      dword ptr [esp + 0x2d4], ecx
433542c6 push     eax
433542c7 push     dword ptr [esp + 0x11c]
433542ce lea      ecx, [esp + 0x2b0]
433542d5 call     0x43419e0f
433542da mov      ecx, dword ptr [esp + 0x2a8]
433542e1 mov      eax, dword ptr [esp + 0x48]
433542e5 mov      edx, dword ptr [esp + 0x2ac]
433542ec sub      edx, ecx
433542ee sar      edx, 2
433542f1 mov      eax, dword ptr [eax*4 + 0x43474950]
433542f8 cmp      eax, edx
433542fa cmovb    edx, eax
433542fd and      dword ptr [esp + 0x48], 0
43354302 mov      dword ptr [esp + 0x60], edx
43354306 test     edx, edx
43354308 je       0x4335471c
4335430e imul     esi, dword ptr [edi + 0x1b8], 0x1190
43354318 mov      ecx, dword ptr [esp + 0x50]
4335431c add      esi, dword ptr [edi + 0x1c0]
43354322 mov      dword ptr [esp + 0x4c], esi
43354326 and      dword ptr [esi], 0
43354329 mov      eax, dword ptr [ecx]
4335432b call     dword ptr [eax + 0x28]
4335432e mov      edx, dword ptr [esp + 0x18]
43354332 mov      dword ptr [esi + 4], eax
43354335 mov      dword ptr [esp + 0x7c], 0x6d2cfbd5
4335433d mov      eax, dword ptr [esp + 0x7c]
43354341 mov      ecx, dword ptr [edx]
43354343 inc      eax
43354344 xor      eax, 0x4a674016
43354349 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
43354350 mov      dword ptr [esp + 0x314], ecx
43354357 call     0x433e533f
4335435c xor      ecx, ecx
4335435e inc      ecx
4335435f cmp      eax, ecx
43354361 jge      0x43354367
43354363 mov      eax, ecx
43354365 jmp      0x4335436f
43354367 push     0x64
43354369 pop      ecx
4335436a cmp      eax, ecx
4335436c cmovg    eax, ecx
4335436f mov      dword ptr [esi + 8], eax
43354372 lea      edx, [esp + 0x224]
43354379 or       dword ptr [esp + 0x228], 0xffffffff
43354381 lea      ecx, [esp + 0x228]
43354388 or       dword ptr [esp + 0x224], 0xffffffff
43354390 call     0x4341f16e
43354395 test     al, al
43354397 je       0x433543bf
43354399 mov      eax, dword ptr [esp + 0x228]
433543a0 cmp      eax, dword ptr [esi + 4]
433543a3 jne      0x433543bf
433543a5 mov      eax, dword ptr [esp + 0x224]
433543ac mov      ecx, 0x3e8
433543b1 sub      dword ptr [esi + 8], eax
433543b4 mov      eax, dword ptr [esi + 8]
433543b7 test     eax, eax
433543b9 cmovle   eax, ecx
433543bc mov      dword ptr [esi + 8], eax
433543bf lea      ecx, [esi + 0xc]
433543c2 call     0x433318b5
433543c7 xor      edx, edx
433543c9 lea      edi, [esi + 0xbc]
433543cf mov      dword ptr [esi + 0xb4], edx
433543d5 mov      dword ptr [esi + 0xb8], edx
433543db lea      esi, [esp + 0x124]
433543e2 push     0xa
433543e4 pop      ecx
433543e5 rep movsd dword ptr es:[edi], dword ptr [esi]
433543e7 mov      edi, dword ptr [esp + 0x4c]
433543eb mov      ecx, dword ptr [esp + 0x48]
433543ef mov      esi, dword ptr [esp + 0x14]
433543f3 mov      dword ptr [edi + 0xe4], edx
433543f9 mov      dword ptr [edi + 0xe8], edx
433543ff mov      eax, dword ptr [esp + 0x2a8]
43354406 mov      eax, dword ptr [eax + ecx*4]
43354409 mov      ecx, esi
4335440b mov      dword ptr [edi + 0xb4], eax
43354411 mov      dword ptr [esp + 0x1a0], edx
43354418 mov      edx, dword ptr [edi + 4]
4335441b call     0x43383e62
43354420 test     al, al
43354422 jne      0x43354458
43354424 mov      edx, dword ptr [esp + 0x18]
43354428 lea      ecx, [esp + 0x1a0]
4335442f push     ecx
43354430 lea      eax, [edi + 0xf0]
43354436 mov      ecx, esi
43354438 push     eax
43354439 call     0x43387bce
4335443e mov      edx, edi
43354440 mov      edi, dword ptr [esp + 0x1c]
43354444 mov      eax, dword ptr [edx + 0x13c]
4335444a mov      dword ptr [edx + 0xb4], eax
43354450 or       dword ptr [edx], 4
43354453 jmp      0x43354512
43354458 mov      edi, dword ptr [esp + 0x1c]
4335445c xor      edx, edx
4335445e inc      edx
4335445f mov      ecx, dword ptr [edi + 0x170]
43354465 mov      eax, ecx
43354467 not      eax
43354469 and      eax, edx
4335446b lea      eax, [eax*4 + 1]
43354472 mov      edx, eax
43354474 or       edx, 8
43354477 and      cl, 8
4335447a cmove    edx, eax
4335447d test     dword ptr [esi], 0x4000
43354483 mov      dword ptr [esp + 0x7c], edx
43354487 mov      dword ptr [esp + 0x84], edx
4335448e jne      0x433544cf
43354490 mov      eax, dword ptr [0x4346db1c]
43354495 cmp      eax, -1
43354498 jne      0x433544a4
4335449a mov      dword ptr [esp + 0x24], 0x1fff
433544a2 jmp      0x433544ab
433544a4 movzx    eax, ax
433544a7 mov      dword ptr [esp + 0x24], eax
433544ab mov      ecx, dword ptr [esp + 0x50]
433544af mov      dword ptr [esp + 0x84], edx
433544b6 mov      eax, dword ptr [ecx]
433544b8 call     dword ptr [eax + 0x28]
433544bb cmp      eax, dword ptr [esp + 0x24]
433544bf je       0x433544cf
433544c1 mov      eax, dword ptr [esp + 0x7c]
433544c5 and      eax, 0xfffffffe
433544c8 mov      dword ptr [esp + 0x84], eax
433544cf mov      eax, dword ptr [esp + 0x4c]
433544d3 lea      edx, [esp + 0x1a0]
433544da push     edx
433544db mov      edx, dword ptr [esp + 0x1c]
433544df lea      ecx, [eax + 0xf0]
433544e5 push     ecx
433544e6 push     dword ptr [esp + 0x8c]
433544ed mov      ecx, esi
433544ef push     dword ptr [eax + 0xb4]
433544f5 call     0x4336c53b
433544fa test     al, al
433544fc jne      0x4335450e
433544fe mov      eax, dword ptr [esp + 0x4c]
43354502 or       dword ptr [eax + 0xb4], 0xffffffff
43354509 jmp      0x43354709
4335450e mov      edx, dword ptr [esp + 0x4c]
43354512 mov      eax, dword ptr [esp + 0x1a0]
43354519 mov      ecx, dword ptr [esp + 0x78]
4335451d mov      dword ptr [esp + 0x24], ecx
43354521 mov      dword ptr [esp + 0x84], eax
43354528 test     al, 0x40
4335452a je       0x43354555
4335452c cmp      dword ptr [esp + 0x48], 0
43354531 jne      0x4335471c
43354537 xor      eax, eax
43354539 or       ecx, 0x20
4335453c inc      eax
4335453d mov      dword ptr [esp + 0x24], ecx
43354541 mov      byte ptr [edx + 0xdd], al
43354547 mov      eax, dword ptr [esp + 0x1a0]
4335454e mov      dword ptr [esp + 0x84], eax
43354555 or       ecx, 8
43354558 and      al, 0x10
4335455a mov      eax, dword ptr [esp + 0x84]
43354561 cmove    ecx, dword ptr [esp + 0x24]
43354566 mov      dword ptr [esp + 0x34], ecx
4335456a or       dword ptr [esp + 0x34], 0x10
4335456f and      al, 0x20
43354571 mov      eax, dword ptr [esp + 0x34]
43354575 cmove    eax, ecx
43354578 cmp      byte ptr [edx + 0xdd], 0
4335457f mov      dword ptr [esp + 0x34], eax
43354583 je       0x4335462c
43354589 mov      eax, dword ptr [edx + 0xc0]
4335458f or       eax, dword ptr [edx + 0xc4]
43354595 push     2
43354597 pop      ecx
43354598 test     cl, al
4335459a je       0x4335462c
433545a0 xor      eax, eax
433545a2 test     byte ptr [0x4346a8d0], 2
433545a9 mov      ecx, eax
433545ab je       0x433545ce
433545ad lea      edi, [edx + 0xf0]
433545b3 test     edi, edi
433545b5 mov      edi, dword ptr [esp + 0x1c]
433545b9 je       0x433545ce
433545bb test     byte ptr [edx + 0x14c], 8
433545c2 mov      esi, dword ptr [esp + 0x14]
433545c6 cmovne   ecx, dword ptr [esp + 0x114]
433545ce test     byte ptr [0x4346a8d0], 4
433545d5 je       0x433545f1
433545d7 lea      edi, [edx + 0xf0]
433545dd test     edi, edi
433545df mov      edi, dword ptr [esp + 0x1c]
433545e3 je       0x433545f1
433545e5 test     byte ptr [edx + 0x14c], 0x20
433545ec je       0x433545f1
433545ee or       ecx, 4
433545f1 test     byte ptr [0x4346a8d0], 8
433545f8 je       0x43354618
433545fa lea      esi, [edx + 0xf0]
43354600 test     esi, esi
43354602 mov      esi, dword ptr [esp + 0x14]
43354606 je       0x43354618
43354608 test     byte ptr [edx + 0x14c], 0x80
4335460f mov      edi, dword ptr [esp + 0x1c]
43354613 je       0x43354618
43354615 or       ecx, 8
43354618 mov      dword ptr [edx + 0xb8], ecx
4335461e test     cl, 8
43354621 je       0x43354634
43354623 or       dword ptr [edx + 0xc4], 2
4335462a jmp      0x43354634
4335462c xor      eax, eax
4335462e mov      dword ptr [edx + 0xb8], eax
43354634 mov      ecx, dword ptr [edx + 0x14c]
4335463a test     cl, cl
4335463c js       0x43354644
4335463e mov      dword ptr [edx + 0xc4], eax
43354644 and      dword ptr [edx + 0xc4], 0xfffffdff
4335464e test     byte ptr [esp + 0x84], 0x70
43354656 jne      0x4335465d
43354658 test     cl, 0x20
4335465b je       0x43354663
4335465d mov      byte ptr [edx + 0xe1], al
43354663 cmp      byte ptr [0x434683fc], 0
4335466a je       0x433546d9
4335466c lea      ecx, [edi + 0x1c4]
43354672 call     0x4340c789
43354677 test     al, al
43354679 jne      0x433546d5
4335467b push     dword ptr [esp + 0x10c]
43354682 lea      ecx, [edi + 0x1c4]
43354688 call     0x4340364b
4335468d mov      ecx, eax
4335468f test     ecx, ecx
43354691 je       0x433546d5
43354693 lea      eax, [edi - 8]
43354696 mov      dword ptr [ecx], eax
43354698 mov      eax, dword ptr [esp + 0x28]
4335469c mov      dword ptr [ecx + 4], esi
4335469f mov      dword ptr [ecx + 8], eax
433546a2 mov      eax, dword ptr [esp + 0x18]
433546a6 mov      dword ptr [ecx + 0xc], eax
433546a9 mov      eax, dword ptr [esp + 0x88]
433546b0 mov      dword ptr [ecx + 0x10], eax
433546b3 mov      eax, dword ptr [esp + 0x34]
433546b7 mov      dword ptr [ecx + 0x14], eax
433546ba mov      eax, dword ptr [esp + 0x4c]
433546be mov      dword ptr [ecx + 0x18], eax
433546c1 lea      eax, [edi + 0x1ac]
433546c7 mov      dword ptr [ecx + 0x1c], eax
433546ca mov      eax, dword ptr [edi + 0x1b8]
433546d0 mov      dword ptr [ecx + 0x20], eax
433546d3 jmp      0x43354703
433546d5 mov      edx, dword ptr [esp + 0x4c]
433546d9 push     dword ptr [edi + 0x1b8]
433546df lea      eax, [edi + 0x1ac]
433546e5 push     eax
433546e6 push     edx
433546e7 push     dword ptr [esp + 0x40]
433546eb lea      ecx, [edi - 8]
433546ee push     dword ptr [esp + 0x98]
433546f5 push     dword ptr [esp + 0x2c]
433546f9 push     dword ptr [esp + 0x40]
433546fd push     esi
433546fe call     0x4335cd37
43354703 inc      dword ptr [edi + 0x1b8]
43354709 mov      eax, dword ptr [esp + 0x48]
4335470d inc      eax
4335470e mov      dword ptr [esp + 0x48], eax
43354712 cmp      eax, dword ptr [esp + 0x60]
43354716 jb       0x4335430e
4335471c lea      ecx, [esp + 0x2a8]
43354723 call     0x433cce8e
43354728 mov      eax, dword ptr [esp + 0x64]
4335472c inc      eax
4335472d mov      dword ptr [esp + 0x64], eax
43354731 cmp      eax, dword ptr [esp + 0xc8]
43354738 jle      0x43351c99
4335473e cmp      byte ptr [0x434683fc], 0
43354745 je       0x43354793
43354747 mov      edi, dword ptr [esp + 0x40]
4335474b mov      eax, dword ptr [edi]
4335474d cmp      eax, dword ptr [edi + 4]
43354750 je       0x43354793
43354752 push     0x1c
43354754 pop      ecx
43354755 call     0x43387448
4335475a test     eax, eax
4335475c je       0x4335476e
4335475e push     0x43406ee0
43354763 mov      ecx, eax
43354765 call     0x4333f91e
4335476a mov      esi, eax
4335476c jmp      0x43354770
4335476e xor      esi, esi
43354770 mov      eax, dword ptr [edi + 4]
43354773 sub      eax, dword ptr [edi]
43354775 push     0x24
43354777 pop      ecx
43354778 cdq      
43354779 idiv     ecx
4335477b mov      ecx, esi
4335477d push     eax
4335477e push     dword ptr [edi]
43354780 call     0x4334b70b
43354785 mov      eax, dword ptr [esi]
43354787 mov      ecx, esi
43354789 call     dword ptr [eax + 4]
4335478c mov      ecx, edi
4335478e call     0x433e0a59
43354793 mov      esi, dword ptr [esp + 0x1c]
43354797 test     byte ptr [esi + 0x170], 9
4335479e jne      0x433547c9
433547a0 mov      eax, dword ptr [0x43469300]
433547a5 xor      ecx, ecx
433547a7 inc      ecx
433547a8 mov      edi, ecx
433547aa mov      eax, dword ptr [eax]
433547ac cmp      eax, ecx
433547ae jl       0x433547c9
433547b0 mov      esi, eax
433547b2 mov      ecx, edi
433547b4 call     0x433b8a2b
433547b9 and      dword ptr [eax + 0x194], 0
433547c0 inc      edi
433547c1 cmp      edi, esi
433547c3 jle      0x433547b2
433547c5 mov      esi, dword ptr [esp + 0x1c]
433547c9 push     0x40
433547cb lea      eax, [esp + 0xb2c]
433547d2 push     -1
433547d4 push     eax
433547d5 call     0x774fdc80
433547da add      esp, 0xc
433547dd lea      ecx, [esi + 0x1ac]
433547e3 xor      eax, eax
433547e5 cmp      dword ptr [ecx], 0
433547e8 jne      0x433547fa
433547ea add      eax, 0x20
433547ed add      ecx, 4
433547f0 cmp      eax, 0x50
433547f3 jb       0x433547e5
433547f5 jmp      0x43354908
433547fa xor      eax, eax
433547fc xor      edi, edi
433547fe mov      dword ptr [esp + 0x50], eax
43354802 mov      dword ptr [esp + 0x48], edi
43354806 push     0x1f
43354808 mov      ecx, eax
4335480a shr      eax, 5
4335480d pop      edx
4335480e and      ecx, edx
43354810 xor      edx, edx
43354812 inc      edx
43354813 shl      edx, cl
43354815 test     dword ptr [esi + eax*4 + 0x1ac], edx
4335481c je       0x433548e6
43354822 mov      edx, dword ptr [esi + 0x1c0]
43354828 xor      eax, eax
4335482a add      edx, edi
4335482c inc      eax
4335482d mov      dword ptr [esp + 0x40], edx
43354831 mov      edi, dword ptr [edx + 4]
43354834 and      edi, 0x3f
43354837 test     byte ptr [esi + 0x170], al
4335483d jne      0x43354860
4335483f mov      edx, edi
43354841 mov      ecx, edi
43354843 shr      edx, 5
43354846 push     0x1f
43354848 pop      eax
43354849 and      ecx, eax
4335484b mov      eax, dword ptr [esi + edx*4 + 0x19c]
43354852 bts      eax, ecx
43354855 mov      dword ptr [esi + edx*4 + 0x19c], eax
4335485c mov      edx, dword ptr [esp + 0x40]
43354860 mov      al, byte ptr [esp + edi + 0xb28]
43354867 cmp      al, 0xff
43354869 jne      0x433548c1
4335486b lea      ecx, [esp + 0x810]
43354872 call     0x43330f51
43354877 test     al, al
43354879 jne      0x433548e6
4335487b mov      eax, dword ptr [esp + 0x814]
43354882 lea      ecx, [esp + 0x810]
43354889 sub      eax, dword ptr [esp + 0x810]
43354890 sar      eax, 2
43354893 mov      byte ptr [esp + edi + 0xb28], al
4335489a mov      eax, dword ptr [esi + 0x1c0]
433548a0 add      eax, dword ptr [esp + 0x48]
433548a4 mov      dword ptr [esp + 0x2d8], eax
433548ab lea      eax, [esp + 0x2d8]
433548b2 push     eax
433548b3 push     dword ptr [esp + 0x318]
433548ba call     0x43419e0f
433548bf jmp      0x433548e6
433548c1 movsx    edi, al
433548c4 mov      eax, dword ptr [esp + 0x810]
433548cb mov      ecx, dword ptr [eax + edi*4]
433548ce mov      eax, dword ptr [edx + 0xe4]
433548d4 cmp      eax, dword ptr [ecx + 0xe4]
433548da jbe      0x433548e6
433548dc mov      eax, dword ptr [esp + 0x810]
433548e3 mov      dword ptr [eax + edi*4], edx
433548e6 mov      eax, dword ptr [esp + 0x48]
433548ea inc      dword ptr [esp + 0x50]
433548ee add      eax, 0x1190
433548f3 mov      dword ptr [esp + 0x48], eax
433548f7 cmp      eax, 0x57d00
433548fc mov      edi, eax
433548fe mov      eax, dword ptr [esp + 0x50]
43354902 jb       0x43354806
43354908 mov      ecx, dword ptr [esp + 0x814]
4335490f mov      eax, dword ptr [esp + 0x810]
43354916 mov      dword ptr [esp + 0xc8], ecx
4335491d cmp      eax, ecx
4335491f je       0x4335619c
43354925 push     0x7f
43354927 pop      esi
43354928 mov      edi, eax
4335492a mov      edx, dword ptr [edi]
4335492c mov      ecx, esi
4335492e push     0x7f
43354930 mov      dword ptr [esp + 0x54], edx
43354934 movss    xmm1, dword ptr [edx + 0x38]
43354939 mov      eax, dword ptr [edx + 8]
4335493c mulss    xmm1, dword ptr [esp + 0xa0]
43354945 add      eax, 5
43354948 cmp      eax, esi
4335494a cmovb    ecx, eax
4335494d mov      eax, dword ptr [edx + 0x28]
43354950 cvtss2si esi, xmm1
43354954 cmp      ecx, eax
43354956 cmovb    eax, ecx
43354959 pop      ecx
4335495a test     esi, esi
4335495c jns      0x43354962
4335495e xor      esi, esi
43354960 jmp      0x43354967
43354962 cmp      esi, ecx
43354964 cmovg    esi, ecx
43354967 and      esi, ecx
43354969 and      eax, ecx
4335496b shl      esi, 9
4335496e or       esi, eax
43354970 push     3
43354972 pop      eax
43354973 cmp      dword ptr [edx + 0x30], eax
43354976 je       0x43354980
43354978 push     2
4335497a pop      eax
4335497b cmp      dword ptr [edx + 0x30], eax
4335497e jne      0x4335498f
43354980 cmp      byte ptr [edx + 0xdd], 0
43354987 je       0x4335498f
43354989 or       esi, 0x100
4335498f xor      eax, eax
43354991 inc      eax
43354992 test     byte ptr [edx + 0x10c], al
43354998 je       0x43354a0f
4335499a mov      ecx, dword ptr [0x4346a890]
433549a0 push     dword ptr [edx + 4]
433549a3 mov      eax, dword ptr [ecx]
433549a5 mov      eax, dword ptr [eax + 0xc]
433549a8 call     eax
433549aa test     eax, eax
433549ac je       0x43354a02
433549ae mov      ecx, dword ptr [0x43467a74]
433549b4 mov      ecx, dword ptr [ecx]
433549b6 xor      ecx, dword ptr [0x434678c0]
433549bc xor      ecx, 0xcd812654
433549c2 mov      ecx, dword ptr [ecx + eax]
433549c5 cmp      ecx, -1
433549c8 je       0x43354a02
433549ca mov      eax, dword ptr [0x4346a890]
433549cf push     ecx
433549d0 mov      eax, dword ptr [eax]
433549d2 mov      edx, dword ptr [eax + 0x10]
433549d5 mov      eax, esp
433549d7 mov      dword ptr [eax], ecx
433549d9 mov      ecx, dword ptr [0x4346a890]
433549df call     edx
433549e1 test     eax, eax
433549e3 je       0x43354a02
433549e5 mov      ecx, dword ptr [0x4346908c]
433549eb push     0x1f
433549ed pop      edx
433549ee mov      ecx, dword ptr [ecx]
433549f0 xor      ecx, dword ptr [0x43468ba0]
433549f6 xor      ecx, 0x5c9f0fbb
433549fc cmp      word ptr [ecx + eax], dx
43354a00 je       0x43354a08
43354a02 or       esi, 0x80
43354a08 mov      edx, dword ptr [esp + 0x50]
43354a0c xor      eax, eax
43354a0e inc      eax
43354a0f cmp      byte ptr [edx + 0xdc], 0
43354a16 je       0x43354a23
43354a18 test     byte ptr [edx + 0x34], al
43354a1b je       0x43354a23
43354a1d or       esi, 0x10000
43354a23 mov      eax, dword ptr [edx + 4]
43354a26 mov      ecx, esi
43354a28 shl      eax, 5
43354a2b or       ecx, 0x20000
43354a31 cmp      byte ptr [eax + 0x4347be0b], 0
43354a38 cmove    ecx, esi
43354a3b mov      esi, dword ptr [edx + 0x28]
43354a3e test     esi, esi
43354a40 jle      0x43354a60
43354a42 mov      eax, dword ptr [edx + 8]
43354a45 dec      eax
43354a46 add      eax, esi
43354a48 cdq      
43354a49 idiv     esi
43354a4b xor      edx, edx
43354a4d inc      edx
43354a4e cmp      eax, edx
43354a50 cmovg    edx, eax
43354a53 test     edx, edx
43354a55 jns      0x43354a5b
43354a57 xor      edx, edx
43354a59 jmp      0x43354a63
43354a5b cmp      edx, 0xf
43354a5e jle      0x43354a63
43354a60 push     0xf
43354a62 pop      edx
43354a63 mov      esi, dword ptr [esp + 0x50]
43354a67 not      edx
43354a69 and      edx, 0xf
43354a6c shl      edx, 0x13
43354a6f or       edx, ecx
43354a71 mov      eax, dword ptr [esi + 0x14c]
43354a77 mov      ecx, edx
43354a79 or       ecx, 0x40000
43354a7f and      eax, 0x1800
43354a84 push     0x7f
43354a86 cmove    ecx, edx
43354a89 add      edi, 4
43354a8c mov      dword ptr [esi + 0xe4], ecx
43354a92 pop      esi
43354a93 cmp      edi, dword ptr [esp + 0xc8]
43354a9a jne      0x4335492a
43354aa0 mov      eax, dword ptr [esp + 0x814]
43354aa7 xor      edx, edx
43354aa9 mov      ecx, dword ptr [esp + 0x810]
43354ab0 inc      edx
43354ab1 mov      edi, dword ptr [esp + 0x14]
43354ab5 sub      eax, ecx
43354ab7 sar      eax, 2
43354aba cmp      eax, edx
43354abc jbe      0x43354ad8
43354abe push     0x433ff5c7
43354ac3 push     4
43354ac5 push     eax
43354ac6 push     ecx
43354ac7 call     dword ptr [esp + 0xf8]
43354ace mov      ecx, dword ptr [esp + 0x820]
43354ad5 add      esp, 0x10
43354ad8 mov      esi, dword ptr [esp + 0x1c]
43354adc mov      edx, dword ptr [esi + 0x170]
43354ae2 test     dl, 0x10
43354ae5 je       0x43354b07
43354ae7 cmp      dword ptr [edi + 0xd8], 0x40
43354aee jne      0x43354b07
43354af0 test     byte ptr [edi], 0x40
43354af3 je       0x43354b07
43354af5 mov      eax, dword ptr [ecx]
43354af7 mov      dword ptr [esp + 0x18], eax
43354afb mov      dword ptr [eax + 0x38], 0x3f800000
43354b02 jmp      0x43354c61
43354b07 mov      eax, dword ptr [esp + 0x814]
43354b0e and      dword ptr [esp + 0xe8], 0
43354b16 sub      eax, ecx
43354b18 sar      eax, 2
43354b1b test     eax, eax
43354b1d je       0x4335617e
43354b23 xor      edx, edx
43354b25 mov      eax, dword ptr [ecx + edx*4]
43354b28 movss    xmm0, dword ptr [esp + 0x68]
43354b2e movss    dword ptr [esp + 0x16c], xmm0
43354b37 test     byte ptr [esi + 0x170], 0x10
43354b3e mov      dword ptr [esp + 0x18], eax
43354b42 je       0x43354c0f
43354b48 lea      ecx, [esp + 0x16c]
43354b4f push     ecx
43354b50 push     eax
43354b51 push     edi
43354b52 lea      ecx, [esi - 8]
43354b55 call     0x4341b4c2
43354b5a test     al, al
43354b5c jne      0x43354bf4
43354b62 test     dword ptr [edi], 0x400
43354b68 je       0x43354be0
43354b6a mov      eax, dword ptr [esp + 0x18]
43354b6e mov      ecx, dword ptr [eax]
43354b70 test     cl, 8
43354b73 je       0x43354be0
43354b75 and      ecx, 0xfffffff7
43354b78 lea      edi, [eax + 0xc]
43354b7b push     0xe
43354b7d mov      dword ptr [eax], ecx
43354b7f lea      esi, [eax + 0x44]
43354b82 pop      ecx
43354b83 rep movsd dword ptr es:[edi], dword ptr [esi]
43354b85 mov      edi, dword ptr [esp + 0x14]
43354b89 lea      ecx, [esp + 0x16c]
43354b90 push     ecx
43354b91 mov      ecx, dword ptr [esp + 0xa4]
43354b98 push     eax
43354b99 push     edi
43354b9a call     0x4341b4c2
43354b9f test     al, al
43354ba1 jne      0x43354bf0
43354ba3 mov      eax, dword ptr [esp + 0x18]
43354ba7 mov      ecx, dword ptr [eax]
43354ba9 test     cl, 0x10
43354bac je       0x43354bdc
43354bae and      ecx, 0xffffffef
43354bb1 lea      esi, [eax + 0x7c]
43354bb4 push     0xe
43354bb6 mov      dword ptr [eax], ecx
43354bb8 lea      edi, [eax + 0xc]
43354bbb pop      ecx
43354bbc rep movsd dword ptr es:[edi], dword ptr [esi]
43354bbe mov      edi, dword ptr [esp + 0x14]
43354bc2 lea      ecx, [esp + 0x16c]
43354bc9 push     ecx
43354bca mov      ecx, dword ptr [esp + 0xa4]
43354bd1 push     eax
43354bd2 push     edi
43354bd3 call     0x4341b4c2
43354bd8 test     al, al
43354bda jne      0x43354bf0
43354bdc mov      esi, dword ptr [esp + 0x1c]
43354be0 mov      ecx, dword ptr [esp + 0x810]
43354be7 mov      edx, dword ptr [esp + 0xe8]
43354bee jmp      0x43354c35
43354bf0 mov      esi, dword ptr [esp + 0x1c]
43354bf4 mov      ecx, dword ptr [esp + 0x810]
43354bfb movss    xmm0, dword ptr [esp + 0x16c]
43354c04 mov      eax, dword ptr [esp + 0x18]
43354c08 mov      edx, dword ptr [esp + 0xe8]
43354c0f test     byte ptr [eax + 0x34], 0x20
43354c13 movaps   xmm1, xmm0
43354c16 je       0x43354c2a
43354c18 mulss    xmm1, dword ptr [esp + 0x90]
43354c21 movss    dword ptr [esp + 0x16c], xmm1
43354c2a movss    xmm2, dword ptr [esp + 0x2c]
43354c30 comiss   xmm2, xmm1
43354c33 jb       0x43354c5c
43354c35 mov      eax, dword ptr [esp + 0x814]
43354c3c inc      edx
43354c3d sub      eax, ecx
43354c3f mov      dword ptr [esp + 0xe8], edx
43354c46 sar      eax, 2
43354c49 cmp      edx, eax
43354c4b jb       0x43354b25
43354c51 mov      edx, dword ptr [esi + 0x170]
43354c57 jmp      0x4335617e
43354c5c movss    dword ptr [eax + 0x38], xmm0
43354c61 cmp      byte ptr [esp + 0x22], 0
43354c66 jne      0x43354e10
43354c6c cmp      byte ptr [esp + 0x98], 0
43354c74 jne      0x43354d6e
43354c7a cmp      byte ptr [esp + 0x83], 0
43354c82 jne      0x43354d6e
43354c88 cmp      byte ptr [esp + 0x33], 0
43354c8d je       0x43354df1
43354c93 mov      eax, dword ptr [eax + 0xb4]
43354c99 mov      dword ptr [esp + 0x40], eax
43354c9d test     eax, eax
43354c9f jle      0x43354d2e
43354ca5 mov      eax, dword ptr [0x4346a338]
43354caa xorps    xmm0, xmm0
43354cad cvtsi2ss xmm0, dword ptr [edi + 0x1d8]
43354cb5 xorps    xmm1, xmm1
43354cb8 mulss    xmm0, dword ptr [eax]
43354cbc cvtsi2ss xmm1, dword ptr [0x43468230]
43354cc4 movss    dword ptr [esp + 0xc8], xmm0
43354ccd movss    xmm0, dword ptr [edi + 0x198]
43354cd5 addss    xmm0, dword ptr [0x43476928]
43354cdd mulss    xmm1, dword ptr [0x43470000]
43354ce5 call     0x43367633
43354cea mov      eax, dword ptr [0x4346a338]
43354cef xorps    xmm1, xmm1
43354cf2 cvtsi2ss xmm1, dword ptr [esp + 0x40]
43354cf8 movaps   xmm2, xmm0
43354cfb movss    xmm0, dword ptr [esp + 0xc8]
43354d04 mulss    xmm1, dword ptr [eax]
43354d08 subss    xmm0, xmm1
43354d0c subss    xmm2, xmm0
43354d10 movss    xmm0, dword ptr [0x4346f868]
43354d18 andps    xmm2, xmmword ptr [esp + 0xb0]
43354d20 comiss   xmm0, xmm2
43354d23 setae    al
43354d26 test     al, al
43354d28 je       0x43354df1
43354d2e xor      ecx, ecx
43354d30 inc      ecx
43354d31 or       dword ptr [edi], 0x400
43354d37 mov      eax, dword ptr [edi + 0x1d8]
43354d3d mov      dl, cl
43354d3f mov      dword ptr [edi + 0xc8], eax
43354d45 mov      byte ptr [esp + 0x23], dl
43354d49 mov      byte ptr [esp + 0x98], cl
43354d50 movd     xmm0, eax
43354d54 mov      eax, dword ptr [0x4346a338]
43354d59 cvtdq2ps xmm0, xmm0
43354d5c mulss    xmm0, dword ptr [eax]
43354d60 mov      eax, dword ptr [0x43467eb8]
43354d65 movss    dword ptr [eax], xmm0
43354d69 jmp      0x43354fb5
43354d6e test     byte ptr [eax + 0x34], 0x30
43354d72 je       0x43354e10
43354d78 mov      ecx, dword ptr [eax + 4]
43354d7b test     ecx, ecx
43354d7d jne      0x43354d8b
43354d7f push     ebp
43354d80 stosb    byte ptr es:[edi], al
43354d81 add      ecx, dword ptr [esi - 0x78aaca4d]
43354d87 xchg     edi, eax
43354d88 cmpsd    dword ptr [esi], dword ptr es:[edi]
43354d89 mov      ebp, 0x3c9be888
43354d8b call     0x433b8a2b
43354d8e push     es
43354d8f add      byte ptr [ebx - 0x27467c38], cl
43354d90 mov      ecx, eax
43354d92 cmp      dword ptr [ecx + 0x5d8], 0
43354d95 add      eax, 0x75000000
43354d99 jne      0x43354da3
43354d9a or       byte ptr [ebx + 0x16881], cl
43354d9b mov      eax, dword ptr [ecx + 0x168]
43354da0 add      bl, ch
43354da1 jmp      0x43354db8
43354da2 adc      eax, 0x5d4818b
43354da3 mov      eax, dword ptr [ecx + 0x5d4]
43354da7 add      byte ptr [eax], al
43354da9 push     0x1f
43354dab pop      edx
43354dac and      eax, edx
43354dae mov      eax, dword ptr [ecx + eax*4 + 0x5dc]
43354db5 mov      eax, dword ptr [eax + 8]
43354db8 mov      ecx, dword ptr [0x4346a514]
43354dbe mov      dword ptr [esp + 0xa0], eax
43354dc5 mov      eax, dword ptr [ecx]
43354dc7 call     dword ptr [eax + 0x38]
43354dca mov      eax, dword ptr [0x43467b04]
43354dcf push     2
43354dd1 pop      ecx
43354dd2 fdiv     dword ptr [eax + 0x20]
43354dd5 fadd     dword ptr [esp + 0xac]
43354ddc fstp     dword ptr [esp + 0x40]
43354de0 cvttss2si eax, dword ptr [esp + 0x40]
43354de6 sub      eax, dword ptr [esp + 0xa0]
43354ded cmp      eax, ecx
43354def jle      0x43354e10
43354df1 mov      eax, dword ptr [edi + 0xac]
43354df7 mov      edi, 0x434759d0
43354dfc mov      ecx, dword ptr [esp + 0x18]
43354e00 mov      dword ptr [0x434759cc], eax
43354e05 lea      esi, [ecx + 0xc]
43354e08 movsd    dword ptr es:[edi], dword ptr [esi]
43354e09 movsd    dword ptr es:[edi], dword ptr [esi]
43354e0a movsd    dword ptr es:[edi], dword ptr [esi]
43354e0b jmp      0x4335519c
43354e10 cmp      dword ptr [edi + 0xd8], 0x40
43354e17 je       0x43354fae
43354e1d cmp      dword ptr [edi + 0x1d4], 0
43354e24 je       0x43354fae
43354e2a mov      eax, dword ptr [0x43467a78]
43354e2f xor      eax, 0x3ae06513
43354e34 jmp      0x43354e38
43354e36 mov      eax, ecx
43354e38 mov      ecx, dword ptr [eax + 0x1c]
43354e3b cmp      eax, ecx
43354e3d jne      0x43354e36
43354e3f cmp      dword ptr [eax + 0x30], eax
43354e42 je       0x43354fae
43354e48 mov      ecx, dword ptr [edi + 0xc8]
43354e4e cmp      ecx, dword ptr [edi + 0x1d8]
43354e54 jge      0x43354fae
43354e5a mov      eax, dword ptr [esp + 0x18]
43354e5e mov      eax, dword ptr [eax + 0xb4]
43354e64 mov      dword ptr [esp + 0x40], eax
43354e68 test     eax, eax
43354e6a jle      0x43354fae
43354e70 mov      eax, dword ptr [0x4346a338]
43354e75 xorps    xmm0, xmm0
43354e78 cvtsi2ss xmm0, ecx
43354e7c xorps    xmm1, xmm1
43354e7f mulss    xmm0, dword ptr [eax]
43354e83 cvtsi2ss xmm1, dword ptr [0x43468230]
43354e8b movss    dword ptr [esp + 0xc8], xmm0
43354e94 movss    xmm0, dword ptr [0x43476928]
43354e9c addss    xmm0, dword ptr [edi + 0x198]
43354ea4 mulss    xmm1, dword ptr [0x43470000]
43354eac call     0x43367633
43354eb1 mov      ecx, dword ptr [0x4346a338]
43354eb7 xorps    xmm1, xmm1
43354eba cvtsi2ss xmm1, dword ptr [esp + 0x40]
43354ec0 movss    xmm2, dword ptr [esp + 0xc8]
43354ec9 mulss    xmm1, dword ptr [ecx]
43354ecd subss    xmm2, xmm1
43354ed1 movss    xmm1, dword ptr [0x4346f868]
43354ed9 subss    xmm0, xmm2
43354edd andps    xmm0, xmmword ptr [esp + 0xb0]
43354ee5 comiss   xmm1, xmm0
43354ee8 setae    al
43354eeb test     al, al
43354eed jne      0x43354fae
43354ef3 mov      eax, dword ptr [esp + 0x18]
43354ef7 mov      eax, dword ptr [eax + 0xb4]
43354efd mov      dword ptr [esp + 0x40], eax
43354f01 test     eax, eax
43354f03 jle      0x43354f83
43354f05 xorps    xmm0, xmm0
43354f08 xorps    xmm1, xmm1
43354f0b cvtsi2ss xmm0, dword ptr [edi + 0x1d8]
43354f13 cvtsi2ss xmm1, dword ptr [0x43468230]
43354f1b mulss    xmm0, dword ptr [ecx]
43354f1f mulss    xmm1, dword ptr [0x43470000]
43354f27 movss    dword ptr [esp + 0xc8], xmm0
43354f30 movss    xmm0, dword ptr [0x43476928]
43354f38 addss    xmm0, dword ptr [edi + 0x198]
43354f40 call     0x43367633
43354f45 mov      ecx, dword ptr [0x4346a338]
43354f4b xorps    xmm1, xmm1
43354f4e cvtsi2ss xmm1, dword ptr [esp + 0x40]
43354f54 movss    xmm2, dword ptr [esp + 0xc8]
43354f5d mulss    xmm1, dword ptr [ecx]
43354f61 subss    xmm2, xmm1
43354f65 movss    xmm1, dword ptr [0x4346f868]
43354f6d subss    xmm0, xmm2
43354f71 andps    xmm0, xmmword ptr [esp + 0xb0]
43354f79 comiss   xmm1, xmm0
43354f7c setae    al
43354f7f test     al, al
43354f81 je       0x43354fae
43354f83 xor      eax, eax
43354f85 lea      edx, [eax + 1]
43354f88 mov      eax, dword ptr [edi + 0x1d8]
43354f8e mov      dword ptr [edi + 0xc8], eax
43354f94 mov      byte ptr [esp + 0x23], dl
43354f98 movd     xmm0, eax
43354f9c mov      eax, dword ptr [0x43467eb8]
43354fa1 cvtdq2ps xmm0, xmm0
43354fa4 mulss    xmm0, dword ptr [ecx]
43354fa8 movss    dword ptr [eax], xmm0
43354fac jmp      0x43354fb2
43354fae mov      dl, byte ptr [esp + 0x23]
43354fb2 xor      ecx, ecx
43354fb4 inc      ecx
43354fb5 test     dword ptr [edi], 0x40000000
43354fbb mov      byte ptr [esp + 0x5b], 0
43354fc0 mov      byte ptr [esp + 0x33], 0
43354fc5 jne      0x43355120
43354fcb test     dl, dl
43354fcd jne      0x43355120
43354fd3 cmp      byte ptr [esp + 0x22], dl
43354fd7 jne      0x43354fff
43354fd9 cmp      byte ptr [0x43468410], dl
43354fdf je       0x43354fff
43354fe1 call     0x4331ff20
43354fe6 xor      ecx, ecx
43354fe8 inc      ecx
43354fe9 cmp      eax, ecx
43354feb jne      0x43354fff
43354fed mov      eax, dword ptr [edi + 0x15c]
43354ff3 mov      byte ptr [esp + 0x5b], cl
43354ff7 cmp      eax, dword ptr [edi + 0xfc]
43354ffd jge      0x43355004
43354fff mov      byte ptr [esp + 0x5b], 0
43355004 cmp      byte ptr [esp + 0x83], 0
4335500c jne      0x4335511c
43355012 mov      ecx, dword ptr [esp + 0x18]
43355016 mov      eax, dword ptr [ecx + 0x28]
43355019 cmp      eax, dword ptr [ecx + 8]
4335501c jge      0x43355112
43355022 cmp      byte ptr [esp + 0x22], 0
43355027 jne      0x43355112
4335502d cmp      byte ptr [0x43468410], 0
43355034 je       0x43355112
4335503a cmp      dword ptr [0x434685b8], 0
43355041 je       0x43355112
43355047 call     0x4331ff20
4335504c push     2
4335504e pop      ecx
4335504f cmp      eax, ecx
43355051 jne      0x43355112
43355055 add      byte ptr [eax], al
43355057 cmp      dword ptr [edi + 0x15c], 0
4335505e jne      0x43355112
43355064 test     byte ptr [esi + 0x170], 0x23
4335506b jne      0x43355112
43355071 test     byte ptr [edi], 0x40
43355074 jne      0x43355112
4335507a test     dword ptr [edi], 0x102000
43355080 jne      0x43355112
43355086 cmp      dword ptr [edi + 0x1d4], ecx
4335508c je       0x43355112
43355092 cmp      dword ptr [edi + 0xfc], 0
43355099 jle      0x43355112
4335509b cmp      dword ptr [edi + 0xd8], 0x40
433550a2 jne      0x433550ed
433550a4 test     dword ptr [edi], 0x8000
433550aa je       0x433550ed
433550ac mov      ecx, dword ptr [edi + 0xc]
433550af test     ecx, ecx
433550b1 jne      0x433550bf
433550b3 popal    
433550b4 inc      esi
433550b5 arpl     word ptr [edx + 0x748048f], bx
433550bb push     ss
433550bc popfd    
433550bd jle      0x43355055
433550bf mov      eax, dword ptr [0x434670a4]
433550c4 mov      eax, dword ptr [eax]
433550c6 xor      eax, dword ptr [0x43468e9c]
433550cc xor      eax, 0xc0d5f8a1
433550d1 movss    xmm0, dword ptr [eax + ecx]
433550d6 mov      eax, dword ptr [0x43467eb8]
433550db comiss   xmm0, dword ptr [eax]
433550de jbe      0x43355112
433550e0 mov      eax, dword ptr [esp + 0x28]
433550e4 test     dword ptr [eax + 0x30], 0x800
433550eb je       0x43355112
433550ed mov      eax, dword ptr [0x43475b2c]
433550f2 mov      ecx, dword ptr [0x434759c4]
433550f8 cmp      ecx, dword ptr [eax]
433550fa jle      0x43355104
433550fc cmp      ecx, dword ptr [edi + 0xac]
43355102 jl       0x43355112
43355103 push     cs
43355104 mov      eax, dword ptr [0x434759c8]
43355109 inc      eax
4335510a cmp      eax, dword ptr [edi + 0xac]
43355110 jne      0x43355119
43355112 mov      byte ptr [esp + 0x33], 0
43355117 jmp      0x43355120
43355119 xor      ecx, ecx
4335511b inc      ecx
4335511c mov      byte ptr [esp + 0x33], cl
43355120 mov      eax, dword ptr [esp + 0x18]
43355124 mov      ecx, dword ptr [eax + 4]
43355127 test     ecx, ecx
43355129 jne      0x43355137
4335512b xlatb    
4335512c xor      ch, byte ptr [ebx + 0x2c77385b]
43355132 inc      eax
43355133 pop      eax
43355134 jo       0x43355103
43355136 pop      esi
43355137 call     0x433b8a2b
4335513c cmp      byte ptr [esp + 0x5b], 0
43355141 mov      edx, eax
43355143 je       0x4335514b
43355145 mov      ecx, dword ptr [esp + 0x18]
43355149 jmp      0x43355177
4335514b cmp      byte ptr [esp + 0x33], 0
43355150 je       0x433551a5
43355152 cmp      byte ptr [esp + 0x22], 0
43355157 mov      ecx, dword ptr [esp + 0x18]
4335515b mov      eax, dword ptr [ecx + 0x13c]
43355161 mov      dword ptr [edx + 0x194], eax
43355167 mov      eax, dword ptr [edi + 8]
4335516a mov      byte ptr [eax], 0
4335516d jne      0x43355177
4335516f mov      eax, dword ptr [esp + 0x28]
43355173 and      dword ptr [eax + 0x30], 0xfffffffe
43355177 mov      eax, dword ptr [edi + 0xac]
4335517d lea      esi, [ecx + 0xc]
43355180 mov      edi, 0x434759d0
43355185 mov      dword ptr [0x434759cc], eax
4335518a movsd    dword ptr es:[edi], dword ptr [esi]
4335518b movsd    dword ptr es:[edi], dword ptr [esi]
4335518c movsd    dword ptr es:[edi], dword ptr [esi]
4335518d mov      edi, dword ptr [esp + 0x14]
43355191 mov      eax, dword ptr [edi + 0xac]
43355197 mov      dword ptr [0x434759c8], eax
4335519c mov      esi, dword ptr [esp + 0x1c]
433551a0 jmp      0x4335615e
433551a5 cmp      byte ptr [esp + 0x98], 0
433551ad jne      0x433551ba
433551af cmp      byte ptr [esp + 0x22], 0
433551b4 je       0x4335615a
433551ba mov      eax, dword ptr [esp + 0x18]
433551be lea      ecx, [edi + 0xdc]
433551c4 add      eax, 0xc
433551c7 mov      esi, dword ptr [esp + 0x28]
433551cb add      esi, 0xc
433551ce mov      dword ptr [esp + 0x170], eax
433551d5 mov      dword ptr [esp + 0x3c], esi
433551d9 movss    xmm4, dword ptr [eax]
433551dd subss    xmm4, dword ptr [ecx]
433551e1 movss    xmm3, dword ptr [eax + 4]
433551e6 subss    xmm3, dword ptr [ecx + 4]
433551eb movss    xmm2, dword ptr [eax + 8]
433551f0 subss    xmm2, dword ptr [ecx + 8]
433551f5 movaps   xmm1, xmm4
433551f8 mulss    xmm1, xmm4
433551fc movaps   xmm0, xmm3
433551ff mulss    xmm0, xmm3
43355203 addss    xmm1, xmm0
43355207 movaps   xmm0, xmm2
4335520a mulss    xmm0, xmm2
4335520e addss    xmm1, xmm0
43355212 movaps   xmm0, xmm1
43355215 movss    xmm1, dword ptr [esp + 0x68]
4335521b sqrtss   xmm0, xmm0
4335521f movss    dword ptr [esp + 0x680], xmm0
43355228 addss    xmm0, dword ptr [esp + 0x94]
43355231 divss    xmm1, xmm0
43355235 movaps   xmm0, xmm1
43355238 mulss    xmm0, xmm4
4335523c movaps   xmm4, xmm1
4335523f mulss    xmm4, xmm3
43355243 mulss    xmm1, xmm2
43355247 movss    xmm2, dword ptr [esp + 0x2c]
4335524d ucomiss  xmm4, xmm2
43355250 movss    dword ptr [esp + 0x40], xmm0
43355256 movss    dword ptr [esp + 0xc8], xmm4
4335525f lahf     
43355260 movss    dword ptr [esp + 0x10c], xmm1
43355269 test     ah, 0x44
4335526c jp       0x43355298
4335526e ucomiss  xmm0, xmm2
43355271 lahf     
43355272 test     ah, 0x44
43355275 jp       0x43355298
43355277 comiss   xmm1, xmm2
4335527a jbe      0x43355287
4335527c movss    xmm0, dword ptr [esp + 0x160]
43355285 jmp      0x43355290
43355287 movss    xmm0, dword ptr [esp + 0x110]
43355290 movaps   xmm1, xmm2
43355293 jmp      0x4335531b
43355298 cvtps2pd xmm1, xmm0
4335529b cvtps2pd xmm0, xmm4
4335529e call     0x77509ee0
433552a3 movss    xmm1, dword ptr [esp + 0x40]
433552a9 cvtsd2ss xmm0, xmm0
433552ad mulss    xmm1, xmm1
433552b1 mulss    xmm0, dword ptr [esp + 0xa4]
433552ba movss    dword ptr [esp + 0x118], xmm0
433552c3 movss    xmm0, dword ptr [esp + 0xc8]
433552cc mulss    xmm0, xmm0
433552d0 addss    xmm1, xmm0
433552d4 movaps   xmm0, xmm1
433552d7 xorps    xmm1, xmm1
433552da sqrtss   xmm0, xmm0
433552de movss    dword ptr [esp + 0x684], xmm0
433552e7 cvtss2sd xmm1, xmm0
433552eb movss    xmm0, dword ptr [esp + 0x10c]
433552f4 xorps    xmm0, xmmword ptr [esp + 0xf0]
433552fc cvtss2sd xmm0, xmm0
43355300 call     0x77509ee0
43355305 movss    xmm1, dword ptr [esp + 0x118]
4335530e cvtsd2ss xmm0, xmm0
43355312 mulss    xmm0, dword ptr [esp + 0xa4]
4335531b movss    dword ptr [esi], xmm0
4335531f movss    dword ptr [esi + 4], xmm1
43355324 and      dword ptr [esi + 8], 0
43355328 mov      al, byte ptr [0x43467144]
4335532d movsx    ecx, byte ptr [edi + 0x124]
43355334 mov      byte ptr [esp + 0x33], al
43355338 call     0x433ea238
4335533d test     al, al
4335533f jne      0x43355347
43355341 cmp      byte ptr [esp + 0x33], al
43355345 jne      0x433553b4
43355347 movss    xmm3, dword ptr [edi + 0x9c]
4335534f movss    xmm2, dword ptr [edi + 0xa0]
43355357 movaps   xmm0, xmm3
4335535a movss    xmm1, dword ptr [edi + 0xa4]
43355362 mulss    xmm0, xmm3
43355366 mulss    xmm2, xmm2
4335536a mulss    xmm1, xmm1
4335536e addss    xmm0, xmm2
43355372 addss    xmm0, xmm1
43355376 ucomiss  xmm0, dword ptr [esp + 0x2c]
4335537b lahf     
4335537c test     ah, 0x44
4335537f jnp      0x433553b4
43355381 movss    xmm0, dword ptr [esi]
43355385 subss    xmm0, xmm3
43355389 movss    dword ptr [esi], xmm0
4335538d movss    xmm0, dword ptr [esi + 4]
43355392 subss    xmm0, dword ptr [edi + 0xa0]
4335539a movss    dword ptr [esi + 4], xmm0
4335539f movss    xmm0, dword ptr [esi + 8]
433553a4 subss    xmm0, dword ptr [edi + 0xa4]
433553ac movss    dword ptr [esi + 8], xmm0
433553b1 or       dword ptr [edi], 0x10
433553b4 mov      ecx, esi
433553b6 call     0x433e9160
433553bb test     byte ptr [edi], 0x40
433553be je       0x43355615
433553c4 mov      ecx, dword ptr [esp + 0x5c]
433553c8 test     ecx, ecx
433553ca jne      0x433553d8
433553cc mov      dh, 0xd3
433553ce jecxz    0x433553da
433553d0 xchg     ecx, eax
433553d1 inc      byte ptr [eax - 0x4f]
433553d4 movsb    byte ptr es:[edi], byte ptr [esi]
433553d5 mov      al, byte ptr [0x50a1a9ea]
433553d8 mov      eax, dword ptr [0x43468b50]
433553da mov      eax, dword ptr [esi + 0x43]
433553dd xor      edx, edx
433553df inc      edx
433553e0 mov      eax, dword ptr [eax]
433553e2 xor      eax, dword ptr [0x43467b48]
433553e8 xor      eax, 0x38ca5228
433553ed mov      eax, dword ptr [eax + ecx]
433553f0 shr      eax, 3
433553f3 test     dl, al
433553f5 jne      0x43355494
433553fb test     ecx, ecx
433553fd jne      0x4335540b
433553ff cmp      edi, ebx
43355401 hlt      
4335540b mov      eax, dword ptr [0x4346757c]
43355410 mov      edx, dword ptr [eax]
43355412 xor      edx, dword ptr [0x4346707c]
43355418 xor      edx, 0x43fa575
4335541e add      edx, ecx
43355420 test     ecx, ecx
43355422 jne      0x43355430
43355424 mov      dword ptr [0x319f2002], eax
43355429 daa      
4335542a push     ebx
4335542b ret      0x600
43355430 mov      eax, dword ptr [0x4346934c]
43355435 mov      ecx, dword ptr [eax]
43355437 xor      ecx, dword ptr [0x434671f8]
4335543d mov      al, byte ptr [edx]
4335543f xor      ecx, 0x334b460c
43355445 mov      edx, dword ptr [esp + 0x5c]
43355449 cmp      al, byte ptr [ecx + edx]
4335544c jne      0x43355494
4335544e mov      eax, dword ptr [esp + 0x28]
43355452 mov      edx, dword ptr [0x4346a894]
43355458 mov      esi, dword ptr [eax + 4]
4335545b mov      dword ptr [esp + 0x40], 0x1c932992
43355463 dec      esi
43355464 mov      eax, dword ptr [esp + 0x40]
43355468 mov      ecx, dword ptr [edx]
4335546a ror      eax, 0x1f
4335546d add      eax, 0x432b67bf
43355472 xor      eax, 0x7c51bac3
43355477 push     esi
43355478 push     0
4335547a mov      ecx, dword ptr [eax + ecx]
4335547d mov      dword ptr [esp + 0x554], ecx
43355484 call     0x433e533f
43355489 mov      esi, dword ptr [esp + 0x3c]
4335548d lea      ecx, [eax + 0xc]
43355490 test     eax, eax
43355492 jne      0x43355497
43355494 lea      ecx, [edi + 0x20]
43355497 and      dword ptr [esi + 8], 0
4335549b movss    xmm3, dword ptr [esi]
4335549f subss    xmm3, dword ptr [ecx]
433554a3 mov      dword ptr [esp + 0x54], ecx
433554a7 ucomiss  xmm3, xmm3
433554aa movss    dword ptr [esp + 0x34], xmm3
433554b0 lahf     
433554b1 test     ah, 0x44
433554b4 jnp      0x433554c7
433554b6 movss    xmm0, dword ptr [esp + 0x2c]
433554bc movaps   xmm3, xmm0
433554bf movss    dword ptr [esp + 0x34], xmm3
433554c5 jmp      0x43355528
433554c7 movss    xmm1, dword ptr [esp + 0xb0]
433554d0 movaps   xmm0, xmm3
433554d3 andps    xmm0, xmm1
433554d6 comiss   xmm0, dword ptr [esp + 0xec]
433554de jbe      0x43355522
433554e0 movaps   xmm0, xmm3
433554e3 divss    xmm0, dword ptr [esp + 0x8c]
433554ec andps    xmm0, xmm1
433554ef call     0x4341ad12
433554f4 movss    xmm3, dword ptr [esp + 0x34]
433554fa movss    xmm1, dword ptr [esp + 0x2c]
43355500 comiss   xmm1, xmm3
43355503 mov      ecx, dword ptr [esp + 0x54]
43355507 mulss    xmm0, dword ptr [esp + 0x8c]
43355510 jbe      0x43355518
43355512 addss    xmm3, xmm0
43355516 jmp      0x4335551c
43355518 subss    xmm3, xmm0
4335551c movss    dword ptr [esp + 0x34], xmm3
43355522 movss    xmm0, dword ptr [esp + 0x2c]
43355528 movss    xmm2, dword ptr [esi + 4]
4335552d subss    xmm2, dword ptr [ecx + 4]
43355532 ucomiss  xmm2, xmm2
43355535 movss    dword ptr [esp + 0x40], xmm2
4335553b lahf     
4335553c test     ah, 0x44
4335553f jnp      0x43355546
43355541 movaps   xmm2, xmm0
43355544 jmp      0x433555a1
43355546 movss    xmm1, dword ptr [esp + 0xb0]
4335554f movaps   xmm0, xmm2
43355552 andps    xmm0, xmm1
43355555 comiss   xmm0, dword ptr [esp + 0xec]
4335555d jbe      0x433555a1
4335555f movaps   xmm0, xmm2
43355562 divss    xmm0, dword ptr [esp + 0x8c]
4335556b andps    xmm0, xmm1
4335556e call     0x4341ad12
43355573 movss    xmm2, dword ptr [esp + 0x40]
43355579 movss    xmm1, dword ptr [esp + 0x2c]
4335557f comiss   xmm1, xmm2
43355582 mov      ecx, dword ptr [esp + 0x54]
43355586 mulss    xmm0, dword ptr [esp + 0x8c]
4335558f movss    xmm3, dword ptr [esp + 0x34]
43355595 jbe      0x4335559d
43355597 addss    xmm2, xmm0
4335559b jmp      0x433555a1
4335559d subss    xmm2, xmm0
433555a1 movaps   xmm1, xmm3
433555a4 movaps   xmm0, xmm2
433555a7 mulss    xmm0, xmm2
433555ab mulss    xmm1, xmm3
433555af addss    xmm1, xmm0
433555b3 xorps    xmm0, xmm0
433555b6 movss    xmm0, xmm1
433555ba movss    xmm1, dword ptr [edi + 0x1e8]
433555c2 sqrtss   xmm0, xmm0
433555c6 comiss   xmm1, xmm0
433555c9 movss    dword ptr [esp + 0x550], xmm0
433555d2 ja       0x43355615
433555d4 divss    xmm1, xmm0
433555d8 mulss    xmm3, xmm1
433555dc mulss    xmm2, xmm1
433555e0 addss    xmm3, dword ptr [ecx]
433555e4 movss    dword ptr [esi], xmm3
433555e8 addss    xmm2, dword ptr [ecx + 4]
433555ed movss    dword ptr [esi + 4], xmm2
433555f2 cmp      dword ptr [edi + 0xd8], 0x40
433555f9 jne      0x43356146
433555ff mov      eax, dword ptr [0x43467eb8]
43355604 movss    xmm0, dword ptr [edi + 0x1e4]
4335560c comiss   xmm0, dword ptr [eax]
4335560f jae      0x43356146
43355615 cmp      byte ptr [0x43468410], 0
4335561c je       0x43356146
43355622 mov      ecx, dword ptr [esp + 0x1c]
43355626 test     byte ptr [ecx + 0x170], 9
4335562d jne      0x43355def
43355633 xor      eax, eax
43355635 lea      edx, [eax + 1]
43355638 mov      byte ptr [esp + 0x22], dl
4335563c cmp      byte ptr [0x43468d7c], al
43355642 je       0x43355de7
43355648 test     dword ptr [edi], 0x400000
4335564e jne      0x43355de7
43355654 cmp      dword ptr [esp + 0x5c], eax
43355658 jne      0x43355666
4335565a fisub    dword ptr [eax + 0xe]
4335565d movsd    dword ptr es:[edi], dword ptr [esi]
4335565e pushal   
4335565f add      dl, bl
43355661 cmp      dword ptr [edi + 0x4c], -0x1a
43355665 mov      eax, dword ptr ss:[0x43467f4c]
43355666 mov      eax, dword ptr [0x43467f4c]
4335566b mov      esi, dword ptr [esp + 0x5c]
4335566f mov      eax, dword ptr [eax]
43355671 xor      eax, dword ptr [0x4346a8b0]
43355677 xor      eax, 0x3d52a1a7
4335567c mov      eax, dword ptr [eax + esi]
4335567f mov      esi, dword ptr [esp + 0x3c]
43355683 mov      dword ptr [esp + 0x40], eax
43355687 test     eax, eax
43355689 je       0x43355de7
4335568f push     dword ptr [esp + 0x5c]
43355693 mov      ecx, eax
43355695 call     0x433d6cd1
4335569a test     al, al
4335569c je       0x43355ddf
433556a2 mov      ecx, dword ptr [esp + 0x5c]
433556a6 call     0x433fd30d
433556ab test     eax, eax
433556ad je       0x43355ddf
433556b3 mov      ecx, dword ptr [esp + 0x5c]
433556b7 call     0x433fd30d
433556bc test     eax, eax
433556be je       0x43355ddf
433556c4 mov      edx, dword ptr [esp + 0x5c]
433556c8 test     edx, edx
433556ca jne      0x433556d8
433556d8 mov      ecx, dword ptr [eax]
433556da mov      eax, dword ptr [0x43468240]
433556df mov      eax, dword ptr [eax]
433556e1 xor      eax, dword ptr [0x4346a84c]
433556e7 xor      eax, 0xc2b6fb10
433556ec imul     edx, dword ptr [eax + edx], 0xc
433556f0 add      edx, dword ptr [ecx + 0xb0]
433556f6 add      edx, ecx
433556f8 je       0x43355ddf
433556fe xor      eax, eax
43355700 cmp      dword ptr [edx + 4], eax
43355703 je       0x43355ddf
43355709 mov      eax, dword ptr [edx + 8]
4335570c add      eax, edx
4335570e je       0x43355ddf
43355714 mov      eax, dword ptr [eax]
43355716 mov      dword ptr [esp + 0x114], eax
4335571d cmp      eax, -1
43355720 je       0x43355ddf
43355726 test     byte ptr [edi], 0x10
43355729 movss    xmm1, dword ptr [esi]
4335572d movss    dword ptr [esp + 0xa0], xmm1
43355736 jne      0x43355749
43355738 subss    xmm1, dword ptr [edi + 0x9c]
43355740 movss    dword ptr [esp + 0xa0], xmm1
43355749 ucomiss  xmm1, xmm1
4335574c lahf     
4335574d test     ah, 0x44
43355750 jnp      0x4335575d
43355752 movss    xmm3, dword ptr [esp + 0x2c]
43355758 movaps   xmm1, xmm3
4335575b jmp      0x433557b9
4335575d movss    xmm2, dword ptr [esp + 0xb0]
43355766 movaps   xmm0, xmm1
43355769 andps    xmm0, xmm2
4335576c comiss   xmm0, dword ptr [esp + 0xec]
43355774 jbe      0x433557b3
43355776 movaps   xmm0, xmm1
43355779 divss    xmm0, dword ptr [esp + 0x8c]
43355782 andps    xmm0, xmm2
43355785 call     0x4341ad12
4335578a movss    xmm1, dword ptr [esp + 0xa0]
43355793 movss    xmm3, dword ptr [esp + 0x2c]
43355799 comiss   xmm3, xmm1
4335579c mulss    xmm0, dword ptr [esp + 0x8c]
433557a5 jbe      0x433557ad
433557a7 addss    xmm1, xmm0
433557ab jmp      0x433557b9
433557ad subss    xmm1, xmm0
433557b1 jmp      0x433557b9
433557b3 movss    xmm3, dword ptr [esp + 0x2c]
433557b9 movss    xmm0, dword ptr [edi + 0xa8]
433557c1 movss    xmm4, dword ptr [esp + 0xec]
433557ca addss    xmm0, xmm1
433557ce comiss   xmm0, xmm4
433557d1 jbe      0x433557dc
433557d3 subss    xmm0, dword ptr [esp + 0x8c]
433557dc movss    xmm1, dword ptr [0x43472228]
433557e4 movaps   xmm2, xmm0
433557e7 movss    xmm5, dword ptr [esp + 0x110]
433557f0 maxss    xmm2, xmm1
433557f4 movss    xmm1, dword ptr [edi + 0x114]
433557fc movaps   xmm0, xmm5
433557ff addss    xmm1, dword ptr [edi + 0x164]
43355807 mov      ecx, dword ptr [0x43467b80]
4335580d mov      edx, dword ptr [0x43467d78]
43355813 minss    xmm2, xmm0
43355817 movss    xmm0, dword ptr [edi + 0xe4]
4335581f ucomiss  xmm0, xmm1
43355822 movss    dword ptr [esp + 0x164], xmm2
4335582b lahf     
4335582c test     ah, 0x44
4335582f jp       0x4335585d
43355831 mov      eax, dword ptr [edx]
43355833 mov      esi, dword ptr [esp + 0x5c]
43355837 xor      eax, ecx
43355839 xor      eax, 0x1caaf0a8
4335583e movss    xmm0, dword ptr [eax + esi + 0x30]
43355844 mov      esi, dword ptr [esp + 0x3c]
43355848 subss    xmm0, xmm3
4335584c mulss    xmm0, xmm4
43355850 subss    xmm0, xmm5
43355854 comiss   xmm2, xmm0
43355857 jbe      0x43355ddf
4335585d mov      eax, dword ptr [edx]
4335585f xor      eax, ecx
43355861 mov      ecx, dword ptr [esp + 0x5c]
43355865 xor      eax, 0x1caaf0a8
4335586a push     0xc
4335586c mov      dword ptr [esp + 0xa4], eax
43355873 movss    xmm0, dword ptr [eax + ecx + 0x30]
43355879 pop      eax
4335587a push     eax
4335587b movss    dword ptr [esp + 0x80], xmm0
43355884 call     0x433bffc5
43355889 mov      ecx, dword ptr [esp + 0x40]
4335588d lea      edx, [esp + 0x3c0]
43355894 xor      eax, eax
43355896 and      dword ptr [esp + 0x3c0], eax
4335589d and      dword ptr [esp + 0x3c8], eax
433558a4 mov      dword ptr [esp + 0x2dc], eax
433558ab movss    xmm0, dword ptr [ecx + 0x80]
433558b3 mov      ecx, dword ptr [esp + 0x5c]
433558b7 movss    xmm1, dword ptr [edi + 0x10c]
433558bf movss    xmm2, dword ptr [edi + 0x110]
433558c7 movss    xmm3, dword ptr [edi + 0x114]
433558cf push     eax
433558d0 inc      eax
433558d1 movss    dword ptr [esp + 0x3c8], xmm0
433558da push     eax
433558db push     dword ptr [esp + 0x11c]
433558e2 lea      eax, [esp + 0x2e8]
433558e9 push     0x300
433558ee push     eax
433558ef lea      eax, [esp + 0x4364]
433558f6 push     eax
433558f7 mov      eax, dword ptr [0x43467eb8]
433558fc movss    xmm0, dword ptr [eax]
43355900 call     0x43388720
43355905 test     al, al
43355907 je       0x43355dc8
4335590d movss    xmm0, dword ptr [edi + 0x114]
43355915 lea      ecx, [esp + 0x4350]
4335591c imul     eax, dword ptr [esp + 0x114], 0x30
43355924 lea      edx, [esp + 0x1bc]
4335592b addss    xmm0, dword ptr [edi + 0x164]
43355933 add      ecx, eax
43355935 movss    dword ptr [esp + 0x1bc], xmm0
4335593e call     0x433df6a6
43355943 movss    xmm0, dword ptr [esp + 0x1bc]
4335594c ucomiss  xmm0, dword ptr [edi + 0xe4]
43355953 lahf     
43355954 test     ah, 0x44
43355957 jnp      0x43355dc8
4335595d mov      eax, dword ptr [esp + 0x170]
43355964 lea      ecx, [edi + 0xdc]
4335596a movss    dword ptr [edi + 0xe4], xmm0
43355972 movss    xmm0, dword ptr [esp + 0x1bc]
4335597b subss    xmm0, dword ptr [edi + 0x114]
43355983 movss    dword ptr [edi + 0x84], xmm0
4335598b movss    xmm4, dword ptr [eax]
4335598f subss    xmm4, dword ptr [ecx]
43355993 movss    xmm3, dword ptr [eax + 4]
43355998 subss    xmm3, dword ptr [ecx + 4]
4335599d movss    xmm2, dword ptr [eax + 8]
433559a2 subss    xmm2, dword ptr [ecx + 8]
433559a7 movaps   xmm1, xmm4
433559aa mulss    xmm1, xmm4
433559ae movaps   xmm0, xmm3
433559b1 mulss    xmm0, xmm3
433559b5 addss    xmm1, xmm0
433559b9 movaps   xmm0, xmm2
433559bc mulss    xmm0, xmm2
433559c0 addss    xmm1, xmm0
433559c4 movaps   xmm0, xmm1
433559c7 movss    xmm1, dword ptr [esp + 0x68]
433559cd sqrtss   xmm0, xmm0
433559d1 movss    dword ptr [esp + 0x554], xmm0
433559da addss    xmm0, dword ptr [esp + 0x94]
433559e3 divss    xmm1, xmm0
433559e7 movaps   xmm0, xmm1
433559ea mulss    xmm0, xmm4
433559ee movaps   xmm4, xmm1
433559f1 mulss    xmm4, xmm3
433559f5 mulss    xmm1, xmm2
433559f9 movss    xmm2, dword ptr [esp + 0x2c]
433559ff ucomiss  xmm4, xmm2
43355a02 movss    dword ptr [esp + 0x40], xmm0
43355a08 movss    dword ptr [esp + 0xc8], xmm4
43355a11 lahf     
43355a12 movss    dword ptr [esp + 0x10c], xmm1
43355a1b test     ah, 0x44
43355a1e jp       0x43355a4a
43355a20 ucomiss  xmm0, xmm2
43355a23 lahf     
43355a24 test     ah, 0x44
43355a27 jp       0x43355a4a
43355a29 comiss   xmm1, xmm2
43355a2c jbe      0x43355a39
43355a2e movss    xmm0, dword ptr [esp + 0x160]
43355a37 jmp      0x43355a42
43355a39 movss    xmm0, dword ptr [esp + 0x110]
43355a42 movaps   xmm1, xmm2
43355a45 jmp      0x43355acd
43355a4a cvtps2pd xmm1, xmm0
43355a4d cvtps2pd xmm0, xmm4
43355a50 call     0x77509ee0
43355a55 movss    xmm1, dword ptr [esp + 0x40]
43355a5b cvtsd2ss xmm0, xmm0
43355a5f mulss    xmm1, xmm1
43355a63 mulss    xmm0, dword ptr [esp + 0xa4]
43355a6c movss    dword ptr [esp + 0x118], xmm0
43355a75 movss    xmm0, dword ptr [esp + 0xc8]
43355a7e mulss    xmm0, xmm0
43355a82 addss    xmm1, xmm0
43355a86 movaps   xmm0, xmm1
43355a89 xorps    xmm1, xmm1
43355a8c sqrtss   xmm0, xmm0
43355a90 movss    dword ptr [esp + 0x558], xmm0
43355a99 cvtss2sd xmm1, xmm0
43355a9d movss    xmm0, dword ptr [esp + 0x10c]
43355aa6 xorps    xmm0, xmmword ptr [esp + 0xf0]
43355aae cvtss2sd xmm0, xmm0
43355ab2 call     0x77509ee0
43355ab7 movss    xmm1, dword ptr [esp + 0x118]
43355ac0 cvtsd2ss xmm0, xmm0
43355ac4 mulss    xmm0, dword ptr [esp + 0xa4]
43355acd movss    dword ptr [esi], xmm0
43355ad1 movss    dword ptr [esi + 4], xmm1
43355ad6 and      dword ptr [esi + 8], 0
43355ada mov      al, byte ptr [0x43467144]
43355adf movsx    ecx, byte ptr [edi + 0x124]
43355ae6 mov      byte ptr [esp + 0x33], al
43355aea call     0x433ea238
43355aef test     al, al
43355af1 jne      0x43355af9
43355af3 cmp      byte ptr [esp + 0x33], al
43355af7 jne      0x43355b66
43355af9 movss    xmm3, dword ptr [edi + 0x9c]
43355b01 movss    xmm2, dword ptr [edi + 0xa0]
43355b09 movaps   xmm0, xmm3
43355b0c movss    xmm1, dword ptr [edi + 0xa4]
43355b14 mulss    xmm0, xmm3
43355b18 mulss    xmm2, xmm2
43355b1c mulss    xmm1, xmm1
43355b20 addss    xmm0, xmm2
43355b24 addss    xmm0, xmm1
43355b28 ucomiss  xmm0, dword ptr [esp + 0x2c]
43355b2d lahf     
43355b2e test     ah, 0x44
43355b31 jnp      0x43355b66
43355b33 movss    xmm0, dword ptr [esi]
43355b37 subss    xmm0, xmm3
43355b3b movss    dword ptr [esi], xmm0
43355b3f movss    xmm0, dword ptr [esi + 4]
43355b44 subss    xmm0, dword ptr [edi + 0xa0]
43355b4c movss    dword ptr [esi + 4], xmm0
43355b51 movss    xmm0, dword ptr [esi + 8]
43355b56 subss    xmm0, dword ptr [edi + 0xa4]
43355b5e movss    dword ptr [esi + 8], xmm0
43355b63 or       dword ptr [edi], 0x10
43355b66 mov      ecx, esi
43355b68 call     0x433e9160
43355b6d xor      edx, edx
43355b6f inc      edx
43355b70 test     byte ptr [edi], 0x40
43355b73 mov      byte ptr [esp + 0x22], dl
43355b77 je       0x43355dc8
43355b7d mov      ecx, dword ptr [esp + 0x5c]
43355b81 test     ecx, ecx
43355b83 jne      0x43355b91
43355b85 push     0xd818e526
43355b91 mov      eax, dword ptr [0x43468b50]
43355b96 mov      eax, dword ptr [eax]
43355b98 xor      eax, dword ptr [0x43467b48]
43355b9e xor      eax, 0x38ca5228
43355ba3 mov      eax, dword ptr [eax + ecx]
43355ba6 shr      eax, 3
43355ba9 test     dl, al
43355bab jne      0x43355c4a
43355bb1 test     ecx, ecx
43355bb3 jne      0x43355bc1
43355bb5 push     esp
43355bb6 retf     0x4acd
43355bbd std      
43355bbe cwde     
43355bbf cmp      al, 0x7d
43355bc1 mov      eax, dword ptr [0x4346757c]
43355bc6 mov      edx, dword ptr [eax]
43355bc8 xor      edx, dword ptr [0x4346707c]
43355bce xor      edx, 0x43fa575
43355bd4 add      edx, ecx
43355bd6 test     ecx, ecx
43355bd8 jne      0x43355be6
43355bda and      dh, byte ptr [ebp - 0x28]
43355bdd mov      eax, dword ptr [0xa90275ca]
43355be2 jl       0x43355bbd
43355be4 aas      
43355be5 dec      esi
43355be6 mov      eax, dword ptr [0x4346934c]
43355beb mov      ecx, dword ptr [eax]
43355bed xor      ecx, dword ptr [0x434671f8]
43355bf3 mov      al, byte ptr [edx]
43355bf5 xor      ecx, 0x334b460c
43355bfb mov      edx, dword ptr [esp + 0x5c]
43355bff cmp      al, byte ptr [ecx + edx]
43355c02 jne      0x43355c4a
43355c04 mov      eax, dword ptr [esp + 0x28]
43355c08 mov      edx, dword ptr [0x4346a894]
43355c0e mov      esi, dword ptr [eax + 4]
43355c11 mov      dword ptr [esp + 0x40], 0x1c932992
43355c19 dec      esi
43355c1a mov      eax, dword ptr [esp + 0x40]
43355c1e mov      ecx, dword ptr [edx]
43355c20 ror      eax, 0x1f
43355c23 add      eax, 0x432b67bf
43355c28 xor      eax, 0x7c51bac3
43355c2d push     esi
43355c2e push     0
43355c30 mov      ecx, dword ptr [eax + ecx]
43355c33 mov      dword ptr [esp + 0x564], ecx
43355c3a call     0x433e533f
43355c3f mov      esi, dword ptr [esp + 0x3c]
43355c43 lea      ecx, [eax + 0xc]
43355c46 test     eax, eax
43355c48 jne      0x43355c4d
43355c4a lea      ecx, [edi + 0x20]
43355c4d and      dword ptr [esi + 8], 0
43355c51 movss    xmm3, dword ptr [esi]
43355c55 subss    xmm3, dword ptr [ecx]
43355c59 mov      dword ptr [esp + 0x54], ecx
43355c5d ucomiss  xmm3, xmm3
43355c60 movss    dword ptr [esp + 0x34], xmm3
43355c66 lahf     
43355c67 test     ah, 0x44
43355c6a jnp      0x43355c7d
43355c6c movss    xmm0, dword ptr [esp + 0x2c]
43355c72 movaps   xmm3, xmm0
43355c75 movss    dword ptr [esp + 0x34], xmm3
43355c7b jmp      0x43355cde
43355c7d movss    xmm1, dword ptr [esp + 0xb0]
43355c86 movaps   xmm0, xmm3
43355c89 andps    xmm0, xmm1
43355c8c comiss   xmm0, dword ptr [esp + 0xec]
43355c94 jbe      0x43355cd8
43355c96 movaps   xmm0, xmm3
43355c99 divss    xmm0, dword ptr [esp + 0x8c]
43355ca2 andps    xmm0, xmm1
43355ca5 call     0x4341ad12
43355caa movss    xmm3, dword ptr [esp + 0x34]
43355cb0 movss    xmm1, dword ptr [esp + 0x2c]
43355cb6 comiss   xmm1, xmm3
43355cb9 mov      ecx, dword ptr [esp + 0x54]
43355cbd mulss    xmm0, dword ptr [esp + 0x8c]
43355cc6 jbe      0x43355cce
43355cc8 addss    xmm3, xmm0
43355ccc jmp      0x43355cd2
43355cce subss    xmm3, xmm0
43355cd2 movss    dword ptr [esp + 0x34], xmm3
43355cd8 movss    xmm0, dword ptr [esp + 0x2c]
43355cde movss    xmm2, dword ptr [esi + 4]
43355ce3 subss    xmm2, dword ptr [ecx + 4]
43355ce8 ucomiss  xmm2, xmm2
43355ceb movss    dword ptr [esp + 0x40], xmm2
43355cf1 lahf     
43355cf2 test     ah, 0x44
43355cf5 jnp      0x43355cfc
43355cf7 movaps   xmm2, xmm0
43355cfa jmp      0x43355d57
43355cfc movss    xmm1, dword ptr [esp + 0xb0]
43355d05 movaps   xmm0, xmm2
43355d08 andps    xmm0, xmm1
43355d0b comiss   xmm0, dword ptr [esp + 0xec]
43355d13 jbe      0x43355d57
43355d15 movaps   xmm0, xmm2
43355d18 divss    xmm0, dword ptr [esp + 0x8c]
43355d21 andps    xmm0, xmm1
43355d24 call     0x4341ad12
43355d29 movss    xmm2, dword ptr [esp + 0x40]
43355d2f movss    xmm1, dword ptr [esp + 0x2c]
43355d35 comiss   xmm1, xmm2
43355d38 mov      ecx, dword ptr [esp + 0x54]
43355d3c mulss    xmm0, dword ptr [esp + 0x8c]
43355d45 movss    xmm3, dword ptr [esp + 0x34]
43355d4b jbe      0x43355d53
43355d4d addss    xmm2, xmm0
43355d51 jmp      0x43355d57
43355d53 subss    xmm2, xmm0
43355d57 movaps   xmm1, xmm3
43355d5a movaps   xmm0, xmm2
43355d5d mulss    xmm0, xmm2
43355d61 mulss    xmm1, xmm3
43355d65 addss    xmm1, xmm0
43355d69 xorps    xmm0, xmm0
43355d6c movss    xmm0, xmm1
43355d70 movss    xmm1, dword ptr [edi + 0x1e8]
43355d78 sqrtss   xmm0, xmm0
43355d7c comiss   xmm1, xmm0
43355d7f movss    dword ptr [esp + 0x560], xmm0
43355d88 ja       0x43355dc8
43355d8a divss    xmm1, xmm0
43355d8e mulss    xmm3, xmm1
43355d92 mulss    xmm2, xmm1
43355d96 addss    xmm3, dword ptr [ecx]
43355d9a movss    dword ptr [esi], xmm3
43355d9e addss    xmm2, dword ptr [ecx + 4]
43355da3 movss    dword ptr [esi + 4], xmm2
43355da8 cmp      dword ptr [edi + 0xd8], 0x40
43355daf jne      0x43355dc3
43355db1 mov      eax, dword ptr [0x43467eb8]
43355db6 movss    xmm0, dword ptr [edi + 0x1e4]
43355dbe comiss   xmm0, dword ptr [eax]
43355dc1 jb       0x43355dc8
43355dc3 mov      byte ptr [esp + 0x22], 0
43355dc8 mov      eax, dword ptr [esp + 0xa0]
43355dcf mov      ecx, dword ptr [esp + 0x5c]
43355dd3 movss    xmm0, dword ptr [esp + 0x7c]
43355dd9 movss    dword ptr [eax + ecx + 0x30], xmm0
43355ddf mov      ecx, dword ptr [esp + 0x1c]
43355de3 mov      dl, byte ptr [esp + 0x22]
43355de7 test     dl, dl
43355de9 je       0x43356146
43355def mov      eax, dword ptr [edi]
43355df1 mov      edx, dword ptr [esp + 0x28]
43355df5 and      eax, 0x800
43355dfa neg      eax
43355dfc sbb      eax, eax
43355dfe and      eax, 0x7ff
43355e03 inc      eax
43355e04 or       dword ptr [edx + 0x30], eax
43355e07 cmp      dword ptr [edi + 0xd8], 0x40
43355e0e jne      0x43355e2e
43355e10 test     dword ptr [edi], 0x800
43355e16 jne      0x43355e2e
43355e18 mov      eax, dword ptr [0x43467eb8]
43355e1d movss    xmm0, dword ptr [eax]
43355e21 comiss   xmm0, dword ptr [edi + 0x1e4]
43355e28 jbe      0x43356146
43355e2e cmp      byte ptr [esp + 0x23], 0
43355e33 mov      eax, dword ptr [edi]
43355e35 je       0x43355e3e
43355e37 or       eax, 0x20000000
43355e3c mov      dword ptr [edi], eax
43355e3e mov      edx, dword ptr [esp + 0x18]
43355e42 test     byte ptr [edx], 4
43355e45 je       0x43355e4e
43355e47 or       eax, 0x2000000
43355e4c mov      dword ptr [edi], eax
43355e4e or       dword ptr [ecx + 0x170], 0x800
43355e58 lea      esi, [edx + 0xc]
43355e5b or       dword ptr [edi], 0x1000
43355e61 add      edi, 0xe8
43355e67 movsd    dword ptr es:[edi], dword ptr [esi]
43355e68 movsd    dword ptr es:[edi], dword ptr [esi]
43355e69 movsd    dword ptr es:[edi], dword ptr [esi]
43355e6a mov      edi, dword ptr [esp + 0x14]
43355e6e mov      eax, dword ptr [edi + 0xac]
43355e74 mov      dword ptr [0x434759c4], eax
43355e79 mov      eax, dword ptr [edi + 8]
43355e7c cmp      byte ptr [eax], 0
43355e7f jne      0x43355e8f
43355e81 cmp      byte ptr [0x43468d7c], 0
43355e88 je       0x43355e8f
43355e8a xor      ecx, ecx
43355e8c inc      ecx
43355e8d mov      byte ptr [eax], cl
43355e8f mov      eax, dword ptr [0x434759c0]
43355e94 mov      ecx, dword ptr [0x4346a890]
43355e9a and      eax, 0xfffffbff
43355e9f or       eax, 0x200
43355ea4 mov      dword ptr [0x434759c0], eax
43355ea9 push     dword ptr [edx + 4]
43355eac mov      eax, dword ptr [ecx]
43355eae mov      eax, dword ptr [eax + 0xc]
43355eb1 call     eax
43355eb3 test     eax, eax
43355eb5 je       0x433560c9
43355ebb cmp      dword ptr [edi + 0x1a0], 0
43355ec2 jne      0x43355ed0
43355ec4 mov      edx, dword ptr [esp + 0x5c]
43355ec8 mov      ecx, edi
43355eca push     eax
43355ecb call     0x43329b30
43355ed0 mov      eax, dword ptr [esp + 0x1c]
43355ed4 mov      esi, 0x96
43355ed9 mov      ecx, dword ptr [eax + 0x168]
43355edf mov      eax, ecx
43355ee1 cdq      
43355ee2 idiv     esi
43355ee4 lea      eax, [ecx + 1]
43355ee7 mov      ecx, dword ptr [esp + 0x1c]
43355eeb mov      esi, edx
43355eed mov      edx, dword ptr [esp + 0x18]
43355ef1 push     esi
43355ef2 mov      dword ptr [ecx + 0x168], eax
43355ef8 mov      ecx, edi
43355efa call     0x4340c8c4
43355eff push     dword ptr [esp + 0x18]
43355f03 mov      edx, esi
43355f05 mov      ecx, edi
43355f07 call     0x4341d449
43355f0c mov      esi, dword ptr [esp + 0x18]
43355f10 mov      ecx, edi
43355f12 mov      edx, esi
43355f14 call     0x4331f3f1
43355f19 xor      eax, eax
43355f1b inc      eax
43355f1c cmp      dword ptr [edi + 0x1d4], eax
43355f22 jne      0x433560c9
43355f28 mov      eax, dword ptr [esi + 0x28]
43355f2b cmp      eax, dword ptr [esi + 8]
43355f2e jge      0x433560c9
43355f34 movss    xmm2, dword ptr [esi + 0xc]
43355f39 lea      ecx, [edi + 0xdc]
43355f3f subss    xmm2, dword ptr [ecx]
43355f43 movss    xmm3, dword ptr [esi + 0x10]
43355f48 subss    xmm3, dword ptr [ecx + 4]
43355f4d movss    xmm4, dword ptr [esi + 0x14]
43355f52 subss    xmm4, dword ptr [ecx + 8]
43355f57 movaps   xmm1, xmm2
43355f5a mov      eax, dword ptr [0x43469300]
43355f5f mulss    xmm1, xmm2
43355f63 xor      ecx, ecx
43355f65 inc      ecx
43355f66 movaps   xmm0, xmm3
43355f69 mov      dword ptr [esp + 0x48], ecx
43355f6d mulss    xmm0, xmm3
43355f71 mov      edx, ecx
43355f73 addss    xmm1, xmm0
43355f77 movaps   xmm0, xmm4
43355f7a mulss    xmm0, xmm4
43355f7e addss    xmm1, xmm0
43355f82 movaps   xmm0, xmm1
43355f85 movss    xmm1, dword ptr [esp + 0x68]
43355f8b sqrtss   xmm0, xmm0
43355f8f movss    dword ptr [esp + 0x564], xmm0
43355f98 addss    xmm0, dword ptr [esp + 0x94]
43355fa1 divss    xmm1, xmm0
43355fa5 movaps   xmm0, xmm1
43355fa8 mulss    xmm0, xmm2
43355fac movss    dword ptr [esp + 0x254], xmm0
43355fb5 movaps   xmm0, xmm1
43355fb8 mulss    xmm0, xmm3
43355fbc mulss    xmm1, xmm4
43355fc0 movss    dword ptr [esp + 0x258], xmm0
43355fc9 movss    dword ptr [esp + 0x25c], xmm1
43355fd2 mov      eax, dword ptr [eax]
43355fd4 mov      dword ptr [esp + 0xc8], eax
43355fdb cmp      eax, ecx
43355fdd jle      0x433560c9
43355fe3 mov      ecx, dword ptr [0x4346a890]
43355fe9 push     edx
43355fea mov      eax, dword ptr [ecx]
43355fec mov      eax, dword ptr [eax + 0xc]
43355fef call     eax
43355ff1 mov      edx, dword ptr [esp + 0x48]
43355ff5 mov      dword ptr [esp + 0x40], eax
43355ff9 cmp      edx, dword ptr [esi + 4]
43355ffc je       0x433560ac
43356002 mov      ecx, eax
43356004 call     0x43358962
43356009 test     al, al
4335600b je       0x433560a8
43356011 mov      ecx, dword ptr [esp + 0x40]
43356015 test     ecx, ecx
43356017 jne      0x43356025
43356019 in       eax, 0xc7
4335601b pop      eax
4335601c idiv     ebp
4335601e pop      ebp
4335601f out      dx, al
43356020 cmp      esp, edi
43356022 into     
43356023 pop      ebx
43356024 loop     0x43355fc7
43356025 mov      eax, dword ptr [0x434670cc]
43356026 int3     
4335602a lea      edi, [esp + 0x36c]
43356031 mov      esi, dword ptr [eax]
43356033 xor      esi, dword ptr [0x43468bcc]
43356039 xor      esi, 0xa9ee6062
4335603f add      esi, ecx
43356041 movsd    dword ptr es:[edi], dword ptr [esi]
43356042 movsd    dword ptr es:[edi], dword ptr [esi]
43356043 movsd    dword ptr es:[edi], dword ptr [esi]
43356044 mov      eax, dword ptr [ecx]
43356046 call     dword ptr [eax + 0xc]
43356049 mov      ecx, eax
4335604b mov      edx, dword ptr [eax]
4335604d call     dword ptr [edx + 8]
43356050 mov      edi, dword ptr [esp + 0x14]
43356054 lea      ecx, [esp + 0x36c]
4335605b movss    xmm0, dword ptr [eax + 8]
43356060 lea      eax, [esp + 0x254]
43356067 mulss    xmm0, dword ptr [esp + 0x90]
43356070 lea      edx, [edi + 0xdc]
43356076 push     eax
43356077 addss    xmm0, dword ptr [esp + 0x378]
43356080 movss    dword ptr [esp + 0x378], xmm0
43356089 movss    xmm0, dword ptr [edi + 0x130]
43356091 call     0x4341cb0c
43356096 movss    xmm1, dword ptr [esp + 0x9c]
4335609f comiss   xmm1, xmm0
433560a2 ja       0x433560c0
433560a4 mov      esi, dword ptr [esp + 0x18]
433560a8 mov      edx, dword ptr [esp + 0x48]
433560ac inc      edx
433560ad mov      dword ptr [esp + 0x48], edx
433560b1 cmp      edx, dword ptr [esp + 0xc8]
433560b8 jl       0x43355fe3
433560be jmp      0x433560c9
433560c0 push     0xc
433560c2 pop      eax
433560c3 mov      dword ptr [edi + 0x1dc], eax
433560c9 mov      esi, dword ptr [esp + 0x18]
433560cd mov      eax, dword ptr [esi + 0xb4]
433560d3 mov      dword ptr [esp + 0x40], eax
433560d7 test     eax, eax
433560d9 jle      0x43356123
433560db movss    xmm1, dword ptr [0x43469254]
433560e3 movss    xmm0, dword ptr [edi + 0x198]
433560eb call     0x4332fc35
433560f0 mov      eax, dword ptr [0x4346a338]
433560f4 inc      ebx
433560f5 mov      ecx, dword ptr [esp + 0x40]
433560f9 divss    xmm0, dword ptr [eax]
433560fd addss    xmm0, dword ptr [esp + 0x90]
43356106 cvttss2si eax, xmm0
4335610a add      ecx, eax
4335610c mov      eax, dword ptr [edi + 0x18c]
43356112 add      eax, dword ptr [edi + 0x144]
43356118 cmp      ecx, eax
4335611a jg       0x43356123
4335611c mov      eax, dword ptr [esp + 0x28]
43356120 mov      dword ptr [eax + 8], ecx
43356123 mov      ecx, dword ptr [esi + 4]
43356126 test     ecx, ecx
43356128 jne      0x43356136
4335612a outsb    dx, byte ptr [esi]
4335612b xor      dword ptr [eax], edi
4335612d inc      eax
4335612f je       0x433560f4
43356131 inc      edi
43356132 pop      es
43356133 adc      ebp, dword ptr [edx + edi]
43356136 call     0x433b8a2b
4335613b mov      esi, dword ptr [esp + 0x3c]
4335613f inc      word ptr [eax + 0xa6]
43356146 cmp      byte ptr [0x434684e0], 0
4335614d jne      0x43356156
4335614f mov      ecx, esi
43356151 call     0x433b8974
43356156 mov      esi, dword ptr [esp + 0x1c]
4335615a mov      ecx, dword ptr [esp + 0x18]
4335615e or       dword ptr [esi + 0x170], 0x80
43356168 movss    xmm0, dword ptr [ecx + 0x38]
4335616d ucomiss  xmm0, dword ptr [esp + 0x68]
43356172 mov      edx, dword ptr [esi + 0x170]
43356178 lahf     
43356179 test     ah, 0x44
4335617c jnp      0x4335618a
4335617e or       edx, 0x100
43356184 mov      dword ptr [esi + 0x170], edx
4335618a mov      eax, dword ptr [esp + 0x810]
43356191 mov      esi, dword ptr [eax]
43356193 mov      dword ptr [esp + 0xe0], esi
4335619a jmp      0x433561a3
4335619c mov      esi, dword ptr [esp + 0xe0]
433561a3 cmp      byte ptr [0x434671e0], 0
433561aa je       0x43356217
433561ac mov      eax, dword ptr [0x4346932c]
433561b1 mov      ecx, 0x43469318
433561b6 mov      eax, dword ptr [eax*4 + 0x434721c4]
433561bd call     eax
433561bf mov      edi, dword ptr [esp + 0x1c]
433561c3 test     al, al
433561c5 je       0x4335621b
433561c7 mov      eax, dword ptr [edi + 0x170]
433561cd test     al, al
433561cf js       0x4335621b
433561d1 test     esi, esi
433561d3 je       0x4335621b
433561d5 and      dword ptr [esp + 0x2e0], 0
433561dd lea      ecx, [edi - 8]
433561e0 or       eax, 8
433561e3 mov      dword ptr [edi + 0x170], eax
433561e9 lea      eax, [esp + 0x2e0]
433561f0 push     eax
433561f1 push     esi
433561f2 mov      esi, dword ptr [esp + 0x1c]
433561f6 push     esi
433561f7 call     0x4341b4c2
433561fc mov      ecx, dword ptr [edi + 0x170]
43356202 test     al, al
43356204 je       0x4335620c
43356206 or       ecx, 0x180
4335620c and      ecx, 0xfffffff7
4335620f mov      dword ptr [edi + 0x170], ecx
43356215 jmp      0x4335621f
43356217 mov      edi, dword ptr [esp + 0x1c]
4335621b mov      esi, dword ptr [esp + 0x14]
4335621f test     byte ptr [edi + 0x170], 0x80
43356226 jne      0x43356ee6
4335622c cmp      byte ptr [0x434671e0], 0
43356233 je       0x43356ee6
43356239 mov      eax, dword ptr [0x4346932c]
4335623e mov      ecx, 0x43469318
43356243 mov      eax, dword ptr [eax*4 + 0x434721c4]
4335624a call     eax
4335624c test     al, al
4335624e je       0x43356ee6
43356254 xor      eax, eax
43356256 inc      eax
43356257 test     byte ptr [0x43467e40], al
4335625d je       0x43356ee0
43356263 xor      eax, eax
43356265 cmp      dword ptr [esi + 0xc], eax
43356268 je       0x43356ee6
4335626e test     dword ptr [esi], 0x40000
43356274 je       0x43356ee6
4335627a push     0x1f
4335627c pop      ecx
4335627d cmp      dword ptr [esi + 0xd8], ecx
43356283 je       0x43356ee6
43356289 push     3
4335628b pop      ecx
4335628c test     byte ptr [edi + 0x170], cl
43356292 jne      0x43356ee6
43356298 mov      ecx, eax
4335629a mov      eax, dword ptr [0x4346db1c]
4335629f cmp      eax, -1
433562a2 je       0x43356307
433562a4 movzx    eax, ax
433562a7 mov      dword ptr [esp + 0x40], eax
433562ab mov      eax, dword ptr [edi + 0x1b8]
433562b1 mov      dword ptr [esp + 0xac], eax
433562b8 test     eax, eax
433562ba je       0x43356307
433562bc mov      edx, dword ptr [edi + 0x1c0]
433562c2 mov      esi, dword ptr [esp + 0x40]
433562c6 cmp      dword ptr [edx + 4], esi
433562c9 jne      0x433562e6
433562cb test     ecx, ecx
433562cd je       0x433562e4
433562cf mov      eax, dword ptr [edx + 0xe8]
433562d5 cmp      eax, dword ptr [ecx + 0xe8]
433562db mov      eax, dword ptr [esp + 0xac]
433562e2 jle      0x433562e6
433562e4 mov      ecx, edx
433562e6 add      edx, 0x1190
433562ec sub      eax, 1
433562ef mov      dword ptr [esp + 0xac], eax
433562f6 jne      0x433562c6
433562f8 mov      esi, dword ptr [esp + 0x14]
433562fc mov      dword ptr [esp + 0x98], ecx
43356303 test     ecx, ecx
43356305 jne      0x4335635e
43356307 mov      eax, dword ptr [edi + 0x1b8]
4335630d mov      dword ptr [esp + 0xac], eax
43356314 test     eax, eax
43356316 je       0x43356ee6
4335631c mov      edx, dword ptr [edi + 0x1c0]
43356322 test     ecx, ecx
43356324 je       0x4335633b
43356326 mov      eax, dword ptr [edx + 0xe8]
4335632c cmp      eax, dword ptr [ecx + 0xe8]
43356332 mov      eax, dword ptr [esp + 0xac]
43356339 jle      0x4335633d
4335633b mov      ecx, edx
4335633d add      edx, 0x1190
43356343 sub      eax, 1
43356346 mov      dword ptr [esp + 0xac], eax
4335634d jne      0x43356322
4335634f mov      dword ptr [esp + 0x98], ecx
43356356 test     ecx, ecx
43356358 je       0x43356ee6
4335635e cmp      dword ptr [ecx + 0xb4], -1
43356365 je       0x43356ee6
4335636b add      ecx, 0xc
4335636e call     0x433318b5
43356373 mov      edx, dword ptr [esp + 0x98]
4335637a xor      eax, eax
4335637c inc      eax
4335637d mov      dword ptr [edx + 0xbc], eax
43356383 test     dword ptr [esi], 0x1000000
43356389 je       0x433563a1
4335638b and      dword ptr [edx + 0xc0], 0xfffffffd
43356392 mov      ecx, dword ptr [edx + 0xc0]
43356398 and      dword ptr [edx + 0xc4], 0xfffffffd
4335639f jmp      0x433563a7
433563a1 mov      ecx, dword ptr [edx + 0xc0]
433563a7 mov      eax, dword ptr [edx + 0xc4]
433563ad or       eax, ecx
433563af je       0x43356ee6
433563b5 or       dword ptr [edi + 0x170], 8
433563bc mov      ecx, dword ptr [0x4346a890]
433563c2 push     dword ptr [edx + 4]
433563c5 mov      eax, dword ptr [ecx]
433563c7 mov      eax, dword ptr [eax + 0xc]
433563ca call     eax
433563cc mov      dword ptr [esp + 0x64], eax
433563d0 mov      eax, dword ptr [esp + 0x98]
433563d7 mov      ecx, dword ptr [eax + 4]
433563da test     ecx, ecx
433563dc jne      0x433563ea
433563de test     al, 0xc5
433563e0 dec      edx
433563e1 add      byte ptr [edi - 0x37], dh
433563e4 mov      ebp, 0xc6208a00
433563e9 test     eax, 0x6263ce8
433563ea call     0x433b8a2b
433563ee add      byte ptr [ecx + 0x1702484], cl
433563ef mov      dword ptr [esp + 0x170], eax
433563f4 add      byte ptr [eax], al
433563f6 lea      edi, [esp + 0x128]
433563fd mov      eax, dword ptr [esp + 0x14]
43356401 mov      ecx, dword ptr [eax + 0xc8]
43356407 mov      dword ptr [esp + 0x124], ecx
4335640e lea      ecx, [eax + 0xdc]
43356414 mov      esi, ecx
43356416 mov      dword ptr [esp + 0xac], ecx
4335641d lea      ecx, [eax + 0x10c]
43356423 movss    xmm0, dword ptr [eax + 0x98]
4335642b mov      dword ptr [esp + 0xe8], ecx
43356432 movss    dword ptr [esp + 0x7c], xmm0
43356438 movsd    dword ptr es:[edi], dword ptr [esi]
43356439 movsd    dword ptr es:[edi], dword ptr [esi]
4335643a movsd    dword ptr es:[edi], dword ptr [esi]
4335643b mov      esi, ecx
4335643d lea      edi, [esp + 0x134]
43356444 lea      ecx, [eax + 0x150]
4335644a mov      dword ptr [esp + 0x24], ecx
4335644e movsd    dword ptr es:[edi], dword ptr [esi]
4335644f movsd    dword ptr es:[edi], dword ptr [esi]
43356450 movsd    dword ptr es:[edi], dword ptr [esi]
43356451 mov      esi, ecx
43356453 lea      edi, [esp + 0x140]
4335645a mov      ecx, dword ptr [eax + 0x7c]
4335645d mov      dword ptr [esp + 0x60], ecx
43356461 movsd    dword ptr es:[edi], dword ptr [esi]
43356462 movsd    dword ptr es:[edi], dword ptr [esi]
43356463 movsd    dword ptr es:[edi], dword ptr [esi]
43356464 mov      dword ptr [esp + 0x150], ecx
4335646b mov      ecx, dword ptr [eax]
4335646d mov      dword ptr [esp + 0xdc], ecx
43356474 mov      ecx, dword ptr [eax + 0xc]
43356477 movss    dword ptr [esp + 0x14c], xmm0
43356480 call     0x433f0c03
43356485 mov      edi, dword ptr [esp + 0x14]
43356489 lea      ecx, [esp + 0xa08]
43356490 xor      eax, eax
43356492 mulss    xmm0, xmm0
43356496 mov      dword ptr [esp + 0x70], eax
4335649a mov      eax, dword ptr [edi + 0xc8]
433564a0 lea      esi, [edi + 0x150]
433564a6 inc      eax
433564a7 movss    dword ptr [esp + 0x40], xmm0
433564ad push     eax
433564ae push     dword ptr [edi + 0x7c]
433564b1 sub      esp, 0xc
433564b4 mov      edi, esp
433564b6 sub      esp, 0xc
433564b9 movsd    dword ptr es:[edi], dword ptr [esi]
433564ba movsd    dword ptr es:[edi], dword ptr [esi]
433564bb movsd    dword ptr es:[edi], dword ptr [esi]
433564bc mov      esi, dword ptr [esp + 0x108]
433564c3 mov      edi, esp
433564c5 push     dword ptr [esp + 0x7c]
433564c9 movsd    dword ptr es:[edi], dword ptr [esi]
433564ca movsd    dword ptr es:[edi], dword ptr [esi]
433564cb movsd    dword ptr es:[edi], dword ptr [esi]
433564cc call     0x433b0d5c
433564d1 mov      esi, dword ptr [esp + 0x14]
433564d5 xor      eax, eax
433564d7 movss    xmm0, dword ptr [esp + 0xa1c]
433564e0 movss    xmm1, dword ptr [esp + 0xa18]
433564e9 mulss    xmm0, xmm0
433564ed mulss    xmm1, xmm1
433564f1 addss    xmm1, xmm0
433564f5 movss    xmm0, dword ptr [esp + 0x40]
433564fb comiss   xmm0, xmm1
433564fe jae      0x43356553
43356500 push     0x19
43356502 pop      ecx
43356503 add      esi, 0x14
43356506 lea      eax, [esp + 0xa08]
4335650d lea      edi, [esp + 0xda8]
43356514 rep movsd dword ptr es:[edi], dword ptr [esi]
43356516 mov      edi, dword ptr [esp + 0x5c]
4335651a mov      edx, edi
4335651c mov      esi, dword ptr [esp + 0x14]
43356520 mov      ecx, esi
43356522 push     eax
43356523 lea      eax, [esp + 0xdac]
4335652a push     eax
4335652b call     0x433ce0fe
43356530 lea      eax, [esp + 0xda8]
43356537 push     eax
43356538 push     edi
43356539 lea      ecx, [esp + 0xa10]
43356540 call     0x433d7606
43356545 mov      eax, dword ptr [esp + 0x70]
43356549 inc      eax
4335654a mov      dword ptr [esp + 0x70], eax
4335654e cmp      eax, 0xe
43356551 jl       0x433564d7
43356553 test     eax, eax
43356555 jne      0x43356561
43356557 and      dword ptr [esp + 0x70], 0
4335655c jmp      0x43356672
43356561 movss    xmm3, dword ptr [esp + 0xa0c]
4335656a lea      eax, [esi + 0x10c]
43356570 movss    xmm4, dword ptr [esp + 0xa10]
43356579 movaps   xmm1, xmm3
4335657c subss    xmm1, dword ptr [eax]
43356580 movss    xmm0, dword ptr [esp + 0xa14]
43356589 movaps   xmm2, xmm4
4335658c subss    xmm2, dword ptr [eax + 4]
43356591 subss    xmm0, dword ptr [eax + 8]
43356596 mulss    xmm1, xmm1
4335659a mulss    xmm2, xmm2
4335659e mulss    xmm0, xmm0
433565a2 addss    xmm2, xmm1
433565a6 addss    xmm2, xmm0
433565aa movss    xmm0, dword ptr [esp + 0x1b4]
433565b3 comiss   xmm0, xmm2
433565b6 ja       0x43356557
433565b8 movss    xmm0, dword ptr [esp + 0xa38]
433565c1 xor      edx, edx
433565c3 addss    xmm0, dword ptr [esp + 0xa14]
433565cc mov      ecx, dword ptr [esp + 0xa24]
433565d3 inc      edx
433565d4 movss    xmm1, dword ptr [esp + 0xa34]
433565dd mov      al, cl
433565df mov      edi, dword ptr [esp + 0xac]
433565e6 and      al, dl
433565e8 mov      edx, dword ptr [esp + 0xa28]
433565ef movss    dword ptr [esp + 0x3e0], xmm0
433565f8 movss    dword ptr [esp + 0x3d8], xmm3
43356601 movss    dword ptr [esp + 0x3dc], xmm4
4335660a mov      dword ptr [esi + 0xc8], edx
43356610 lea      esi, [esp + 0x3d8]
43356617 movsd    dword ptr es:[edi], dword ptr [esi]
43356618 movd     xmm0, edx
4335661c cvtdq2ps xmm0, xmm0
4335661f movsd    dword ptr es:[edi], dword ptr [esi]
43356620 movsd    dword ptr es:[edi], dword ptr [esi]
43356621 mov      edi, dword ptr [esp + 0xe8]
43356628 lea      esi, [esp + 0xa0c]
4335662f movsd    dword ptr es:[edi], dword ptr [esi]
43356630 movsd    dword ptr es:[edi], dword ptr [esi]
43356631 movsd    dword ptr es:[edi], dword ptr [esi]
43356632 mov      edi, dword ptr [esp + 0x24]
43356636 lea      esi, [esp + 0xa18]
4335663d movsd    dword ptr es:[edi], dword ptr [esi]
4335663e movsd    dword ptr es:[edi], dword ptr [esi]
4335663f movsd    dword ptr es:[edi], dword ptr [esi]
43356640 mov      esi, dword ptr [esp + 0x14]
43356644 movss    dword ptr [esi + 0x98], xmm1
4335664c mov      dword ptr [esi + 0x7c], ecx
4335664f movzx    ecx, al
43356652 mov      eax, dword ptr [esi]
43356654 and      eax, 0xfffbffff
43356659 shl      ecx, 0x12
4335665c or       ecx, eax
4335665e mov      eax, dword ptr [0x4346a338]
43356663 mov      dword ptr [esi], ecx
43356665 mulss    xmm0, dword ptr [eax]
43356669 mov      eax, dword ptr [0x43467eb8]
4335666e movss    dword ptr [eax], xmm0
43356672 mov      edi, dword ptr [esp + 0x98]
43356679 cmp      byte ptr [edi + 0xde], 0
43356680 mov      edi, dword ptr [esp + 0x1c]
43356684 je       0x43356dcb
4335668a test     dword ptr [esi], 0x400
43356690 je       0x43356dcb
43356696 push     3
43356698 pop      eax
43356699 test     byte ptr [edi + 0x170], al
4335669f jne      0x43356dcb
433566a5 test     byte ptr [0x434759c0], 8
433566ac jne      0x43356dcb
433566b2 mov      ecx, dword ptr [esp + 0x64]
433566b6 add      ecx, 8
433566b9 mov      eax, dword ptr [ecx]
433566bb call     dword ptr [eax + 0x28]
433566be test     eax, eax
433566c0 jne      0x433566ce
433566c2 sub      eax, 0xf4cb538d
433566c7 cld      
433566c8 fcmovnbe st(0), st(2)
433566ca inc      esi
433566cb push     esp
433566cc movsb    byte ptr es:[edi], byte ptr [esi]
433566cd ror      byte ptr [ebx + 0x2356e8c8], 6
433566ce mov      ecx, eax
433566d0 call     0x433b8a2b
433566d4 add      byte ptr [ebx - 0x27467c38], cl
433566d5 mov      ecx, eax
433566d7 cmp      dword ptr [ecx + 0x5d8], 0
433566da add      eax, 0xf000000
433566de je       0x43356dcb
433566df test     bh, ah
433566e1 push     es
433566e2 add      byte ptr [eax], al
433566e4 test     dword ptr [esi], 0x8000000
433566ea jne      0x43356dcb
433566f0 cmp      dword ptr [esi + 0xd8], 0x40
433566f7 jne      0x43356708
433566f9 xor      eax, eax
433566fb inc      eax
433566fc test     byte ptr [edi + 0x174], al
43356702 je       0x43356dcb
43356708 test     dword ptr [esi], 0x102000
4335670e jne      0x43356dcb
43356714 test     dword ptr [esi], 0x40000
4335671a je       0x43356dcb
43356720 test     dword ptr [esi], 0x4000
43356726 jne      0x43356dcb
4335672c movss    xmm0, dword ptr [0x4346eeb0]
43356734 comiss   xmm0, dword ptr [esi + 0xc0]
4335673b jbe      0x4335674a
4335673d test     dword ptr [esi + 0x44], 0x618
43356744 je       0x43356dcb
4335674a and      dword ptr [esp + 0x44c], 0
43356752 mov      eax, 0x600400b
43356757 and      dword ptr [esp + 0x450], 0
4335675f and      dword ptr [esp + 0x454], 0
43356767 and      dword ptr [esp + 0x458], 0
4335676f and      dword ptr [esp + 0x45c], 0
43356777 and      dword ptr [esp + 0x32b0], 0
4335677f push     0x10a0
43356784 mov      dword ptr [esp + 0x464], eax
4335678b mov      dword ptr [esp + 0x468], eax
43356792 push     0x1f
43356794 mov      dword ptr [esp + 0x450], 0x43470404
4335679f mov      dword ptr [esp + 0x470], 0x3f800000
433567aa mov      eax, dword ptr [ecx + 0x5d4]
433567b0 pop      edx
433567b1 and      eax, edx
433567b3 push     dword ptr [ecx + eax*4 + 0x5dc]
433567ba lea      eax, [esp + 0x32b8]
433567c1 push     eax
433567c2 call     0x774fd4a0
433567c7 mov      edx, dword ptr [esp + 0x70]
433567cb lea      eax, [esp + 0x32bc]
433567d2 add      esp, 0xc
433567d5 mov      ecx, esi
433567d7 push     eax
433567d8 call     0x43327659
433567dd xor      eax, eax
433567df lea      ecx, [esp + 0xce8]
433567e6 inc      eax
433567e7 push     eax
433567e8 push     dword ptr [esi + 0xc]
433567eb call     0x433eb28b
433567f0 movss    xmm0, dword ptr [esp + 0x32e0]
433567f9 lea      esi, [esp + 0x1cc]
43356800 mov      eax, dword ptr [0x43475808]
43356805 lea      edi, [esp + 0x648]
4335680c movss    dword ptr [esp + 0x1cc], xmm0
43356815 lea      ecx, [esp + 0xce8]
4335681c movss    xmm0, dword ptr [esp + 0x32e4]
43356825 mov      edx, dword ptr [esp + 0xac]
4335682c movss    dword ptr [esp + 0x1d0], xmm0
43356835 movss    xmm0, dword ptr [esp + 0x32c8]
4335683e mulss    xmm0, dword ptr [esp + 0x90]
43356847 push     ecx
43356848 lea      ecx, [esp + 0x44c]
4335684f mov      dword ptr [esp + 0x3c], eax
43356853 push     ecx
43356854 addss    xmm0, dword ptr [esp + 0x32f0]
4335685d lea      ecx, [esp + 0x650]
43356864 push     ecx
43356865 mov      ecx, eax
43356867 movss    dword ptr [esp + 0x1e0], xmm0
43356870 movsd    dword ptr es:[edi], dword ptr [esi]
43356871 movsd    dword ptr es:[edi], dword ptr [esi]
43356872 movsd    dword ptr es:[edi], dword ptr [esi]
43356873 call     0x43329d2b
43356878 cmp      dword ptr [esp + 0xd68], 0
43356880 je       0x43356dc3
43356886 mov      edi, dword ptr [esp + 0x64]
4335688a mov      edx, edi
4335688c mov      dword ptr [esp + 0x40], 0x6d2cfbd5
43356894 mov      eax, dword ptr [esp + 0x40]
43356898 inc      eax
43356899 mov      ecx, dword ptr [edi]
4335689b xor      eax, 0x4a674016
433568a0 mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
433568a7 mov      dword ptr [esp + 0x568], ecx
433568ae call     0x433e533f
433568b3 push     3
433568b5 mov      esi, eax
433568b7 lea      ecx, [esp + 0xcec]
433568be pop      eax
433568bf push     eax
433568c0 push     edi
433568c1 mov      dword ptr [esp + 0x114], esi
433568c8 call     0x433e9ecd
433568cd mov      ecx, eax
433568cf mov      dword ptr [esp + 0x118], ecx
433568d6 test     ecx, ecx
433568d8 jle      0x433568f8
433568da lea      eax, [esi - 1]
433568dd add      eax, ecx
433568df cdq      
433568e0 idiv     ecx
433568e2 xor      edx, edx
433568e4 inc      edx
433568e5 cmp      eax, edx
433568e7 mov      ecx, edx
433568e9 cmovg    ecx, eax
433568ec mov      dword ptr [esp + 0x6c], ecx
433568f0 cmp      ecx, edx
433568f2 jle      0x43356dc3
433568f8 mov      edi, dword ptr [esp + 0x14]
433568fc lea      eax, [esp + 0x1f0]
43356903 push     0
43356905 push     eax
43356906 lea      edx, [esp + 0x1ec]
4335690d lea      ecx, [edi + 0x118]
43356913 call     0x43366128
43356918 movss    xmm1, dword ptr [esp + 0x1e4]
43356921 movss    xmm0, dword ptr [esp + 0x1e8]
4335692a movss    xmm5, dword ptr [esp + 0x2c]
43356930 mulss    xmm0, xmm0
43356934 mov      eax, dword ptr [esp + 0x28]
43356938 mulss    xmm1, xmm1
4335693c mov      ecx, dword ptr [esp + 0x38]
43356940 addss    xmm1, xmm0
43356944 movaps   xmm0, xmm5
43356947 mulss    xmm0, xmm5
4335694b addss    xmm1, xmm0
4335694f movaps   xmm0, xmm1
43356952 movss    xmm1, dword ptr [esp + 0x68]
43356958 sqrtss   xmm0, xmm0
4335695c movss    dword ptr [esp + 0x56c], xmm0
43356965 addss    xmm0, dword ptr [esp + 0x94]
4335696e divss    xmm1, xmm0
43356972 movss    xmm0, dword ptr [esp + 0x1f4]
4335697b movaps   xmm2, xmm1
4335697e mulss    xmm0, xmm0
43356982 movaps   xmm3, xmm1
43356985 mulss    xmm2, dword ptr [esp + 0x1e4]
4335698e mulss    xmm1, xmm5
43356992 mulss    xmm3, dword ptr [esp + 0x1e8]
4335699b movss    dword ptr [esp + 0x1ec], xmm1
433569a4 movss    xmm1, dword ptr [esp + 0x1f0]
433569ad mulss    xmm1, xmm1
433569b1 movss    dword ptr [esp + 0x1e4], xmm2
433569ba movss    dword ptr [esp + 0x1e8], xmm3
433569c3 addss    xmm1, xmm0
433569c7 movaps   xmm0, xmm5
433569ca mulss    xmm0, xmm5
433569ce addss    xmm1, xmm0
433569d2 movaps   xmm0, xmm1
433569d5 movss    xmm1, dword ptr [esp + 0x68]
433569db sqrtss   xmm0, xmm0
433569df movss    dword ptr [esp + 0x570], xmm0
433569e8 addss    xmm0, dword ptr [esp + 0x94]
433569f1 divss    xmm1, xmm0
433569f5 movaps   xmm4, xmm1
433569f8 movaps   xmm0, xmm1
433569fb mulss    xmm4, dword ptr [esp + 0x1f0]
43356a04 mulss    xmm0, dword ptr [esp + 0x1f4]
43356a0d mulss    xmm1, xmm5
43356a11 movss    dword ptr [esp + 0x1f0], xmm4
43356a1a movss    dword ptr [esp + 0x1f4], xmm0
43356a23 movss    dword ptr [esp + 0x1f8], xmm1
43356a2c mulss    xmm4, dword ptr [eax + 0x28]
43356a31 mulss    xmm2, dword ptr [eax + 0x24]
43356a36 mulss    xmm0, dword ptr [eax + 0x28]
43356a3b mulss    xmm3, dword ptr [eax + 0x24]
43356a40 addss    xmm4, xmm2
43356a44 addss    xmm0, xmm3
43356a48 movss    dword ptr [esp + 0xa0], xmm4
43356a51 movss    dword ptr [esp + 0x114], xmm0
43356a5a call     0x4336961e
43356a5f movss    xmm2, dword ptr [esp + 0xa0]
43356a68 movaps   xmm3, xmm0
43356a6b movss    xmm1, dword ptr [esp + 0x114]
43356a74 mulss    xmm2, xmm2
43356a78 mov      edx, dword ptr [edi + 0xc]
43356a7b mulss    xmm1, xmm1
43356a7f addss    xmm2, xmm1
43356a83 movss    xmm1, dword ptr [esp + 0x2c]
43356a89 mulss    xmm1, xmm1
43356a8d addss    xmm2, xmm1
43356a91 movaps   xmm0, xmm2
43356a94 sqrtss   xmm0, xmm0
43356a98 movss    dword ptr [esp + 0x574], xmm0
43356aa1 addss    xmm0, dword ptr [esp + 0x94]
43356aaa mov      dword ptr [esp + 0x40], 0xe3852753
43356ab2 mov      eax, dword ptr [esp + 0x40]
43356ab6 divss    xmm3, xmm0
43356aba movss    dword ptr [esp + 0xc8], xmm3
43356ac3 mov      ecx, dword ptr [edx]
43356ac5 add      eax, 0x1c7af3bd
43356aca ror      eax, 2
43356acd push     0
43356acf mov      ecx, dword ptr [eax + ecx]
43356ad2 mov      dword ptr [esp + 0x57c], ecx
43356ad9 call     0x433e533f
43356ade movss    xmm3, dword ptr [esp + 0xc8]
43356ae7 lea      edx, [edi + 0xdc]
43356aed fmul     dword ptr [esp + 0xd0]
43356af4 xor      ecx, ecx
43356af6 movss    xmm0, dword ptr [edx]
43356afa movss    xmm4, dword ptr [esp + 0xa0]
43356b03 movss    xmm1, dword ptr [edx + 4]
43356b08 movss    xmm2, dword ptr [edx + 8]
43356b0d mulss    xmm4, xmm3
43356b11 or       dword ptr [esp + 0x9e4], 0xffffffff
43356b19 or       dword ptr [esp + 0x9f0], 0xffffffff
43356b21 fstp     dword ptr [esp + 0xd0]
43356b28 mulss    xmm4, dword ptr [esp + 0xd0]
43356b31 mov      dword ptr [esp + 0x9cc], 0x3f800000
43356b3c mov      word ptr [esp + 0x9d6], cx
43356b44 mov      dword ptr [esp + 0x9ec], ecx
43356b4b addss    xmm4, xmm0
43356b4f mov      dword ptr [esp + 0x800], ecx
43356b56 movss    xmm0, dword ptr [esp + 0x114]
43356b5f mulss    xmm0, xmm3
43356b63 subss    xmm4, dword ptr [edx]
43356b67 mulss    xmm0, dword ptr [esp + 0xd0]
43356b70 addss    xmm0, xmm1
43356b74 movss    dword ptr [esp + 0x7d0], xmm4
43356b7d movss    xmm1, dword ptr [esp + 0x2c]
43356b83 mulss    xmm3, xmm1
43356b87 mulss    xmm4, xmm4
43356b8b mulss    xmm3, dword ptr [esp + 0xd0]
43356b94 subss    xmm0, dword ptr [edx + 4]
43356b99 addss    xmm3, xmm2
43356b9d movss    dword ptr [esp + 0x7d4], xmm0
43356ba6 mulss    xmm0, xmm0
43356baa subss    xmm3, dword ptr [edx + 8]
43356baf addss    xmm4, xmm0
43356bb3 movss    dword ptr [esp + 0x7d8], xmm3
43356bbc mulss    xmm3, xmm3
43356bc0 addss    xmm4, xmm3
43356bc4 ucomiss  xmm4, xmm1
43356bc7 lahf     
43356bc8 test     ah, 0x44
43356bcb jnp      0x43356bd9
43356bcd xor      eax, eax
43356bcf inc      eax
43356bd0 mov      byte ptr [esp + 0x805], al
43356bd7 jmp      0x43356be0
43356bd9 mov      byte ptr [esp + 0x805], cl
43356be0 and      dword ptr [esp + 0x7f0], ecx
43356be7 lea      eax, [esp + 0x9a0]
43356bee and      dword ptr [esp + 0x7f4], ecx
43356bf5 mov      byte ptr [esp + 0x804], cl
43356bfc lea      ecx, [esp + 0x7c0]
43356c03 mov      dword ptr [esp + 0x7f8], 0x40000000
43356c0e movss    xmm0, dword ptr [edx]
43356c12 subss    xmm0, dword ptr [0x4346f1f0]
43356c1a push     eax
43356c1b xor      eax, eax
43356c1d movss    dword ptr [esp + 0x7c4], xmm0
43356c26 movss    xmm0, dword ptr [edx + 4]
43356c2b subss    xmm0, dword ptr [0x4346f1f0]
43356c33 movss    dword ptr [esp + 0x7c8], xmm0
43356c3c movss    xmm0, dword ptr [edx + 8]
43356c41 lea      edx, [eax + 1]
43356c44 addss    xmm0, xmm1
43356c48 mov      dword ptr [esp + 0x7e4], 0x41800000
43356c53 mov      dword ptr [esp + 0x7e8], 0x41800000
43356c5e mov      dword ptr [esp + 0x7ec], 0x80000000
43356c69 movss    dword ptr [esp + 0x7cc], xmm0
43356c72 call     0x433f545e
43356c77 mov      ecx, dword ptr [esp + 0x38]
43356c7b lea      esi, [esp + 0x9ac]
43356c82 lea      edi, [esp + 0x884]
43356c89 movsd    dword ptr es:[edi], dword ptr [esi]
43356c8a lea      eax, [esp + 0xce8]
43356c91 push     eax
43356c92 lea      eax, [esp + 0x44c]
43356c99 push     eax
43356c9a movsd    dword ptr es:[edi], dword ptr [esi]
43356c9b lea      eax, [esp + 0x650]
43356ca2 push     eax
43356ca3 lea      edx, [esp + 0x890]
43356caa movsd    dword ptr es:[edi], dword ptr [esi]
43356cab call     0x43329d2b
43356cb0 test     eax, eax
43356cb2 je       0x43356dc3
43356cb8 push     3
43356cba pop      eax
43356cbb push     eax
43356cbc push     dword ptr [esp + 0x68]
43356cc0 lea      ecx, [esp + 0xcf0]
43356cc7 call     0x433e9ecd
43356ccc mov      esi, dword ptr [esp + 0x14]
43356cd0 mov      ecx, eax
43356cd2 mov      dword ptr [esp + 0xa0], ecx
43356cd9 test     ecx, ecx
43356cdb jle      0x43356dc7
43356ce1 mov      edi, dword ptr [esp + 0x10c]
43356ce8 lea      eax, [edi - 1]
43356ceb add      eax, ecx
43356ced cdq      
43356cee idiv     ecx
43356cf0 xor      edx, edx
43356cf2 inc      edx
43356cf3 cmp      eax, edx
43356cf5 mov      ecx, edx
43356cf7 cmovg    ecx, eax
43356cfa cmp      dword ptr [esp + 0x6c], ecx
43356cfe jle      0x43356dc7
43356d04 push     2
43356d06 pop      eax
43356d07 cmp      ecx, eax
43356d09 jl       0x43356d23
43356d0b test     dword ptr [0x434759c0], 0x8000
43356d15 je       0x43356d23
43356d17 cmp      dword ptr [esi + 0x1d4], edx
43356d1d je       0x43356dc7
43356d23 mov      eax, edi
43356d25 cdq      
43356d26 idiv     ecx
43356d28 test     edx, edx
43356d2a je       0x43356d34
43356d2c mov      eax, ecx
43356d2e sub      eax, edx
43356d30 add      eax, edi
43356d32 jmp      0x43356d36
43356d34 mov      eax, edi
43356d36 cdq      
43356d37 idiv     ecx
43356d39 cmp      eax, dword ptr [esp + 0xa0]
43356d40 cmovg    eax, dword ptr [esp + 0xa0]
43356d48 xor      ecx, ecx
43356d4a inc      ecx
43356d4b mov      dword ptr [esp + 0xc8], eax
43356d52 cmp      dword ptr [esi + 0x1d4], ecx
43356d58 jne      0x43356dac
43356d5a mov      edx, dword ptr [esi + 0xc]
43356d5d mov      dword ptr [esp + 0x40], 0x289d6d91
43356d65 mov      eax, dword ptr [esp + 0x40]
43356d69 mov      ecx, dword ptr [edx]
43356d6b sub      ecx, eax
43356d6d mov      ecx, dword ptr [ecx + 0x289d7449]
43356d73 mov      dword ptr [esp + 0x57c], ecx
43356d7a call     0x433e533f
43356d7f test     al, al
43356d81 je       0x43356da5
43356d83 mov      eax, dword ptr [esp + 0x118]
43356d8a mov      ecx, dword ptr [esp + 0xa0]
43356d91 add      eax, ecx
43356d93 cmp      eax, edi
43356d95 jg       0x43356dc7
43356d97 sub      edi, ecx
43356d99 xor      ecx, ecx
43356d9b inc      ecx
43356d9c cmp      edi, ecx
43356d9e mov      eax, ecx
43356da0 cmovg    eax, edi
43356da3 jmp      0x43356dac
43356da5 mov      eax, dword ptr [esp + 0xc8]
43356dac mov      edi, dword ptr [esp + 0x98]
43356db3 cmp      eax, dword ptr [edi + 0xd0]
43356db9 jle      0x43356dc7
43356dbb mov      dword ptr [edi + 0xd0], eax
43356dc1 jmp      0x43356dc7
43356dc3 mov      esi, dword ptr [esp + 0x14]
43356dc7 mov      edi, dword ptr [esp + 0x1c]
43356dcb and      dword ptr [esp + 0x220], 0
43356dd3 lea      eax, [esp + 0x220]
43356dda push     0
43356ddc push     eax
43356ddd push     dword ptr [esp + 0xa0]
43356de4 lea      ecx, [edi - 8]
43356de7 push     0
43356de9 push     dword ptr [esp + 0x180]
43356df0 push     dword ptr [esp + 0x78]
43356df4 push     dword ptr [esp + 0x40]
43356df8 push     esi
43356df9 call     0x4335cd37
43356dfe cmp      dword ptr [esp + 0x220], 0
43356e06 je       0x43356e49
43356e08 lea      eax, [esp + 0x2e4]
43356e0f mov      dword ptr [esp + 0x2e4], 0x3f800000
43356e1a push     eax
43356e1b push     dword ptr [esp + 0x9c]
43356e22 lea      ecx, [edi - 8]
43356e25 push     esi
43356e26 call     0x4341b4c2
43356e2b test     al, al
43356e2d je       0x43356e49
43356e2f or       dword ptr [edi + 0x170], 0x100
43356e39 or       dword ptr [esi], 0x10000
43356e3f or       dword ptr [edi + 0x170], 0x80
43356e49 and      dword ptr [edi + 0x170], 0xfffffff7
43356e50 cmp      dword ptr [esp + 0x70], 0
43356e55 je       0x43356eea
43356e5b mov      ecx, dword ptr [esp + 0x124]
43356e62 mov      edi, dword ptr [esp + 0xac]
43356e69 mov      dword ptr [esi + 0xc8], ecx
43356e6f lea      esi, [esp + 0x128]
43356e76 movss    xmm0, dword ptr [esp + 0x7c]
43356e7c mov      eax, dword ptr [esp + 0x60]
43356e80 movsd    dword ptr es:[edi], dword ptr [esi]
43356e81 movsd    dword ptr es:[edi], dword ptr [esi]
43356e82 movsd    dword ptr es:[edi], dword ptr [esi]
43356e83 mov      edi, dword ptr [esp + 0xe8]
43356e8a lea      esi, [esp + 0x134]
43356e91 movsd    dword ptr es:[edi], dword ptr [esi]
43356e92 movsd    dword ptr es:[edi], dword ptr [esi]
43356e93 movsd    dword ptr es:[edi], dword ptr [esi]
43356e94 mov      edi, dword ptr [esp + 0x24]
43356e98 lea      esi, [esp + 0x140]
43356e9f movsd    dword ptr es:[edi], dword ptr [esi]
43356ea0 movsd    dword ptr es:[edi], dword ptr [esi]
43356ea1 movsd    dword ptr es:[edi], dword ptr [esi]
43356ea2 mov      esi, dword ptr [esp + 0x14]
43356ea6 mov      edi, dword ptr [esp + 0x1c]
43356eaa movss    dword ptr [esi + 0x98], xmm0
43356eb2 mov      dword ptr [esi + 0x7c], eax
43356eb5 mov      eax, dword ptr [esi]
43356eb7 xor      eax, dword ptr [esp + 0xdc]
43356ebe and      eax, 0x40000
43356ec3 movd     xmm0, ecx
43356ec7 xor      dword ptr [esi], eax
43356ec9 mov      eax, dword ptr [0x4346a338]
43356ece cvtdq2ps xmm0, xmm0
43356ed1 mulss    xmm0, dword ptr [eax]
43356ed5 mov      eax, dword ptr [0x43467eb8]
43356eda movss    dword ptr [eax], xmm0
43356ede jmp      0x43356eea
43356ee0 mov      esi, dword ptr [esp + 0x14]
43356ee4 jmp      0x43356eed
43356ee6 mov      esi, dword ptr [esp + 0x14]
43356eea xor      eax, eax
43356eec inc      eax
43356eed cmp      byte ptr [0x434693d4], 0
43356ef4 je       0x43357002
43356efa test     dword ptr [esi], 0x4000
43356f00 jne      0x43357002
43356f06 test     dword ptr [edi + 0x170], 0x100
43356f10 je       0x43357002
43356f16 test     dword ptr [esi], 0x40000
43356f1c je       0x43356f26
43356f1e test     byte ptr [esi + 0xf8], al
43356f24 jne      0x43356f6d
43356f26 cmp      dword ptr [esi + 0xd8], 0x28
43356f2d jne      0x43357002
43356f33 test     dword ptr [esi + 0x44], 0x618
43356f3a jne      0x43357002
43356f40 movss    xmm0, dword ptr [esi + 0x154]
43356f48 movss    xmm1, dword ptr [esi + 0x150]
43356f50 mulss    xmm0, xmm0
43356f54 mulss    xmm1, xmm1
43356f58 addss    xmm1, xmm0
43356f5c movss    xmm0, dword ptr [0x4346fd98]
43356f64 comiss   xmm0, xmm1
43356f67 jbe      0x43357002
43356f6d mov      edx, dword ptr [esi + 0xc]
43356f70 mov      dword ptr [esp + 0x40], 0x734b1df2
43356f78 mov      eax, dword ptr [esp + 0x40]
43356f7c rol      eax, 0x11
43356f7f mov      ecx, dword ptr [edx]
43356f81 mov      ecx, dword ptr [eax + ecx - 0x3be4dfaa]
43356f88 mov      dword ptr [esp + 0x580], ecx
43356f8f call     0x433e533f
43356f94 test     eax, eax
43356f96 jle      0x43357002
43356f98 mov      ecx, dword ptr [esp + 0x5c]
43356f9c test     ecx, ecx
43356f9e jne      0x43356fac
43356fa0 cmc      
43356fa1 sub      esp, dword ptr [edx]
43356fa3 and      byte ptr [0xda25aa5b], dh
43356fa9 sahf     
43356faa xchg     esp, eax
43356fab pushfd   
43356fac mov      eax, dword ptr [0x43468da4]
43356fb1 mov      eax, dword ptr [eax]
43356fb3 xor      eax, dword ptr [0x434684ec]
43356fb9 xor      eax, 0xcacaeecc
43356fbe cmp      byte ptr [eax + ecx], 0
43356fc2 jne      0x43357002
43356fc4 test     ecx, ecx
43356fc6 jne      0x43356fd4
43356fc8 add      bh, byte ptr [eax - 0x7b941273]
43356fce fsubr    dword ptr [eax + 0x2ec91a84]
43356fd4 mov      eax, dword ptr [0x43467a90]
43356fd9 mov      eax, dword ptr [eax]
43356fdb xor      eax, dword ptr [0x434671fc]
43356fe1 xor      eax, 0xc07d1150
43356fe6 cmp      byte ptr [eax + ecx], 0
43356fea jne      0x43357002
43356fec mov      ecx, dword ptr [esp + 0x28]
43356ff0 xor      edx, edx
43356ff2 inc      edx
43356ff3 mov      eax, dword ptr [ecx + 0x30]
43356ff6 test     dl, al
43356ff8 jne      0x43357002
43356ffa or       eax, 0x800
43356fff mov      dword ptr [ecx + 0x30], eax
43357002 test     byte ptr [edi + 0x170], 0x80
43357009 je       0x43357320
4335700f cmp      byte ptr [0x434671e0], 0
43357016 je       0x43357320
4335701c mov      eax, dword ptr [0x4346932c]
43357021 mov      ecx, 0x43469318
43357026 mov      eax, dword ptr [eax*4 + 0x434721c4]
4335702d call     eax
4335702f test     al, al
43357031 je       0x43357320
43357037 push     2
43357039 pop      ecx
4335703a cmp      byte ptr [esi + 0x104], cl
43357040 jne      0x43357320
43357046 mov      eax, dword ptr [0x43467e40]
4335704b xor      ecx, ecx
4335704d inc      ecx
4335704e mov      dword ptr [esp + 0x6c], eax
43357052 cmp      dword ptr [esi + 0x1d4], ecx
43357058 jne      0x43357064
4335705a or       eax, dword ptr [0x4346a674]
43357060 mov      dword ptr [esp + 0x6c], eax
43357064 push     0x1f
43357066 pop      ecx
43357067 cmp      dword ptr [esi + 0xd8], ecx
4335706d jne      0x43357077
4335706f test     al, 0x40
43357071 je       0x43357320
43357077 test     al, 8
43357079 je       0x43357113
4335707f test     dword ptr [esi], 0x400
43357085 jne      0x43357113
4335708b mov      edx, dword ptr [esi + 0xc]
4335708e test     edx, edx
43357090 je       0x433570ce
43357092 mov      dword ptr [esp + 0x40], 0xe3852753
4335709a mov      eax, dword ptr [esp + 0x40]
4335709e mov      ecx, dword ptr [edx]
433570a0 add      eax, 0x1c7af3bd
433570a5 ror      eax, 2
433570a8 push     0
433570aa mov      ecx, dword ptr [eax + ecx]
433570ad mov      dword ptr [esp + 0x588], ecx
433570b4 call     0x433e533f
433570b9 fstp     dword ptr [esp + 0x40]
433570bd movss    xmm0, dword ptr [esp + 0x40]
433570c3 comiss   xmm0, dword ptr [esp + 0x68]
433570c8 ja       0x43357320
433570ce mov      ecx, dword ptr [esp + 0x5c]
433570d2 test     ecx, ecx
433570d4 jne      0x433570e2
433570d6 cmp      eax, 0xa7c4007a
433570db stc      
433570dc lodsb    al, byte ptr [esi]
433570dd mov      ebp, 0x2100ded8
433570e2 mov      eax, dword ptr [0x4346a80c]
433570e7 mov      eax, dword ptr [eax]
433570e9 xor      eax, dword ptr [0x43469208]
433570ef xor      eax, 0xde530a8b
433570f4 movss    xmm0, dword ptr [eax + ecx]
433570f9 mov      eax, dword ptr [0x43467eb8]
433570fe subss    xmm0, dword ptr [eax]
43357102 comiss   xmm0, dword ptr [0x43470228]
43357109 ja       0x43357320
4335710f mov      eax, dword ptr [esp + 0x6c]
43357113 or       dword ptr [0x434759c0], 8
4335711a cmp      dword ptr [esp + 0xe0], 0
43357122 je       0x43357320
43357128 push     2
4335712a pop      ecx
4335712b test     cl, al
4335712d je       0x4335727b
43357133 movss    xmm2, dword ptr [esi + 0x114]
4335713b lea      ecx, [esp + 0xed0]
43357142 addss    xmm2, dword ptr [0x4346fd94]
4335714a movss    xmm1, dword ptr [esi + 0x110]
43357152 movss    xmm0, dword ptr [esi + 0x10c]
4335715a movzx    eax, byte ptr [0x4346a3e0]
43357161 push     eax
43357162 movss    dword ptr [esp + 0x388], xmm0
4335716b movss    dword ptr [esp + 0x38c], xmm1
43357174 movss    dword ptr [esp + 0x390], xmm2
4335717d push     dword ptr [esi + 0xc]
43357180 call     0x433eb28b
43357185 mov      ecx, dword ptr [esp + 0xe0]
4335718c lea      edx, [esp + 0x384]
43357193 xor      eax, eax
43357195 mov      dword ptr [esp + 0x4cc], 0x43470404
433571a0 mov      dword ptr [esp + 0x4d0], eax
433571a7 mov      dword ptr [esp + 0x4d4], eax
433571ae mov      dword ptr [esp + 0x4d8], eax
433571b5 mov      dword ptr [esp + 0x4dc], eax
433571bc mov      dword ptr [esp + 0x4e0], eax
433571c3 mov      eax, 0x600400b
433571c8 mov      dword ptr [esp + 0x4e4], eax
433571cf mov      dword ptr [esp + 0x4e8], eax
433571d6 movd     xmm0, dword ptr [ecx + 0xd0]
433571de mov      eax, dword ptr [ecx + 0x30]
433571e1 and      eax, 0xf
433571e4 cvtdq2ps xmm0, xmm0
433571e7 divss    xmm0, dword ptr [eax*4 + 0x43474540]
433571f0 lea      eax, [esp + 0xed0]
433571f7 push     eax
433571f8 lea      eax, [esp + 0x4d0]
433571ff push     eax
43357200 lea      eax, [ecx + 0xc]
43357203 mov      ecx, dword ptr [esp + 0x64]
43357207 push     eax
43357208 movss    dword ptr [esp + 0x4f8], xmm0
43357211 call     0x43329d2b
43357216 cvttss2si eax, dword ptr [esp + 0xed8]
4335721f mov      dword ptr [esp + 0x40], eax
43357223 test     eax, eax
43357225 je       0x4335725f
43357227 mov      ecx, dword ptr [0x4346a890]
4335722d mov      edx, dword ptr [esp + 0xe0]
43357234 mov      eax, dword ptr [ecx]
43357236 push     dword ptr [edx + 4]
43357239 mov      eax, dword ptr [eax + 0xc]
4335723c call     eax
4335723e test     eax, eax
43357240 je       0x4335725b
43357242 mov      ecx, dword ptr [esp + 0xe0]
43357249 push     dword ptr [ecx + 0x30]
4335724c lea      ecx, [esp + 0xed4]
43357253 push     eax
43357254 call     0x433e9ecd
43357259 jmp      0x4335725f
4335725b mov      eax, dword ptr [esp + 0x40]
4335725f mov      ecx, dword ptr [esp + 0xe0]
43357266 push     2
43357268 cmp      eax, dword ptr [ecx + 0xd0]
4335726e pop      ecx
4335726f jl       0x4335727b
43357271 or       dword ptr [0x434759c0], 0x11000
4335727b test     byte ptr [edi + 0x170], 0x40
43357282 je       0x43357320
43357288 test     dword ptr [esi], 0x40000
4335728e je       0x43357320
43357294 mov      eax, dword ptr [esi + 0xb0]
4335729a mov      edx, dword ptr [esi + 0xc]
4335729d mov      dword ptr [esp + 0x6c], eax
433572a1 push     eax
433572a2 test     byte ptr [esi + 0x7c], cl
433572a5 je       0x433572cd
433572a7 mov      dword ptr [esp + 0x44], 0x1b406d4b
433572af mov      eax, dword ptr [esp + 0x44]
433572b3 mov      ecx, dword ptr [edx]
433572b5 not      eax
433572b7 add      eax, 0x63659d2f
433572bc xor      eax, 0x48252933
433572c1 mov      ecx, dword ptr [eax + ecx]
433572c4 mov      dword ptr [esp + 0x58c], ecx
433572cb jmp      0x433572ed
433572cd mov      dword ptr [esp + 0x44], 0xffffc9a8
433572d5 mov      eax, dword ptr [esp + 0x44]
433572d9 mov      ecx, dword ptr [edx]
433572db dec      eax
433572dc rol      eax, 8
433572df ror      eax, 0xb
433572e2 sub      ecx, eax
433572e4 mov      ecx, dword ptr [ecx]
433572e6 mov      dword ptr [esp + 0x590], ecx
433572ed call     0x433e533f
433572f2 movss    xmm0, dword ptr [esi + 0xc4]
433572fa movss    xmm1, dword ptr [0x434723ec]
43357302 fstp     dword ptr [esp + 0x6c]
43357306 subss    xmm0, dword ptr [esp + 0x6c]
4335730c andps    xmm0, xmmword ptr [esp + 0xb0]
43357314 comiss   xmm1, xmm0
43357317 jbe      0x43357320
43357319 or       dword ptr [0x434759c0], 0x10
43357320 test     byte ptr [0x43467e40], 0x20
43357327 je       0x433573a2
43357329 mov      cx, word ptr [esi + 0xd8]
43357330 call     0x433d24bb
43357335 test     al, al
43357337 je       0x433573a2
43357339 push     0x1f
4335733b pop      eax
4335733c cmp      dword ptr [esi + 0xd8], eax
43357342 je       0x433573a2
43357344 push     2
43357346 pop      eax
43357347 cmp      byte ptr [esi + 0x104], al
4335734d jne      0x433573a2
4335734f test     dword ptr [esi], 0x40000
43357355 je       0x433573a2
43357357 test     byte ptr [esi + 0x44], 6
4335735b jne      0x433573a2
4335735d mov      ecx, dword ptr [0x4346db1c]
43357363 cmp      ecx, -1
43357366 je       0x433573a2
43357368 mov      eax, dword ptr [0x4346a890]
4335736d push     ecx
4335736e mov      eax, dword ptr [eax]
43357370 mov      edx, dword ptr [eax + 0x10]
43357373 mov      eax, esp
43357375 mov      dword ptr [eax], ecx
43357377 mov      ecx, dword ptr [0x4346a890]
4335737d call     edx
4335737f test     eax, eax
43357381 je       0x433573a2
43357383 lea      ecx, [eax + 8]
43357386 mov      eax, dword ptr [ecx]
43357388 call     dword ptr [eax + 0x24]
4335738b test     al, al
4335738d jne      0x433573a2
4335738f call     0x433c8bd6
43357394 test     al, al
43357396 je       0x433573a2
43357398 or       dword ptr [0x434759c0], 0x100
433573a2 test     dword ptr [esi], 0x20000
433573a8 je       0x433576da
433573ae mov      eax, dword ptr [0x434759c0]
433573b3 test     al, 8
433573b5 jne      0x433576da
433573bb test     eax, 0x4000
433573c0 je       0x433576da
433573c6 xor      edx, edx
433573c8 lea      eax, [edi + 0x19c]
433573ce mov      ecx, edx
433573d0 cmp      dword ptr [eax], edx
433573d2 jne      0x433573e4
433573d4 add      ecx, 0x20
433573d7 add      eax, 4
433573da cmp      ecx, 0x40
433573dd jb       0x433573d0
433573df jmp      0x433576da
433573e4 push     2
433573e6 pop      ecx
433573e7 cmp      byte ptr [esi + 0x104], cl
433573ed jne      0x433576da
433573f3 mov      eax, dword ptr [0x43467e40]
433573f8 xor      ecx, ecx
433573fa inc      ecx
433573fb mov      dword ptr [esp + 0x6c], eax
433573ff cmp      dword ptr [esi + 0x1d4], ecx
43357405 jne      0x43357411
43357407 or       eax, dword ptr [0x4346a674]
4335740d mov      dword ptr [esp + 0x6c], eax
43357411 push     0x1f
43357413 pop      ecx
43357414 cmp      dword ptr [esi + 0xd8], ecx
4335741a jne      0x43357424
4335741c test     al, 0x40
4335741e je       0x433576da
43357424 test     al, 8
43357426 je       0x433574cd
4335742c test     dword ptr [esi], 0x400
43357432 jne      0x433574cd
43357438 mov      ecx, dword ptr [esi + 0xc]
4335743b mov      dword ptr [esp + 0xc8], ecx
43357442 test     ecx, ecx
43357444 je       0x43357488
43357446 mov      dword ptr [esp + 0x40], 0xe3852753
4335744e mov      eax, dword ptr [esp + 0x40]
43357452 mov      ecx, dword ptr [ecx]
43357454 add      eax, 0x1c7af3bd
43357459 ror      eax, 2
4335745c push     edx
4335745d mov      edx, dword ptr [esp + 0xcc]
43357464 mov      ecx, dword ptr [eax + ecx]
43357467 mov      dword ptr [esp + 0x594], ecx
4335746e call     0x433e533f
43357473 fstp     dword ptr [esp + 0x40]
43357477 movss    xmm0, dword ptr [esp + 0x40]
4335747d comiss   xmm0, dword ptr [esp + 0x68]
43357482 ja       0x433576da
43357488 mov      ecx, dword ptr [esp + 0x5c]
4335748c test     ecx, ecx
4335748e jne      0x4335749c
43357490 xor      byte ptr [edx], bl
43357492 mov      edi, 0x3eacae7d
4335749c mov      eax, dword ptr [0x4346a80c]
433574a1 mov      eax, dword ptr [eax]
433574a3 xor      eax, dword ptr [0x43469208]
433574a9 xor      eax, 0xde530a8b
433574ae movss    xmm0, dword ptr [eax + ecx]
433574b3 mov      eax, dword ptr [0x43467eb8]
433574b8 subss    xmm0, dword ptr [eax]
433574bc comiss   xmm0, dword ptr [0x43470228]
433574c3 ja       0x433576da
433574c9 mov      eax, dword ptr [esp + 0x6c]
433574cd or       dword ptr [0x434759c0], 8
433574d4 cmp      dword ptr [esp + 0xe0], 0
433574dc je       0x433576da
433574e2 push     2
433574e4 pop      ecx
433574e5 test     cl, al
433574e7 je       0x43357635
433574ed movss    xmm2, dword ptr [esi + 0x114]
433574f5 lea      ecx, [esp + 0xf90]
433574fc addss    xmm2, dword ptr [0x4346fd94]
43357504 movss    xmm1, dword ptr [esi + 0x110]
4335750c movss    xmm0, dword ptr [esi + 0x10c]
43357514 movzx    eax, byte ptr [0x4346a3e0]
4335751b push     eax
4335751c movss    dword ptr [esp + 0x394], xmm0
43357525 movss    dword ptr [esp + 0x398], xmm1
4335752e movss    dword ptr [esp + 0x39c], xmm2
43357537 push     dword ptr [esi + 0xc]
4335753a call     0x433eb28b
4335753f mov      ecx, dword ptr [esp + 0xe0]
43357546 lea      edx, [esp + 0x390]
4335754d xor      eax, eax
4335754f mov      dword ptr [esp + 0x484], 0x43470404
4335755a mov      dword ptr [esp + 0x488], eax
43357561 mov      dword ptr [esp + 0x48c], eax
43357568 mov      dword ptr [esp + 0x490], eax
4335756f mov      dword ptr [esp + 0x494], eax
43357576 mov      dword ptr [esp + 0x498], eax
4335757d mov      eax, 0x600400b
43357582 mov      dword ptr [esp + 0x49c], eax
43357589 mov      dword ptr [esp + 0x4a0], eax
43357590 movd     xmm0, dword ptr [ecx + 0xd0]
43357598 mov      eax, dword ptr [ecx + 0x30]
4335759b and      eax, 0xf
4335759e cvtdq2ps xmm0, xmm0
433575a1 divss    xmm0, dword ptr [eax*4 + 0x43474540]
433575aa lea      eax, [esp + 0xf90]
433575b1 push     eax
433575b2 lea      eax, [esp + 0x488]
433575b9 push     eax
433575ba lea      eax, [ecx + 0xc]
433575bd mov      ecx, dword ptr [esp + 0x64]
433575c1 push     eax
433575c2 movss    dword ptr [esp + 0x4b0], xmm0
433575cb call     0x43329d2b
433575d0 cvttss2si eax, dword ptr [esp + 0xf98]
433575d9 mov      dword ptr [esp + 0x40], eax
433575dd test     eax, eax
433575df je       0x43357619
433575e1 mov      ecx, dword ptr [0x4346a890]
433575e7 mov      edx, dword ptr [esp + 0xe0]
433575ee mov      eax, dword ptr [ecx]
433575f0 push     dword ptr [edx + 4]
433575f3 mov      eax, dword ptr [eax + 0xc]
433575f6 call     eax
433575f8 test     eax, eax
433575fa je       0x43357615
433575fc mov      ecx, dword ptr [esp + 0xe0]
43357603 push     dword ptr [ecx + 0x30]
43357606 lea      ecx, [esp + 0xf94]
4335760d push     eax
4335760e call     0x433e9ecd
43357613 jmp      0x43357619
43357615 mov      eax, dword ptr [esp + 0x40]
43357619 mov      ecx, dword ptr [esp + 0xe0]
43357620 push     2
43357622 cmp      eax, dword ptr [ecx + 0xd0]
43357628 pop      ecx
43357629 jl       0x43357635
4335762b or       dword ptr [0x434759c0], 0x11000
43357635 test     byte ptr [edi + 0x170], 0x40
4335763c je       0x433576da
43357642 test     dword ptr [esi], 0x40000
43357648 je       0x433576da
4335764e mov      eax, dword ptr [esi + 0xb0]
43357654 mov      edx, dword ptr [esi + 0xc]
43357657 mov      dword ptr [esp + 0x6c], eax
4335765b push     eax
4335765c test     byte ptr [esi + 0x7c], cl
4335765f je       0x43357687
43357661 mov      dword ptr [esp + 0x44], 0x1b406d4b
43357669 mov      eax, dword ptr [esp + 0x44]
4335766d mov      ecx, dword ptr [edx]
4335766f not      eax
43357671 add      eax, 0x63659d2f
43357676 xor      eax, 0x48252933
4335767b mov      ecx, dword ptr [eax + ecx]
4335767e mov      dword ptr [esp + 0x598], ecx
43357685 jmp      0x433576a7
43357687 mov      dword ptr [esp + 0x44], 0xffffc9a8
4335768f mov      eax, dword ptr [esp + 0x44]
43357693 mov      ecx, dword ptr [edx]
43357695 dec      eax
43357696 rol      eax, 8
43357699 ror      eax, 0xb
4335769c sub      ecx, eax
4335769e mov      ecx, dword ptr [ecx]
433576a0 mov      dword ptr [esp + 0x59c], ecx
433576a7 call     0x433e533f
433576ac movss    xmm0, dword ptr [esi + 0xc4]
433576b4 movss    xmm1, dword ptr [0x434723ec]
433576bc fstp     dword ptr [esp + 0x6c]
433576c0 subss    xmm0, dword ptr [esp + 0x6c]
433576c6 andps    xmm0, xmmword ptr [esp + 0xb0]
433576ce comiss   xmm1, xmm0
433576d1 jbe      0x433576da
433576d3 or       dword ptr [0x434759c0], 0x10
433576da mov      eax, dword ptr [esp + 0xd8]
433576e1 movzx    eax, al
433576e4 shl      eax, 0xa
433576e7 xor      eax, dword ptr [esi]
433576e9 and      eax, 0x400
433576ee xor      dword ptr [esi], eax
433576f0 cmp      esi, dword ptr [esp + 0xa8]
433576f7 jne      0x43357733
433576f9 mov      eax, dword ptr [esp + 0xe4]
43357700 cmp      dword ptr [esi + 0xc8], eax
43357706 je       0x43357733
43357708 test     dword ptr [edi + 0x170], 0x800
43357712 jne      0x43357733
43357714 movd     xmm0, eax
43357718 mov      dword ptr [esi + 0xc8], eax
4335771e mov      eax, dword ptr [0x4346a338]
43357723 cvtdq2ps xmm0, xmm0
43357726 mulss    xmm0, dword ptr [eax]
4335772a mov      eax, dword ptr [0x43467eb8]
4335772f movss    dword ptr [eax], xmm0
43357733 push     dword ptr [esp + 0x28]
43357737 lea      ecx, [edi - 8]
4335773a push     dword ptr [esp + 0x60]
4335773e push     esi
4335773f call     0x433320d4
43357744 test     dword ptr [esi], 0x100000
4335774a jne      0x4335778e
4335774c test     dword ptr [esi], 0x400
43357752 mov      eax, dword ptr [esp + 0x28]
43357756 je       0x43357760
43357758 xor      ecx, ecx
4335775a inc      ecx
4335775b test     byte ptr [eax + 0x30], cl
4335775e jne      0x4335778e
43357760 push     2
43357762 pop      ecx
43357763 test     byte ptr [esi], cl
43357765 je       0x433583ee
4335776b test     dword ptr [eax + 0x30], 0x800
43357772 je       0x433583ee
43357778 cmp      dword ptr [esi + 0xd8], 0x40
4335777f je       0x4335778e
43357781 cmp      byte ptr [esi + 0x124], 0
43357788 jne      0x433583ee
4335778e cmp      dword ptr [esi + 0xc], 0
43357792 je       0x433583ee
43357798 mov      eax, dword ptr [0x4346908c]
4335779d mov      eax, dword ptr [eax]
4335779f xor      eax, dword ptr [0x43468ba0]
433577a5 xor      eax, 0x5c9f0fbb
433577aa add      eax, dword ptr [esi + 0xc]
433577ad mov      cx, word ptr [eax]
433577b0 call     0x433d24bb
433577b5 test     al, al
433577b7 je       0x433583ee
433577bd mov      eax, dword ptr [esi + 0xac]
433577c3 mov      dword ptr [0x434759c4], eax
433577c8 test     dword ptr [esi], 0x4000
433577ce je       0x43358082
433577d4 mov      eax, dword ptr [esp + 0x28]
433577d8 mov      ecx, esi
433577da movzx    edx, byte ptr [eax + 0x40]
433577de call     0x4339ef31
433577e3 movss    dword ptr [esp + 0x250], xmm1
433577ec movaps   xmm1, xmm0
433577ef movss    xmm2, dword ptr [esp + 0x250]
433577f8 mulss    xmm1, xmm0
433577fc movss    dword ptr [esp + 0x24c], xmm0
43357805 movss    dword ptr [esp + 0xd8], xmm0
4335780e movaps   xmm0, xmm2
43357811 mulss    xmm0, xmm2
43357815 movss    dword ptr [esp + 0xd0], xmm2
4335781e addss    xmm1, xmm0
43357822 movaps   xmm0, xmm1
43357825 movss    xmm1, dword ptr [0x434701dc]
4335782d sqrtss   xmm0, xmm0
43357831 comiss   xmm1, xmm0
43357834 movups   xmmword ptr [esp + 0x350], xmm0
4335783c movss    dword ptr [esp + 0x1c], xmm0
43357842 ja       0x43358082
43357848 test     byte ptr [esi], 8
4335784b je       0x43357e86
43357851 call     0x7750a400
43357856 mov      eax, dword ptr [esp + 0x28]
4335785a mulss    xmm0, dword ptr [esp + 0xa4]
43357863 movss    xmm1, dword ptr [eax + 0xc]
43357868 addss    xmm1, xmm0
4335786c movss    xmm0, dword ptr [esp + 0xd8]
43357875 cvtps2pd xmm0, xmm0
43357878 movss    dword ptr [eax + 0xc], xmm1
4335787d movss    xmm1, dword ptr [esp + 0xd0]
43357886 cvtps2pd xmm1, xmm1
43357889 call     0x77509ee0
4335788e mov      eax, dword ptr [esp + 0x28]
43357892 xorps    xmm1, xmm1
43357895 mov      ecx, dword ptr [esp + 0x5c]
43357899 cvtsd2ss xmm1, xmm0
4335789d mulss    xmm1, dword ptr [esp + 0xa4]
433578a6 xorps    xmm1, xmmword ptr [esp + 0xf0]
433578ae movss    dword ptr [eax + 0x14], xmm1
433578b3 test     ecx, ecx
433578b5 je       0x43358082
433578bb cmp      byte ptr [0x43467224], 0
433578c2 je       0x43358082
433578c8 xor      eax, eax
433578ca inc      eax
433578cb test     byte ptr [edi + 0x170], al
433578d1 mov      edi, dword ptr [esp + 0x28]
433578d5 jne      0x43358086
433578db test     byte ptr [esi], 0x40
433578de jne      0x43358086
433578e4 movss    xmm0, dword ptr [edi + 0x28]
433578e9 movss    xmm3, dword ptr [esp + 0xb0]
433578f2 movss    xmm2, dword ptr [esp + 0x2c]
433578f8 andps    xmm0, xmm3
433578fb ucomiss  xmm0, xmm2
433578fe lahf     
433578ff test     ah, 0x44
43357902 jnp      0x43358086
43357908 test     dword ptr [esi], 0x40000
4335790e jne      0x43358086
43357914 andps    xmm1, xmm3
43357917 ucomiss  xmm1, xmm2
4335791a lahf     
4335791b test     ah, 0x44
4335791e jnp      0x43358086
43357924 and      dword ptr [edi + 0x28], 0
43357928 test     dword ptr [esi], 0x1000
4335792e je       0x43358086
43357934 push     dword ptr [esi + 0xc8]
4335793a push     dword ptr [esi + 0xf8]
43357940 add      esi, 0x180
43357946 sub      esp, 0xc
43357949 mov      edi, esp
4335794b sub      esp, 0xc
4335794e movsd    dword ptr es:[edi], dword ptr [esi]
4335794f movsd    dword ptr es:[edi], dword ptr [esi]
43357950 movsd    dword ptr es:[edi], dword ptr [esi]
43357951 mov      esi, dword ptr [esp + 0x34]
43357955 mov      edi, esp
43357957 push     ecx
43357958 lea      ecx, [esp + 0x1074]
4335795f lea      esi, [esi + 0x168]
43357965 movsd    dword ptr es:[edi], dword ptr [esi]
43357966 movsd    dword ptr es:[edi], dword ptr [esi]
43357967 movsd    dword ptr es:[edi], dword ptr [esi]
43357968 call     0x433b0d5c
4335796d push     dword ptr [esp + 0x28]
43357971 lea      ecx, [esp + 0x1054]
43357978 push     dword ptr [esp + 0x60]
4335797c call     0x433d7606
43357981 movss    xmm1, dword ptr [esp + 0x1054]
4335798a lea      esi, [esp + 0x1054]
43357991 movss    xmm2, dword ptr [esp + 0x1058]
4335799a lea      edi, [esp + 0x1cc]
433579a1 movsd    dword ptr es:[edi], dword ptr [esi]
433579a2 movsd    dword ptr es:[edi], dword ptr [esi]
433579a3 movsd    dword ptr es:[edi], dword ptr [esi]
433579a4 mov      esi, dword ptr [esp + 0x14]
433579a8 lea      edi, [esi + 0x10c]
433579ae subss    xmm1, dword ptr [edi]
433579b2 subss    xmm2, dword ptr [edi + 4]
433579b7 movaps   xmm0, xmm1
433579ba movaps   xmm3, xmm2
433579bd mulss    xmm0, xmm1
433579c1 mulss    xmm3, xmm2
433579c5 addss    xmm3, xmm0
433579c9 comiss   xmm3, dword ptr [esp + 0x168]
433579d1 jbe      0x43358082
433579d7 movss    xmm0, dword ptr [0x43472b60]
433579df comiss   xmm0, xmm3
433579e2 jbe      0x43358082
433579e8 movss    xmm0, dword ptr [esi + 0x114]
433579f0 lea      esi, [esp + 0x1cc]
433579f7 movss    dword ptr [esp + 0x1d4], xmm0
43357a00 movsd    dword ptr es:[edi], dword ptr [esi]
43357a01 movsd    dword ptr es:[edi], dword ptr [esi]
43357a02 movsd    dword ptr es:[edi], dword ptr [esi]
43357a03 mov      esi, dword ptr [esp + 0x14]
43357a07 addss    xmm1, dword ptr [esi + 0xdc]
43357a0f movss    dword ptr [esi + 0xdc], xmm1
43357a17 addss    xmm2, dword ptr [esi + 0xe0]
43357a1f movss    dword ptr [esi + 0xe0], xmm2
43357a27 movss    xmm4, dword ptr [esi + 0xe8]
43357a2f movss    xmm3, dword ptr [esi + 0xec]
43357a37 subss    xmm4, xmm1
43357a3b subss    xmm3, xmm2
43357a3f movss    xmm2, dword ptr [esi + 0xf0]
43357a47 subss    xmm2, dword ptr [esi + 0xe4]
43357a4f movaps   xmm1, xmm4
43357a52 mulss    xmm1, xmm4
43357a56 movaps   xmm0, xmm3
43357a59 mulss    xmm0, xmm3
43357a5d addss    xmm1, xmm0
43357a61 movaps   xmm0, xmm2
43357a64 mulss    xmm0, xmm2
43357a68 addss    xmm1, xmm0
43357a6c movaps   xmm0, xmm1
43357a6f movss    xmm1, dword ptr [esp + 0x68]
43357a75 sqrtss   xmm0, xmm0
43357a79 movss    dword ptr [esp + 0x24c], xmm0
43357a82 addss    xmm0, dword ptr [esp + 0x94]
43357a8b divss    xmm1, xmm0
43357a8f movaps   xmm0, xmm1
43357a92 mulss    xmm0, xmm4
43357a96 movaps   xmm4, xmm1
43357a99 mulss    xmm4, xmm3
43357a9d mulss    xmm1, xmm2
43357aa1 movss    xmm2, dword ptr [esp + 0x2c]
43357aa7 ucomiss  xmm4, xmm2
43357aaa movss    dword ptr [esp + 0xe4], xmm0
43357ab3 movss    dword ptr [esp + 0x40], xmm4
43357ab9 lahf     
43357aba movss    dword ptr [esp + 0xc8], xmm1
43357ac3 test     ah, 0x44
43357ac6 jp       0x43357af2
43357ac8 ucomiss  xmm0, xmm2
43357acb lahf     
43357acc test     ah, 0x44
43357acf jp       0x43357af2
43357ad1 comiss   xmm1, xmm2
43357ad4 jbe      0x43357ae1
43357ad6 movss    xmm0, dword ptr [esp + 0x160]
43357adf jmp      0x43357aea
43357ae1 movss    xmm0, dword ptr [esp + 0x110]
43357aea movaps   xmm1, xmm2
43357aed jmp      0x43357b75
43357af2 cvtps2pd xmm1, xmm0
43357af5 cvtps2pd xmm0, xmm4
43357af8 call     0x77509ee0
43357afd movss    xmm1, dword ptr [esp + 0xe4]
43357b06 cvtsd2ss xmm0, xmm0
43357b0a mulss    xmm1, xmm1
43357b0e mulss    xmm0, dword ptr [esp + 0xa4]
43357b17 movss    dword ptr [esp + 0x10c], xmm0
43357b20 movss    xmm0, dword ptr [esp + 0x40]
43357b26 mulss    xmm0, xmm0
43357b2a addss    xmm1, xmm0
43357b2e movaps   xmm0, xmm1
43357b31 xorps    xmm1, xmm1
43357b34 sqrtss   xmm0, xmm0
43357b38 movss    dword ptr [esp + 0x158], xmm0
43357b41 cvtss2sd xmm1, xmm0
43357b45 movss    xmm0, dword ptr [esp + 0xc8]
43357b4e xorps    xmm0, xmmword ptr [esp + 0xf0]
43357b56 cvtss2sd xmm0, xmm0
43357b5a call     0x77509ee0
43357b5f movss    xmm1, dword ptr [esp + 0x10c]
43357b68 cvtsd2ss xmm0, xmm0
43357b6c mulss    xmm0, dword ptr [esp + 0xa4]
43357b75 mov      edi, dword ptr [esp + 0x28]
43357b79 movss    dword ptr [edi + 0xc], xmm0
43357b7e movss    dword ptr [edi + 0x10], xmm1
43357b83 and      dword ptr [edi + 0x14], 0
43357b87 mov      al, byte ptr [0x43467144]
43357b8c movsx    ecx, byte ptr [esi + 0x124]
43357b93 mov      byte ptr [esp + 0x33], al
43357b97 call     0x433ea238
43357b9c test     al, al
43357b9e jne      0x43357ba6
43357ba0 cmp      byte ptr [esp + 0x33], al
43357ba4 jne      0x43357c15
43357ba6 movss    xmm3, dword ptr [esi + 0x9c]
43357bae movss    xmm2, dword ptr [esi + 0xa0]
43357bb6 movaps   xmm0, xmm3
43357bb9 movss    xmm1, dword ptr [esi + 0xa4]
43357bc1 mulss    xmm0, xmm3
43357bc5 mulss    xmm2, xmm2
43357bc9 mulss    xmm1, xmm1
43357bcd addss    xmm0, xmm2
43357bd1 addss    xmm0, xmm1
43357bd5 ucomiss  xmm0, dword ptr [esp + 0x2c]
43357bda lahf     
43357bdb test     ah, 0x44
43357bde jnp      0x43357c15
43357be0 movss    xmm0, dword ptr [edi + 0xc]
43357be5 subss    xmm0, xmm3
43357be9 movss    dword ptr [edi + 0xc], xmm0
43357bee movss    xmm0, dword ptr [edi + 0x10]
43357bf3 subss    xmm0, dword ptr [esi + 0xa0]
43357bfb movss    dword ptr [edi + 0x10], xmm0
43357c00 movss    xmm0, dword ptr [edi + 0x14]
43357c05 subss    xmm0, dword ptr [esi + 0xa4]
43357c0d movss    dword ptr [edi + 0x14], xmm0
43357c12 or       dword ptr [esi], 0x10
43357c15 lea      ecx, [edi + 0xc]
43357c18 call     0x433e9160
43357c1d test     byte ptr [esi], 0x40
43357c20 je       0x43357e25
43357c26 mov      eax, dword ptr [0x43468b50]
43357c2b xor      edx, edx
43357c2d mov      ecx, dword ptr [esp + 0x5c]
43357c31 inc      edx
43357c32 mov      eax, dword ptr [eax]
43357c34 xor      eax, dword ptr [0x43467b48]
43357c3a xor      eax, 0x38ca5228
43357c3f mov      eax, dword ptr [eax + ecx]
43357c42 shr      eax, 3
43357c45 test     dl, al
43357c47 jne      0x43357cc8
43357c49 mov      eax, dword ptr [0x4346757c]
43357c4e mov      edx, dword ptr [eax]
43357c50 xor      edx, dword ptr [0x4346707c]
43357c56 mov      eax, dword ptr [0x4346934c]
43357c5b xor      edx, 0x43fa575
43357c61 add      edx, ecx
43357c63 mov      ecx, dword ptr [eax]
43357c65 xor      ecx, dword ptr [0x434671f8]
43357c6b mov      al, byte ptr [edx]
43357c6d xor      ecx, 0x334b460c
43357c73 mov      edx, dword ptr [esp + 0x5c]
43357c77 cmp      al, byte ptr [ecx + edx]
43357c7a jne      0x43357cc8
43357c7c mov      eax, dword ptr [esp + 0x28]
43357c80 mov      edx, dword ptr [0x4346a894]
43357c86 mov      esi, dword ptr [eax + 4]
43357c89 mov      dword ptr [esp + 0xe4], 0x1c932992
43357c94 dec      esi
43357c95 mov      eax, dword ptr [esp + 0xe4]
43357c9c mov      ecx, dword ptr [edx]
43357c9e ror      eax, 0x1f
43357ca1 add      eax, 0x432b67bf
43357ca6 xor      eax, 0x7c51bac3
43357cab push     esi
43357cac push     0
43357cae mov      ecx, dword ptr [eax + ecx]
43357cb1 mov      dword ptr [esp + 0x5ac], ecx
43357cb8 call     0x433e533f
43357cbd mov      esi, dword ptr [esp + 0x14]
43357cc1 lea      ecx, [eax + 0xc]
43357cc4 test     eax, eax
43357cc6 jne      0x43357ccb
43357cc8 lea      ecx, [esi + 0x20]
43357ccb and      dword ptr [edi + 0x14], 0
43357ccf movss    xmm3, dword ptr [edi + 0xc]
43357cd4 subss    xmm3, dword ptr [ecx]
43357cd8 mov      dword ptr [esp + 0x3c], ecx
43357cdc ucomiss  xmm3, xmm3
43357cdf movss    dword ptr [esp + 0x34], xmm3
43357ce5 lahf     
43357ce6 test     ah, 0x44
43357ce9 jnp      0x43357cfc
43357ceb movss    xmm0, dword ptr [esp + 0x2c]
43357cf1 movaps   xmm3, xmm0
43357cf4 movss    dword ptr [esp + 0x34], xmm3
43357cfa jmp      0x43357d5d
43357cfc movss    xmm1, dword ptr [esp + 0xb0]
43357d05 movaps   xmm0, xmm3
43357d08 andps    xmm0, xmm1
43357d0b comiss   xmm0, dword ptr [esp + 0xec]
43357d13 jbe      0x43357d57
43357d15 movaps   xmm0, xmm3
43357d18 divss    xmm0, dword ptr [esp + 0x8c]
43357d21 andps    xmm0, xmm1
43357d24 call     0x4341ad12
43357d29 movss    xmm3, dword ptr [esp + 0x34]
43357d2f movss    xmm1, dword ptr [esp + 0x2c]
43357d35 comiss   xmm1, xmm3
43357d38 mov      ecx, dword ptr [esp + 0x3c]
43357d3c mulss    xmm0, dword ptr [esp + 0x8c]
43357d45 jbe      0x43357d4d
43357d47 addss    xmm3, xmm0
43357d4b jmp      0x43357d51
43357d4d subss    xmm3, xmm0
43357d51 movss    dword ptr [esp + 0x34], xmm3
43357d57 movss    xmm0, dword ptr [esp + 0x2c]
43357d5d movss    xmm2, dword ptr [edi + 0x10]
43357d62 subss    xmm2, dword ptr [ecx + 4]
43357d67 ucomiss  xmm2, xmm2
43357d6a movss    dword ptr [esp + 0xe4], xmm2
43357d73 lahf     
43357d74 test     ah, 0x44
43357d77 jnp      0x43357d7e
43357d79 movaps   xmm2, xmm0
43357d7c jmp      0x43357ddc
43357d7e movss    xmm1, dword ptr [esp + 0xb0]
43357d87 movaps   xmm0, xmm2
43357d8a andps    xmm0, xmm1
43357d8d comiss   xmm0, dword ptr [esp + 0xec]
43357d95 jbe      0x43357ddc
43357d97 movaps   xmm0, xmm2
43357d9a divss    xmm0, dword ptr [esp + 0x8c]
43357da3 andps    xmm0, xmm1
43357da6 call     0x4341ad12
43357dab movss    xmm2, dword ptr [esp + 0xe4]
43357db4 movss    xmm1, dword ptr [esp + 0x2c]
43357dba comiss   xmm1, xmm2
43357dbd mov      ecx, dword ptr [esp + 0x3c]
43357dc1 mulss    xmm0, dword ptr [esp + 0x8c]
43357dca movss    xmm3, dword ptr [esp + 0x34]
43357dd0 jbe      0x43357dd8
43357dd2 addss    xmm2, xmm0
43357dd6 jmp      0x43357ddc
43357dd8 subss    xmm2, xmm0
43357ddc movaps   xmm1, xmm3
43357ddf movaps   xmm0, xmm2
43357de2 mulss    xmm0, xmm2
43357de6 mulss    xmm1, xmm3
43357dea addss    xmm1, xmm0
43357dee xorps    xmm0, xmm0
43357df1 movss    xmm0, xmm1
43357df5 movss    xmm1, dword ptr [esi + 0x1e8]
43357dfd sqrtss   xmm0, xmm0
43357e01 comiss   xmm1, xmm0
43357e04 ja       0x43357e25
43357e06 divss    xmm1, xmm0
43357e0a mulss    xmm3, xmm1
43357e0e mulss    xmm2, xmm1
43357e12 addss    xmm3, dword ptr [ecx]
43357e16 movss    dword ptr [edi + 0xc], xmm3
43357e1b addss    xmm2, dword ptr [ecx + 4]
43357e20 movss    dword ptr [edi + 0x10], xmm2
43357e25 movss    xmm0, dword ptr [esp + 0x350]
43357e2e call     0x7750a400
43357e33 mulss    xmm0, dword ptr [esp + 0xa4]
43357e3c movss    xmm1, dword ptr [esp + 0xd0]
43357e45 cvtps2pd xmm1, xmm1
43357e48 addss    xmm0, dword ptr [edi + 0xc]
43357e4d movss    dword ptr [edi + 0xc], xmm0
43357e52 movss    xmm0, dword ptr [esp + 0xd8]
43357e5b cvtps2pd xmm0, xmm0
43357e5e call     0x77509ee0
43357e63 mov      edi, dword ptr [esp + 0x28]
43357e67 cvtsd2ss xmm0, xmm0
43357e6b mulss    xmm0, dword ptr [esp + 0xa4]
43357e74 xorps    xmm0, xmmword ptr [esp + 0xf0]
43357e7c movss    dword ptr [edi + 0x14], xmm0
43357e81 jmp      0x43358086
43357e86 mov      edi, dword ptr [esp + 0x28]
43357e8a lea      eax, [esp + 0x290]
43357e91 push     eax
43357e92 lea      eax, [esp + 0x2a0]
43357e99 push     eax
43357e9a lea      edx, [esp + 0x3a4]
43357ea1 lea      ecx, [edi + 0xc]
43357ea4 call     0x43366128
43357ea9 movss    xmm0, dword ptr [esp + 0xd8]
43357eb2 movss    xmm3, dword ptr [esp + 0x29c]
43357ebb movss    xmm4, dword ptr [esp + 0x2a0]
43357ec4 movss    xmm5, dword ptr [esp + 0x2a4]
43357ecd movss    xmm6, dword ptr [esp + 0xd0]
43357ed6 movss    xmm1, dword ptr [esp + 0x294]
43357edf movss    xmm2, dword ptr [esp + 0x298]
43357ee8 mulss    xmm4, xmm0
43357eec mulss    xmm5, xmm0
43357ef0 mulss    xmm3, xmm0
43357ef4 movss    xmm0, dword ptr [esp + 0x290]
43357efd mulss    xmm0, xmm6
43357f01 mulss    xmm1, xmm6
43357f05 movss    dword ptr [esp + 0x290], xmm0
43357f0e addss    xmm0, xmm3
43357f12 movss    dword ptr [esp + 0x29c], xmm3
43357f1b movss    xmm3, dword ptr [esp + 0x39c]
43357f24 movss    dword ptr [esp + 0x294], xmm1
43357f2d addss    xmm1, xmm4
43357f31 movss    dword ptr [esp + 0x2a0], xmm4
43357f3a movss    xmm4, dword ptr [esp + 0x3a0]
43357f43 subss    xmm3, xmm0
43357f47 mulss    xmm2, xmm6
43357f4b subss    xmm4, xmm1
43357f4f movss    dword ptr [esp + 0x2a4], xmm5
43357f58 movss    dword ptr [esp + 0x298], xmm2
43357f61 movaps   xmm1, xmm3
43357f64 addss    xmm2, xmm5
43357f68 mulss    xmm1, xmm3
43357f6c movss    xmm5, dword ptr [esp + 0x3a4]
43357f75 movaps   xmm0, xmm4
43357f78 mulss    xmm0, xmm4
43357f7c subss    xmm5, xmm2
43357f80 addss    xmm1, xmm0
43357f84 movaps   xmm0, xmm5
43357f87 mulss    xmm0, xmm5
43357f8b addss    xmm1, xmm0
43357f8f movaps   xmm0, xmm1
43357f92 movss    xmm1, dword ptr [esp + 0x68]
43357f98 sqrtss   xmm0, xmm0
43357f9c addss    xmm0, dword ptr [esp + 0x94]
43357fa5 divss    xmm1, xmm0
43357fa9 movss    xmm0, dword ptr [esp + 0x2c]
43357faf mulss    xmm4, xmm1
43357fb3 mulss    xmm3, xmm1
43357fb7 ucomiss  xmm4, xmm0
43357fba mulss    xmm5, xmm1
43357fbe lahf     
43357fbf movss    dword ptr [esp + 0xe4], xmm3
43357fc8 movss    dword ptr [esp + 0x164], xmm4
43357fd1 movss    dword ptr [esp + 0x40], xmm5
43357fd7 test     ah, 0x44
43357fda jp       0x43358004
43357fdc ucomiss  xmm3, xmm0
43357fdf lahf     
43357fe0 test     ah, 0x44
43357fe3 jp       0x43358004
43357fe5 and      dword ptr [edi + 0x10], 0
43357fe9 comiss   xmm5, xmm0
43357fec jbe      0x43357ff9
43357fee movss    xmm0, dword ptr [esp + 0x160]
43357ff7 jmp      0x43358071
43357ff9 movss    xmm0, dword ptr [esp + 0x110]
43358002 jmp      0x43358071
43358004 cvtps2pd xmm1, xmm3
43358007 cvtps2pd xmm0, xmm4
4335800a call     0x77509ee0
4335800f movss    xmm1, dword ptr [esp + 0xe4]
43358018 cvtsd2ss xmm0, xmm0
4335801c mulss    xmm1, xmm1
43358020 mulss    xmm0, dword ptr [esp + 0xa4]
43358029 movss    dword ptr [edi + 0x10], xmm0
4335802e movss    xmm0, dword ptr [esp + 0x164]
43358037 mulss    xmm0, xmm0
4335803b addss    xmm1, xmm0
4335803f movaps   xmm0, xmm1
43358042 xorps    xmm1, xmm1
43358045 sqrtss   xmm0, xmm0
43358049 cvtss2sd xmm1, xmm0
4335804d movss    xmm0, dword ptr [esp + 0x40]
43358053 xorps    xmm0, xmmword ptr [esp + 0xf0]
4335805b cvtss2sd xmm0, xmm0
4335805f call     0x77509ee0
43358064 cvtsd2ss xmm0, xmm0
43358068 mulss    xmm0, dword ptr [esp + 0xa4]
43358071 movss    dword ptr [edi + 0xc], xmm0
43358076 lea      ecx, [edi + 0xc]
43358079 and      dword ptr [edi + 0x14], 0
4335807d call     0x433e9160
43358082 mov      edi, dword ptr [esp + 0x28]
43358086 cmp      byte ptr [0x43467144], 0
4335808d je       0x433583ee
43358093 movsx    ecx, byte ptr [esi + 0x124]
4335809a call     0x433ea238
4335809f test     al, al
433580a1 jne      0x433583ee
433580a7 cmp      byte ptr [0x43467cb4], al
433580ad je       0x43358373
433580b3 mov      eax, dword ptr [0x43468520]
433580b8 xor      eax, 0x394bff56
433580bd jmp      0x433580c1
433580bf mov      eax, ecx
433580c1 mov      ecx, dword ptr [eax + 0x1c]
433580c4 cmp      eax, ecx
433580c6 jne      0x433580bf
433580c8 cmp      dword ptr [eax + 0x30], eax
433580cb je       0x43358373
433580d1 cmp      dword ptr [0x43467ddc], 0
433580d8 je       0x43358373
433580de mov      eax, dword ptr [esi + 0x19c]
433580e4 xor      ecx, ecx
433580e6 inc      ecx
433580e7 cmp      eax, ecx
433580e9 jle      0x43358373
433580ef movss    xmm2, dword ptr [esi + 0x100]
433580f7 mov      edx, dword ptr [esi + 0xb0]
433580fd mov      ecx, dword ptr [esi + 0xd8]
43358103 movss    xmm1, dword ptr [esi + 0xc4]
4335810b movss    xmm0, dword ptr [esi + 0xd0]
43358113 push     eax
43358114 movzx    eax, byte ptr [edi + 0x40]
43358118 push     eax
43358119 call     0x43389a9a
4335811e movss    dword ptr [esp + 0x15c], xmm1
43358127 movaps   xmm1, xmm0
4335812a mulss    xmm1, xmm0
4335812e movss    dword ptr [esp + 0x158], xmm0
43358137 movss    xmm0, dword ptr [esp + 0x15c]
43358140 mulss    xmm0, xmm0
43358144 addss    xmm1, xmm0
43358148 movaps   xmm0, xmm1
4335814b movss    xmm1, dword ptr [0x434701dc]
43358153 sqrtss   xmm0, xmm0
43358157 comiss   xmm1, xmm0
4335815a ja       0x43358373
43358160 lea      eax, [esp + 0x278]
43358167 push     eax
43358168 lea      eax, [esp + 0x288]
4335816f push     eax
43358170 lea      edx, [esp + 0x3b0]
43358177 lea      ecx, [edi + 0xc]
4335817a call     0x43366128
4335817f movss    xmm0, dword ptr [esp + 0x278]
43358188 mulss    xmm0, dword ptr [esp + 0x15c]
43358191 movss    xmm1, dword ptr [esp + 0x27c]
4335819a mulss    xmm1, dword ptr [esp + 0x15c]
433581a3 movss    xmm3, dword ptr [esp + 0x284]
433581ac mulss    xmm3, dword ptr [esp + 0x158]
433581b5 movss    xmm4, dword ptr [esp + 0x288]
433581be mulss    xmm4, dword ptr [esp + 0x158]
433581c7 movss    xmm5, dword ptr [esp + 0x28c]
433581d0 mulss    xmm5, dword ptr [esp + 0x158]
433581d9 movss    xmm2, dword ptr [esp + 0x280]
433581e2 mulss    xmm2, dword ptr [esp + 0x15c]
433581eb movss    dword ptr [esp + 0x278], xmm0
433581f4 addss    xmm0, xmm3
433581f8 movss    dword ptr [esp + 0x27c], xmm1
43358201 addss    xmm1, xmm4
43358205 movss    dword ptr [esp + 0x284], xmm3
4335820e movss    xmm3, dword ptr [esp + 0x3a8]
43358217 movss    dword ptr [esp + 0x288], xmm4
43358220 movss    xmm4, dword ptr [esp + 0x3ac]
43358229 subss    xmm3, xmm0
4335822d subss    xmm4, xmm1
43358231 movss    dword ptr [esp + 0x280], xmm2
4335823a addss    xmm2, xmm5
4335823e movss    dword ptr [esp + 0x28c], xmm5
43358247 movss    xmm5, dword ptr [esp + 0x3b0]
43358250 movaps   xmm1, xmm3
43358253 mulss    xmm1, xmm3
43358257 movaps   xmm0, xmm4
4335825a mulss    xmm0, xmm4
4335825e subss    xmm5, xmm2
43358262 addss    xmm1, xmm0
43358266 movaps   xmm0, xmm5
43358269 mulss    xmm0, xmm5
4335826d addss    xmm1, xmm0
43358271 movaps   xmm0, xmm1
43358274 movss    xmm1, dword ptr [esp + 0x68]
4335827a sqrtss   xmm0, xmm0
4335827e addss    xmm0, dword ptr [esp + 0x94]
43358287 divss    xmm1, xmm0
4335828b movss    xmm0, dword ptr [esp + 0x2c]
43358291 mulss    xmm4, xmm1
43358295 mulss    xmm3, xmm1
43358299 ucomiss  xmm4, xmm0
4335829c mulss    xmm5, xmm1
433582a0 lahf     
433582a1 movss    dword ptr [esp + 0xe4], xmm3
433582aa movss    dword ptr [esp + 0x164], xmm4
433582b3 movss    dword ptr [esp + 0x40], xmm5
433582b9 test     ah, 0x44
433582bc jp       0x433582ed
433582be ucomiss  xmm3, xmm0
433582c1 lahf     
433582c2 test     ah, 0x44
433582c5 jp       0x433582ed
433582c7 mov      eax, dword ptr [esp + 0x28]
433582cb and      dword ptr [eax + 0x10], 0
433582cf comiss   xmm5, xmm0
433582d2 jbe      0x433582e2
433582d4 movss    xmm0, dword ptr [esp + 0x160]
433582dd jmp      0x43358362
433582e2 movss    xmm0, dword ptr [esp + 0x110]
433582eb jmp      0x43358362
433582ed cvtps2pd xmm1, xmm3
433582f0 cvtps2pd xmm0, xmm4
433582f3 call     0x77509ee0
433582f8 mov      eax, dword ptr [esp + 0x28]
433582fc movss    xmm1, dword ptr [esp + 0xe4]
43358305 cvtsd2ss xmm0, xmm0
43358309 mulss    xmm1, xmm1
4335830d mulss    xmm0, dword ptr [esp + 0xa4]
43358316 movss    dword ptr [eax + 0x10], xmm0
4335831b movss    xmm0, dword ptr [esp + 0x164]
43358324 mulss    xmm0, xmm0
43358328 addss    xmm1, xmm0
4335832c movaps   xmm0, xmm1
4335832f xorps    xmm1, xmm1
43358332 sqrtss   xmm0, xmm0
43358336 cvtss2sd xmm1, xmm0
4335833a movss    xmm0, dword ptr [esp + 0x40]
43358340 xorps    xmm0, xmmword ptr [esp + 0xf0]
43358348 cvtss2sd xmm0, xmm0
4335834c call     0x77509ee0
43358351 mov      eax, dword ptr [esp + 0x28]
43358355 cvtsd2ss xmm0, xmm0
43358359 mulss    xmm0, dword ptr [esp + 0xa4]
43358362 movss    dword ptr [edi + 0xc], xmm0
43358367 lea      ecx, [edi + 0xc]
4335836a and      dword ptr [eax + 0x14], 0
4335836e call     0x433e9160
43358373 movss    xmm3, dword ptr [esi + 0x9c]
4335837b movss    xmm2, dword ptr [esi + 0xa0]
43358383 movaps   xmm0, xmm3
43358386 movss    xmm1, dword ptr [esi + 0xa4]
4335838e mulss    xmm0, xmm3
43358392 mov      edi, dword ptr [esp + 0x28]
43358396 mulss    xmm2, xmm2
4335839a mulss    xmm1, xmm1
4335839e addss    xmm0, xmm2
433583a2 addss    xmm0, xmm1
433583a6 ucomiss  xmm0, dword ptr [esp + 0x2c]
433583ab lahf     
433583ac test     ah, 0x44
433583af jnp      0x433583f2
433583b1 lea      ecx, [edi + 0xc]
433583b4 movss    xmm0, dword ptr [ecx]
433583b8 subss    xmm0, xmm3
433583bc movss    dword ptr [ecx], xmm0
433583c0 movss    xmm0, dword ptr [ecx + 4]
433583c5 subss    xmm0, dword ptr [esi + 0xa0]
433583cd movss    dword ptr [ecx + 4], xmm0
433583d2 movss    xmm0, dword ptr [ecx + 8]
433583d7 subss    xmm0, dword ptr [esi + 0xa4]
433583df movss    dword ptr [ecx + 8], xmm0
433583e4 call     0x433e9160
433583e9 or       dword ptr [esi], 0x10
433583ec jmp      0x433583f2
433583ee mov      edi, dword ptr [esp + 0x28]
433583f2 cmp      esi, dword ptr [esp + 0xa8]
433583f9 je       0x433584e5
433583ff push     0x64
43358401 pop      eax
43358402 mov      edx, eax
43358404 mov      ecx, edi
43358406 call     0x4333d6a2
4335840b cmp      dword ptr [esp + 0x11c], eax
43358412 je       0x433584e5
43358418 mov      ecx, dword ptr [esi + 0xac]
4335841e xor      edx, edx
43358420 mov      eax, ecx
43358422 div      dword ptr [esp + 0x2ec]
43358429 mov      eax, dword ptr [0x4346a894]
4335842e imul     edx, edx, 0x68
43358431 add      edx, dword ptr [eax + 0xf4]
43358437 mov      dword ptr [esp + 0x11c], edx
4335843e cmp      dword ptr [edx + 4], ecx
43358441 jne      0x433584e5
43358447 mov      eax, dword ptr [esi + 0x78]
4335844a xor      ecx, ecx
4335844c mov      dword ptr [edi + 0x24], eax
4335844f inc      ecx
43358450 mov      eax, dword ptr [esi + 0x80]
43358456 mov      dword ptr [edi + 0x28], eax
43358459 mov      eax, dword ptr [esi]
4335845b mov      dl, byte ptr [esi + 0x104]
43358461 movss    xmm0, dword ptr [esi + 0x118]
43358469 movss    xmm1, dword ptr [esi + 0x11c]
43358471 movss    xmm2, dword ptr [esi + 0x120]
43358479 shr      eax, 0x12
4335847c and      al, cl
4335847e push     ecx
4335847f movzx    eax, al
43358482 mov      ecx, edi
43358484 push     eax
43358485 call     0x433b7fea
4335848a mov      edx, dword ptr [esi]
4335848c xor      ecx, ecx
4335848e inc      ecx
4335848f shr      edx, 3
43358492 and      dl, cl
43358494 mov      ecx, edi
43358496 call     0x4332b266
4335849b xor      ecx, ecx
4335849d lea      esi, [edi + 0xc]
433584a0 mov      byte ptr [edi + 0x48], cl
433584a3 mov      eax, dword ptr [edi + 0x30]
433584a6 mov      dword ptr [edi + 0x58], eax
433584a9 add      edi, 0x4c
433584ac mov      eax, dword ptr [esp + 0x28]
433584b0 movsd    dword ptr es:[edi], dword ptr [esi]
433584b1 movsd    dword ptr es:[edi], dword ptr [esi]
433584b2 movsd    dword ptr es:[edi], dword ptr [esi]
433584b3 mov      edi, dword ptr [esp + 0x11c]
433584ba cmp      edi, eax
433584bc je       0x433584ce
433584be push     0x19
433584c0 pop      ecx
433584c1 mov      esi, eax
433584c3 rep movsd dword ptr es:[edi], dword ptr [esi]
433584c5 mov      edi, dword ptr [esp + 0x11c]
433584cc xor      ecx, ecx
433584ce mov      eax, dword ptr [0x43467c48]
433584d3 test     eax, eax
433584d5 je       0x433584dd
433584d7 mov      ecx, edi
433584d9 call     eax
433584db mov      ecx, eax
433584dd mov      dword ptr [edi + 0x64], ecx
433584e0 call     0x433d11f7
433584e5 movss    xmm0, dword ptr [esp + 0x120]
433584ee ucomiss  xmm0, dword ptr [esp + 0x2f0]
433584f6 lahf     
433584f7 test     ah, 0x44
433584fa jnp      0x43358507
433584fc mov      eax, dword ptr [0x43467eb8]
43358501 mov      dword ptr [eax], 0x3f800000
43358507 pop      edi
43358508 pop      esi
43358509 mov      esp, ebp
4335850b pop      ebp
4335850c ret      8
