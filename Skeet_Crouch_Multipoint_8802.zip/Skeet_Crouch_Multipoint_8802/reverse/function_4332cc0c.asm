4332cc0c push     -1
4332cc0e push     dword ptr [ecx + 0xe0]
4332cc14 call     0x4333ff8d
4332cc19 ret      
