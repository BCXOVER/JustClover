43482470 mov      eax, dword ptr [esp + 4]
43482474 push     esi
43482475 mov      esi, ecx
43482477 push     4
43482479 mov      dword ptr [esi + 8], eax
4348247c pop      eax
4348247d mov      word ptr [esi + 0xc], ax
43482481 mov      byte ptr [esi + 0xe], 3
43482485 call     0x43385ae4
4348248a mov      eax, dword ptr [esp + 0xc]
4348248e mov      dword ptr [esi + 0x10], eax
43482491 mov      eax, esi
43482493 pop      esi
43482494 ret      8
