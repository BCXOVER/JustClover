433656b0 sub      al, 0xf3
433656b2 movups   xmmword ptr [esp], xmm0
433656b6 push     dword ptr [esp + 0x28]
433656ba push     dword ptr [esp + 0x28]
433656be push     edi
433656bf call     0x433efaaa
433656c4 test     al, al
433656c6 jne      0x4336575e
433656cc mov      ecx, dword ptr [0x434759c8]
433656d2 cmp      byte ptr [esi + 0x100], 0
433656d9 je       0x43365718
433656db mov      eax, dword ptr [edi + 0xac]
433656e1 cmp      ecx, eax
433656e3 jne      0x43365718
433656e5 cmp      dword ptr [0x434759cc], eax
433656eb jne      0x43365718
433656ed movss    xmm0, dword ptr [esp + 0x24]
433656f3 lea      eax, [esp + 0x14]
433656f7 push     eax
433656f8 push     ecx
433656f9 movss    dword ptr [esp], xmm0
433656fe mov      ecx, esi
43365700 push     dword ptr [esp + 0x24]
43365704 push     dword ptr [esp + 0x24]
43365708 push     edi
43365709 call     0x433b7773
4336570e test     al, al
43365710 jne      0x4336575e
43365712 mov      ecx, dword ptr [0x434759c8]
43365718 mov      eax, dword ptr [0x434685b8]
4336571d cmp      ecx, dword ptr [edi + 0xac]
43365723 jne      0x4336573b
43365725 cmp      eax, 3
43365728 jne      0x43365842
4336572e cmp      dword ptr [esi + 0x9c], 0
43365735 jne      0x43365842
4336573b sub      eax, 1
4336573e je       0x43365842
43365744 sub      eax, 1
43365747 je       0x43365769
43365749 sub      eax, 1
4336574c jne      0x4336575e
4336574e movd     xmm0, dword ptr [esi + 0x9c]
43365756 cvtdq2ps xmm0, xmm0
43365759 jmp      0x433658e4
4336575e movss    xmm0, dword ptr [esp + 0x14]
43365764 jmp      0x433658e4
43365769 cmp      dword ptr [esi + 0x40], 4
4336576d jne      0x43365792
4336576f mov      eax, dword ptr [esi + 0x190]
43365775 xor      edx, edx
43365777 push     0xc
43365779 pop      ecx
4336577a div      ecx
4336577c movss    xmm0, dword ptr [esi + edx*4 + 0x15c]
43365785 mulss    xmm0, dword ptr [esi + 0x134]
4336578d jmp      0x433658e4
43365792 mov      eax, dword ptr [esi + 0x98]
43365798 movss    xmm1, dword ptr [esi + 0x144]
433657a0 movss    dword ptr [esp + 0x20], xmm1
433657a6 cmp      eax, 0xffffff4c
433657ab je       0x4336581c
433657ad test     eax, eax
433657af je       0x43365804
433657b1 cmp      eax, 0xb4
433657b6 je       0x433657fd
433657b8 push     eax
433657b9 call     0x63c2ff20
433657be movss    xmm0, dword ptr [esp + 0x24]
433657c4 and      dword ptr [esp], 0
433657c8 xorps    xmm0, xmmword ptr [0x434703d0]
433657cf push     ecx
433657d0 movss    dword ptr [esp], xmm0
433657d5 call     0x63c2ff40
433657da movss    xmm0, dword ptr [esi + 0x144]
433657e2 movss    dword ptr [esp + 4], xmm0
433657e8 and      dword ptr [esp], 0
433657ec fstp     dword ptr [esp + 0x10]
433657f0 call     0x63c2ff40
433657f5 pop      ecx
433657f6 fstp     dword ptr [esp + 0x10]
433657fa pop      ecx
433657fb jmp      0x4336582e
433657fd and      dword ptr [esp + 8], 0
43365802 jmp      0x43365814
43365804 movaps   xmm0, xmm1
43365807 xorps    xmm0, xmmword ptr [0x434703d0]
4336580e movss    dword ptr [esp + 8], xmm0
43365814 movss    dword ptr [esp + 0xc], xmm1
4336581a jmp      0x4336582e
4336581c xorps    xmm1, xmmword ptr [0x434703d0]
43365823 and      dword ptr [esp + 0xc], 0
43365828 movss    dword ptr [esp + 8], xmm1
4336582e mov      eax, dword ptr [esi + 0x190]
43365834 and      eax, 1
43365837 movss    xmm0, dword ptr [esp + eax*4 + 8]
4336583d jmp      0x433658e4
43365842 movss    xmm0, dword ptr [esp + 0x20]
43365848 subss    xmm0, dword ptr [esi + 0x258]
43365850 cvtps2pd xmm0, xmm0
43365853 movsd    qword ptr [esp + 8], xmm0
43365859 fld      qword ptr [esp + 8]
4336585d fld      qword ptr [0x4346f598]
43365863 call     0x7750834a
43365868 movss    xmm0, dword ptr [esp + 0x20]
4336586e comiss   xmm0, dword ptr [esi + 0x258]
43365875 fstp     dword ptr [esp + 0x24]
43365879 movss    xmm1, dword ptr [esp + 0x24]
4336587f jbe      0x43365894
43365881 comiss   xmm1, dword ptr [0x434725e4]
43365888 jb       0x433658a9
4336588a subss    xmm1, dword ptr [0x43471f88]
43365892 jmp      0x433658a9
43365894 movss    xmm0, dword ptr [0x434724b4]
4336589c comiss   xmm0, xmm1
4336589f jb       0x433658a9
433658a1 addss    xmm1, dword ptr [0x43471f88]
433658a9 movaps   xmm0, xmm1
433658ac andps    xmm0, xmmword ptr [0x43470340]
433658b3 comiss   xmm0, dword ptr [0x4346fd78]
433658ba jbe      0x433658dc
433658bc comiss   xmm1, dword ptr [0x4346ee6c]
433658c3 movss    xmm0, dword ptr [esi + 0x134]
433658cb jbe      0x433658d4
433658cd xorps    xmm0, xmmword ptr [0x434703d0]
433658d4 movss    dword ptr [esi + 0x1a0], xmm0
433658dc movss    xmm0, dword ptr [esi + 0x1a0]
433658e4 pop      edi
433658e5 pop      esi
433658e6 pop      ecx
433658e7 pop      ecx
433658e8 ret      0x14
