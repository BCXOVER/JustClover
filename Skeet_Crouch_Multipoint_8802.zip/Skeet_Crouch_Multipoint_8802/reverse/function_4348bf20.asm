4348bf20 mov      esi, ecx
4348bf22 mov      ecx, dword ptr [edi]
4348bf24 push     ebx
4348bf25 call     0x433e000b
4348bf2a add      edi, 4
4348bf2d cmp      edi, esi
4348bf2f jne      0x4348bf22
4348bf31 mov      edi, dword ptr [esp + 0xc]
4348bf35 mov      esi, dword ptr [esp + 0x10]
4348bf39 lea      ecx, [esp + 0x274]
4348bf40 call     0x4339f3a5
4348bf45 mov      dword ptr [edi + 0xa0], esi
4348bf4b jmp      0x4348bf4f
4348bf4f push     edi
4348bf50 mov      edi, dword ptr [esp + 0x1c]
4348bf54 mov      ecx, edi
4348bf56 call     0x43342275
4348bf5b mov      ecx, 0x158
4348bf60 mov      dword ptr [edi + 0xc0], eax
4348bf66 call     0x43387448
4348bf6b mov      esi, eax
4348bf6d mov      dword ptr [esp + 0xc], esi
4348bf71 test     esi, esi
4348bf73 je       0x4348cb50
4348bf79 lea      eax, [esp + 0x20]
4348bf7d push     eax
4348bf7e push     0x2524
4348bf83 call     0x434938ff
4348bf88 push     eax
4348bf89 push     edi
4348bf8a mov      ecx, esi
4348bf8c call     0x4348e41d
4348bf91 lea      eax, [esp + 0x3e]
4348bf95 mov      dword ptr [esi], 0x43470684
4348bf9b push     eax
4348bf9c lea      eax, [esp + 0x43]
4348bfa0 mov      dword ptr [esi + 0xe0], ebx
4348bfa6 push     eax
4348bfa7 lea      eax, [esp + 0x48]
4348bfab mov      dword ptr [esi + 0xe4], 3
4348bfb5 push     eax
4348bfb6 lea      eax, [esp + 0x4d]
4348bfba mov      word ptr [esi + 0xe8], 0
4348bfc3 push     eax
4348bfc4 lea      eax, [esp + 0x52]
4348bfc8 mov      byte ptr [esi + 0xea], bl
4348bfce push     eax
4348bfcf lea      eax, [esp + 0x57]
4348bfd3 mov      dword ptr [esi + 0x134], ebx
4348bfd9 push     eax
4348bfda push     ebx
4348bfdb lea      ecx, [esi + 0x138]
4348bfe1 call     0x4331eca4
4348bfe6 mov      ecx, 0xde88b6dc
4348bfeb call     0x433e7f74
4348bff0 push     0x10
4348bff2 pop      edi
4348bff3 add      eax, edi
4348bff5 mov      ecx, 0xf6d4d395
4348bffa mov      dword ptr [esi + 0x98], eax
4348c000 call     0x433e7f74
4348c005 add      eax, edi
4348c007 mov      ecx, 0x588fc522
4348c00c mov      dword ptr [esi + 0x9c], eax
4348c012 call     0x433e7f74
4348c017 add      eax, edi
4348c019 mov      ecx, 0x82097ad3
4348c01e mov      dword ptr [esi + 0xa0], eax
4348c024 call     0x433e7f74
4348c029 add      eax, edi
4348c02b mov      ecx, 0x3a8ef907
4348c030 mov      dword ptr [esi + 0xa4], eax
4348c036 call     0x433e7f74
4348c03b add      eax, edi
4348c03d mov      ecx, 0xe5249ca0
4348c042 mov      dword ptr [esi + 0xa8], eax
4348c048 call     0x433e7f74
4348c04d add      eax, edi
4348c04f mov      ecx, 0x7439e8b5
4348c054 mov      dword ptr [esi + 0xac], eax
4348c05a call     0x433e7f74
4348c05f add      eax, edi
4348c061 mov      ecx, 0x5101537e
4348c066 mov      dword ptr [esi + 0xb0], eax
4348c06c call     0x433e7f74
4348c071 add      eax, edi
4348c073 mov      ecx, 0xe13f61e0
4348c078 mov      dword ptr [esi + 0xb4], eax
4348c07e call     0x433e7f74
4348c083 add      eax, edi
4348c085 mov      ecx, 0x7cfd0011
4348c08a mov      dword ptr [esi + 0xb8], eax
4348c090 call     0x433e7f74
4348c095 add      eax, edi
4348c097 mov      ecx, 0x191a5a61
4348c09c mov      dword ptr [esi + 0xbc], eax
4348c0a2 call     0x433e7f74
4348c0a7 add      eax, edi
4348c0a9 mov      ecx, 0x6caf4832
4348c0ae mov      dword ptr [esi + 0xc0], eax
4348c0b4 call     0x433e7f74
4348c0b9 add      eax, edi
4348c0bb mov      ecx, 0xd347bc87
4348c0c0 mov      dword ptr [esi + 0xc4], eax
4348c0c6 call     0x433e7f74
4348c0cb add      eax, edi
4348c0cd mov      ecx, 0xd4f2a320
4348c0d2 mov      dword ptr [esi + 0xc8], eax
4348c0d8 call     0x433e7f74
4348c0dd add      eax, edi
4348c0df mov      ecx, 0xe0bda969
4348c0e4 mov      dword ptr [esi + 0xcc], eax
4348c0ea call     0x433e7f74
4348c0ef add      eax, edi
4348c0f1 mov      ecx, 0xb3c4b6ca
4348c0f6 mov      dword ptr [esi + 0xd0], eax
4348c0fc call     0x433e7f74
4348c101 add      eax, edi
4348c103 mov      ecx, 0xb6218fec
4348c108 mov      dword ptr [esi + 0xd4], eax
4348c10e call     0x433e7f74
4348c113 add      eax, edi
4348c115 mov      dword ptr [esp + 0x10], 0x18000c00
4348c11d push     0x4b30
4348c122 mov      dword ptr [esi + 0x130], eax
4348c128 call     0x434938ff
4348c12d mov      ecx, 0xc8
4348c132 mov      edi, eax
4348c134 call     0x43387448
4348c139 test     eax, eax
4348c13b je       0x4348c14e
4348c13d push     ebx
4348c13e push     ebx
4348c13f push     dword ptr [esp + 0x18]
4348c143 mov      ecx, eax
4348c145 push     edi
4348c146 push     esi
4348c147 call     0x4348210c
4348c14c jmp      0x4348c150
4348c14e mov      eax, ebx
4348c150 push     eax
4348c151 mov      ecx, esi
4348c153 call     0x4347de9b
4348c158 push     1
4348c15a mov      edi, eax
4348c15c lea      eax, [esi + 0xe4]
4348c162 push     eax
4348c163 push     3
4348c165 push     2
4348c167 push     0x4b24
4348c16c call     0x434938ff
4348c171 push     eax
4348c172 mov      ecx, edi
4348c174 call     0x43484978
4348c179 push     ebx
4348c17a mov      ecx, eax
4348c17c mov      dword ptr [esi + 0xec], eax
4348c182 call     0x433e000b
4348c187 mov      ecx, dword ptr [esi + 0xec]
4348c18d lea      eax, [esp + 0x1d0]
4348c194 push     eax
4348c195 add      ecx, 0x40
4348c198 mov      dword ptr [esp + 0x1d4], esi
4348c19f mov      dword ptr [esp + 0x1d8], 0x433eb2c8
4348c1aa call     0x433c081c
4348c1af mov      esi, dword ptr [esi + 0xc8]
4348c1b5 push     0x4b60
4348c1ba call     0x434938ff
4348c1bf push     esi
4348c1c0 push     eax
4348c1c1 mov      ecx, edi
4348c1c3 call     0x43486bb2
4348c1c8 mov      esi, dword ptr [esp + 0xc]
4348c1cc lea      ecx, [esp + 0x1d8]
4348c1d3 push     ecx
4348c1d4 mov      dword ptr [esp + 0x1dc], esi
4348c1db lea      ecx, [eax + 0x40]
4348c1de mov      dword ptr [esp + 0x1e0], 0x4335ca65
4348c1e9 mov      dword ptr [esi + 0xfc], eax
4348c1ef call     0x433c081c
4348c1f4 push     ebx
4348c1f5 push     dword ptr [esi + 0xd0]
4348c1fb mov      ecx, edi
4348c1fd push     0x434745b8
4348c202 call     0x4348017f
4348c207 lea      ecx, [esp + 0x1e0]
4348c20e mov      dword ptr [esi + 0x100], eax
4348c214 push     ecx
4348c215 mov      dword ptr [esp + 0x1e4], esi
4348c21c lea      ecx, [eax + 0x40]
4348c21f mov      dword ptr [esp + 0x1e8], 0x433658fa
4348c22a call     0x433c081c
4348c22f mov      ecx, dword ptr [esi + 0x100]
4348c235 push     0x13
4348c237 add      ecx, 0x7c
4348c23a call     0x433ccb69
4348c23f mov      esi, dword ptr [esi + 0x100]
4348c245 push     0x4b58
4348c24a call     0x434938fb
4348c24f push     ebx
4348c250 push     eax
4348c251 mov      ecx, esi
4348c253 call     0x433f8d73
4348c258 mov      ecx, dword ptr [esp + 0xc]
4348c25c push     0x4b50
4348c261 mov      esi, dword ptr [ecx + 0x100]
4348c267 call     0x434938fb
4348c26c push     1
4348c26e push     eax
4348c26f mov      ecx, esi
4348c271 call     0x433f8d73
4348c276 mov      eax, dword ptr [esp + 0xc]
4348c27a push     0x4b4c
4348c27f mov      esi, dword ptr [eax + 0x100]
4348c285 call     0x434938fb
4348c28a push     2
4348c28c push     eax
4348c28d mov      ecx, esi
4348c28f call     0x433f8d73
4348c294 mov      eax, dword ptr [esp + 0xc]
4348c298 mov      esi, dword ptr [eax + 0x100]
4348c29e push     0x4ba0
4348c2a3 call     0x434938fb
4348c2a8 push     3
4348c2aa push     eax
4348c2ab mov      ecx, esi
4348c2ad call     0x433f8d73
4348c2b2 mov      eax, dword ptr [esp + 0xc]
4348c2b6 push     0x4b94
4348c2bb mov      esi, dword ptr [eax + 0x100]
4348c2c1 call     0x434938fb
4348c2c6 push     4
4348c2c8 push     eax
4348c2c9 mov      ecx, esi
4348c2cb call     0x433f8d73
4348c2d0 mov      eax, dword ptr [esp + 0xc]
4348c2d4 push     0x4b88
4348c2d9 mov      esi, dword ptr [eax + 0x100]
4348c2df call     0x434938fb
4348c2e4 push     5
4348c2e6 push     eax
4348c2e7 mov      ecx, esi
4348c2e9 call     0x433f8d73
4348c2ee mov      eax, dword ptr [esp + 0xc]
4348c2f2 push     0x4b7c
4348c2f7 mov      esi, dword ptr [eax + 0x100]
4348c2fd call     0x434938fb
4348c302 push     6
4348c304 push     eax
4348c305 mov      ecx, esi
4348c307 call     0x433f8d73
4348c30c mov      eax, dword ptr [esp + 0xc]
4348c310 push     0x4bd4
4348c315 mov      esi, dword ptr [eax + 0x100]
4348c31b call     0x434938fb
4348c320 push     7
4348c322 push     eax
4348c323 mov      ecx, esi
4348c325 call     0x433f8d73
4348c32a mov      eax, dword ptr [esp + 0xc]
4348c32e push     0x4bc4
4348c333 mov      esi, dword ptr [eax + 0x100]
4348c339 call     0x434938fb
4348c33e push     8
4348c340 push     eax
4348c341 mov      ecx, esi
4348c343 call     0x433f8d73
4348c348 mov      eax, dword ptr [esp + 0xc]
4348c34c push     0x4bb4
4348c351 mov      esi, dword ptr [eax + 0x100]
4348c357 call     0x434938fb
4348c35c push     9
4348c35e push     eax
4348c35f mov      ecx, esi
4348c361 call     0x433f8d73
4348c366 mov      eax, dword ptr [esp + 0xc]
4348c36a push     0x4bac
4348c36f mov      esi, dword ptr [eax + 0x100]
4348c375 call     0x434938fb
4348c37a push     0xa
4348c37c push     eax
4348c37d mov      ecx, esi
4348c37f call     0x433f8d73
4348c384 mov      eax, dword ptr [esp + 0xc]
4348c388 push     0x4c04
4348c38d mov      esi, dword ptr [eax + 0x100]
4348c393 call     0x434938fb
4348c398 push     0xb
4348c39a push     eax
4348c39b mov      ecx, esi
4348c39d call     0x433f8d73
4348c3a2 mov      eax, dword ptr [esp + 0xc]
4348c3a6 push     0x4bf8
4348c3ab mov      esi, dword ptr [eax + 0x100]
4348c3b1 call     0x434938fb
4348c3b6 push     0xc
4348c3b8 push     eax
4348c3b9 mov      ecx, esi
4348c3bb call     0x433f8d73
4348c3c0 mov      eax, dword ptr [esp + 0xc]
4348c3c4 push     0x4bf0
4348c3c9 mov      esi, dword ptr [eax + 0x100]
4348c3cf call     0x434938fb
4348c3d4 push     0xd
4348c3d6 push     eax
4348c3d7 mov      ecx, esi
4348c3d9 call     0x433f8d73
4348c3de mov      eax, dword ptr [esp + 0xc]
4348c3e2 push     0x4be0
4348c3e7 mov      esi, dword ptr [eax + 0x100]
4348c3ed call     0x434938fb
4348c3f2 push     0xe
4348c3f4 push     eax
4348c3f5 mov      ecx, esi
4348c3f7 call     0x433f8d73
4348c3fc mov      eax, dword ptr [esp + 0xc]
4348c400 push     0x4c2c
4348c405 mov      esi, dword ptr [eax + 0x100]
4348c40b call     0x434938fb
4348c410 push     0xf
4348c412 push     eax
4348c413 mov      ecx, esi
4348c415 call     0x433f8d73
4348c41a mov      eax, dword ptr [esp + 0xc]
4348c41e push     0x4c20
4348c423 mov      esi, dword ptr [eax + 0x100]
4348c429 call     0x434938fb
4348c42e push     0x10
4348c430 push     eax
4348c431 mov      ecx, esi
4348c433 call     0x433f8d73
4348c438 mov      eax, dword ptr [esp + 0xc]
4348c43c push     0x4c18
4348c441 mov      esi, dword ptr [eax + 0x100]
4348c447 call     0x434938fb
4348c44c push     0x11
4348c44e push     eax
4348c44f mov      ecx, esi
4348c451 call     0x433f8d73
4348c456 mov      eax, dword ptr [esp + 0xc]
4348c45a push     0x4c0c
4348c45f mov      esi, dword ptr [eax + 0x100]
4348c465 call     0x434938fb
4348c46a push     0x12
4348c46c push     eax
4348c46d mov      ecx, esi
4348c46f call     0x433f8d73
4348c474 mov      esi, dword ptr [esp + 0xc]
4348c478 push     ebx
4348c479 mov      ecx, dword ptr [esi + 0x100]
4348c47f call     0x433e000b
4348c484 mov      edx, dword ptr [esi + 0xfc]
4348c48a mov      ecx, dword ptr [esi + 0x100]
4348c490 add      edx, 0x70
4348c493 add      ecx, 4
4348c496 push     0x4c64
4348c49b mov      eax, dword ptr [edx + 4]
4348c49e mov      dword ptr [ecx], edx
4348c4a0 mov      dword ptr [ecx + 4], eax
4348c4a3 mov      dword ptr [eax], ecx
4348c4a5 mov      dword ptr [edx + 4], ecx
4348c4a8 mov      esi, dword ptr [esi + 0xa8]
4348c4ae call     0x434938ff
4348c4b3 push     esi
4348c4b4 push     eax
4348c4b5 mov      ecx, edi
4348c4b7 call     0x43486bb2
4348c4bc mov      esi, dword ptr [esp + 0xc]
4348c4c0 lea      ecx, [esp + 0x1e8]
4348c4c7 push     ecx
4348c4c8 mov      dword ptr [esp + 0x1ec], esi
4348c4cf lea      ecx, [eax + 0x40]
4348c4d2 mov      dword ptr [esp + 0x1f0], 0x433d66b5
4348c4dd mov      dword ptr [esi + 0xf0], eax
4348c4e3 call     0x433c081c
4348c4e8 push     dword ptr [esi + 0xb0]
4348c4ee mov      ecx, edi
4348c4f0 push     0x434745b8
4348c4f5 call     0x4347ea53
4348c4fa mov      dword ptr [esi + 0xf4], eax
4348c500 lea      ecx, [esp + 0x1f0]
4348c507 mov      dword ptr [esp + 0x1f0], esi
4348c50e mov      dword ptr [esp + 0x1f4], 0x4333cea9
4348c519 push     ecx
4348c51a lea      ecx, [eax + 0x40]
4348c51d call     0x433c081c
4348c522 push     dword ptr [esi + 0xb8]
4348c528 mov      ecx, edi
4348c52a push     0x434745b8
4348c52f call     0x4347ea53
4348c534 lea      ecx, [esp + 0x1f8]
4348c53b mov      dword ptr [esi + 0xf8], eax
4348c541 push     ecx
4348c542 mov      dword ptr [esp + 0x1fc], esi
4348c549 lea      ecx, [eax + 0x40]
4348c54c mov      dword ptr [esp + 0x200], 0x433cce8e
4348c557 call     0x433c081c
4348c55c mov      ecx, dword ptr [esi + 0xf4]
4348c562 push     ebx
4348c563 call     0x433e000b
4348c568 mov      ecx, dword ptr [esi + 0xf8]
4348c56e push     ebx
4348c56f call     0x433e000b
4348c574 mov      edx, dword ptr [esi + 0xf0]
4348c57a mov      ecx, dword ptr [esi + 0xf4]
4348c580 add      edx, 0x70
4348c583 add      ecx, 4
4348c586 push     0x4c48
4348c58b mov      eax, dword ptr [edx + 4]
4348c58e mov      dword ptr [ecx], edx
4348c590 mov      dword ptr [ecx + 4], eax
4348c593 mov      dword ptr [eax], ecx
4348c595 mov      dword ptr [edx + 4], ecx
4348c598 mov      edx, dword ptr [esi + 0xf0]
4348c59e mov      ecx, dword ptr [esi + 0xf8]
4348c5a4 add      edx, 0x70
4348c5a7 add      ecx, 4
4348c5aa mov      eax, dword ptr [edx + 4]
4348c5ad mov      dword ptr [ecx], edx
4348c5af mov      dword ptr [ecx + 4], eax
4348c5b2 mov      dword ptr [eax], ecx
4348c5b4 mov      dword ptr [edx + 4], ecx
4348c5b7 mov      esi, dword ptr [esi + 0x98]
4348c5bd call     0x434938ff
4348c5c2 push     esi
4348c5c3 push     eax
4348c5c4 mov      ecx, edi
4348c5c6 call     0x43486bb2
4348c5cb mov      esi, dword ptr [esp + 0xc]
4348c5cf mov      ecx, edi
4348c5d1 push     dword ptr [esi + 0xa0]
4348c5d7 mov      dword ptr [esi + 0x104], eax
4348c5dd push     0x434745b8
4348c5e2 call     0x4347ea53
4348c5e7 push     0x16
4348c5e9 mov      dword ptr [esi + 0x108], eax
4348c5ef lea      ecx, [eax + 0x7c]
4348c5f2 call     0x433ccb69
4348c5f7 mov      esi, dword ptr [esi + 0x108]
4348c5fd push     0x4c40
4348c602 call     0x434938fb
4348c607 push     ebx
4348c608 push     eax
4348c609 mov      ecx, esi
4348c60b call     0x433f8d73
4348c610 mov      eax, dword ptr [esp + 0xc]
4348c614 push     0x4c38
4348c619 mov      esi, dword ptr [eax + 0x108]
4348c61f call     0x434938fb
4348c624 push     1
4348c626 push     eax
4348c627 mov      ecx, esi
4348c629 call     0x433f8d73
4348c62e mov      eax, dword ptr [esp + 0xc]
4348c632 push     0x4c98
4348c637 mov      esi, dword ptr [eax + 0x108]
4348c63d call     0x434938fb
4348c642 push     3
4348c644 push     eax
4348c645 mov      ecx, esi
4348c647 call     0x433f8d73
4348c64c mov      eax, dword ptr [esp + 0xc]
4348c650 push     0x4c90
4348c655 mov      esi, dword ptr [eax + 0x108]
4348c65b call     0x434938fb
4348c660 push     4
4348c662 push     eax
4348c663 mov      ecx, esi
4348c665 call     0x433f8d73
4348c66a mov      eax, dword ptr [esp + 0xc]
4348c66e push     0x4c88
4348c673 mov      esi, dword ptr [eax + 0x108]
4348c679 call     0x434938fb
4348c67e push     5
4348c680 push     eax
4348c681 mov      ecx, esi
4348c683 call     0x433f8d73
4348c688 mov      eax, dword ptr [esp + 0xc]
4348c68c push     0x4c80
4348c691 mov      esi, dword ptr [eax + 0x108]
4348c697 call     0x434938fb
4348c69c push     6
4348c69e push     eax
4348c69f mov      ecx, esi
4348c6a1 call     0x433f8d73
4348c6a6 mov      eax, dword ptr [esp + 0xc]
4348c6aa push     0x4cc0
4348c6af mov      esi, dword ptr [eax + 0x108]
4348c6b5 call     0x434938fb
4348c6ba push     7
4348c6bc push     eax
4348c6bd mov      ecx, esi
4348c6bf call     0x433f8d73
4348c6c4 mov      eax, dword ptr [esp + 0xc]
4348c6c8 push     0x4cb4
4348c6cd mov      esi, dword ptr [eax + 0x108]
4348c6d3 call     0x434938fb
4348c6d8 push     8
4348c6da push     eax
4348c6db mov      ecx, esi
4348c6dd call     0x433f8d73
4348c6e2 mov      eax, dword ptr [esp + 0xc]
4348c6e6 push     0x4ca8
4348c6eb mov      esi, dword ptr [eax + 0x108]
4348c6f1 call     0x434938fb
4348c6f6 push     9
4348c6f8 push     eax
4348c6f9 mov      ecx, esi
4348c6fb call     0x433f8d73
4348c700 mov      eax, dword ptr [esp + 0xc]
4348c704 push     0x4ca0
4348c709 mov      esi, dword ptr [eax + 0x108]
4348c70f call     0x434938fb
4348c714 push     0xa
4348c716 push     eax
4348c717 mov      ecx, esi
4348c719 call     0x433f8d73
4348c71e mov      eax, dword ptr [esp + 0xc]
4348c722 push     0x4cec
4348c727 mov      esi, dword ptr [eax + 0x108]
4348c72d call     0x434938fb
4348c732 push     0xb
4348c734 push     eax
4348c735 mov      ecx, esi
4348c737 call     0x433f8d73
4348c73c mov      eax, dword ptr [esp + 0xc]
4348c740 push     0x4cdc
4348c745 mov      esi, dword ptr [eax + 0x108]
4348c74b call     0x434938fb
4348c750 push     0xc
4348c752 push     eax
4348c753 mov      ecx, esi
4348c755 call     0x433f8d73
4348c75a mov      eax, dword ptr [esp + 0xc]
4348c75e push     0x4cd4
4348c763 mov      esi, dword ptr [eax + 0x108]
4348c769 call     0x434938fb
4348c76e push     0xd
4348c770 push     eax
4348c771 mov      ecx, esi
4348c773 call     0x433f8d73
4348c778 mov      eax, dword ptr [esp + 0xc]
4348c77c push     0x4ccc
4348c781 mov      esi, dword ptr [eax + 0x108]
4348c787 call     0x434938fb
4348c78c push     0xe
4348c78e push     eax
4348c78f mov      ecx, esi
4348c791 call     0x433f8d73
4348c796 mov      eax, dword ptr [esp + 0xc]
4348c79a push     0x4d10
4348c79f mov      esi, dword ptr [eax + 0x108]
4348c7a5 call     0x434938fb
4348c7aa push     0xf
4348c7ac push     eax
4348c7ad mov      ecx, esi
4348c7af call     0x433f8d73
4348c7b4 mov      eax, dword ptr [esp + 0xc]
4348c7b8 push     0x4d08
4348c7bd mov      esi, dword ptr [eax + 0x108]
4348c7c3 call     0x434938fb
4348c7c8 push     0x10
4348c7ca push     eax
4348c7cb mov      ecx, esi
4348c7cd call     0x433f8d73
4348c7d2 mov      eax, dword ptr [esp + 0xc]
4348c7d6 push     0x4d00
4348c7db mov      esi, dword ptr [eax + 0x108]
4348c7e1 call     0x434938fb
4348c7e6 push     0x11
4348c7e8 push     eax
4348c7e9 mov      ecx, esi
4348c7eb call     0x433f8d73
4348c7f0 mov      eax, dword ptr [esp + 0xc]
4348c7f4 push     0x4cf4
4348c7f9 mov      esi, dword ptr [eax + 0x108]
4348c7ff call     0x434938fb
4348c804 push     0x12
4348c806 push     eax
4348c807 mov      ecx, esi
4348c809 call     0x433f8d73
4348c80e mov      eax, dword ptr [esp + 0xc]
4348c812 push     0x4d48
4348c817 mov      esi, dword ptr [eax + 0x108]
4348c81d call     0x434938fb
4348c822 push     0x13
4348c824 push     eax
4348c825 mov      ecx, esi
4348c827 call     0x433f8d73
4348c82c mov      eax, dword ptr [esp + 0xc]
4348c830 push     0x4d40
4348c835 mov      esi, dword ptr [eax + 0x108]
4348c83b call     0x434938fb
4348c840 push     0x14
4348c842 push     eax
4348c843 mov      ecx, esi
4348c845 call     0x433f8d73
4348c84a mov      eax, dword ptr [esp + 0xc]
4348c84e push     0x4d34
4348c853 mov      esi, dword ptr [eax + 0x108]
4348c859 call     0x434938fb
4348c85e push     0x15
4348c860 push     eax
4348c861 mov      ecx, esi
4348c863 call     0x433f8d73
4348c868 mov      esi, dword ptr [esp + 0xc]
4348c86c push     ebx
4348c86d mov      ecx, dword ptr [esi + 0x108]
4348c873 call     0x433e000b
4348c878 mov      edx, dword ptr [esi + 0x104]
4348c87e mov      ecx, dword ptr [esi + 0x108]
4348c884 add      edx, 0x70
4348c887 add      ecx, 4
4348c88a push     0x4d18
4348c88f mov      eax, dword ptr [edx + 4]
4348c892 mov      dword ptr [ecx], edx
4348c894 mov      dword ptr [ecx + 4], eax
4348c897 mov      dword ptr [eax], ecx
4348c899 mov      dword ptr [edx + 4], ecx
4348c89c mov      esi, dword ptr [esi + 0xc0]
4348c8a2 call     0x434938ff
4348c8a7 push     esi
4348c8a8 push     eax
4348c8a9 mov      ecx, edi
4348c8ab call     0x43486bb2
4348c8b0 mov      esi, dword ptr [esp + 0xc]
4348c8b4 mov      ecx, 0x3eb3f20b
4348c8b9 mov      dword ptr [esi + 0x10c], eax
4348c8bf call     0x433e7f74
4348c8c4 add      eax, 0x10
4348c8c7 mov      ecx, edi
4348c8c9 push     eax
4348c8ca push     0x434745b8
4348c8cf call     0x4347ea53
4348c8d4 mov      ecx, 0x8191d9bc
4348c8d9 mov      dword ptr [esi + 0x110], eax
4348c8df call     0x433e7f74
4348c8e4 add      eax, 0x10
4348c8e7 mov      ecx, edi
4348c8e9 push     eax
4348c8ea push     0x434745b8
4348c8ef call     0x4347ea53
4348c8f4 mov      ecx, dword ptr [esi + 0x10c]
4348c8fa mov      dword ptr [esi + 0x114], eax
4348c900 add      ecx, 0x40
4348c903 lea      eax, [esp + 0x200]
4348c90a mov      dword ptr [esp + 0x200], esi
4348c911 push     eax
4348c912 mov      dword ptr [esp + 0x208], 0x43384c8d
4348c91d call     0x433c081c
4348c922 mov      ecx, dword ptr [esi + 0x110]
4348c928 push     ebx
4348c929 call     0x433e000b
4348c92e mov      ecx, dword ptr [esi + 0x114]
4348c934 push     ebx
4348c935 call     0x433e000b
4348c93a mov      dword ptr [esi + 0xd8], edi
4348c940 cmp      edi, 0x1d
4348c943 jne      0x4348c951
4348c945 mov      cl, 0x5b
4348c951 push     0x4d84
4348c956 mov      dword ptr [esp + 0x14], 0x18000c0c
4348c95e call     0x434938ff
4348c963 mov      ecx, 0xc8
4348c968 mov      edi, eax
4348c96a call     0x43387448
4348c96f test     eax, eax
4348c971 je       0x4348c985
4348c973 push     ebx
4348c974 push     0xe
4348c976 push     dword ptr [esp + 0x18]
4348c97a mov      ecx, eax
4348c97c push     edi
4348c97d push     esi
4348c97e call     0x4348210c
4348c983 jmp      0x4348c987
4348c985 mov      eax, ebx
4348c987 push     eax
4348c988 mov      ecx, esi
4348c98a call     0x4347de9b
4348c98f push     1
4348c991 mov      edi, eax
4348c993 lea      eax, [esi + 0xe0]
4348c999 push     eax
4348c99a push     0x3e8
4348c99f push     ebx
4348c9a0 push     0x4d74
4348c9a5 call     0x434938ff
4348c9aa push     eax
4348c9ab mov      ecx, edi
4348c9ad call     0x43484978
4348c9b2 push     ebx
4348c9b3 mov      ecx, eax
4348c9b5 mov      dword ptr [esi + 0x118], eax
4348c9bb call     0x433e000b
4348c9c0 mov      ecx, dword ptr [esi + 0x118]
4348c9c6 lea      eax, [esp + 0x208]
4348c9cd push     eax
4348c9ce add      ecx, 0x40
4348c9d1 mov      dword ptr [esp + 0x20c], esi
4348c9d8 mov      dword ptr [esp + 0x210], 0x4332cc0c
4348c9e3 call     0x433c081c
4348c9e8 mov      esi, dword ptr [esi + 0x130]
4348c9ee push     0x4d64
4348c9f3 call     0x434938ff
4348c9f8 push     esi
4348c9f9 push     eax
4348c9fa mov      ecx, edi
4348c9fc call     0x43486bb2
4348ca01 mov      esi, dword ptr [esp + 0xc]
4348ca05 lea      ecx, [esp + 0x210]
4348ca0c push     ecx
4348ca0d mov      dword ptr [esp + 0x214], esi
4348ca14 lea      ecx, [eax + 0x40]
4348ca17 mov      dword ptr [esp + 0x218], 0x433e10cc
4348ca22 mov      dword ptr [esi + 0x11c], eax
4348ca28 call     0x433c081c
4348ca2d mov      esi, dword ptr [esi + 0x130]
4348ca33 push     0x4d50
4348ca38 inc      esi
4348ca39 call     0x434938ff
4348ca3e push     esi
4348ca3f push     eax
4348ca40 mov      ecx, edi
4348ca42 call     0x43486bb2
4348ca47 mov      ecx, dword ptr [esp + 0xc]
4348ca4b push     0x4dd8
4348ca50 mov      esi, dword ptr [ecx + 0x130]
4348ca56 mov      dword ptr [ecx + 0x120], eax
4348ca5c add      esi, 4
4348ca5f call     0x434938ff
4348ca64 push     0x25
4348ca66 push     1
4348ca68 push     esi
4348ca69 push     0x64
4348ca6b push     ebx
4348ca6c push     eax
4348ca6d mov      ecx, edi
4348ca6f call     0x43484e7d
4348ca74 mov      ecx, dword ptr [esp + 0xc]
4348ca78 push     0x4dcc
4348ca7d mov      esi, dword ptr [ecx + 0x130]
4348ca83 mov      dword ptr [ecx + 0x124], eax
4348ca89 add      esi, 8
4348ca8c call     0x434938ff
4348ca91 push     1
4348ca93 push     esi
4348ca94 push     0x3e8
4348ca99 push     ebx
4348ca9a push     eax
4348ca9b mov      ecx, edi
4348ca9d call     0x43484978
4348caa2 mov      ecx, dword ptr [esp + 0xc]
4348caa6 mov      dword ptr [ecx + 0x128], eax
4348caac mov      ecx, 0x9ab5333c
4348cab1 call     0x433e7f74
4348cab6 push     0x4da8
4348cabb lea      esi, [eax + 0x10]
4348cabe call     0x434938ff
4348cac3 push     esi
4348cac4 push     eax
4348cac5 mov      ecx, edi
4348cac7 call     0x43486bb2
4348cacc mov      esi, dword ptr [esp + 0xc]
4348cad0 lea      ecx, [esp + 0x218]
4348cad7 push     ecx
4348cad8 mov      dword ptr [esp + 0x21c], esi
4348cadf lea      ecx, [eax + 0x40]
4348cae2 mov      dword ptr [esp + 0x220], 0x433fd925
4348caed call     0x433c081c
4348caf2 mov      esi, dword ptr [esi + 0x130]
4348caf8 push     0x4d9c
4348cafd add      esi, 0xc
4348cb00 call     0x434938ff
4348cb05 push     0x142
4348cb0a push     0x9e
4348cb0f push     esi
4348cb10 push     eax
4348cb11 mov      ecx, edi
4348cb13 call     0x43486ff9
4348cb18 mov      esi, dword ptr [esp + 0xc]
4348cb1c lea      ecx, [esp + 0x220]
4348cb23 push     ecx
4348cb24 mov      dword ptr [esp + 0x224], esi
4348cb2b lea      ecx, [eax + 0x40]
4348cb2e mov      dword ptr [esp + 0x228], 0x43406ed3
4348cb39 mov      dword ptr [esi + 0x12c], eax
4348cb3f call     0x433c081c
4348cb44 mov      dword ptr [esi + 0xdc], edi
4348cb4a mov      edi, dword ptr [esp + 0x18]
4348cb4e jmp      0x4348cb52
4348cb50 mov      esi, ebx
4348cb52 push     esi
4348cb53 mov      ecx, edi
4348cb55 call     0x43342275
4348cb5a mov      ecx, 0xd8
4348cb5f mov      dword ptr [edi + 0xc4], eax
4348cb65 call     0x43387448
4348cb6a mov      edi, eax
4348cb6c mov      dword ptr [esp + 0x10], edi
4348cb70 test     edi, edi
4348cb72 je       0x4348cf2c
4348cb78 lea      eax, [esp + 0x20]
4348cb7c push     eax
4348cb7d push     0x2530
4348cb82 call     0x434938ff
4348cb87 push     eax
4348cb88 push     dword ptr [esp + 0x20]
4348cb8c mov      ecx, edi
4348cb8e call     0x4348e41d
4348cb93 push     0x4924
4348cb98 mov      dword ptr [edi], 0x43471fcc
4348cb9e mov      dword ptr [edi + 0x98], ebx
4348cba4 mov      dword ptr [esp + 0x10], 0x18000c00
4348cbac call     0x434938ff
4348cbb1 mov      ecx, 0xc8
4348cbb6 mov      esi, eax
4348cbb8 call     0x43387448
4348cbbd test     eax, eax
4348cbbf je       0x4348cbd3
4348cbc1 push     1
4348cbc3 push     ebx
4348cbc4 push     dword ptr [esp + 0x14]
4348cbc8 mov      ecx, eax
4348cbca push     esi
4348cbcb push     edi
4348cbcc call     0x4348210c
4348cbd1 jmp      0x4348cbd5
4348cbd3 mov      eax, ebx
4348cbd5 push     eax
4348cbd6 mov      ecx, edi
4348cbd8 call     0x4347de9b
4348cbdd push     0x490c
4348cbe2 mov      esi, eax
4348cbe4 call     0x434938ff
4348cbe9 push     0x1a9
4348cbee push     0x9e
4348cbf3 push     ebx
4348cbf4 lea      ecx, [edi + 0x98]
4348cbfa push     ecx
4348cbfb push     eax
4348cbfc mov      ecx, esi
4348cbfe call     0x434859b4
4348cc03 lea      ecx, [esp + 0x228]
4348cc0a mov      dword ptr [edi + 0xa4], eax
4348cc10 push     ecx
4348cc11 mov      dword ptr [esp + 0x22c], edi
4348cc18 lea      ecx, [eax + 0x40]
4348cc1b mov      dword ptr [esp + 0x230], 0x4336b1d5
4348cc26 call     0x433c081c
4348cc2b push     0x48f8
4348cc30 call     0x434938ff
4348cc35 push     ecx
4348cc36 push     ecx
4348cc37 mov      ecx, esp
4348cc39 push     eax
4348cc3a mov      dword ptr [ecx], edi
4348cc3c mov      dword ptr [ecx + 4], 0x4337f167
4348cc43 mov      ecx, esi
4348cc45 call     0x4347e840
4348cc4a mov      dword ptr [edi + 0xa8], eax
4348cc50 mov      dword ptr [edi + 0x9c], esi
4348cc56 cmp      esi, 0xac
4348cc5c jne      0x4348cc6a
4348cc5e push     edi
4348cc60 lodsd    eax, dword ptr [esi]
4348cc61 pop      ebx
4348cc62 insd     dword ptr es:[edi], dx
4348cc63 cld      
4348cc64 cmp      eax, 0x4564b84c
4348cc69 salc     
4348cc6a push     0x49ac
4348cc6f mov      dword ptr [esp + 0x10], 0x18000c0c
4348cc77 call     0x434938ff
4348cc7c mov      ecx, 0xc8
4348cc81 mov      esi, eax
4348cc83 call     0x43387448
4348cc88 test     eax, eax
4348cc8a je       0x4348cca3
4348cc8c push     1
4348cc8e push     0xd
4348cc90 push     dword ptr [esp + 0x14]
4348cc94 mov      ecx, eax
4348cc96 push     esi
4348cc97 mov      esi, dword ptr [esp + 0x20]
4348cc9b push     esi
4348cc9c call     0x4348210c
4348cca1 jmp      0x4348cca9
4348cca3 mov      esi, dword ptr [esp + 0x10]
4348cca7 mov      eax, ebx
4348cca9 push     eax
4348ccaa mov      ecx, esi
4348ccac call     0x4347de9b
4348ccb1 push     0x4988
4348ccb6 mov      edi, eax
4348ccb8 call     0x434938ff
4348ccbd push     eax
4348ccbe mov      ecx, edi
4348ccc0 call     0x4347e7a8
4348ccc5 push     0x4954
4348ccca mov      dword ptr [esi + 0xac], eax
4348ccd0 call     0x434938ff
4348ccd5 push     eax
4348ccd6 mov      ecx, edi
4348ccd8 call     0x4347e7a8
4348ccdd push     0x4934
4348cce2 mov      dword ptr [esi + 0xb0], eax
4348cce8 call     0x434938ff
4348cced push     eax
4348ccee mov      ecx, edi
4348ccf0 call     0x4347e7a8
4348ccf5 push     0x4a20
4348ccfa mov      dword ptr [esi + 0xb4], eax
4348cd00 call     0x434938ff
4348cd05 push     eax
4348cd06 mov      ecx, edi
4348cd08 call     0x4347e7a8
4348cd0d push     0x4a08
4348cd12 mov      dword ptr [esi + 0xb8], eax
4348cd18 call     0x434938ff
4348cd1d push     eax
4348cd1e mov      ecx, edi
4348cd20 call     0x4347e7a8
4348cd25 push     0xb0
4348cd2a push     1
4348cd2c push     ebx
4348cd2d push     0x5a
4348cd2f push     -0x5a
4348cd31 push     0x49e4
4348cd36 mov      dword ptr [esi + 0xbc], eax
4348cd3c call     0x434938ff
4348cd41 push     eax
4348cd42 mov      ecx, edi
4348cd44 call     0x43485039
4348cd49 push     ebx
4348cd4a mov      ecx, eax
4348cd4c mov      dword ptr [esi + 0xc0], eax
4348cd52 call     0x433e000b
4348cd57 mov      edx, dword ptr [esi + 0xbc]
4348cd5d mov      ecx, dword ptr [esi + 0xc0]
4348cd63 add      edx, 0x70
4348cd66 add      ecx, 4
4348cd69 push     0x49c4
4348cd6e mov      eax, dword ptr [edx + 4]
4348cd71 mov      dword ptr [ecx], edx
4348cd73 mov      dword ptr [ecx + 4], eax
4348cd76 mov      dword ptr [eax], ecx
4348cd78 mov      dword ptr [edx + 4], ecx
4348cd7b call     0x434938ff
4348cd80 push     eax
4348cd81 mov      ecx, edi
4348cd83 call     0x4347e7a8
4348cd88 push     0xb0
4348cd8d push     1
4348cd8f push     ebx
4348cd90 push     0x3c
4348cd92 push     -0x3c
4348cd94 push     0x4a98
4348cd99 mov      dword ptr [esi + 0xc4], eax
4348cd9f call     0x434938ff
4348cda4 push     eax
4348cda5 mov      ecx, edi
4348cda7 call     0x43485039
4348cdac push     ebx
4348cdad mov      ecx, eax
4348cdaf mov      dword ptr [esi + 0xc8], eax
4348cdb5 call     0x433e000b
4348cdba mov      edx, dword ptr [esi + 0xc4]
4348cdc0 mov      ecx, dword ptr [esi + 0xc8]
4348cdc6 add      edx, 0x70
4348cdc9 add      ecx, 4
4348cdcc mov      eax, dword ptr [edx + 4]
4348cdcf mov      dword ptr [ecx], edx
4348cdd1 mov      dword ptr [ecx + 4], eax
4348cdd4 push     0x4a74
4348cdd9 mov      dword ptr [eax], ecx
4348cddb mov      dword ptr [edx + 4], ecx
4348cdde call     0x434938ff
4348cde3 push     eax
4348cde4 mov      ecx, edi
4348cde6 call     0x4347e7a8
4348cdeb push     0x4a40
4348cdf0 mov      dword ptr [esi + 0xcc], eax
4348cdf6 call     0x434938ff
4348cdfb push     eax
4348cdfc mov      ecx, edi
4348cdfe call     0x434909b1
4348ce03 push     4
4348ce05 mov      dword ptr [esi + 0xd0], eax
4348ce0b lea      ecx, [eax + 0x7c]
4348ce0e call     0x433ccb69
4348ce13 mov      esi, dword ptr [esi + 0xd0]
4348ce19 push     0x4a3c
4348ce1e call     0x434938fb
4348ce23 push     ebx
4348ce24 push     eax
4348ce25 mov      ecx, esi
4348ce27 call     0x433f8d73
4348ce2c mov      esi, dword ptr [esp + 0x10]
4348ce30 push     0x4af8
4348ce35 mov      esi, dword ptr [esi + 0xd0]
4348ce3b call     0x434938fb
4348ce40 push     1
4348ce42 push     eax
4348ce43 mov      ecx, esi
4348ce45 call     0x433f8d73
4348ce4a mov      eax, dword ptr [esp + 0x10]
4348ce4e push     0x4af4
4348ce53 mov      esi, dword ptr [eax + 0xd0]
4348ce59 call     0x434938fb
4348ce5e push     2
4348ce60 push     eax
4348ce61 mov      ecx, esi
4348ce63 call     0x433f8d73
4348ce68 mov      eax, dword ptr [esp + 0x10]
4348ce6c push     0x4aec
4348ce71 mov      esi, dword ptr [eax + 0xd0]
4348ce77 call     0x434938fb
4348ce7c push     3
4348ce7e push     eax
4348ce7f mov      ecx, esi
4348ce81 call     0x433f8d73
4348ce86 push     0x4ac4
4348ce8b call     0x434938ff
4348ce90 push     eax
4348ce91 mov      ecx, edi
4348ce93 call     0x434909b1
4348ce98 mov      esi, dword ptr [esp + 0x10]
4348ce9c push     3
4348ce9e lea      ecx, [eax + 0x7c]
4348cea1 mov      dword ptr [esi + 0xd4], eax
4348cea7 call     0x433ccb69
4348ceac mov      esi, dword ptr [esi + 0xd4]
4348ceb2 push     0x4b20
4348ceb7 call     0x434938fb
4348cebc push     ebx
4348cebd push     eax
4348cebe mov      ecx, esi
4348cec0 call     0x433f8d73
4348cec5 mov      eax, dword ptr [esp + 0x10]
4348cec9 push     0x4b1c
4348cece mov      esi, dword ptr [eax + 0xd4]
4348ced4 call     0x434938fb
4348ced9 push     1
4348cedb push     eax
4348cedc mov      ecx, esi
4348cede call     0x433f8d73
4348cee3 mov      eax, dword ptr [esp + 0x10]
4348cee7 push     0x4b18
4348ceec mov      esi, dword ptr [eax + 0xd4]
4348cef2 call     0x434938fb
4348cef7 push     2
4348cef9 push     eax
4348cefa mov      ecx, esi
4348cefc call     0x433f8d73
4348cf01 push     0x4afc
4348cf06 call     0x434938ff
4348cf0b mov      esi, dword ptr [esp + 0x10]
4348cf0f push     ecx
4348cf10 push     ecx
4348cf11 mov      ecx, esp
4348cf13 push     eax
4348cf14 mov      dword ptr [ecx], esi
4348cf16 mov      dword ptr [ecx + 4], 0x4336bc51
4348cf1d mov      ecx, edi
4348cf1f call     0x4347e840
4348cf24 mov      dword ptr [esi + 0xa0], edi
4348cf2a jmp      0x4348cf2e
4348cf2c mov      esi, ebx
4348cf2e push     esi
4348cf2f mov      esi, dword ptr [esp + 0x1c]
4348cf33 mov      ecx, esi
4348cf35 call     0x43342275
4348cf3a mov      ecx, 0xd4
4348cf3f mov      dword ptr [esi + 0xc8], eax
4348cf45 call     0x43387448
4348cf4a mov      edi, eax
4348cf4c mov      dword ptr [esp + 0xc], edi
4348cf50 test     edi, edi
4348cf52 je       0x4348d30c
4348cf58 lea      eax, [esp + 0x20]
4348cf5c push     eax
4348cf5d push     0x24f4
4348cf62 call     0x434938ff
4348cf67 push     eax
4348cf68 push     esi
4348cf69 mov      ecx, edi
4348cf6b call     0x4348e41d
4348cf70 mov      dword ptr [edi], 0x4346f6dc
4348cf76 push     0x4df8
4348cf7b mov      dword ptr [edi + 0x98], ebx
4348cf81 mov      dword ptr [edi + 0x9c], ebx
4348cf87 mov      dword ptr [edi + 0xa0], ebx
4348cf8d mov      dword ptr [esp + 0x14], 0x18000c00
4348cf95 call     0x434938ff
4348cf9a mov      ecx, 0xc8
4348cf9f mov      esi, eax
4348cfa1 call     0x43387448
4348cfa6 test     eax, eax
4348cfa8 je       0x4348cfbd
4348cfaa push     1
4348cfac push     8
4348cfae push     dword ptr [esp + 0x18]
4348cfb2 mov      ecx, eax
4348cfb4 push     esi
4348cfb5 push     edi
4348cfb6 call     0x4348210c
4348cfbb mov      ebx, eax
4348cfbd push     ebx
4348cfbe mov      ecx, edi
4348cfc0 call     0x4347de9b
4348cfc5 int3     
4348d30c mov      edi, ebx
4348d30e push     edi
4348d30f mov      ecx, esi
4348d311 call     0x43342275
4348d316 mov      ecx, 0x98
4348d31b mov      dword ptr [esi + 0xd0], eax
4348d321 call     0x43387448
4348d326 mov      edi, eax
4348d328 test     edi, edi
4348d32a je       0x4348d346
4348d32c push     0x4f70
4348d331 call     0x434938ff
4348d336 lea      ecx, [esp + 0x20]
4348d33a push     ecx
4348d33b push     eax
4348d33c push     esi
4348d33d mov      ecx, edi
4348d33f call     0x4348e41d
4348d344 jmp      0x4348d348
4348d346 mov      eax, ebx
4348d348 push     eax
4348d349 mov      ecx, esi
4348d34b call     0x43342275
4348d350 mov      edi, eax
4348d352 mov      dword ptr [esp + 0x14], 0x18000c00
4348d35a push     0x4f6c
4348d35f mov      dword ptr [esi + 0xd4], edi
4348d365 call     0x434938ff
4348d36a mov      ecx, 0xc8
4348d36f mov      dword ptr [esp + 0x1c], eax
4348d373 call     0x43387448
4348d378 test     eax, eax
4348d37a je       0x4348d391
4348d37c push     1
4348d37e push     ebx
4348d37f push     dword ptr [esp + 0x1c]
4348d383 mov      ecx, eax
4348d385 push     dword ptr [esp + 0x28]
4348d389 push     edi
4348d38a call     0x4348210c
4348d38f jmp      0x4348d393
4348d391 mov      eax, ebx
4348d393 push     eax
4348d394 mov      ecx, edi
4348d396 call     0x4347de9b
4348d39b mov      edi, dword ptr [esi + 0xd4]
4348d3a1 push     0x4f68
4348d3a6 mov      dword ptr [esp + 0x18], 0x18000c0c
4348d3ae call     0x434938ff
4348d3b3 mov      ecx, 0xc8
4348d3b8 mov      dword ptr [esp + 0x1c], eax
4348d3bc call     0x43387448
4348d3c1 test     eax, eax
4348d3c3 je       0x4348d3da
4348d3c5 push     1
4348d3c7 push     ebx
4348d3c8 push     dword ptr [esp + 0x1c]
4348d3cc mov      ecx, eax
4348d3ce push     dword ptr [esp + 0x28]
4348d3d2 push     edi
4348d3d3 call     0x4348210c
4348d3d8 jmp      0x4348d3dc
4348d3da mov      eax, ebx
4348d3dc push     eax
4348d3dd mov      ecx, edi
4348d3df call     0x4347de9b
4348d3e4 mov      ecx, dword ptr [esi + 0xd4]
4348d3ea push     ebx
4348d3eb call     0x433e000b
4348d3f0 mov      ecx, dword ptr [esi + 0xc4]
4348d3f6 call     0x433cd70e
4348d3fb mov      ecx, dword ptr [esi + 0xd4]
4348d401 mov      eax, dword ptr [ecx]
4348d403 call     dword ptr [eax + 0x24]
4348d406 pop      edi
4348d407 pop      esi
4348d408 pop      ebx
4348d409 mov      esp, ebp
4348d40b pop      ebp
4348d40c ret      
