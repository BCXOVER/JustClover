434058e0 ucomiss  xmm0, dword ptr [ecx + 0x1ac]
434058e7 lahf     
434058e8 test     ah, 0x44
434058eb jp       0x434059af
434058f1 mov      ecx, dword ptr [0x43479798]
434058f7 xor      esi, esi
434058f9 mov      eax, dword ptr [0x43479794]
434058fe mov      byte ptr [0x43468d7c], 1
43405905 test     ecx, ecx
43405907 je       0x43405930
43405909 add      eax, esi
4340590b xor      edx, edx
4340590d div      dword ptr [esp + 0x48]
43405911 cmp      byte ptr [edx + 0x4347979c], 0
43405918 je       0x43405926
4340591a mov      eax, dword ptr [0x43479794]
4340591f inc      esi
43405920 cmp      esi, ecx
43405922 jne      0x43405909
43405924 jmp      0x43405930
43405926 xor      ecx, ecx
43405928 xor      eax, eax
4340592a mov      dword ptr [0x43479798], ecx
43405930 push     3
43405932 pop      esi
43405933 cmp      ecx, esi
43405935 je       0x4340593e
43405937 inc      ecx
43405938 mov      dword ptr [0x43479798], ecx
4340593e add      eax, 2
43405941 xor      edx, edx
43405943 div      esi
43405945 mov      dword ptr [0x43479794], edx
4340594b mov      byte ptr [edx + 0x4347979c], 1
43405952 jmp      0x434059af
434059af cmp      byte ptr [esp + 0xf], 0
434059b4 je       0x43405a12
434059b6 mov      eax, dword ptr [esp + 0x10]
434059ba push     dword ptr [esp + 0x20]
434059be mov      ecx, dword ptr [eax + 0x54]
434059c1 call     0x433f0944
434059c6 mov      ecx, eax
434059c8 test     ecx, ecx
434059ca je       0x43405a12
434059cc test     edi, edi
434059ce jne      0x434059dc
434059d0 cmp      dh, byte ptr [0x48063d7c]
434059d6 xor      dword ptr [ebp + ecx*8 - 0x5e08bbe4], 0x1c
434059dc mov      eax, dword ptr [0x4346791c]
434059de jns      0x43405a26
434059e0 inc      ebx
434059e1 mov      edx, dword ptr [esp + 0x10]
434059e5 mov      eax, dword ptr [eax]
434059e7 xor      eax, dword ptr [0x43467bd4]
434059ed xor      eax, 0x7f5ed2d0
434059f2 mov      eax, dword ptr [eax + edi]
434059f5 mov      dword ptr [ecx + 0x40], eax
434059f8 mov      eax, dword ptr [edx + 0x24]
434059fb or       dword ptr [eax + 0xc], 0xffffffff
434059ff mov      eax, dword ptr [edx + 0x24]
43405a02 and      dword ptr [eax + 0x1c], 0
43405a06 mov      eax, dword ptr [edx + 0x24]
43405a09 mov      dword ptr [eax + 0x24], 1
43405a10 jmp      0x43405a16
43405a12 mov      edx, dword ptr [esp + 0x10]
43405a16 cmp      dword ptr [esp + 0x28], 0
43405a1b jg       0x43405a2b
43405a1d mov      eax, dword ptr [esp + 0x2c]
43405a21 cmp      eax, dword ptr [esp + 0x3c]
43405a25 je       0x43405c5d
43405a26 test     byte ptr [edx], dh
43405a28 add      al, byte ptr [eax]
43405a2a add      byte ptr [ebx + 0x74035472], cl
43405a2b mov      esi, dword ptr [edx + 0x54]
43405a2e add      esi, dword ptr [esp + 0x40]
43405a30 and      al, 0x40
43405a32 mov      ecx, dword ptr [esi + 0x8c]
43405a38 shr      ecx, 4
43405a3b and      ecx, 7
43405a3e test     edi, edi
43405a40 jne      0x43405a4e
43405a42 mov      dword ptr [esi - 0x32e60634], esi
43405a48 sub      dword ptr [ecx + esi], ecx
43405a4b xchg     ebx, eax
43405a4c jge      0x43405a12
43405a4e mov      eax, dword ptr [0x4346a41c]
43405a53 mov      eax, dword ptr [eax]
43405a55 xor      eax, dword ptr [0x43469260]
43405a5b xor      eax, 0xb5a66556
43405a60 mov      dword ptr [eax + edi], ecx
43405a63 test     edi, edi
43405a65 jne      0x43405a73
43405a67 inc      ebx
43405a68 lea      edi, [ebx + eax*2 - 0x55]
43405a6c xchg     edx, eax
43405a6d stc      
43405a6e sbb      byte ptr [edx - 0x5eddb7b0], al
43405a73 mov      eax, dword ptr [0x43468354]
43405a74 push     esp
43405a75 add      dword ptr [esi + 0x43], -0xd
43405a78 movss    xmm0, dword ptr [edx + 0x38]
43405a79 movups   xmm0, xmmword ptr [edx + 0x38]
43405a7d mov      eax, dword ptr [eax]
43405a7f xor      eax, dword ptr [0x4346852c]
43405a85 xor      eax, 0x66146802
43405a8a movss    xmm2, dword ptr [eax + edi]
43405a8f ucomiss  xmm0, xmm2
43405a92 lahf     
43405a93 test     ah, 0x44
43405a96 jp       0x43405aa5
43405a98 cmp      dword ptr [0x43467114], -1
43405a9f je       0x43405b9c
43405aa5 mov      ecx, dword ptr [0x4346794c]
43405aab or       dword ptr [0x43467114], 0xffffffff
43405ab2 xor      ecx, 0xc429e1bf
43405ab8 jmp      0x43405abc
43405aba mov      ecx, eax
43405abc mov      eax, dword ptr [ecx + 0x1c]
43405abf cmp      ecx, eax
43405ac1 jne      0x43405aba
43405ac3 movss    xmm0, dword ptr [ecx + 0x2c]
43405ac8 movss    dword ptr [esp + 0x58], xmm0
43405ace xor      dword ptr [esp + 0x58], ecx
43405ad2 movss    xmm0, dword ptr [esp + 0x58]
43405ad8 ucomiss  xmm0, dword ptr [0x4346ee6c]
43405adf lahf     
43405ae0 test     ah, 0x44
43405ae3 jnp      0x43405b9c
43405ae9 push     dword ptr [esp + 0x20]
43405aed mov      ecx, dword ptr [edx + 0x54]
43405af0 call     0x433f0944
43405af5 mov      dword ptr [esp + 0x58], eax
43405af9 test     eax, eax
43405afb je       0x43405b9c
43405b01 test     edi, edi
43405b03 jne      0x43405b11
43405b05 inc      ecx
43405b06 xchg     ecx, eax
43405b07 push     edx
43405b08 add      eax, 0xa4a935d5
43405b0d xchg     ebp, eax
43405b0e cmp      dh, byte ptr fs:[edi - 0x2fa1f00d]
43405b11 divss    xmm2, xmm0
43405b15 movss    xmm1, dword ptr [eax + 0x10]
43405b1a movss    xmm0, dword ptr [0x4347275c]
43405b22 subss    xmm1, xmm2
43405b26 andps    xmm1, xmmword ptr [0x43470340]
43405b2d comiss   xmm0, xmm1
43405b30 jae      0x43405b9c
43405b32 movaps   xmm0, xmm2
43405b35 call     0x433e104f
43405b3a ucomiss  xmm0, dword ptr [esp + 0x5c]
43405b3f lahf     
43405b40 test     ah, 0x44
43405b43 jnp      0x43405b50
43405b45 mov      eax, dword ptr [esp + 0x20]
43405b49 mov      dword ptr [0x43467114], eax
43405b4e jmp      0x43405b9c
43405b50 test     edi, edi
43405b52 jne      0x43405b60
43405b54 dec      ebp
43405b55 push     esi
43405b56 lea      ecx, [edi]
43405b58 cmp      byte ptr [esi], al
43405b5a sal      dword ptr [esi + 0x3a], 1
43405b5d dec      esp
43405b5e or       ah, byte ptr [ecx]
43405b60 mov      eax, dword ptr [0x434682b8]
43405b61 mov      eax, 0x8b434682
43405b65 mov      ecx, dword ptr [esp + 0x10]
43405b66 dec      esp
43405b67 and      al, 0x10
43405b69 mov      eax, dword ptr [eax]
43405b6b xor      eax, dword ptr [0x43467d90]
43405b71 xor      eax, 0x1bae1168
43405b76 movss    dword ptr [eax + edi], xmm2
43405b7b mov      eax, dword ptr [esp + 0x58]
43405b7f movss    dword ptr [eax + 0x10], xmm2
43405b84 mov      eax, dword ptr [ecx + 0x24]
43405b87 or       dword ptr [eax + 0xc], 0xffffffff
43405b8b mov      eax, dword ptr [ecx + 0x24]
43405b8e and      dword ptr [eax + 0x1c], 0
43405b92 mov      eax, dword ptr [ecx + 0x24]
43405b95 mov      dword ptr [eax + 0x24], 1
43405b9c test     edi, edi
43405b9e jne      0x43405bac
43405ba0 xor      byte ptr [edx + 0x2c], ch
43405ba3 stosd    dword ptr es:[edi], eax
43405ba4 out      dx, al
43405ba5 adc      eax, 0xb5c7cf9
43405baa add      bl, byte ptr [ebx + 0x467a74a1]
43405bac mov      eax, dword ptr [0x43467a74]
43405bb0 inc      ebx
43405bb1 mov      eax, dword ptr [eax]
43405bb3 xor      eax, dword ptr [0x434678c0]
43405bb9 xor      eax, 0xcd812654
43405bbe mov      ecx, dword ptr [eax + edi]
43405bc1 cmp      ecx, -1
43405bc4 je       0x43405c0d
43405bc6 mov      eax, dword ptr [0x4346a890]
43405bcb push     ecx
43405bcc mov      eax, dword ptr [eax]
43405bce mov      edx, dword ptr [eax + 0x10]
43405bd1 mov      eax, esp
43405bd3 mov      dword ptr [eax], ecx
43405bd5 mov      ecx, dword ptr [0x4346a890]
43405bdb call     edx
43405bdd mov      dword ptr [esp + 0x5c], eax
43405be1 test     eax, eax
43405be3 je       0x43405c0d
43405be5 mov      edx, dword ptr [eax]
43405be7 mov      ecx, eax
43405be9 call     dword ptr [edx + 8]
43405bec mov      ecx, dword ptr [eax]
43405bee mov      dword ptr [esi + 0x5c], ecx
43405bf1 mov      eax, dword ptr [0x43467b44]
43405bf6 mov      ecx, dword ptr [esp + 0x5c]
43405bfa mov      eax, dword ptr [eax]
43405bfc xor      eax, dword ptr [0x4346a774]
43405c02 xor      eax, 0x6777c9ce
43405c07 mov      eax, dword ptr [eax + ecx]
43405c0a mov      dword ptr [esi + 0x48], eax
43405c0d test     edi, edi
43405c0f jne      0x43405c1d
43405c11 add      byte ptr [ecx + 0x13], dl
43405c14 mov      eax, 0x9d80d029
43405c19 mov      ah, 0xdf
43405c1b mov      al, 0xfe
43405c1d mov      eax, dword ptr [0x43468354]
43405c22 mov      eax, dword ptr [eax]
43405c24 xor      eax, dword ptr [0x4346852c]
43405c2a xor      eax, 0x66146802
43405c2f mov      eax, dword ptr [eax + edi]
43405c32 mov      dword ptr [esi + 0x50], eax
43405c35 test     edi, edi
43405c37 jne      0x43405c45
43405c39 inc      esp
43405c3a sal      dword ptr [ecx - 0x3e], 1
43405c3d ret      
43405c45 mov      eax, dword ptr [0x4346799c]
43405c4a mov      eax, dword ptr [eax]
43405c4c xor      eax, dword ptr [0x4346a2ec]
43405c52 xor      eax, 0xbcb263a5
43405c57 mov      al, byte ptr [eax + edi]
43405c5a mov      byte ptr [esi + 0x4c], al
43405c5d pop      edi
43405c5e pop      esi
43405c5f mov      esp, ebp
43405c61 pop      ebp
43405c62 ret      4
