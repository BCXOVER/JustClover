43344b4d push     esi
43344b4e mov      esi, dword ptr [esp + 8]
43344b52 cmp      dword ptr [esi + 4], 0x100
43344b59 jne      0x43344bb3
43344b5b mov      eax, dword ptr [esi + 8]
43344b5e cmp      eax, 8
43344b61 jne      0x43344b9a
43344b63 lea      esi, [ecx + 0x64]
43344b66 mov      eax, dword ptr [esi]
43344b68 test     eax, eax
43344b6a je       0x43344bfe
43344b70 call     0x4334dc45
43344b75 mov      eax, dword ptr [eax + 0x38]
43344b78 shr      eax, 3
43344b7b test     al, 1
43344b7d je       0x43344b92
43344b7f xor      eax, eax
43344b81 xchg     dword ptr [esi], eax
43344b83 jmp      0x43344bfe
43344b85 lea      ecx, [edx - 1]
43344b88 mov      eax, edx
43344b8a lock cmpxchg dword ptr [esi], ecx
43344b8e cmp      eax, edx
43344b90 je       0x43344bfe
43344b92 mov      edx, dword ptr [esi]
43344b94 test     edx, edx
43344b96 jne      0x43344b85
43344b98 jmp      0x43344bfe
43344b9a cmp      eax, 0x1b
43344b9d jne      0x43344bfe
43344b9f call     0x43330228
43344ba4 test     eax, eax
43344ba6 je       0x43344bfe
43344ba8 push     0
43344baa mov      ecx, eax
43344bac call     0x433b1444
43344bb1 jmp      0x43344bfe
43344bb3 cmp      dword ptr [esi + 4], 0x102
43344bba jne      0x43344c02
43344bbc mov      edx, dword ptr [esi + 8]
43344bbf lea      eax, [edx - 0x20]
43344bc2 cmp      eax, 0x5e
43344bc5 ja       0x43344bfe
43344bc7 cmp      edx, 0x60
43344bca je       0x43344bfe
43344bcc mov      eax, dword ptr [ecx + 0x64]
43344bcf cmp      eax, 0x3f
43344bd2 jae      0x43344bfe
43344bd4 movzx    esi, word ptr [esi + 8]
43344bd8 lea      edx, [ecx + 0x60]
43344bdb jmp      0x43344bdf
43344bdd pause    
43344bdf xor      eax, eax
43344be1 inc      eax
43344be2 xchg     dword ptr [edx], eax
43344be4 test     eax, eax
43344be6 jne      0x43344bdd
43344be8 lea      eax, [edx + 4]
43344beb mov      ecx, dword ptr [eax]
43344bed cmp      ecx, 0x3f
43344bf0 jae      0x43344bfa
43344bf2 mov      word ptr [edx + ecx*2 + 8], si
43344bf7 inc      ecx
43344bf8 xchg     dword ptr [eax], ecx
43344bfa xor      ecx, ecx
43344bfc xchg     dword ptr [edx], ecx
43344bfe mov      al, 1
43344c00 jmp      0x43344c04
43344c02 xor      al, al
43344c04 pop      esi
43344c05 ret      4
