4332325f push     esi
43323260 mov      esi, dword ptr [esp + 0xc]
43323264 push     edi
43323265 mov      edi, dword ptr [ecx + 4]
43323268 push     6
4332326a lea      eax, [edi + 0x18]
4332326d mov      dword ptr [ecx + 4], eax
43323270 pop      ecx
43323271 rep movsd dword ptr es:[edi], dword ptr [esi]
43323273 pop      edi
43323274 pop      esi
43323275 ret      8
