4332e7b0 inc      edi
4332e7b1 inc      ebx
4332e7b2 mulss    xmm0, dword ptr [0x43472240]
4332e7ba movss    dword ptr [esp + 0x2c], xmm0
4332e7c0 call     0x63c2ff20
4332e7c5 movss    xmm0, dword ptr [esp + 0x2c]
4332e7cb movss    dword ptr [esp], xmm0
4332e7d0 xorps    xmm0, xmmword ptr [0x434703d0]
4332e7d7 push     ecx
4332e7d8 movss    dword ptr [esp], xmm0
4332e7dd call     0x63c2ff40
4332e7e2 pop      ecx
4332e7e3 fstp     dword ptr [esp + 0x2c]
4332e7e7 movss    xmm1, dword ptr [esp + 0x2c]
4332e7ed pop      ecx
4332e7ee jmp      0x4332e827
4332e827 mov      eax, dword ptr [esp + 0x30]
4332e82b movss    xmm0, dword ptr [eax]
4332e82f addss    xmm0, xmm1
4332e833 movss    dword ptr [eax], xmm0
4332e837 test     byte ptr [esi], 0x40
4332e83a jne      0x4332ebbc
4332e840 mov      ecx, esi
4332e842 call     0x433b76be
4332e847 test     al, al
4332e849 mov      eax, dword ptr [ebp + 0xc]
4332e84c je       0x4332ebbf
4332e852 mov      eax, dword ptr [eax + 4]
4332e855 cmp      eax, dword ptr [0x434759f4]
4332e85b je       0x4332ebbc
4332e861 cmp      dword ptr [0x434685b8], 0
4332e868 je       0x4332ebbc
4332e86e mov      ecx, dword ptr [ebp + 8]
4332e871 test     ecx, ecx
4332e873 jne      0x4332e881
4332e875 and      byte ptr [edx + 0x6d], dl
4332e878 or       al, 0xf
4332e87a out      dx, al
4332e87b ljmp     0xa1a1:0xc572e052
4332e881 mov      eax, dword ptr [0x43467f4c]
4332e882 dec      esp
4332e883 jg       0x4332e8cb
4332e885 inc      ebx
4332e886 mov      eax, dword ptr [eax]
4332e888 xor      eax, dword ptr [0x4346a8b0]
4332e88e xor      eax, 0x3d52a1a7
4332e893 mov      ecx, dword ptr [eax + ecx]
4332e896 mov      dword ptr [esp + 0x14], ecx
4332e89a test     ecx, ecx
4332e89c jne      0x4332e8aa
4332e89e push     ds
4332e8aa mov      eax, dword ptr [esp + 0x30]
4332e8ae movss    xmm0, dword ptr [eax]
4332e8b2 mov      eax, dword ptr [0x434759cc]
4332e8b7 movss    dword ptr [esp + 0x18], xmm0
4332e8bd cmp      eax, dword ptr [esi + 0xac]
4332e8c3 jne      0x4332e92c
4332e8c5 cmp      byte ptr [0x43468410], 0
4332e8cb add      byte ptr [esi + ebx*2 - 0xd], dh
4332e8cc je       0x4332e92c
4332e8ce movss    xmm2, dword ptr [0x434759d4]
4332e8cf movups   xmm2, xmmword ptr [0x434759d4]
4332e8d6 xorps    xmm0, xmm0
4332e8d9 subss    xmm2, dword ptr [esi + 0xe0]
4332e8e1 movss    xmm1, dword ptr [0x434759d0]
4332e8e9 subss    xmm1, dword ptr [esi + 0xdc]
4332e8f1 ucomiss  xmm2, xmm0
4332e8f4 lahf     
4332e8f5 test     ah, 0x44
4332e8f8 jp       0x4332e903
4332e8fa ucomiss  xmm1, xmm0
4332e8fd lahf     
4332e8fe test     ah, 0x44
4332e901 jnp      0x4332e91e
4332e903 cvtps2pd xmm1, xmm1
4332e906 cvtps2pd xmm0, xmm2
4332e909 call     0x77509ee0
4332e90e mov      ecx, dword ptr [esp + 0x14]
4332e912 cvtsd2ss xmm0, xmm0
4332e916 mulss    xmm0, dword ptr [0x4346dd48]
4332e91e subss    xmm0, dword ptr [esi + 0xa0]
4332e926 movss    dword ptr [esp + 0x18], xmm0
4332e92c lea      eax, [esp + 0x24]
4332e930 push     eax
4332e931 lea      edx, [esp + 0x3c]
4332e935 call     0x433eaeeb
4332e93a mov      eax, dword ptr [ebp + 8]
4332e93d test     eax, eax
4332e93e sal      byte ptr [ebp + 0xc], 0xdf
4332e93f jne      0x4332e94d
4332e941 fisttp   word ptr [eax - 0x7a]
4332e942 dec      esp
4332e943 loopne   0x4332e8cb
4332e945 jno      0x4332e93e
4332e947 int3     
4332e94d movss    xmm0, dword ptr [esp + 0x24]
4332e953 push     ecx
4332e954 push     ecx
4332e955 movss    dword ptr [esp + 4], xmm0
4332e95b lea      ecx, [edi - 8]
4332e95e movss    xmm0, dword ptr [esp + 0x20]
4332e964 movss    dword ptr [esp], xmm0
4332e969 push     dword ptr [ebp + 0xc]
4332e96c push     eax
4332e96d push     esi
4332e96e call     0x43365675
4332e973 movss    xmm2, dword ptr [esp + 0x38]
4332e979 xorps    xmm1, xmm1
4332e97c mov      eax, dword ptr [esp + 0x14]
4332e980 movss    xmm1, xmm0
4332e984 movss    dword ptr [esp + 0x48], xmm0
4332e98a maxss    xmm1, xmm2
4332e98e movss    xmm0, dword ptr [esp + 0x24]
4332e994 minss    xmm1, xmm0
4332e998 movss    xmm0, dword ptr [esp + 0x18]
4332e99e subss    xmm0, xmm1
4332e9a2 movss    xmm1, dword ptr [eax + 0x80]
4332e9aa movss    dword ptr [esp + 0x40], xmm1
4332e9b0 movss    dword ptr [esp + 0x28], xmm0
4332e9b6 subss    xmm0, xmm1
4332e9ba cvtps2pd xmm0, xmm0
4332e9bd movsd    qword ptr [esp + 0x50], xmm0
4332e9c3 fld      qword ptr [esp + 0x50]
4332e9c7 fld      qword ptr [esp + 0x68]
4332e9cb call     0x7750834a
4332e9d0 movss    xmm5, dword ptr [esp + 0x40]
4332e9d6 movss    xmm4, dword ptr [esp + 0x28]
4332e9dc comiss   xmm4, xmm5
4332e9df movss    xmm6, dword ptr [0x434725e4]
4332e9e7 movss    xmm2, dword ptr [0x43471f88]
4332e9ef fstp     dword ptr [esp + 0x14]
4332e9f3 movss    xmm1, dword ptr [esp + 0x14]
4332e9f9 jbe      0x4332ea06
4332e9fb comiss   xmm1, xmm6
4332e9fe jb       0x4332ea17
4332ea00 subss    xmm1, xmm2
4332ea04 jmp      0x4332ea17
4332ea06 movss    xmm0, dword ptr [0x434724b4]
4332ea0e comiss   xmm0, xmm1
4332ea11 jb       0x4332ea17
4332ea13 addss    xmm1, xmm2
4332ea17 movss    xmm7, dword ptr [esp + 0x48]
4332ea1d cvttss2si eax, xmm7
4332ea21 test     eax, eax
4332ea23 je       0x4332ec28
4332ea29 movss    xmm3, dword ptr [esp + 0x18]
4332ea2f movaps   xmm4, xmm3
4332ea32 subss    xmm4, xmm5
4332ea36 ucomiss  xmm4, xmm4
4332ea39 movss    dword ptr [esp + 0x28], xmm4
4332ea3f lahf     
4332ea40 test     ah, 0x44
4332ea43 jnp      0x4332eacf
4332ea49 xorps    xmm4, xmm4
4332ea4c xorps    xmm2, xmm2
4332ea4f mov      eax, dword ptr [esi + 8]
4332ea52 cmp      byte ptr [eax], 0
4332ea55 jne      0x4332eb8e
4332ea5b mov      eax, dword ptr [esi + 0x15c]
4332ea61 cmp      eax, dword ptr [esi + 0xfc]
4332ea67 jge      0x4332eb8e
4332ea6d movss    xmm0, dword ptr [edi + 0x12c]
4332ea75 movaps   xmm1, xmm7
4332ea78 andps    xmm1, xmmword ptr [0x43470340]
4332ea7f movss    xmm6, dword ptr [edi + 0x14c]
4332ea87 movaps   xmm5, xmm1
4332ea8a movss    xmm1, dword ptr [edi + 0x130]
4332ea92 maxss    xmm5, xmm0
4332ea96 mulss    xmm6, dword ptr [esp + 0x24]
4332ea9c movaps   xmm0, xmm1
4332ea9f addss    xmm6, dword ptr [edi + 0x13c]
4332eaa7 minss    xmm5, xmm0
4332eaab movss    xmm0, dword ptr [edi + 0x12c]
4332eab3 ucomiss  xmm0, xmm1
4332eab6 lahf     
4332eab7 test     ah, 0x44
4332eaba jp       0x4332eb29
4332eabc comiss   xmm5, xmm1
4332eabf jae      0x4332eb49
4332eac5 movss    xmm6, dword ptr [edi + 0x134]
4332eacd jmp      0x4332eb49
4332eacf movss    xmm1, dword ptr [0x43470340]
4332ead7 movaps   xmm0, xmm4
4332eada andps    xmm0, xmm1
4332eadd comiss   xmm0, xmm6
4332eae0 jbe      0x4332ea4c
4332eae6 movaps   xmm0, xmm4
4332eae9 divss    xmm0, xmm2
4332eaed andps    xmm0, xmm1
4332eaf0 call     0x4341ad12
4332eaf5 movss    xmm4, dword ptr [esp + 0x28]
4332eafb xorps    xmm2, xmm2
4332eafe comiss   xmm2, xmm4
4332eb01 mulss    xmm0, dword ptr [0x43471f88]
4332eb09 movss    xmm3, dword ptr [esp + 0x18]
4332eb0f movss    xmm7, dword ptr [esp + 0x48]
4332eb15 jbe      0x4332eb20
4332eb17 addss    xmm4, xmm0
4332eb1b jmp      0x4332ea4f
4332eb20 subss    xmm4, xmm0
4332eb24 jmp      0x4332ea4f
4332eb29 subss    xmm6, dword ptr [edi + 0x134]
4332eb31 subss    xmm5, xmm0
4332eb35 subss    xmm1, xmm0
4332eb39 mulss    xmm6, xmm5
4332eb3d divss    xmm6, xmm1
4332eb41 addss    xmm6, dword ptr [edi + 0x134]
4332eb49 comiss   xmm7, xmm2
4332eb4c mov      eax, dword ptr [ebp + 0xc]
4332eb4f movaps   xmm0, xmm3
4332eb52 jbe      0x4332eb71
4332eb54 comiss   xmm4, xmm2
4332eb57 subss    xmm0, dword ptr [edi + 0x134]
4332eb5f movss    dword ptr [eax + 0x10], xmm0
4332eb64 jbe      0x4332ebbf
4332eb66 subss    xmm3, xmm6
4332eb6a movss    dword ptr [eax + 0x10], xmm3
4332eb6f jmp      0x4332ebbf
4332eb71 comiss   xmm2, xmm4
4332eb74 addss    xmm0, dword ptr [edi + 0x134]
4332eb7c movss    dword ptr [eax + 0x10], xmm0
4332eb81 jbe      0x4332ebbf
4332eb83 addss    xmm6, xmm3
4332eb87 movss    dword ptr [eax + 0x10], xmm6
4332eb8c jmp      0x4332ebbf
4332eb8e comiss   xmm7, xmm2
4332eb91 jbe      0x4332ebff
4332eb93 comiss   xmm2, xmm4
4332eb96 jbe      0x4332ebbc
4332eb98 mov      eax, dword ptr [esi + 0x15c]
4332eb9e cmp      eax, dword ptr [esi + 0xfc]
4332eba4 jge      0x4332ebbc
4332eba6 subss    xmm3, dword ptr [edi + 0x134]
4332ebae mov      eax, dword ptr [esp + 0x30]
4332ebb2 movss    dword ptr [eax], xmm3
4332ebb6 mov      eax, dword ptr [esi + 8]
4332ebb9 mov      byte ptr [eax], 0
4332ebbc mov      eax, dword ptr [ebp + 0xc]
4332ebbf movss    xmm3, dword ptr [0x43470340]
4332ebc7 movss    xmm1, dword ptr [eax + 0x10]
4332ebcc movss    xmm0, dword ptr [esi + 0x24]
4332ebd1 ucomiss  xmm0, xmm1
4332ebd4 movss    dword ptr [esp + 0x20], xmm1
4332ebda lahf     
4332ebdb test     ah, 0x44
4332ebde jnp      0x4332ee8f
4332ebe4 ucomiss  xmm1, xmm1
4332ebe7 movss    dword ptr [esp + 0x20], xmm1
4332ebed lahf     
4332ebee test     ah, 0x44
4332ebf1 jnp      0x4332ee3c
4332ebf7 xorps    xmm1, xmm1
4332ebfa jmp      0x4332ee81
4332ebff comiss   xmm4, xmm2
4332ec02 jbe      0x4332ebbc
4332ec04 mov      eax, dword ptr [esi + 0x15c]
4332ec0a cmp      eax, dword ptr [esi + 0xfc]
4332ec10 jge      0x4332ebbc
4332ec12 movss    xmm0, dword ptr [edi + 0x134]
4332ec1a mov      eax, dword ptr [esp + 0x30]
4332ec1e addss    xmm0, xmm3
4332ec22 movss    dword ptr [eax], xmm0
4332ec26 jmp      0x4332ebb6
4332ec28 movss    xmm3, dword ptr [0x43470340]
4332ec30 movaps   xmm0, xmm1
4332ec33 andps    xmm0, xmm3
4332ec36 comiss   xmm0, dword ptr [0x4346fd78]
4332ec3d jb       0x4332ee23
4332ec43 mov      eax, dword ptr [esi + 0x15c]
4332ec49 cmp      eax, dword ptr [esi + 0xfc]
4332ec4f jge      0x4332ee23
4332ec55 mov      eax, dword ptr [esi + 8]
4332ec58 xorps    xmm2, xmm2
4332ec5b comiss   xmm1, xmm2
4332ec5e mov      byte ptr [eax], 0
4332ec61 movss    xmm3, dword ptr [esp + 0x24]
4332ec67 jbe      0x4332ec6f
4332ec69 addss    xmm1, xmm3
4332ec6d jmp      0x4332ec73
4332ec6f subss    xmm1, xmm3
4332ec73 movaps   xmm0, xmm1
4332ec76 andps    xmm0, xmmword ptr [0x43470340]
4332ec7d comiss   xmm0, dword ptr [edi + 0x130]
4332ec84 jbe      0x4332ee0a
4332ec8a movss    xmm0, dword ptr [esp + 0x38]
4332ec90 movaps   xmm1, xmm7
4332ec93 maxss    xmm1, xmm0
4332ec97 movss    dword ptr [esp + 0x50], xmm7
4332ec9d movaps   xmm0, xmm3
4332eca0 movaps   xmm2, xmm5
4332eca3 minss    xmm1, xmm0
4332eca7 movss    xmm0, dword ptr [edi + 0x13c]
4332ecaf subss    xmm0, xmm3
4332ecb3 movups   xmmword ptr [esp + 0xb0], xmm1
4332ecbb movaps   xmm1, xmm0
4332ecbe subss    xmm2, xmm0
4332ecc2 movss    xmm0, dword ptr [esp + 0x18]
4332ecc8 addss    xmm1, xmm5
4332eccc movss    dword ptr [esp + 0x1c], xmm2
4332ecd2 subss    xmm0, xmm1
4332ecd6 movss    dword ptr [esp + 0x28], xmm1
4332ecdc cvtps2pd xmm0, xmm0
4332ecdf movsd    qword ptr [esp + 0x50], xmm0
4332ece5 fld      qword ptr [esp + 0x50]
4332ece9 fld      qword ptr [esp + 0x68]
4332eced call     0x7750834a
4332ecf2 movss    xmm1, dword ptr [esp + 0x18]
4332ecf8 comiss   xmm1, dword ptr [esp + 0x28]
4332ecfd fstp     dword ptr [esp + 0x14]
4332ed01 movss    xmm2, dword ptr [esp + 0x14]
4332ed07 jbe      0x4332ed1c
4332ed09 comiss   xmm2, dword ptr [0x434725e4]
4332ed10 jb       0x4332ed31
4332ed12 subss    xmm2, dword ptr [0x43471f88]
4332ed1a jmp      0x4332ed31
4332ed1c movss    xmm0, dword ptr [0x434724b4]
4332ed24 comiss   xmm0, xmm2
4332ed27 jb       0x4332ed31
4332ed29 addss    xmm2, dword ptr [0x43471f88]
4332ed31 movss    xmm0, dword ptr [esp + 0x38]
4332ed37 movaps   xmm3, xmm2
4332ed3a maxss    xmm3, xmm0
4332ed3e movss    xmm0, dword ptr [esp + 0x24]
4332ed44 minss    xmm3, xmm0
4332ed48 movaps   xmm0, xmm1
4332ed4b subss    xmm0, dword ptr [esp + 0x1c]
4332ed51 movups   xmmword ptr [esp + 0x90], xmm3
4332ed59 cvtps2pd xmm0, xmm0
4332ed5c movsd    qword ptr [esp + 0x28], xmm0
4332ed62 fld      qword ptr [esp + 0x28]
4332ed66 fld      qword ptr [esp + 0x68]
4332ed6a call     0x7750834a
4332ed6f movss    xmm0, dword ptr [esp + 0x18]
4332ed75 comiss   xmm0, dword ptr [esp + 0x1c]
4332ed7a fstp     dword ptr [esp + 0x14]
4332ed7e movss    xmm2, dword ptr [esp + 0x14]
4332ed84 jbe      0x4332ed99
4332ed86 comiss   xmm2, dword ptr [0x434725e4]
4332ed8d jb       0x4332edae
4332ed8f subss    xmm2, dword ptr [0x43471f88]
4332ed97 jmp      0x4332edae
4332ed99 movss    xmm0, dword ptr [0x434724b4]
4332eda1 comiss   xmm0, xmm2
4332eda4 jb       0x4332edae
4332eda6 addss    xmm2, dword ptr [0x43471f88]
4332edae movss    xmm0, dword ptr [esp + 0x38]
4332edb4 movaps   xmm1, xmm2
4332edb7 movups   xmm2, xmmword ptr [esp + 0xb0]
4332edbf movss    xmm3, dword ptr [0x43470340]
4332edc7 maxss    xmm1, xmm0
4332edcb movss    xmm0, dword ptr [esp + 0x24]
4332edd1 movss    xmm5, dword ptr [esp + 0x40]
4332edd7 minss    xmm1, xmm0
4332eddb movups   xmm0, xmmword ptr [esp + 0x90]
4332ede3 subss    xmm0, xmm2
4332ede7 subss    xmm1, xmm2
4332edeb andps    xmm0, xmm3
4332edee andps    xmm1, xmm3
4332edf1 comiss   xmm0, xmm1
4332edf4 jbe      0x4332ee00
4332edf6 subss    xmm5, dword ptr [edi + 0x13c]
4332edfe jmp      0x4332ee16
4332ee00 addss    xmm5, dword ptr [edi + 0x13c]
4332ee08 jmp      0x4332ee16
4332ee0a movss    xmm3, dword ptr [0x43470340]
4332ee12 addss    xmm5, xmm1
4332ee16 mov      eax, dword ptr [ebp + 0xc]
4332ee19 movss    dword ptr [eax + 0x10], xmm5
4332ee1e jmp      0x4332ebc7
4332ee23 mov      eax, dword ptr [esi + 8]
4332ee26 cmp      byte ptr [eax], 0
4332ee29 mov      eax, dword ptr [ebp + 0xc]
4332ee2c jne      0x4332ebc7
4332ee32 movss    dword ptr [eax + 0x10], xmm4
4332ee37 jmp      0x4332ebc7
4332ee3c movaps   xmm0, xmm1
4332ee3f andps    xmm0, xmm3
4332ee42 comiss   xmm0, dword ptr [0x434725e4]
4332ee49 jbe      0x4332ee87
4332ee4b movaps   xmm0, xmm1
4332ee4e divss    xmm0, dword ptr [0x43471f88]
4332ee56 andps    xmm0, xmm3
4332ee59 call     0x4341ad12
4332ee5e movss    xmm1, dword ptr [esp + 0x20]
4332ee64 movaps   xmm2, xmm0
4332ee67 mulss    xmm2, dword ptr [0x43471f88]
4332ee6f xorps    xmm0, xmm0
4332ee72 comiss   xmm0, xmm1
4332ee75 jbe      0x4332ee7d
4332ee77 addss    xmm1, xmm2
4332ee7b jmp      0x4332ee81
4332ee7d subss    xmm1, xmm2
4332ee81 movss    dword ptr [esp + 0x20], xmm1
4332ee87 mov      eax, dword ptr [esp + 0x30]
4332ee8b movss    dword ptr [eax], xmm1
4332ee8f movss    xmm2, dword ptr [0x43472244]
4332ee97 test     byte ptr [edi + 0x128], 8
4332ee9e je       0x4332ef25
4332eea4 movss    xmm0, dword ptr [edi + 0x184]
4332eeac ucomiss  xmm0, xmm2
4332eeaf lahf     
4332eeb0 test     ah, 0x44
4332eeb3 jnp      0x4332eebf
4332eeb5 mov      eax, dword ptr [ebp + 0xc]
4332eeb8 movss    dword ptr [eax + 0x10], xmm0
4332eebd jmp      0x4332ef25
4332eebf ucomiss  xmm1, xmm1
4332eec2 lahf     
4332eec3 test     ah, 0x44
4332eec6 jnp      0x4332eecd
4332eec8 xorps    xmm0, xmm0
4332eecb jmp      0x4332ef1d
4332eecd movss    xmm2, dword ptr [0x43470340]
4332eed5 movaps   xmm0, xmm1
4332eed8 andps    xmm0, xmm2
4332eedb comiss   xmm0, dword ptr [0x434725e4]
4332eee2 jbe      0x4332ef1a
4332eee4 movaps   xmm0, xmm1
4332eee7 divss    xmm0, dword ptr [0x43471f88]
4332eeef andps    xmm0, xmm2
4332eef2 call     0x4341ad12
4332eef7 movss    xmm1, dword ptr [esp + 0x20]
4332eefd movaps   xmm2, xmm0
4332ef00 mulss    xmm2, dword ptr [0x43471f88]
4332ef08 xorps    xmm0, xmm0
4332ef0b comiss   xmm0, xmm1
4332ef0e jbe      0x4332ef16
4332ef10 addss    xmm1, xmm2
4332ef14 jmp      0x4332ef1a
4332ef16 subss    xmm1, xmm2
4332ef1a movaps   xmm0, xmm1
4332ef1d movss    dword ptr [edi + 0x184], xmm0
4332ef25 pop      edi
4332ef26 pop      esi
4332ef27 mov      esp, ebp
4332ef29 pop      ebp
4332ef2a ret      8
