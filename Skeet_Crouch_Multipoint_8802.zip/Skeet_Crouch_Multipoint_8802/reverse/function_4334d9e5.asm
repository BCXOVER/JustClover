4334d9e5 mov      ecx, dword ptr [0x4346a514]
4334d9eb mov      eax, dword ptr [ecx]
4334d9ed call     dword ptr [eax + 0x68]
4334d9f0 test     al, al
4334d9f2 je       0x4334da3c
4334d9f4 mov      ecx, dword ptr [0x4346a514]
4334d9fa mov      eax, dword ptr [ecx]
4334d9fc call     dword ptr [eax + 0x30]
4334d9ff mov      ecx, dword ptr [0x4346a890]
4334da05 push     eax
4334da06 mov      edx, dword ptr [ecx]
4334da08 call     dword ptr [edx + 0xc]
4334da0b test     eax, eax
4334da0d je       0x4334da3c
4334da0f mov      ecx, dword ptr [0x43468e78]
4334da15 push     esi
4334da16 xor      esi, esi
4334da18 inc      esi
4334da19 mov      edx, dword ptr [ecx]
4334da1b xor      edx, dword ptr [0x434684e4]
4334da21 movzx    ecx, byte ptr [0x43475bd2]
4334da28 xor      edx, 0x9d920e35
4334da2e cmp      byte ptr [edx + eax], 0
4334da32 cmove    ecx, esi
4334da35 mov      byte ptr [0x43475bd2], cl
4334da3b pop      esi
4334da3c ret      
