43384761 or       eax, 0x43468ea4
43384766 xor      ecx, 0xfcd2da7a
4338476c jmp      0x43384770
4338476e mov      ecx, eax
43384770 mov      eax, dword ptr [ecx + 0x1c]
43384773 cmp      ecx, eax
43384775 jne      0x4338476e
43384777 movzx    eax, byte ptr [0x43468d7c]
4338477e xor      edx, edx
43384780 inc      edx
43384781 cmp      dword ptr [ecx + 0x30], ecx
43384784 cmove    eax, edx
43384787 mov      byte ptr [0x43468d7c], al
4338478c ret      
