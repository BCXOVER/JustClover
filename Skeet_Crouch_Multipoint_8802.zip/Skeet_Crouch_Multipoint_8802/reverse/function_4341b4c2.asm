4341b4c2 push     ebp
4341b4c3 mov      ebp, esp
4341b4c5 and      esp, 0xfffffff0
4341b4c8 sub      esp, 0x7298
4341b4ce push     esi
4341b4cf mov      esi, dword ptr [ebp + 8]
4341b4d2 push     edi
4341b4d3 mov      edi, dword ptr [ebp + 0xc]
4341b4d6 mov      dword ptr [esp + 0x34], ecx
4341b4da test     dword ptr [esi], 0x4000
4341b4e0 je       0x4341b4f2
4341b4e2 mov      eax, dword ptr [ebp + 0x10]
4341b4e5 mov      dword ptr [eax], 0x3f800000
4341b4eb mov      al, 1
4341b4ed jmp      0x4341c9d3
4341b4f2 mov      ecx, dword ptr [0x4346a890]
4341b4f8 push     dword ptr [edi + 4]
4341b4fb mov      eax, dword ptr [ecx]
4341b4fd mov      eax, dword ptr [eax + 0xc]
4341b500 call     eax
4341b502 mov      dword ptr [esp + 0x30], eax
4341b506 test     eax, eax
4341b508 jne      0x4341b511
4341b50a xor      al, al
4341b50c jmp      0x4341c9d3
4341b511 movzx    eax, byte ptr [0x4346a3e0]
4341b518 lea      ecx, [esp + 0x210]
4341b51f push     eax
4341b520 push     dword ptr [esi + 0xc]
4341b523 call     0x433eb28b
4341b528 movss    xmm2, dword ptr [edi + 0xc]
4341b52d lea      eax, [esi + 0xdc]
4341b533 movss    xmm0, dword ptr [edi + 0x10]
4341b538 subss    xmm0, dword ptr [eax + 4]
4341b53d subss    xmm2, dword ptr [eax]
4341b541 movss    xmm1, dword ptr [edi + 0x14]
4341b546 subss    xmm1, dword ptr [eax + 8]
4341b54b unpcklps xmm2, xmm0
4341b54e movq     xmm0, xmm2
4341b552 movq     qword ptr [esp + 0xbc], xmm2
4341b55b movq     qword ptr [esp + 0x50], xmm0
4341b561 movaps   xmm3, xmm1
4341b564 movss    xmm7, dword ptr [esp + 0x50]
4341b56a xorps    xmm2, xmm2
4341b56d movss    xmm4, dword ptr [esp + 0x54]
4341b573 movaps   xmm0, xmm7
4341b576 movss    dword ptr [esp + 0xc4], xmm1
4341b57f movaps   xmm1, xmm3
4341b582 mulss    xmm0, xmm7
4341b586 mulss    xmm1, xmm3
4341b58a addss    xmm1, xmm0
4341b58e movaps   xmm0, xmm4
4341b591 mulss    xmm0, xmm4
4341b595 addss    xmm1, xmm0
4341b599 movaps   xmm0, xmm1
4341b59c movss    xmm1, dword ptr [0x43470514]
4341b5a4 sqrtss   xmm0, xmm0
4341b5a8 movss    dword ptr [esp + 0xac], xmm0
4341b5b1 addss    xmm0, dword ptr [0x43472108]
4341b5b9 divss    xmm1, xmm0
4341b5bd movss    xmm0, dword ptr [0x434703d0]
4341b5c5 mulss    xmm7, xmm1
4341b5c9 mulss    xmm3, xmm1
4341b5cd ucomiss  xmm7, xmm2
4341b5d0 mulss    xmm4, xmm1
4341b5d4 lahf     
4341b5d5 movss    dword ptr [esp + 0x50], xmm7
4341b5db movss    dword ptr [esp + 0x54], xmm4
4341b5e1 movss    dword ptr [esp + 0x58], xmm3
4341b5e7 movups   xmmword ptr [esp + 0x80], xmm3
4341b5ef test     ah, 0x44
4341b5f2 jp       0x4341b649
4341b5f4 ucomiss  xmm4, xmm2
4341b5f7 lahf     
4341b5f8 test     ah, 0x44
4341b5fb jp       0x4341b649
4341b5fd movss    xmm6, dword ptr [0x4346f858]
4341b605 movaps   xmm4, xmm3
4341b608 xorps    xmm5, xmm5
4341b60b movss    dword ptr [esp + 0x18], xmm6
4341b611 xorps    xmm7, xmm7
4341b614 movss    dword ptr [esp + 0x14], xmm5
4341b61a xorps    xmm4, xmm0
4341b61d movss    dword ptr [esp + 0x60], xmm5
4341b623 xorps    xmm0, xmm0
4341b626 movss    dword ptr [esp + 0x64], xmm6
4341b62c movss    dword ptr [esp + 0x1c], xmm7
4341b632 movss    dword ptr [esp + 0x68], xmm7
4341b638 movss    dword ptr [esp + 0x24], xmm0
4341b63e movss    dword ptr [esp + 0x70], xmm0
4341b644 jmp      0x4341b78d
4341b649 movaps   xmm6, xmm3
4341b64c movaps   xmm5, xmm4
4341b64f mulss    xmm6, xmm2
4341b653 movaps   xmm0, xmm4
4341b656 mulss    xmm0, xmm2
4341b65a subss    xmm5, xmm6
4341b65e subss    xmm6, xmm7
4341b662 mulss    xmm7, xmm2
4341b666 subss    xmm7, xmm0
4341b66a movaps   xmm1, xmm5
4341b66d mulss    xmm1, xmm5
4341b671 movaps   xmm0, xmm6
4341b674 mulss    xmm0, xmm6
4341b678 addss    xmm1, xmm0
4341b67c movaps   xmm0, xmm7
4341b67f mulss    xmm0, xmm7
4341b683 addss    xmm1, xmm0
4341b687 movaps   xmm0, xmm1
4341b68a movss    xmm1, dword ptr [0x43470514]
4341b692 sqrtss   xmm0, xmm0
4341b696 movss    dword ptr [esp + 0xb0], xmm0
4341b69f addss    xmm0, dword ptr [0x43472108]
4341b6a7 divss    xmm1, xmm0
4341b6ab mulss    xmm6, xmm1
4341b6af mulss    xmm7, xmm1
4341b6b3 movaps   xmm4, xmm6
4341b6b6 mulss    xmm5, xmm1
4341b6ba mulss    xmm4, xmm3
4341b6be movaps   xmm0, xmm7
4341b6c1 mulss    xmm0, dword ptr [esp + 0x54]
4341b6c7 movaps   xmm1, xmm5
4341b6ca mulss    xmm1, dword ptr [esp + 0x54]
4341b6d0 subss    xmm4, xmm0
4341b6d4 movss    dword ptr [esp + 0x14], xmm5
4341b6da movaps   xmm0, xmm7
4341b6dd movss    dword ptr [esp + 0x60], xmm5
4341b6e3 mulss    xmm0, dword ptr [esp + 0x50]
4341b6e9 movss    dword ptr [esp + 0x18], xmm6
4341b6ef movss    dword ptr [esp + 0x64], xmm6
4341b6f5 movss    dword ptr [esp + 0x24], xmm0
4341b6fb movaps   xmm0, xmm5
4341b6fe mulss    xmm0, xmm3
4341b702 movss    xmm3, dword ptr [esp + 0x24]
4341b708 movss    dword ptr [esp + 0x1c], xmm7
4341b70e subss    xmm3, xmm0
4341b712 movss    dword ptr [esp + 0x68], xmm7
4341b718 movaps   xmm0, xmm6
4341b71b mulss    xmm0, dword ptr [esp + 0x50]
4341b721 subss    xmm1, xmm0
4341b725 movaps   xmm0, xmm3
4341b728 mulss    xmm0, xmm3
4341b72c movss    dword ptr [esp + 0x10], xmm1
4341b732 movaps   xmm1, xmm4
4341b735 mulss    xmm1, xmm4
4341b739 addss    xmm1, xmm0
4341b73d movss    xmm0, dword ptr [esp + 0x10]
4341b743 mulss    xmm0, xmm0
4341b747 addss    xmm1, xmm0
4341b74b movaps   xmm0, xmm1
4341b74e movss    xmm1, dword ptr [0x43470514]
4341b756 sqrtss   xmm0, xmm0
4341b75a movss    dword ptr [esp + 0xb4], xmm0
4341b763 addss    xmm0, dword ptr [0x43472108]
4341b76b divss    xmm1, xmm0
4341b76f movss    xmm0, dword ptr [esp + 0x10]
4341b775 mulss    xmm3, xmm1
4341b779 mulss    xmm4, xmm1
4341b77d movss    dword ptr [esp + 0x24], xmm3
4341b783 movss    dword ptr [esp + 0x70], xmm3
4341b789 mulss    xmm0, xmm1
4341b78d mov      ecx, dword ptr [esp + 0x34]
4341b791 xor      edx, edx
4341b793 movss    dword ptr [esp + 0x74], xmm0
4341b799 movss    dword ptr [esp + 0x10], xmm0
4341b79f movss    dword ptr [esp + 0x6c], xmm4
4341b7a5 test     byte ptr [ecx + 0x178], 8
4341b7ac movss    dword ptr [esp + 0x28], xmm4
4341b7b2 mov      dword ptr [esp + 0x78], edx
4341b7b6 jne      0x4341bb3c
4341b7bc mov      eax, dword ptr [0x43467c3c]
4341b7c1 xor      eax, 0x211963a6
4341b7c6 jmp      0x4341b7ca
4341b7c8 mov      eax, ecx
4341b7ca mov      ecx, dword ptr [eax + 0x1c]
4341b7cd cmp      eax, ecx
4341b7cf jne      0x4341b7c8
4341b7d1 cmp      dword ptr [eax + 0x30], eax
4341b7d4 je       0x4341b80a
4341b7d6 mov      eax, dword ptr [0x43467084]
4341b7db xor      eax, 0x9c2756f5
4341b7e0 jmp      0x4341b7e4
4341b7e2 mov      eax, ecx
4341b7e4 mov      ecx, dword ptr [eax + 0x1c]
4341b7e7 cmp      eax, ecx
4341b7e9 jne      0x4341b7e2
4341b7eb movss    xmm0, dword ptr [eax + 0x2c]
4341b7f0 movss    dword ptr [esp + 0xc], xmm0
4341b7f6 xor      dword ptr [esp + 0xc], eax
4341b7fa movss    xmm0, dword ptr [esp + 0xc]
4341b800 comiss   xmm0, xmm2
4341b803 seta     al
4341b806 test     al, al
4341b808 jne      0x4341b842
4341b80a mov      eax, dword ptr [0x43468c90]
4341b80f xor      eax, 0x98d588d4
4341b814 jmp      0x4341b818
4341b816 mov      eax, ecx
4341b818 mov      ecx, dword ptr [eax + 0x1c]
4341b81b cmp      eax, ecx
4341b81d jne      0x4341b816
4341b81f movss    xmm0, dword ptr [eax + 0x2c]
4341b824 movss    dword ptr [esp + 0xc], xmm0
4341b82a xor      dword ptr [esp + 0xc], eax
4341b82e movss    xmm0, dword ptr [esp + 0xc]
4341b834 comiss   xmm0, xmm2
4341b837 seta     al
4341b83a test     al, al
4341b83c jne      0x4341bb3c
4341b842 movaps   xmm0, xmmword ptr [0x4346f560]
4341b849 mov      ecx, dword ptr [0x4346a568]
4341b84f mov      eax, dword ptr [esi + 0x1d0]
4341b855 xor      ecx, 0x9190e2e6
4341b85b mov      dword ptr [esp + 0x138], edx
4341b862 mov      dword ptr [esp + 0x13c], edx
4341b869 mov      dword ptr [esp + 0x140], edx
4341b870 movups   xmmword ptr [esp + 0x144], xmm0
4341b878 mov      dword ptr [esp + 0x154], 0x3f800000
4341b883 mov      dword ptr [esp + 0x134], 0x43470578
4341b88e mov      dword ptr [esp + 0x158], eax
4341b895 jmp      0x4341b899
4341b897 mov      ecx, eax
4341b899 mov      eax, dword ptr [ecx + 0x1c]
4341b89c cmp      ecx, eax
4341b89e jne      0x4341b897
4341b8a0 cmp      dword ptr [ecx + 0x30], ecx
4341b8a3 setne    byte ptr [esp + 0x15c]
4341b8ab jne      0x4341bb3c
4341b8b1 movss    xmm1, dword ptr [esi + 0xc4]
4341b8b9 movss    xmm0, dword ptr [0x43470514]
4341b8c1 call     0x43367633
4341b8c6 movaps   xmm1, xmmword ptr [0x4346edb0]
4341b8cd mov      eax, edx
4341b8cf movss    xmm2, dword ptr [esi + 0xd0]
4341b8d7 movups   xmmword ptr [esp + 0x1d0], xmm1
4341b8df movaps   xmm1, xmmword ptr [0x43470140]
4341b8e6 addss    xmm2, xmm0
4341b8ea movups   xmmword ptr [esp + 0x1e0], xmm1
4341b8f2 movss    xmm0, dword ptr [esp + eax + 0x1d4]
4341b8fb movaps   xmm1, xmm2
4341b8fe mulss    xmm1, dword ptr [esp + eax + 0x1d0]
4341b907 mulss    xmm0, xmm2
4341b90b movss    dword ptr [esp + eax + 0x1f0], xmm1
4341b914 movss    dword ptr [esp + eax + 0x1f4], xmm0
4341b91d add      eax, 8
4341b920 cmp      eax, 0x20
4341b923 jl       0x4341b8f2
4341b925 mov      eax, edx
4341b927 mov      dword ptr [esp + 0x3c], edx
4341b92b movss    xmm1, dword ptr [esp + eax*8 + 0x1f0]
4341b934 lea      edx, [esi + 0xdc]
4341b93a movss    xmm2, dword ptr [esp + eax*8 + 0x1f4]
4341b943 movaps   xmm3, xmm7
4341b946 mulss    xmm5, xmm1
4341b94a lea      eax, [esp + 0x210]
4341b951 mov      ecx, dword ptr [0x43475808]
4341b957 movaps   xmm0, xmm2
4341b95a mulss    xmm3, xmm1
4341b95e push     eax
4341b95f mulss    xmm0, xmm4
4341b963 movaps   xmm4, xmm6
4341b966 lea      eax, [esp + 0x138]
4341b96d mulss    xmm4, xmm1
4341b971 push     eax
4341b972 addss    xmm5, dword ptr [esp + 0x58]
4341b978 addss    xmm3, dword ptr [esp + 0x88]
4341b981 addss    xmm4, dword ptr [esp + 0x5c]
4341b987 lea      eax, [esp + 0xa8]
4341b98e push     eax
4341b98f addss    xmm5, xmm0
4341b993 movaps   xmm0, xmm2
4341b996 mulss    xmm0, dword ptr [esp + 0x30]
4341b99c mulss    xmm2, dword ptr [esp + 0x1c]
4341b9a2 addss    xmm4, xmm0
4341b9a6 movaps   xmm1, xmm5
4341b9a9 mulss    xmm1, xmm5
4341b9ad addss    xmm3, xmm2
4341b9b1 movaps   xmm0, xmm4
4341b9b4 mulss    xmm0, xmm4
4341b9b8 addss    xmm1, xmm0
4341b9bc movaps   xmm0, xmm3
4341b9bf mulss    xmm0, xmm3
4341b9c3 addss    xmm1, xmm0
4341b9c7 xorps    xmm0, xmm0
4341b9ca movss    xmm0, xmm1
4341b9ce movss    xmm1, dword ptr [0x43470514]
4341b9d6 sqrtss   xmm0, xmm0
4341b9da movss    dword ptr [esp + 0xc4], xmm0
4341b9e3 addss    xmm0, dword ptr [0x43472108]
4341b9eb divss    xmm1, xmm0
4341b9ef mulss    xmm5, xmm1
4341b9f3 mulss    xmm4, xmm1
4341b9f7 mulss    xmm3, xmm1
4341b9fb movss    dword ptr [esp + 0xac], xmm5
4341ba04 movss    dword ptr [esp + 0xb0], xmm4
4341ba0d movss    dword ptr [esp + 0xb4], xmm3
4341ba16 call     0x43364cec
4341ba1b movss    xmm0, dword ptr [0x43470514]
4341ba23 comiss   xmm0, dword ptr [esp + 0x268]
4341ba2b ja       0x4341ba45
4341ba2d cmp      byte ptr [esp + 0x272], 0
4341ba35 jne      0x4341ba45
4341ba37 cmp      byte ptr [esp + 0x273], 0
4341ba3f je       0x4341bb0d
4341ba45 cmp      dword ptr [esp + 0x288], 0
4341ba4d je       0x4341bb0d
4341ba53 mov      dword ptr [esp + 0x4c], 0x1127189e
4341ba5b mov      eax, dword ptr [esp + 0x4c]
4341ba5f mov      edx, dword ptr [esp + 0x288]
4341ba66 mov      ecx, dword ptr [edx]
4341ba68 mov      ecx, dword ptr [eax + ecx - 0x11271626]
4341ba6f mov      dword ptr [esp + 0x7c], ecx
4341ba73 call     0x433e533f
4341ba78 test     al, al
4341ba7a je       0x4341bab5
4341ba7c mov      edx, dword ptr [esp + 0x288]
4341ba83 test     edx, edx
4341ba85 jne      0x4341ba93
4341ba87 push     ebx
4341ba88 sub      byte ptr [ecx], bh
4341ba8a sbb      dword ptr [esi], edx
4341ba8c or       ah, byte ptr [ecx + 0x3d]
4341ba8f hlt      
4341ba93 mov      eax, dword ptr [0x434688b0]
4341ba98 mov      ecx, dword ptr [eax]
4341ba9a xor      ecx, dword ptr [0x4346a518]
4341baa0 mov      eax, dword ptr [esi + 0x1d0]
4341baa6 xor      ecx, 0x8b5586f6
4341baac cmp      eax, dword ptr [ecx + edx]
4341baaf je       0x4341bc93
4341bab5 movss    xmm0, dword ptr [esp + 0x58]
4341babb movss    xmm4, dword ptr [esp + 0x6c]
4341bac1 movss    xmm7, dword ptr [esp + 0x68]
4341bac7 movss    xmm6, dword ptr [esp + 0x64]
4341bacd movss    xmm5, dword ptr [esp + 0x60]
4341bad3 movups   xmmword ptr [esp + 0x80], xmm0
4341badb movss    xmm0, dword ptr [esp + 0x74]
4341bae1 movss    dword ptr [esp + 0x10], xmm0
4341bae7 movss    xmm0, dword ptr [esp + 0x70]
4341baed movss    dword ptr [esp + 0x24], xmm0
4341baf3 movss    dword ptr [esp + 0x28], xmm4
4341baf9 movss    dword ptr [esp + 0x1c], xmm7
4341baff movss    dword ptr [esp + 0x18], xmm6
4341bb05 movss    dword ptr [esp + 0x14], xmm5
4341bb0b jmp      0x4341bb25
4341bb0d movss    xmm5, dword ptr [esp + 0x14]
4341bb13 movss    xmm7, dword ptr [esp + 0x1c]
4341bb19 movss    xmm6, dword ptr [esp + 0x18]
4341bb1f movss    xmm4, dword ptr [esp + 0x28]
4341bb25 mov      eax, dword ptr [esp + 0x3c]
4341bb29 inc      eax
4341bb2a mov      dword ptr [esp + 0x3c], eax
4341bb2e cmp      eax, 4
4341bb31 jl       0x4341b92b
4341bb37 xorps    xmm2, xmm2
4341bb3a xor      edx, edx
4341bb3c mov      eax, dword ptr [0x43467e8c]
4341bb41 mov      ecx, dword ptr [esp + 0x30]
4341bb45 mov      eax, dword ptr [eax]
4341bb47 xor      eax, dword ptr [0x43467900]
4341bb4d xor      eax, 0x32e4daf1
4341bb52 mov      ecx, dword ptr [eax + ecx]
4341bb55 test     ecx, ecx
4341bb57 je       0x4341bb8b
4341bb59 cmp      dword ptr [ecx], edx
4341bb5b je       0x4341bb8b
4341bb5d mov      eax, dword ptr [0x43468240]
4341bb62 mov      esi, dword ptr [esp + 0x30]
4341bb66 mov      ecx, dword ptr [ecx]
4341bb68 mov      eax, dword ptr [eax]
4341bb6a xor      eax, dword ptr [0x4346a84c]
4341bb70 xor      eax, 0xc2b6fb10
4341bb75 imul     eax, dword ptr [eax + esi], 0xc
4341bb79 mov      esi, dword ptr [ebp + 8]
4341bb7c add      eax, dword ptr [ecx + 0xb0]
4341bb82 add      eax, ecx
4341bb84 je       0x4341bb8b
4341bb86 cmp      dword ptr [eax + 4], edx
4341bb89 jne      0x4341bb8d
4341bb8b mov      eax, edx
4341bb8d imul     ecx, dword ptr [edi + 0x2c], 0x44
4341bb91 add      ecx, dword ptr [eax + 8]
4341bb94 add      ecx, eax
4341bb96 test     byte ptr [edi + 0x34], 1
4341bb9a mov      dword ptr [esp + 0x94], ecx
4341bba1 je       0x4341bbbf
4341bba3 test     byte ptr [edi + 0x14c], 0x80
4341bbaa je       0x4341bbbf
4341bbac test     ecx, ecx
4341bbae je       0x4341bbbf
4341bbb0 movss    xmm0, dword ptr [ecx + 0x30]
4341bbb5 comiss   xmm0, xmm2
4341bbb8 mov      byte ptr [esp + 0xb], 1
4341bbbd ja       0x4341bbc3
4341bbbf mov      byte ptr [esp + 0xb], dl
4341bbc3 mov      eax, dword ptr [esp + 0x34]
4341bbc7 mov      dword ptr [esp + 0x10], 0x40
4341bbcf test     byte ptr [eax + 0x178], 8
4341bbd6 jne      0x4341bbf8
4341bbd8 mov      edx, dword ptr [edi + 4]
4341bbdb xor      eax, eax
4341bbdd and      edx, 0x3f
4341bbe0 inc      eax
4341bbe1 mov      ecx, edx
4341bbe3 shr      edx, 5
4341bbe6 and      ecx, 0x1f
4341bbe9 shl      eax, cl
4341bbeb mov      ecx, dword ptr [esp + 0x34]
4341bbef test     dword ptr [ecx + edx*4 + 0x1ac], eax
4341bbf6 je       0x4341bc00
4341bbf8 mov      dword ptr [esp + 0x10], 0x20
4341bc00 xor      edx, edx
4341bc02 movzx    ecx, byte ptr [esp + 0xb]
4341bc07 mov      eax, 0x80
4341bc0c movss    xmm0, dword ptr [edi + 0xd4]
4341bc14 div      dword ptr [esp + 0x10]
4341bc18 lea      ecx, [ecx*2 + 1]
4341bc1f movss    dword ptr [esp + 0x40], xmm0
4341bc25 imul     ecx, dword ptr [esp + 0x10]
4341bc2a mov      dword ptr [esp + 0x5c], eax
4341bc2e movd     xmm1, ecx
4341bc32 cvtdq2ps xmm1, xmm1
4341bc35 mulss    xmm1, xmm0
4341bc39 cvtss2si eax, xmm1
4341bc3d sub      ecx, eax
4341bc3f add      ecx, 2
4341bc42 mov      dword ptr [esp + 0x4c], ecx
4341bc46 lea      ecx, [esp + 0x4d0]
4341bc4d call     0x433ab385
4341bc52 push     dword ptr [esp + 0x30]
4341bc56 lea      ecx, [esp + 0x2fd4]
4341bc5d call     0x4339f326
4341bc62 cmp      byte ptr [esp + 0xb], 0
4341bc67 je       0x4341c777
4341bc6d cmp      dword ptr [esi + 0xd8], 0x1f
4341bc74 mov      esi, dword ptr [esp + 0x30]
4341bc78 jne      0x4341bc9e
4341bc7a movss    xmm3, dword ptr [0x43470514]
4341bc82 movss    dword ptr [esp + 0x3c], xmm3
4341bc88 movss    dword ptr [esp + 0x24], xmm2
4341bc8e jmp      0x4341bd6e
4341bc93 mov      eax, dword ptr [ebp + 0x10]
4341bc96 and      dword ptr [eax], 0
4341bc99 jmp      0x4341b50a
4341bc9e movzx    eax, word ptr [esp + 0x21c]
4341bca6 mov      ecx, esi
4341bca8 movss    xmm0, dword ptr [esp + 0x22c]
4341bcb1 mov      edx, dword ptr [edi + 0x30]
4341bcb4 push     eax
4341bcb5 call     0x4338a519
4341bcba mov      ecx, dword ptr [edi + 0x28]
4341bcbd mov      eax, dword ptr [edi + 0x30]
4341bcc0 and      eax, 0xf
4341bcc3 movss    dword ptr [esp + 0x3c], xmm0
4341bcc9 movd     xmm2, ecx
4341bccd cvtdq2ps xmm2, xmm2
4341bcd0 movss    xmm1, dword ptr [eax*4 + 0x43474540]
4341bcd9 movss    dword ptr [esp + 0x24], xmm1
4341bcdf divss    xmm2, xmm1
4341bce3 test     ecx, ecx
4341bce5 jg       0x4341bcf2
4341bce7 mov      eax, 0x7fffffff
4341bcec mov      dword ptr [esp + 0xc], eax
4341bcf0 jmp      0x4341bd09
4341bcf2 mov      eax, dword ptr [edi + 8]
4341bcf5 dec      eax
4341bcf6 add      eax, ecx
4341bcf8 cdq      
4341bcf9 idiv     ecx
4341bcfb xor      edx, edx
4341bcfd inc      edx
4341bcfe cmp      eax, edx
4341bd00 cmovg    edx, eax
4341bd03 mov      dword ptr [esp + 0xc], edx
4341bd07 mov      eax, edx
4341bd09 movaps   xmm0, xmmword ptr [0x434709d0]
4341bd10 lea      ecx, [esp + 0x160]
4341bd17 movups   xmmword ptr [esp + 0x160], xmm0
4341bd1f movss    xmm1, dword ptr [ecx]
4341bd23 movaps   xmm0, xmm1
4341bd26 mulss    xmm0, xmm2
4341bd2a cvttss2si edx, xmm0
4341bd2e mov      dword ptr [esp + 0x20], edx
4341bd32 test     edx, edx
4341bd34 jg       0x4341bd3d
4341bd36 mov      edx, 0x7fffffff
4341bd3b jmp      0x4341bd54
4341bd3d mov      eax, dword ptr [edi + 8]
4341bd40 dec      eax
4341bd41 add      eax, edx
4341bd43 cdq      
4341bd44 idiv     dword ptr [esp + 0x20]
4341bd48 xor      edx, edx
4341bd4a inc      edx
4341bd4b cmp      eax, edx
4341bd4d cmovg    edx, eax
4341bd50 mov      eax, dword ptr [esp + 0xc]
4341bd54 cmp      edx, eax
4341bd56 jle      0x4341bd68
4341bd58 add      ecx, 4
4341bd5b lea      edx, [esp + 0x170]
4341bd62 cmp      ecx, edx
4341bd64 jne      0x4341bd1f
4341bd66 jmp      0x4341bd6e
4341bd68 movss    dword ptr [esp + 0x24], xmm1
4341bd6e mov      eax, dword ptr [0x43467e8c]
4341bd73 xor      edx, edx
4341bd75 mov      eax, dword ptr [eax]
4341bd77 xor      eax, dword ptr [0x43467900]
4341bd7d xor      eax, 0x32e4daf1
4341bd82 mov      ecx, dword ptr [eax + esi]
4341bd85 test     ecx, ecx
4341bd87 je       0x4341c19b
4341bd8d cmp      dword ptr [ecx], edx
4341bd8f je       0x4341c19b
4341bd95 mov      eax, dword ptr [0x43468240]
4341bd9a mov      ecx, dword ptr [ecx]
4341bd9c mov      eax, dword ptr [eax]
4341bd9e xor      eax, dword ptr [0x4346a84c]
4341bda4 xor      eax, 0xc2b6fb10
4341bda9 imul     eax, dword ptr [eax + esi], 0xc
4341bdad add      eax, dword ptr [ecx + 0xb0]
4341bdb3 add      eax, ecx
4341bdb5 mov      dword ptr [esp + 0x20], eax
4341bdb9 je       0x4341c19b
4341bdbf cmp      dword ptr [eax + 4], edx
4341bdc2 je       0x4341c19b
4341bdc8 mov      eax, dword ptr [eax + 4]
4341bdcb push     0x13
4341bdcd pop      ecx
4341bdce cmp      eax, ecx
4341bdd0 mov      dword ptr [esp + 0xc], edx
4341bdd4 cmova    eax, ecx
4341bdd7 mov      dword ptr [esp + 0x4d0], eax
4341bdde test     eax, eax
4341bde0 jle      0x4341c1a6
4341bde6 lea      eax, [edi + 0x340]
4341bdec mov      dword ptr [esp + 0x28], edx
4341bdf0 mov      edi, dword ptr [esp + 0x20]
4341bdf4 lea      ecx, [esp + 0x504]
4341bdfb mov      dword ptr [esp + 0x1c], ecx
4341bdff mov      dword ptr [esp + 0x18], eax
4341be03 mov      esi, dword ptr [edi + 8]
4341be06 mov      eax, dword ptr [esp + 0xc]
4341be0a add      esi, edi
4341be0c add      esi, edx
4341be0e mov      dword ptr [ecx - 0x24], eax
4341be11 mov      dword ptr [ecx - 0x20], esi
4341be14 movss    xmm0, dword ptr [esi + 0x28]
4341be19 mulss    xmm0, dword ptr [0x43470528]
4341be21 movss    dword ptr [esp + 0x20], xmm0
4341be27 call     0x7750c6d0
4341be2c movss    dword ptr [esp + 0x44], xmm0
4341be32 movss    xmm0, dword ptr [esp + 0x20]
4341be38 call     0x7750a770
4341be3d movss    dword ptr [esp + 0x38], xmm0
4341be43 movss    xmm0, dword ptr [esi + 0x24]
4341be48 mulss    xmm0, dword ptr [0x43470528]
4341be50 movss    dword ptr [esp + 0x20], xmm0
4341be56 call     0x7750c6d0
4341be5b movss    dword ptr [esp + 0x14], xmm0
4341be61 movss    xmm0, dword ptr [esp + 0x20]
4341be67 call     0x7750a770
4341be6c movss    dword ptr [esp + 0x48], xmm0
4341be72 movss    xmm0, dword ptr [esi + 0x2c]
4341be77 mulss    xmm0, dword ptr [0x43470528]
4341be7f movss    dword ptr [esp + 0x20], xmm0
4341be85 call     0x7750c6d0
4341be8a movss    dword ptr [esp + 0x2c], xmm0
4341be90 movss    xmm0, dword ptr [esp + 0x20]
4341be96 call     0x7750a770
4341be9b movss    xmm3, dword ptr [esp + 0x48]
4341bea1 movaps   xmm7, xmm0
4341bea4 movss    xmm2, dword ptr [esp + 0x44]
4341beaa movaps   xmm1, xmm3
4341bead mulss    xmm7, dword ptr [esp + 0x38]
4341beb3 movaps   xmm6, xmm0
4341beb6 mov      eax, dword ptr [esp + 0x18]
4341beba mulss    xmm1, xmm2
4341bebe and      dword ptr [esp + 0x19c], 0
4341bec6 mulss    xmm0, xmm3
4341beca movss    dword ptr [esp + 0x180], xmm1
4341bed3 movss    xmm1, dword ptr [esp + 0x2c]
4341bed9 movaps   xmm5, xmm1
4341bedc mulss    xmm6, xmm2
4341bee0 mulss    xmm5, dword ptr [esp + 0x38]
4341bee6 movaps   xmm4, xmm1
4341bee9 mulss    xmm1, xmm3
4341beed mulss    xmm3, dword ptr [esp + 0x38]
4341bef3 mulss    xmm4, xmm2
4341bef7 xorps    xmm2, xmm2
4341befa movss    dword ptr [esp + 0x194], xmm1
4341bf03 movaps   xmm2, xmm6
4341bf06 movaps   xmm1, xmm7
4341bf09 movss    dword ptr [esp + 0x198], xmm0
4341bf12 mulss    xmm1, dword ptr [esp + 0x14]
4341bf18 movaps   xmm0, xmm5
4341bf1b mulss    xmm0, dword ptr [esp + 0x14]
4341bf21 addss    xmm1, xmm4
4341bf25 subss    xmm0, xmm6
4341bf29 movups   xmm6, xmmword ptr [eax]
4341bf2c unpcklps xmm3, xmm1
4341bf2f movss    xmm1, dword ptr [esp + 0x14]
4341bf35 mulss    xmm2, xmm1
4341bf39 unpcklps xmm3, xmm0
4341bf3c movaps   xmmword ptr [esp + 0x80], xmm3
4341bf44 movaps   xmmword ptr [esp + 0x170], xmm3
4341bf4c subss    xmm2, xmm5
4341bf50 movaps   xmm3, xmm1
4341bf53 movaps   xmm1, xmm4
4341bf56 mulss    xmm1, dword ptr [esp + 0x14]
4341bf5c xorps    xmm3, xmmword ptr [0x434703d0]
4341bf63 movups   xmm4, xmmword ptr [eax - 0x10]
4341bf67 addss    xmm1, xmm7
4341bf6b unpcklps xmm2, xmm3
4341bf6e movaps   xmm7, xmmword ptr [0x43471e40]
4341bf75 unpcklps xmm1, xmm2
4341bf78 movups   xmm2, xmmword ptr [eax - 0x20]
4341bf7c movups   xmmword ptr [esp + 0x184], xmm1
4341bf84 movaps   xmm5, xmmword ptr [esp + 0x180]
4341bf8c movaps   xmm1, xmm2
4341bf8f movaps   xmm3, xmmword ptr [esp + 0x190]
4341bf97 shufps   xmm1, xmm2, 0xaa
4341bf9b mulps    xmm1, xmm3
4341bf9e movaps   xmm0, xmm2
4341bfa1 mov      eax, dword ptr [esp + 0x1c]
4341bfa5 shufps   xmm0, xmm2, 0x55
4341bfa9 mulps    xmm0, xmm5
4341bfac push     0x44
4341bfae push     esi
4341bfaf addps    xmm1, xmm0
4341bfb2 movaps   xmm0, xmm2
4341bfb5 shufps   xmm0, xmm2, 0
4341bfb9 andps    xmm2, xmm7
4341bfbc mulps    xmm0, xmmword ptr [esp + 0x88]
4341bfc4 addps    xmm1, xmm0
4341bfc7 movaps   xmm0, xmm4
4341bfca shufps   xmm0, xmm4, 0x55
4341bfce mulps    xmm0, xmm5
4341bfd1 addps    xmm1, xmm2
4341bfd4 movups   xmmword ptr [eax - 0x14], xmm1
4341bfd8 movaps   xmm1, xmm4
4341bfdb shufps   xmm1, xmm4, 0xaa
4341bfdf mulps    xmm1, xmm3
4341bfe2 addps    xmm1, xmm0
4341bfe5 movaps   xmm0, xmm4
4341bfe8 shufps   xmm0, xmm4, 0
4341bfec andps    xmm4, xmm7
4341bfef mulps    xmm0, xmmword ptr [esp + 0x88]
4341bff7 addps    xmm1, xmm0
4341bffa movaps   xmm0, xmm6
4341bffd shufps   xmm0, xmm6, 0x55
4341c001 mulps    xmm0, xmm5
4341c004 addps    xmm1, xmm4
4341c007 movups   xmmword ptr [eax - 4], xmm1
4341c00b movaps   xmm1, xmm6
4341c00e shufps   xmm1, xmm6, 0xaa
4341c012 mulps    xmm1, xmm3
4341c015 addps    xmm1, xmm0
4341c018 movaps   xmm0, xmm6
4341c01b shufps   xmm0, xmm6, 0
4341c01f andps    xmm6, xmm7
4341c022 mulps    xmm0, xmmword ptr [esp + 0x88]
4341c02a addps    xmm1, xmm0
4341c02d addps    xmm1, xmm6
4341c030 movups   xmmword ptr [eax + 0xc], xmm1
4341c034 add      eax, 0x1c
4341c037 push     eax
4341c038 call     0x774fd4a0
4341c03d mov      ecx, dword ptr [esp + 0x28]
4341c041 add      esp, 0xc
4341c044 movss    xmm1, dword ptr [ecx - 0x10]
4341c049 mulss    xmm1, dword ptr [esi + 0xc]
4341c04e movss    xmm0, dword ptr [ecx - 0x14]
4341c053 mulss    xmm0, dword ptr [esi + 8]
4341c058 addss    xmm1, xmm0
4341c05c movss    xmm0, dword ptr [esi + 0x10]
4341c061 mulss    xmm0, dword ptr [ecx - 0xc]
4341c066 addss    xmm1, xmm0
4341c06a addss    xmm1, dword ptr [ecx - 8]
4341c06f movss    dword ptr [ecx + 0x24], xmm1
4341c074 movss    xmm1, dword ptr [ecx]
4341c078 mulss    xmm1, dword ptr [esi + 0xc]
4341c07d movss    xmm0, dword ptr [ecx - 4]
4341c082 mulss    xmm0, dword ptr [esi + 8]
4341c087 addss    xmm1, xmm0
4341c08b movss    xmm0, dword ptr [esi + 0x10]
4341c090 mulss    xmm0, dword ptr [ecx + 4]
4341c095 addss    xmm1, xmm0
4341c099 addss    xmm1, dword ptr [ecx + 8]
4341c09e movss    dword ptr [ecx + 0x28], xmm1
4341c0a3 movss    xmm5, dword ptr [ecx + 0x10]
4341c0a8 movss    xmm1, dword ptr [ecx + 0xc]
4341c0ad movaps   xmm0, xmm5
4341c0b0 mulss    xmm1, dword ptr [esi + 8]
4341c0b5 mulss    xmm0, dword ptr [esi + 0xc]
4341c0ba movss    xmm4, dword ptr [ecx + 0x14]
4341c0bf addss    xmm1, xmm0
4341c0c3 movaps   xmm0, xmm4
4341c0c6 mulss    xmm0, dword ptr [esi + 0x10]
4341c0cb addss    xmm1, xmm0
4341c0cf addss    xmm1, dword ptr [ecx + 0x18]
4341c0d4 movss    dword ptr [ecx + 0x2c], xmm1
4341c0d9 movss    xmm1, dword ptr [esi + 0x14]
4341c0de mulss    xmm1, dword ptr [ecx - 0x14]
4341c0e3 mov      edx, dword ptr [esp + 0x28]
4341c0e7 movss    xmm0, dword ptr [ecx - 0x10]
4341c0ec add      edx, 0x44
4341c0ef mulss    xmm0, dword ptr [esi + 0x18]
4341c0f4 add      dword ptr [esp + 0x18], 0x30
4341c0f9 mov      dword ptr [esp + 0x28], edx
4341c0fd addss    xmm1, xmm0
4341c101 movss    xmm0, dword ptr [ecx - 0xc]
4341c106 mulss    xmm0, dword ptr [esi + 0x1c]
4341c10b addss    xmm1, xmm0
4341c10f addss    xmm1, dword ptr [ecx - 8]
4341c114 movss    dword ptr [ecx + 0x30], xmm1
4341c119 movss    xmm0, dword ptr [esi + 0x14]
4341c11e mulss    xmm0, dword ptr [ecx - 4]
4341c123 movss    xmm1, dword ptr [ecx]
4341c127 mulss    xmm1, dword ptr [esi + 0x18]
4341c12c addss    xmm1, xmm0
4341c130 movss    xmm0, dword ptr [ecx + 4]
4341c135 mulss    xmm0, dword ptr [esi + 0x1c]
4341c13a addss    xmm1, xmm0
4341c13e addss    xmm1, dword ptr [ecx + 8]
4341c143 movss    dword ptr [ecx + 0x34], xmm1
4341c148 mulss    xmm5, dword ptr [esi + 0x18]
4341c14d movss    xmm0, dword ptr [esi + 0x14]
4341c152 mulss    xmm0, dword ptr [ecx + 0xc]
4341c157 mulss    xmm4, dword ptr [esi + 0x1c]
4341c15c mov      esi, dword ptr [esp + 0xc]
4341c160 addss    xmm5, xmm0
4341c164 inc      esi
4341c165 mov      dword ptr [esp + 0xc], esi
4341c169 addss    xmm5, xmm4
4341c16d addss    xmm5, dword ptr [ecx + 0x18]
4341c172 movss    dword ptr [ecx + 0x38], xmm5
4341c177 add      ecx, 0x90
4341c17d mov      eax, dword ptr [esp + 0x4d0]
4341c184 mov      dword ptr [esp + 0x1c], ecx
4341c188 cmp      esi, eax
4341c18a jl       0x4341be03
4341c190 mov      edi, dword ptr [ebp + 0xc]
4341c193 xor      edx, edx
4341c195 mov      esi, dword ptr [esp + 0x30]
4341c199 jmp      0x4341c1a4
4341c19b mov      eax, edx
4341c19d mov      dword ptr [esp + 0x4d0], eax
4341c1a4 test     eax, eax
4341c1a6 je       0x4341c62f
4341c1ac test     byte ptr [edi + 0x14c], 0x80
4341c1b3 je       0x4341c62f
4341c1b9 lea      eax, [esp + 0xf90]
4341c1c0 mov      dword ptr [esp + 0x20], 3
4341c1c8 mov      dword ptr [esp + 0x28], eax
4341c1cc lea      eax, [edi + 0x6e0]
4341c1d2 mov      dword ptr [esp + 0x38], eax
4341c1d6 lea      edi, [esp + 0xf90]
4341c1dd mov      eax, dword ptr [0x43467e8c]
4341c1e2 mov      eax, dword ptr [eax]
4341c1e4 xor      eax, dword ptr [0x43467900]
4341c1ea xor      eax, 0x32e4daf1
4341c1ef mov      ecx, dword ptr [eax + esi]
4341c1f2 test     ecx, ecx
4341c1f4 je       0x4341c60d
4341c1fa cmp      dword ptr [ecx], edx
4341c1fc je       0x4341c60d
4341c202 mov      eax, dword ptr [0x43468240]
4341c207 mov      ecx, dword ptr [ecx]
4341c209 mov      eax, dword ptr [eax]
4341c20b xor      eax, dword ptr [0x4346a84c]
4341c211 xor      eax, 0xc2b6fb10
4341c216 imul     eax, dword ptr [eax + esi], 0xc
4341c21a add      eax, dword ptr [ecx + 0xb0]
4341c220 add      eax, ecx
4341c222 mov      dword ptr [esp + 0x2c], eax
4341c226 je       0x4341c60d
4341c22c cmp      dword ptr [eax + 4], edx
4341c22f je       0x4341c60d
4341c235 mov      eax, dword ptr [eax + 4]
4341c238 push     0x13
4341c23a pop      ecx
4341c23b cmp      eax, ecx
4341c23d mov      dword ptr [esp + 0xc], edx
4341c241 cmova    eax, ecx
4341c244 mov      dword ptr [edi], eax
4341c246 test     eax, eax
4341c248 jle      0x4341c60f
4341c24e mov      eax, dword ptr [esp + 0x38]
4341c252 lea      ecx, [edi + 0x34]
4341c255 mov      edi, dword ptr [esp + 0x2c]
4341c259 mov      dword ptr [esp + 0x48], edx
4341c25d mov      dword ptr [esp + 0x1c], eax
4341c261 mov      dword ptr [esp + 0x18], ecx
4341c265 mov      eax, dword ptr [esp + 0xc]
4341c269 lea      esi, [edx + edi]
4341c26c add      esi, dword ptr [edi + 8]
4341c26f mov      dword ptr [ecx - 0x24], eax
4341c272 mov      dword ptr [ecx - 0x20], esi
4341c275 movss    xmm0, dword ptr [esi + 0x28]
4341c27a mulss    xmm0, dword ptr [0x43470528]
4341c282 movss    dword ptr [esp + 0x2c], xmm0
4341c288 call     0x7750c6d0
4341c28d movss    dword ptr [esp + 0x9c], xmm0
4341c296 movss    xmm0, dword ptr [esp + 0x2c]
4341c29c call     0x7750a770
4341c2a1 movss    dword ptr [esp + 0x44], xmm0
4341c2a7 movss    xmm0, dword ptr [esi + 0x24]
4341c2ac mulss    xmm0, dword ptr [0x43470528]
4341c2b4 movss    dword ptr [esp + 0x2c], xmm0
4341c2ba call     0x7750c6d0
4341c2bf movss    dword ptr [esp + 0x14], xmm0
4341c2c5 movss    xmm0, dword ptr [esp + 0x2c]
4341c2cb call     0x7750a770
4341c2d0 movss    dword ptr [esp + 0x90], xmm0
4341c2d9 movss    xmm0, dword ptr [esi + 0x2c]
4341c2de mulss    xmm0, dword ptr [0x43470528]
4341c2e6 movss    dword ptr [esp + 0x2c], xmm0
4341c2ec call     0x7750c6d0
4341c2f1 movss    dword ptr [esp + 0x98], xmm0
4341c2fa movss    xmm0, dword ptr [esp + 0x2c]
4341c300 call     0x7750a770
4341c305 movss    xmm3, dword ptr [esp + 0x90]
4341c30e movaps   xmm7, xmm0
4341c311 movss    xmm2, dword ptr [esp + 0x9c]
4341c31a movaps   xmm1, xmm3
4341c31d mulss    xmm7, dword ptr [esp + 0x44]
4341c323 movaps   xmm6, xmm0
4341c326 mov      eax, dword ptr [esp + 0x1c]
4341c32a mulss    xmm1, xmm2
4341c32e and      dword ptr [esp + 0x1cc], 0
4341c336 mulss    xmm0, xmm3
4341c33a movss    dword ptr [esp + 0x1b0], xmm1
4341c343 movss    xmm1, dword ptr [esp + 0x98]
4341c34c movaps   xmm5, xmm1
4341c34f mulss    xmm6, xmm2
4341c353 mulss    xmm5, dword ptr [esp + 0x44]
4341c359 movaps   xmm4, xmm1
4341c35c mulss    xmm1, xmm3
4341c360 mulss    xmm3, dword ptr [esp + 0x44]
4341c366 mulss    xmm4, xmm2
4341c36a xorps    xmm2, xmm2
4341c36d movss    dword ptr [esp + 0x1c4], xmm1
4341c376 movaps   xmm2, xmm6
4341c379 movaps   xmm1, xmm7
4341c37c movss    dword ptr [esp + 0x1c8], xmm0
4341c385 mulss    xmm1, dword ptr [esp + 0x14]
4341c38b movaps   xmm0, xmm5
4341c38e mulss    xmm0, dword ptr [esp + 0x14]
4341c394 addss    xmm1, xmm4
4341c398 subss    xmm0, xmm6
4341c39c movups   xmm6, xmmword ptr [eax]
4341c39f unpcklps xmm3, xmm1
4341c3a2 movss    xmm1, dword ptr [esp + 0x14]
4341c3a8 mulss    xmm2, xmm1
4341c3ac unpcklps xmm3, xmm0
4341c3af movaps   xmmword ptr [esp + 0x80], xmm3
4341c3b7 movaps   xmmword ptr [esp + 0x1a0], xmm3
4341c3bf subss    xmm2, xmm5
4341c3c3 movaps   xmm3, xmm1
4341c3c6 movaps   xmm1, xmm4
4341c3c9 mulss    xmm1, dword ptr [esp + 0x14]
4341c3cf xorps    xmm3, xmmword ptr [0x434703d0]
4341c3d6 movups   xmm4, xmmword ptr [eax - 0x10]
4341c3da addss    xmm1, xmm7
4341c3de unpcklps xmm2, xmm3
4341c3e1 movaps   xmm7, xmmword ptr [0x43471e40]
4341c3e8 unpcklps xmm1, xmm2
4341c3eb movups   xmm2, xmmword ptr [eax - 0x20]
4341c3ef movups   xmmword ptr [esp + 0x1b4], xmm1
4341c3f7 movaps   xmm3, xmmword ptr [esp + 0x1c0]
4341c3ff movaps   xmm1, xmm2
4341c402 movaps   xmm5, xmmword ptr [esp + 0x1b0]
4341c40a shufps   xmm1, xmm2, 0xaa
4341c40e mulps    xmm1, xmm3
4341c411 mov      eax, dword ptr [esp + 0x18]
4341c415 movaps   xmm0, xmm2
4341c418 shufps   xmm0, xmm2, 0x55
4341c41c mulps    xmm0, xmm5
4341c41f push     0x44
4341c421 push     esi
4341c422 addps    xmm1, xmm0
4341c425 movaps   xmm0, xmm2
4341c428 shufps   xmm0, xmm2, 0
4341c42c andps    xmm2, xmm7
4341c42f mulps    xmm0, xmmword ptr [esp + 0x88]
4341c437 addps    xmm1, xmm0
4341c43a movaps   xmm0, xmm4
4341c43d shufps   xmm0, xmm4, 0x55
4341c441 mulps    xmm0, xmm5
4341c444 addps    xmm1, xmm2
4341c447 movups   xmmword ptr [eax - 0x14], xmm1
4341c44b movaps   xmm1, xmm4
4341c44e shufps   xmm1, xmm4, 0xaa
4341c452 mulps    xmm1, xmm3
4341c455 addps    xmm1, xmm0
4341c458 movaps   xmm0, xmm4
4341c45b shufps   xmm0, xmm4, 0
4341c45f andps    xmm4, xmm7
4341c462 mulps    xmm0, xmmword ptr [esp + 0x88]
4341c46a addps    xmm1, xmm0
4341c46d movaps   xmm0, xmm6
4341c470 shufps   xmm0, xmm6, 0x55
4341c474 mulps    xmm0, xmm5
4341c477 addps    xmm1, xmm4
4341c47a movups   xmmword ptr [eax - 4], xmm1
4341c47e movaps   xmm1, xmm6
4341c481 shufps   xmm1, xmm6, 0xaa
4341c485 mulps    xmm1, xmm3
4341c488 addps    xmm1, xmm0
4341c48b movaps   xmm0, xmm6
4341c48e shufps   xmm0, xmm6, 0
4341c492 andps    xmm6, xmm7
4341c495 mulps    xmm0, xmmword ptr [esp + 0x88]
4341c49d addps    xmm1, xmm0
4341c4a0 addps    xmm1, xmm6
4341c4a3 movups   xmmword ptr [eax + 0xc], xmm1
4341c4a7 add      eax, 0x1c
4341c4aa push     eax
4341c4ab call     0x774fd4a0
4341c4b0 mov      ecx, dword ptr [esp + 0x24]
4341c4b4 add      esp, 0xc
4341c4b7 movss    xmm1, dword ptr [esi + 0xc]
4341c4bc movss    xmm0, dword ptr [esi + 8]
4341c4c1 mulss    xmm1, dword ptr [ecx - 0x10]
4341c4c6 mulss    xmm0, dword ptr [ecx - 0x14]
4341c4cb addss    xmm1, xmm0
4341c4cf movss    xmm0, dword ptr [esi + 0x10]
4341c4d4 mulss    xmm0, dword ptr [ecx - 0xc]
4341c4d9 addss    xmm1, xmm0
4341c4dd addss    xmm1, dword ptr [ecx - 8]
4341c4e2 movss    dword ptr [ecx + 0x24], xmm1
4341c4e7 movss    xmm1, dword ptr [esi + 8]
4341c4ec mulss    xmm1, dword ptr [ecx - 4]
4341c4f1 movss    xmm0, dword ptr [ecx]
4341c4f5 mulss    xmm0, dword ptr [esi + 0xc]
4341c4fa addss    xmm1, xmm0
4341c4fe movss    xmm0, dword ptr [esi + 0x10]
4341c503 mulss    xmm0, dword ptr [ecx + 4]
4341c508 addss    xmm1, xmm0
4341c50c addss    xmm1, dword ptr [ecx + 8]
4341c511 movss    dword ptr [ecx + 0x28], xmm1
4341c516 movss    xmm1, dword ptr [esi + 0xc]
4341c51b movss    xmm0, dword ptr [ecx + 0xc]
4341c520 mulss    xmm0, dword ptr [esi + 8]
4341c525 movss    xmm5, dword ptr [ecx + 0x10]
4341c52a mulss    xmm1, xmm5
4341c52e addss    xmm1, xmm0
4341c532 movss    xmm0, dword ptr [esi + 0x10]
4341c537 mulss    xmm0, dword ptr [ecx + 0x14]
4341c53c addss    xmm1, xmm0
4341c540 addss    xmm1, dword ptr [ecx + 0x18]
4341c545 movss    dword ptr [ecx + 0x2c], xmm1
4341c54a movss    xmm1, dword ptr [esi + 0x14]
4341c54f mulss    xmm1, dword ptr [ecx - 0x14]
4341c554 movss    xmm0, dword ptr [ecx - 0x10]
4341c559 mulss    xmm0, dword ptr [esi + 0x18]
4341c55e mov      eax, dword ptr [esp + 0x28]
4341c562 mov      edx, dword ptr [esp + 0x48]
4341c566 add      dword ptr [esp + 0x1c], 0x30
4341c56b add      edx, 0x44
4341c56e addss    xmm1, xmm0
4341c572 mov      dword ptr [esp + 0x48], edx
4341c576 movss    xmm0, dword ptr [esi + 0x1c]
4341c57b mulss    xmm0, dword ptr [ecx - 0xc]
4341c580 addss    xmm1, xmm0
4341c584 addss    xmm1, dword ptr [ecx - 8]
4341c589 movss    dword ptr [ecx + 0x30], xmm1
4341c58e movss    xmm1, dword ptr [esi + 0x14]
4341c593 mulss    xmm1, dword ptr [ecx - 4]
4341c598 movss    xmm0, dword ptr [ecx]
4341c59c mulss    xmm0, dword ptr [esi + 0x18]
4341c5a1 addss    xmm1, xmm0
4341c5a5 movss    xmm0, dword ptr [esi + 0x1c]
4341c5aa mulss    xmm0, dword ptr [ecx + 4]
4341c5af addss    xmm1, xmm0
4341c5b3 addss    xmm1, dword ptr [ecx + 8]
4341c5b8 movss    dword ptr [ecx + 0x34], xmm1
4341c5bd movss    xmm1, dword ptr [esi + 0x14]
4341c5c2 mulss    xmm1, dword ptr [ecx + 0xc]
4341c5c7 mulss    xmm5, dword ptr [esi + 0x18]
4341c5cc movss    xmm0, dword ptr [esi + 0x1c]
4341c5d1 mulss    xmm0, dword ptr [ecx + 0x14]
4341c5d6 mov      esi, dword ptr [esp + 0xc]
4341c5da addss    xmm1, xmm5
4341c5de inc      esi
4341c5df mov      dword ptr [esp + 0xc], esi
4341c5e3 addss    xmm1, xmm0
4341c5e7 addss    xmm1, dword ptr [ecx + 0x18]
4341c5ec movss    dword ptr [ecx + 0x38], xmm1
4341c5f1 add      ecx, 0x90
4341c5f7 mov      dword ptr [esp + 0x18], ecx
4341c5fb cmp      esi, dword ptr [eax]
4341c5fd jl       0x4341c265
4341c603 mov      esi, dword ptr [esp + 0x30]
4341c607 xor      edx, edx
4341c609 mov      edi, eax
4341c60b jmp      0x4341c60f
4341c60d mov      dword ptr [edi], edx
4341c60f add      dword ptr [esp + 0x38], 0x3a0
4341c617 add      edi, 0xac0
4341c61d sub      dword ptr [esp + 0x20], 1
4341c622 mov      dword ptr [esp + 0x28], edi
4341c626 jne      0x4341c1dd
4341c62c mov      edi, dword ptr [ebp + 0xc]
4341c62f movss    xmm0, dword ptr [esp + 0x24]
4341c635 mov      eax, dword ptr [ebp + 8]
4341c638 lea      esi, [esp + 0xbc]
4341c63f mov      ecx, dword ptr [esp + 0x34]
4341c643 mov      edx, 0x111c
4341c648 mov      dword ptr [esp + 0xc8], eax
4341c64f mov      eax, dword ptr [esp + 0x30]
4341c653 mov      dword ptr [esp + 0xd0], eax
4341c65a lea      eax, [esp + 0x4d0]
4341c661 test     byte ptr [ecx + 0x178], 8
4341c668 mov      dword ptr [esp + 0xd4], eax
4341c66f mov      eax, 0xd1c
4341c674 mov      dword ptr [esp + 0xcc], edi
4341c67b cmovne   eax, edx
4341c67e add      eax, ecx
4341c680 movss    xmm1, dword ptr [esp + 0x3c]
4341c686 mov      dword ptr [esp + 0xd8], eax
4341c68d lea      edi, [esp + 0xdc]
4341c694 movsd    dword ptr es:[edi], dword ptr [esi]
4341c695 mov      eax, dword ptr [esp + 0x94]
4341c69c movsd    dword ptr es:[edi], dword ptr [esi]
4341c69d movsd    dword ptr es:[edi], dword ptr [esi]
4341c69e lea      esi, [esp + 0x50]
4341c6a2 lea      edi, [esp + 0xe8]
4341c6a9 movsd    dword ptr es:[edi], dword ptr [esi]
4341c6aa movsd    dword ptr es:[edi], dword ptr [esi]
4341c6ab movsd    dword ptr es:[edi], dword ptr [esi]
4341c6ac mov      eax, dword ptr [eax + 4]
4341c6af lea      esi, [esp + 0x6c]
4341c6b3 mov      dword ptr [esp + 0xf4], eax
4341c6ba lea      edi, [esp + 0x104]
4341c6c1 mov      eax, dword ptr [esp + 0x10]
4341c6c5 mov      dword ptr [esp + 0x100], eax
4341c6cc mov      eax, dword ptr [esp + 0x5c]
4341c6d0 movss    dword ptr [esp + 0xf8], xmm1
4341c6d9 movss    dword ptr [esp + 0xfc], xmm0
4341c6e2 movsd    dword ptr es:[edi], dword ptr [esi]
4341c6e3 movsd    dword ptr es:[edi], dword ptr [esi]
4341c6e4 movsd    dword ptr es:[edi], dword ptr [esi]
4341c6e5 lea      esi, [esp + 0x60]
4341c6e9 lea      edi, [esp + 0x110]
4341c6f0 movsd    dword ptr es:[edi], dword ptr [esi]
4341c6f1 movsd    dword ptr es:[edi], dword ptr [esi]
4341c6f2 movsd    dword ptr es:[edi], dword ptr [esi]
4341c6f3 mov      edi, dword ptr [esp + 0x4c]
4341c6f7 mov      dword ptr [esp + 0x11c], eax
4341c6fe mov      al, byte ptr [esp + 0xb]
4341c702 mov      byte ptr [esp + 0x120], al
4341c709 xor      eax, eax
4341c70b mov      dword ptr [esp + 0x124], edi
4341c712 mov      dword ptr [esp + 0x128], eax
4341c719 mov      dword ptr [esp + 0x12c], eax
4341c720 lea      ecx, [esp + 0xc8]
4341c727 mov      dword ptr [esp + eax*8 + 0x2d4], eax
4341c72e mov      dword ptr [esp + eax*8 + 0x2d0], ecx
4341c735 inc      eax
4341c736 cmp      eax, 0x40
4341c739 jl       0x4341c720
4341c73b cmp      byte ptr [0x434683fc], 0
4341c742 je       0x4341c7cf
4341c748 push     0x1c
4341c74a pop      ecx
4341c74b call     0x43387448
4341c750 mov      esi, eax
4341c752 xor      eax, eax
4341c754 test     esi, esi
4341c756 je       0x4341c7a1
4341c758 mov      dword ptr [esi], 0x4346f518
4341c75e mov      dword ptr [esi + 8], 1
4341c765 mov      dword ptr [esi + 0xc], 0x433df8a0
4341c76c mov      dword ptr [esi + 0x10], eax
4341c76f mov      dword ptr [esi + 0x14], eax
4341c772 mov      dword ptr [esi + 0x18], eax
4341c775 jmp      0x4341c7a3
4341c777 lea      eax, [edi + 0xf0]
4341c77d push     eax
4341c77e lea      ecx, [esp + 0x2fd4]
4341c785 call     0x4331e453
4341c78a movss    xmm0, dword ptr [esp + 0x7c]
4341c790 movss    dword ptr [esp + 0x3c], xmm0
4341c796 movss    xmm0, dword ptr [esp + 0x7c]
4341c79c jmp      0x4341c635
4341c7a1 mov      esi, eax
4341c7a3 push     dword ptr [esp + 0x10]
4341c7a7 lea      eax, [esp + 0x2d4]
4341c7ae mov      ecx, esi
4341c7b0 push     eax
4341c7b1 call     0x4338714f
4341c7b6 mov      eax, dword ptr [esi]
4341c7b8 mov      ecx, esi
4341c7ba mov      eax, dword ptr [eax + 4]
4341c7bd cmp      eax, 0x43346f24
4341c7c2 jne      0x4341c7cb
4341c7c4 call     0x43346f24
4341c7c9 jmp      0x4341c7ed
4341c7cb call     eax
4341c7cd jmp      0x4341c7ed
4341c7cf mov      edi, dword ptr [esp + 0x10]
4341c7d3 lea      esi, [esp + 0x2d0]
4341c7da mov      ecx, esi
4341c7dc call     0x433df8a0
4341c7e1 add      esi, 8
4341c7e4 sub      edi, 1
4341c7e7 jne      0x4341c7da
4341c7e9 mov      edi, dword ptr [esp + 0x4c]
4341c7ed movzx    edx, word ptr [esp + 0x128]
4341c7f5 mov      ecx, dword ptr [esp + 0x128]
4341c7fc sar      ecx, 0x10
4341c7ff mov      eax, ecx
4341c801 sub      eax, edx
4341c803 cmp      eax, edi
4341c805 jge      0x4341c814
4341c807 xor      eax, eax
4341c809 cmp      dword ptr [esp + 0x12c], eax
4341c810 je       0x4341c81a
4341c812 jmp      0x4341c816
4341c814 xor      eax, eax
4341c816 mov      edx, eax
4341c818 mov      ecx, eax
4341c81a mov      esi, dword ptr [ebp + 0xc]
4341c81d xorps    xmm2, xmm2
4341c820 mov      eax, dword ptr [esi + 0x28]
4341c823 mov      dword ptr [esp + 0x5c], eax
4341c827 test     ecx, ecx
4341c829 jne      0x4341c830
4341c82b xorps    xmm1, xmm1
4341c82e jmp      0x4341c842
4341c830 movd     xmm1, edx
4341c834 movd     xmm0, ecx
4341c838 cvtdq2ps xmm1, xmm1
4341c83b cvtdq2ps xmm0, xmm0
4341c83e divss    xmm1, xmm0
4341c842 mov      eax, dword ptr [ebp + 0x10]
4341c845 movss    xmm0, dword ptr [esp + 0x40]
4341c84b comiss   xmm0, xmm1
4341c84e movss    dword ptr [eax], xmm1
4341c852 jbe      0x4341c9be
4341c858 mov      eax, dword ptr [esp + 0x34]
4341c85c test     byte ptr [eax + 0x178], 8
4341c863 jne      0x4341c9c3
4341c869 mov      edi, dword ptr [ebp + 8]
4341c86c test     dword ptr [edi], 0x40000
4341c872 je       0x4341c9b1
4341c878 cmp      dword ptr [esi + 0x30], 1
4341c87c jne      0x4341c9b1
4341c882 test     dword ptr [edi], 0x400
4341c888 je       0x4341c9b1
4341c88e mov      edx, dword ptr [edi + 0xc]
4341c891 test     edx, edx
4341c893 je       0x4341c948
4341c899 mov      dword ptr [esp + 0x40], 0xc606305
4341c8a1 mov      eax, dword ptr [esp + 0x40]
4341c8a5 mov      ecx, dword ptr [edx]
4341c8a7 rol      eax, 0x1e
4341c8aa mov      ecx, dword ptr [eax + ecx - 0x431811d9]
4341c8b1 call     0x433e533f
4341c8b6 fstp     dword ptr [esp + 0x40]
4341c8ba movss    xmm3, dword ptr [esp + 0x40]
4341c8c0 xorps    xmm2, xmm2
4341c8c3 ucomiss  xmm3, xmm2
4341c8c6 lahf     
4341c8c7 test     ah, 0x44
4341c8ca jnp      0x4341c948
4341c8cc movss    xmm1, dword ptr [edi + 0x150]
4341c8d4 movss    xmm0, dword ptr [edi + 0x154]
4341c8dc mulss    xmm1, xmm1
4341c8e0 mulss    xmm0, xmm0
4341c8e4 addss    xmm1, xmm0
4341c8e8 movaps   xmm0, xmm1
4341c8eb movaps   xmm1, xmm3
4341c8ee mulss    xmm1, dword ptr [0x43472144]
4341c8f6 mulss    xmm3, dword ptr [0x43472714]
4341c8fe sqrtss   xmm0, xmm0
4341c902 ucomiss  xmm1, xmm3
4341c905 lahf     
4341c906 test     ah, 0x44
4341c909 jp       0x4341c915
4341c90b comiss   xmm0, xmm3
4341c90e jb       0x4341c948
4341c910 jmp      0x4341c9b1
4341c915 subss    xmm0, xmm1
4341c919 subss    xmm3, xmm1
4341c91d xorps    xmm1, xmm1
4341c920 divss    xmm0, xmm3
4341c924 movss    xmm1, xmm0
4341c928 movaps   xmm0, xmm2
4341c92b maxss    xmm1, xmm0
4341c92f movss    xmm0, dword ptr [0x43470514]
4341c937 minss    xmm1, xmm0
4341c93b addss    xmm1, xmm2
4341c93f ucomiss  xmm1, xmm2
4341c942 lahf     
4341c943 test     ah, 0x44
4341c946 jp       0x4341c9b1
4341c948 movss    xmm1, dword ptr [edi + 0x108]
4341c950 subss    xmm1, dword ptr [edi + 0xc4]
4341c958 comiss   xmm1, xmm2
4341c95b jb       0x4341c9b1
4341c95d movss    xmm0, dword ptr [0x434723ec]
4341c965 comiss   xmm0, xmm1
4341c968 jbe      0x4341c9b1
4341c96a movd     xmm0, dword ptr [esp + 0x5c]
4341c970 cvtdq2ps xmm0, xmm0
4341c973 mulss    xmm0, dword ptr [0x43472750]
4341c97b addss    xmm0, dword ptr [0x43472240]
4341c983 cvttss2si eax, xmm0
4341c987 cmp      eax, dword ptr [esi + 0xd0]
4341c98d jl       0x4341c9b1
4341c98f mov      ecx, dword ptr [esi + 4]
4341c992 test     ecx, ecx
4341c994 jne      0x4341c9a2
4341c996 xchg     cl, ah
4341c998 salc     
4341c999 cmp      dh, byte ptr [esi - 0x67]
4341c99c insd     dword ptr es:[edi], dx
4341c99d or       dword ptr [edx - 0x17be325e], esp
4341c9a2 call     0x433b8a2b
4341c9a3 test     al, al
4341c9a5 stc      
4341c9a6 inc      edi
4341c9a7 mov      dword ptr [eax + 0xf8], 3
4341c9a8 cmp      al, 0
4341c9ab add      byte ptr [eax], al
4341c9ad add      eax, dword ptr [eax]
4341c9af add      byte ptr [eax], al
4341c9b1 mov      eax, dword ptr [esp + 0x34]
4341c9b5 or       dword ptr [eax + 0x178], 0x40
4341c9bc jmp      0x4341c9c3
4341c9be mov      byte ptr [esp + 0x78], 1
4341c9c3 lea      ecx, [esp + 0x2fd0]
4341c9ca call     0x4336630d
4341c9cf mov      eax, dword ptr [esp + 0x78]
4341c9d3 pop      edi
4341c9d4 pop      esi
4341c9d5 mov      esp, ebp
4341c9d7 pop      ebp
4341c9d8 ret      0xc
