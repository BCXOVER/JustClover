433eb28b push     esi
433eb28c mov      esi, ecx
433eb28e xor      eax, eax
433eb290 or       dword ptr [esi + 0x70], 0xffffffff
433eb294 or       dword ptr [esi + 0x7c], 0xffffffff
433eb298 mov      word ptr [esi + 0x62], ax
433eb29c mov      dword ptr [esi + 0x78], eax
433eb29f mov      al, byte ptr [esp + 0xc]
433eb2a3 mov      dword ptr [esi + 0x58], 0x3f800000
433eb2aa mov      byte ptr [esi], al
433eb2ac call     0x433fcfd4
433eb2b1 mov      ecx, dword ptr [esp + 8]
433eb2b5 lea      edx, [esi + 0xc]
433eb2b8 call     0x433c8c4d
433eb2bd mov      eax, esi
433eb2bf pop      esi
433eb2c0 ret      8
