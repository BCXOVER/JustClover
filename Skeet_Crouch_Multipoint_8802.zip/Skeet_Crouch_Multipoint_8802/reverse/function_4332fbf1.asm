4332fbf1 mov      eax, dword ptr [esp + 4]
4332fbf5 mov      eax, dword ptr [eax + 0x5c]
4332fbf8 test     eax, eax
4332fbfa jne      0x4332fc00
4332fbfc xor      al, al
4332fbfe jmp      0x4332fc02
4332fc00 mov      al, byte ptr [eax]
4332fc02 cmp      byte ptr [ecx + 0xe8], al
4332fc08 je       0x4332fc2e
4332fc0a mov      byte ptr [ecx + 0xe8], al
4332fc10 call     0x4334d9e5
4332fc15 mov      eax, dword ptr [0x4346a334]
4332fc1a movss    xmm0, dword ptr [eax]
4332fc1e addss    xmm0, dword ptr [0x4346dd4c]
4332fc26 movss    dword ptr [0x4346a8a0], xmm0
4332fc2e ret      4
