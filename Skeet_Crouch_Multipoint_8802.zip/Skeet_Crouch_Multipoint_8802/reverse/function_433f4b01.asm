433f4b01 push     ecx
433f4b02 push     ebx
433f4b03 push     ebp
433f4b04 push     esi
433f4b05 push     edi
433f4b06 xor      edx, edx
433f4b08 xor      bl, bl
433f4b0a push     0x10
433f4b0c mov      ebp, ecx
433f4b0e inc      edx
433f4b0f pop      edi
433f4b10 mov      esi, edx
433f4b12 mov      ecx, edx
433f4b14 shr      esi, 5
433f4b17 and      ecx, 0x1f
433f4b1a cmp      edx, 0x400
433f4b20 jae      0x433f4b33
433f4b22 xor      eax, eax
433f4b24 inc      eax
433f4b25 shl      eax, cl
433f4b27 test     dword ptr [esi*4 + 0x43479098], eax
433f4b2e setne    bh
433f4b31 jmp      0x433f4b35
433f4b33 xor      bh, bh
433f4b35 mov      eax, dword ptr [ebp + 0x130]
433f4b3b mov      al, byte ptr [edi + eax]
433f4b3e mov      byte ptr [esp + 0x13], al
433f4b42 cmp      bh, al
433f4b44 je       0x433f4b6d
433f4b46 cmp      edx, 0x400
433f4b4c jae      0x433f4b6b
433f4b4e cmp      byte ptr [esp + 0x13], 0
433f4b53 mov      eax, dword ptr [esi*4 + 0x43479098]
433f4b5a je       0x433f4b61
433f4b5c bts      eax, ecx
433f4b5f jmp      0x433f4b64
433f4b61 btr      eax, ecx
433f4b64 mov      dword ptr [esi*4 + 0x43479098], eax
433f4b6b mov      bl, 1
433f4b6d add      edi, 0x10
433f4b70 inc      edx
433f4b71 cmp      edi, 0x410
433f4b77 jl       0x433f4b10
433f4b79 pop      edi
433f4b7a pop      esi
433f4b7b pop      ebp
433f4b7c test     bl, bl
433f4b7e pop      ebx
433f4b7f je       0x433f4b9f
433f4b81 call     0x4334d9e5
433f4b86 mov      eax, dword ptr [0x4346a334]
433f4b8b movss    xmm0, dword ptr [eax]
433f4b8f addss    xmm0, dword ptr [0x4346dd4c]
433f4b97 movss    dword ptr [0x4346a8a0], xmm0
433f4b9f pop      ecx
433f4ba0 ret      4
