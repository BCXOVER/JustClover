4335cd37  55                       push     ebp
4335cd38  8bec                     mov      ebp, esp
4335cd3a  83e4f0                   and      esp, 0xfffffff0
4335cd3d  81eca8800000             sub      esp, 0x80a8
4335cd43  56                       push     esi
4335cd44  57                       push     edi
4335cd45  8b7d1c                   mov      edi, dword ptr [ebp + 0x1c]
4335cd48  898c2480000000           mov      dword ptr [esp + 0x80], ecx
4335cd4f  8d8c24e01c0000           lea      ecx, [esp + 0x1ce0]
4335cd56  897c245c                 mov      dword ptr [esp + 0x5c], edi
4335cd5a  e826e60400               call     0x433ab385
4335cd5f  8d8c2450120000           lea      ecx, [esp + 0x1250]
4335cd66  e825870000               call     0x43365490
4335cd6b  8b7510                   mov      esi, dword ptr [ebp + 0x10]
4335cd6e  8bce                     mov      ecx, esi
4335cd70  89b42490000000           mov      dword ptr [esp + 0x90], esi
4335cd77  e891050a00               call     0x433fd30d
4335cd7c  f30f100d28054743         movss    xmm1, dword ptr [0x43470528]
4335cd84  33d2                     xor      edx, edx
4335cd86  85c0                     test     eax, eax
4335cd88  0f8413040000             je       0x4335d1a1
4335cd8e  85f6                     test     esi, esi
4335cd90  750c                     jne      0x4335cd9e
4335cd92  3f                       aas      
4335cd93  e6fe                     out      0xfe, al
4335cd9e  8b08                     mov      ecx, dword ptr [eax]
4335cda0  a140824643               mov      eax, dword ptr [0x43468240]
4335cda5  8b00                     mov      eax, dword ptr [eax]
4335cda7  33054ca84643             xor      eax, dword ptr [0x4346a84c]
4335cdad  3510fbb6c2               xor      eax, 0xc2b6fb10
4335cdb2  6b04300c                 imul     eax, dword ptr [eax + esi], 0xc
4335cdb6  0381b0000000             add      eax, dword ptr [ecx + 0xb0]
4335cdbc  03c1                     add      eax, ecx
4335cdbe  89442424                 mov      dword ptr [esp + 0x24], eax
4335cdc2  0f84d9030000             je       0x4335d1a1
4335cdc8  395004                   cmp      dword ptr [eax + 4], edx
4335cdcb  0f84d0030000             je       0x4335d1a1
4335cdd1  8b4004                   mov      eax, dword ptr [eax + 4]
4335cdd4  6a13                     push     0x13
4335cdd6  59                       pop      ecx
4335cdd7  3bc1                     cmp      eax, ecx
4335cdd9  89542420                 mov      dword ptr [esp + 0x20], edx
4335cddd  0f47c1                   cmova    eax, ecx
4335cde0  898424e01c0000           mov      dword ptr [esp + 0x1ce0], eax
4335cde7  85c0                     test     eax, eax
4335cde9  0f8ebd030000             jle      0x4335d1ac
4335cdef  8d8740030000             lea      eax, [edi + 0x340]
4335cdf5  8954241c                 mov      dword ptr [esp + 0x1c], edx
4335cdf9  8b7c2424                 mov      edi, dword ptr [esp + 0x24]
4335cdfd  8d8c24141d0000           lea      ecx, [esp + 0x1d14]
4335ce04  894c2418                 mov      dword ptr [esp + 0x18], ecx
4335ce08  8944242c                 mov      dword ptr [esp + 0x2c], eax
4335ce0c  eb08                     jmp      0x4335ce16
4335ce0e  f30f100d28054743         movss    xmm1, dword ptr [0x43470528]
4335ce16  8b7708                   mov      esi, dword ptr [edi + 8]
4335ce19  0374241c                 add      esi, dword ptr [esp + 0x1c]
4335ce1d  03f7                     add      esi, edi
4335ce1f  8951dc                   mov      dword ptr [ecx - 0x24], edx
4335ce22  8971e0                   mov      dword ptr [ecx - 0x20], esi
4335ce25  f30f104628               movss    xmm0, dword ptr [esi + 0x28]
4335ce2a  f30f59c1                 mulss    xmm0, xmm1
4335ce2e  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
4335ce34  e897f81a34               call     0x7750c6d0
4335ce39  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
4335ce3f  f30f10442424             movss    xmm0, dword ptr [esp + 0x24]
4335ce45  e826d91a34               call     0x7750a770
4335ce4a  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
4335ce50  f30f104624               movss    xmm0, dword ptr [esi + 0x24]
4335ce55  f30f590528054743         mulss    xmm0, dword ptr [0x43470528]
4335ce5d  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
4335ce63  e868f81a34               call     0x7750c6d0
4335ce68  f30f11442428             movss    dword ptr [esp + 0x28], xmm0
4335ce6e  f30f10442424             movss    xmm0, dword ptr [esp + 0x24]
4335ce74  e8f7d81a34               call     0x7750a770
4335ce79  f30f1144244c             movss    dword ptr [esp + 0x4c], xmm0
4335ce7f  f30f10462c               movss    xmm0, dword ptr [esi + 0x2c]
4335ce84  f30f590528054743         mulss    xmm0, dword ptr [0x43470528]
4335ce8c  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
4335ce92  e839f81a34               call     0x7750c6d0
4335ce97  f30f11442440             movss    dword ptr [esp + 0x40], xmm0
4335ce9d  f30f10442424             movss    xmm0, dword ptr [esp + 0x24]
4335cea3  e8c8d81a34               call     0x7750a770
4335cea8  f30f105c244c             movss    xmm3, dword ptr [esp + 0x4c]
4335ceae  0f28f8                   movaps   xmm7, xmm0
4335ceb1  f30f10542438             movss    xmm2, dword ptr [esp + 0x38]
4335ceb7  0f28cb                   movaps   xmm1, xmm3
4335ceba  f30f597c2414             mulss    xmm7, dword ptr [esp + 0x14]
4335cec0  0f28f0                   movaps   xmm6, xmm0
4335cec3  8b44242c                 mov      eax, dword ptr [esp + 0x2c]
4335cec7  f30f59ca                 mulss    xmm1, xmm2
4335cecb  83a4242c0c000000         and      dword ptr [esp + 0xc2c], 0
4335ced3  f30f59c3                 mulss    xmm0, xmm3
4335ced7  f30f118c24100c0000       movss    dword ptr [esp + 0xc10], xmm1
4335cee0  f30f104c2440             movss    xmm1, dword ptr [esp + 0x40]
4335cee6  0f28e9                   movaps   xmm5, xmm1
4335cee9  f30f59f2                 mulss    xmm6, xmm2
4335ceed  f30f596c2414             mulss    xmm5, dword ptr [esp + 0x14]
4335cef3  0f28e1                   movaps   xmm4, xmm1
4335cef6  f30f59cb                 mulss    xmm1, xmm3
4335cefa  f30f595c2414             mulss    xmm3, dword ptr [esp + 0x14]
4335cf00  f30f59e2                 mulss    xmm4, xmm2
4335cf04  0f57d2                   xorps    xmm2, xmm2
4335cf07  f30f118c24240c0000       movss    dword ptr [esp + 0xc24], xmm1
4335cf10  0f28d6                   movaps   xmm2, xmm6
4335cf13  0f28cf                   movaps   xmm1, xmm7
4335cf16  f30f118424280c0000       movss    dword ptr [esp + 0xc28], xmm0
4335cf1f  f30f594c2428             mulss    xmm1, dword ptr [esp + 0x28]
4335cf25  0f28c5                   movaps   xmm0, xmm5
4335cf28  f30f59442428             mulss    xmm0, dword ptr [esp + 0x28]
4335cf2e  f30f58cc                 addss    xmm1, xmm4
4335cf32  f30f5cc6                 subss    xmm0, xmm6
4335cf36  0f1030                   movups   xmm6, xmmword ptr [eax]
4335cf39  0f14d9                   unpcklps xmm3, xmm1
4335cf3c  f30f104c2428             movss    xmm1, dword ptr [esp + 0x28]
4335cf42  f30f59d1                 mulss    xmm2, xmm1
4335cf46  0f14d8                   unpcklps xmm3, xmm0
4335cf49  0f299c2400010000         movaps   xmmword ptr [esp + 0x100], xmm3
4335cf51  0f299c24000c0000         movaps   xmmword ptr [esp + 0xc00], xmm3
4335cf59  f30f5cd5                 subss    xmm2, xmm5
4335cf5d  0f28d9                   movaps   xmm3, xmm1
4335cf60  0f28cc                   movaps   xmm1, xmm4
4335cf63  f30f594c2428             mulss    xmm1, dword ptr [esp + 0x28]
4335cf69  0f571dd0034743           xorps    xmm3, xmmword ptr [0x434703d0]
4335cf70  0f1060f0                 movups   xmm4, xmmword ptr [eax - 0x10]
4335cf74  f30f58cf                 addss    xmm1, xmm7
4335cf78  0f14d3                   unpcklps xmm2, xmm3
4335cf7b  0f283d401e4743           movaps   xmm7, xmmword ptr [0x43471e40]
4335cf82  0f14ca                   unpcklps xmm1, xmm2
4335cf85  0f1050e0                 movups   xmm2, xmmword ptr [eax - 0x20]
4335cf89  0f118c24140c0000         movups   xmmword ptr [esp + 0xc14], xmm1
4335cf91  0f289c24200c0000         movaps   xmm3, xmmword ptr [esp + 0xc20]
4335cf99  0f28ca                   movaps   xmm1, xmm2
4335cf9c  0f28ac24100c0000         movaps   xmm5, xmmword ptr [esp + 0xc10]
4335cfa4  0fc6caaa                 shufps   xmm1, xmm2, 0xaa
4335cfa8  0f59cb                   mulps    xmm1, xmm3
4335cfab  8b442418                 mov      eax, dword ptr [esp + 0x18]
4335cfaf  0f28c2                   movaps   xmm0, xmm2
4335cfb2  0fc6c255                 shufps   xmm0, xmm2, 0x55
4335cfb6  0f59c5                   mulps    xmm0, xmm5
4335cfb9  6a44                     push     0x44
4335cfbb  56                       push     esi
4335cfbc  0f58c8                   addps    xmm1, xmm0
4335cfbf  0f28c2                   movaps   xmm0, xmm2
4335cfc2  0fc6c200                 shufps   xmm0, xmm2, 0
4335cfc6  0f54d7                   andps    xmm2, xmm7
4335cfc9  0f59842408010000         mulps    xmm0, xmmword ptr [esp + 0x108]
4335cfd1  0f58c8                   addps    xmm1, xmm0
4335cfd4  0f28c4                   movaps   xmm0, xmm4
4335cfd7  0fc6c455                 shufps   xmm0, xmm4, 0x55
4335cfdb  0f59c5                   mulps    xmm0, xmm5
4335cfde  0f58ca                   addps    xmm1, xmm2
4335cfe1  0f1148ec                 movups   xmmword ptr [eax - 0x14], xmm1
4335cfe5  0f28cc                   movaps   xmm1, xmm4
4335cfe8  0fc6ccaa                 shufps   xmm1, xmm4, 0xaa
4335cfec  0f59cb                   mulps    xmm1, xmm3
4335cfef  0f58c8                   addps    xmm1, xmm0
4335cff2  0f28c4                   movaps   xmm0, xmm4
4335cff5  0fc6c400                 shufps   xmm0, xmm4, 0
4335cff9  0f54e7                   andps    xmm4, xmm7
4335cffc  0f59842408010000         mulps    xmm0, xmmword ptr [esp + 0x108]
4335d004  0f58c8                   addps    xmm1, xmm0
4335d007  0f28c6                   movaps   xmm0, xmm6
4335d00a  0fc6c655                 shufps   xmm0, xmm6, 0x55
4335d00e  0f59c5                   mulps    xmm0, xmm5
4335d011  0f58cc                   addps    xmm1, xmm4
4335d014  0f1148fc                 movups   xmmword ptr [eax - 4], xmm1
4335d018  0f28ce                   movaps   xmm1, xmm6
4335d01b  0fc6ceaa                 shufps   xmm1, xmm6, 0xaa
4335d01f  0f59cb                   mulps    xmm1, xmm3
4335d022  0f58c8                   addps    xmm1, xmm0
4335d025  0f28c6                   movaps   xmm0, xmm6
4335d028  0fc6c600                 shufps   xmm0, xmm6, 0
4335d02c  0f54f7                   andps    xmm6, xmm7
4335d02f  0f59842408010000         mulps    xmm0, xmmword ptr [esp + 0x108]
4335d037  0f58c8                   addps    xmm1, xmm0
4335d03a  0f58ce                   addps    xmm1, xmm6
4335d03d  0f11480c                 movups   xmmword ptr [eax + 0xc], xmm1
4335d041  83c01c                   add      eax, 0x1c
4335d044  50                       push     eax
4335d045  e856041a34               call     0x774fd4a0
4335d04a  8b4c2424                 mov      ecx, dword ptr [esp + 0x24]
4335d04e  83c40c                   add      esp, 0xc
4335d051  f30f104e0c               movss    xmm1, dword ptr [esi + 0xc]
4335d056  f30f5949f0               mulss    xmm1, dword ptr [ecx - 0x10]
4335d05b  f30f1041ec               movss    xmm0, dword ptr [ecx - 0x14]
4335d060  f30f594608               mulss    xmm0, dword ptr [esi + 8]
4335d065  f30f58c8                 addss    xmm1, xmm0
4335d069  f30f1041f4               movss    xmm0, dword ptr [ecx - 0xc]
4335d06e  f30f594610               mulss    xmm0, dword ptr [esi + 0x10]
4335d073  f30f58c8                 addss    xmm1, xmm0
4335d077  f30f5849f8               addss    xmm1, dword ptr [ecx - 8]
4335d07c  f30f114924               movss    dword ptr [ecx + 0x24], xmm1
4335d081  f30f1009                 movss    xmm1, dword ptr [ecx]
4335d085  f30f594e0c               mulss    xmm1, dword ptr [esi + 0xc]
4335d08a  f30f1041fc               movss    xmm0, dword ptr [ecx - 4]
4335d08f  f30f594608               mulss    xmm0, dword ptr [esi + 8]
4335d094  f30f58c8                 addss    xmm1, xmm0
4335d098  f30f104104               movss    xmm0, dword ptr [ecx + 4]
4335d09d  f30f594610               mulss    xmm0, dword ptr [esi + 0x10]
4335d0a2  f30f58c8                 addss    xmm1, xmm0
4335d0a6  f30f584908               addss    xmm1, dword ptr [ecx + 8]
4335d0ab  f30f114928               movss    dword ptr [ecx + 0x28], xmm1
4335d0b0  f30f104e0c               movss    xmm1, dword ptr [esi + 0xc]
4335d0b5  f30f594910               mulss    xmm1, dword ptr [ecx + 0x10]
4335d0ba  f30f10410c               movss    xmm0, dword ptr [ecx + 0xc]
4335d0bf  f30f594608               mulss    xmm0, dword ptr [esi + 8]
4335d0c4  f30f58c8                 addss    xmm1, xmm0
4335d0c8  f30f104114               movss    xmm0, dword ptr [ecx + 0x14]
4335d0cd  f30f594610               mulss    xmm0, dword ptr [esi + 0x10]
4335d0d2  f30f58c8                 addss    xmm1, xmm0
4335d0d6  f30f584918               addss    xmm1, dword ptr [ecx + 0x18]
4335d0db  f30f11492c               movss    dword ptr [ecx + 0x2c], xmm1
4335d0e0  f30f104e14               movss    xmm1, dword ptr [esi + 0x14]
4335d0e5  f30f104618               movss    xmm0, dword ptr [esi + 0x18]
4335d0ea  f30f5949ec               mulss    xmm1, dword ptr [ecx - 0x14]
4335d0ef  f30f5941f0               mulss    xmm0, dword ptr [ecx - 0x10]
4335d0f4  f30f58c8                 addss    xmm1, xmm0
4335d0f8  8b542420                 mov      edx, dword ptr [esp + 0x20]
4335d0fc  f30f10461c               movss    xmm0, dword ptr [esi + 0x1c]
4335d101  42                       inc      edx
4335d102  f30f5941f4               mulss    xmm0, dword ptr [ecx - 0xc]
4335d107  8344241c44               add      dword ptr [esp + 0x1c], 0x44
4335d10c  8344242c30               add      dword ptr [esp + 0x2c], 0x30
4335d111  89542420                 mov      dword ptr [esp + 0x20], edx
4335d115  f30f58c8                 addss    xmm1, xmm0
4335d119  f30f5849f8               addss    xmm1, dword ptr [ecx - 8]
4335d11e  f30f114930               movss    dword ptr [ecx + 0x30], xmm1
4335d123  f30f1009                 movss    xmm1, dword ptr [ecx]
4335d127  f30f594e18               mulss    xmm1, dword ptr [esi + 0x18]
4335d12c  f30f104614               movss    xmm0, dword ptr [esi + 0x14]
4335d131  f30f5941fc               mulss    xmm0, dword ptr [ecx - 4]
4335d136  f30f58c8                 addss    xmm1, xmm0
4335d13a  f30f10461c               movss    xmm0, dword ptr [esi + 0x1c]
4335d13f  f30f594104               mulss    xmm0, dword ptr [ecx + 4]
4335d144  f30f58c8                 addss    xmm1, xmm0
4335d148  f30f584908               addss    xmm1, dword ptr [ecx + 8]
4335d14d  f30f114934               movss    dword ptr [ecx + 0x34], xmm1
4335d152  f30f104618               movss    xmm0, dword ptr [esi + 0x18]
4335d157  f30f594110               mulss    xmm0, dword ptr [ecx + 0x10]
4335d15c  f30f104e14               movss    xmm1, dword ptr [esi + 0x14]
4335d161  f30f59490c               mulss    xmm1, dword ptr [ecx + 0xc]
4335d166  f30f58c8                 addss    xmm1, xmm0
4335d16a  f30f10461c               movss    xmm0, dword ptr [esi + 0x1c]
4335d16f  f30f594114               mulss    xmm0, dword ptr [ecx + 0x14]
4335d174  f30f58c8                 addss    xmm1, xmm0
4335d178  f30f584918               addss    xmm1, dword ptr [ecx + 0x18]
4335d17d  f30f114938               movss    dword ptr [ecx + 0x38], xmm1
4335d182  81c190000000             add      ecx, 0x90
4335d188  8b8424e01c0000           mov      eax, dword ptr [esp + 0x1ce0]
4335d18f  894c2418                 mov      dword ptr [esp + 0x18], ecx
4335d193  3bd0                     cmp      edx, eax
4335d195  0f8c73fcffff             jl       0x4335ce0e
4335d19b  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4335d19f  eb09                     jmp      0x4335d1aa
4335d1a1  8bc2                     mov      eax, edx
4335d1a3  898424e01c0000           mov      dword ptr [esp + 0x1ce0], eax
4335d1aa  85c0                     test     eax, eax
4335d1ac  0f8468040000             je       0x4335d61a
4335d1b2  f6874c01000080           test     byte ptr [edi + 0x14c], 0x80
4335d1b9  0f845b040000             je       0x4335d61a
4335d1bf  8d87e0060000             lea      eax, [edi + 0x6e0]
4335d1c5  c744246003000000         mov      dword ptr [esp + 0x60], 3
4335d1cd  8db424a0270000           lea      esi, [esp + 0x27a0]
4335d1d4  89442434                 mov      dword ptr [esp + 0x34], eax
4335d1d8  89742444                 mov      dword ptr [esp + 0x44], esi
4335d1dc  33ff                     xor      edi, edi
4335d1de  8b8c2490000000           mov      ecx, dword ptr [esp + 0x90]
4335d1e5  e823010a00               call     0x433fd30d
4335d1ea  85c0                     test     eax, eax
4335d1ec  0f8405040000             je       0x4335d5f7
4335d1f2  8b942490000000           mov      edx, dword ptr [esp + 0x90]
4335d1f9  85d2                     test     edx, edx
4335d1fb  750c                     jne      0x4335d209
4335d1fd  03fd                     add      edi, ebp
4335d1ff  3d24c787e2               cmp      eax, 0xe287c724
4335d204  6bf118                   imul     esi, ecx, 0x18
4335d207  dd33                     fnsave   dword ptr [ebx]
4335d209  8b08                     mov      ecx, dword ptr [eax]
4335d20b  a140824643               mov      eax, dword ptr [0x43468240]
4335d210  8b00                     mov      eax, dword ptr [eax]
4335d212  33054ca84643             xor      eax, dword ptr [0x4346a84c]
4335d218  3510fbb6c2               xor      eax, 0xc2b6fb10
4335d21d  6b14100c                 imul     edx, dword ptr [eax + edx], 0xc
4335d221  0391b0000000             add      edx, dword ptr [ecx + 0xb0]
4335d227  03d1                     add      edx, ecx
4335d229  89542458                 mov      dword ptr [esp + 0x58], edx
4335d22d  0f84c4030000             je       0x4335d5f7
4335d233  397a04                   cmp      dword ptr [edx + 4], edi
4335d236  0f84bb030000             je       0x4335d5f7
4335d23c  8b4204                   mov      eax, dword ptr [edx + 4]
4335d23f  6a13                     push     0x13
4335d241  59                       pop      ecx
4335d242  3bc1                     cmp      eax, ecx
4335d244  897c2420                 mov      dword ptr [esp + 0x20], edi
4335d248  0f47c1                   cmova    eax, ecx
4335d24b  8906                     mov      dword ptr [esi], eax
4335d24d  85c0                     test     eax, eax
4335d24f  0f8ea4030000             jle      0x4335d5f9
4335d255  8b4c2434                 mov      ecx, dword ptr [esp + 0x34]
4335d259  8d4634                   lea      eax, [esi + 0x34]
4335d25c  894c241c                 mov      dword ptr [esp + 0x1c], ecx
4335d260  8bcf                     mov      ecx, edi
4335d262  897c2418                 mov      dword ptr [esp + 0x18], edi
4335d266  8944242c                 mov      dword ptr [esp + 0x2c], eax
4335d26a  8d3411                   lea      esi, [ecx + edx]
4335d26d  8b4c2420                 mov      ecx, dword ptr [esp + 0x20]
4335d271  037208                   add      esi, dword ptr [edx + 8]
4335d274  8948dc                   mov      dword ptr [eax - 0x24], ecx
4335d277  8970e0                   mov      dword ptr [eax - 0x20], esi
4335d27a  f30f104628               movss    xmm0, dword ptr [esi + 0x28]
4335d27f  f30f590528054743         mulss    xmm0, dword ptr [0x43470528]
4335d287  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
4335d28d  e83ef41a34               call     0x7750c6d0
4335d292  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
4335d298  f30f10442424             movss    xmm0, dword ptr [esp + 0x24]
4335d29e  e8cdd41a34               call     0x7750a770
4335d2a3  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
4335d2a9  f30f104624               movss    xmm0, dword ptr [esi + 0x24]
4335d2ae  f30f590528054743         mulss    xmm0, dword ptr [0x43470528]
4335d2b6  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
4335d2bc  e80ff41a34               call     0x7750c6d0
4335d2c1  f30f11442428             movss    dword ptr [esp + 0x28], xmm0
4335d2c7  f30f10442424             movss    xmm0, dword ptr [esp + 0x24]
4335d2cd  e89ed41a34               call     0x7750a770
4335d2d2  f30f1144244c             movss    dword ptr [esp + 0x4c], xmm0
4335d2d8  f30f10462c               movss    xmm0, dword ptr [esi + 0x2c]
4335d2dd  f30f590528054743         mulss    xmm0, dword ptr [0x43470528]
4335d2e5  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
4335d2eb  e8e0f31a34               call     0x7750c6d0
4335d2f0  f30f11442440             movss    dword ptr [esp + 0x40], xmm0
4335d2f6  f30f10442424             movss    xmm0, dword ptr [esp + 0x24]
4335d2fc  e86fd41a34               call     0x7750a770
4335d301  f30f105c244c             movss    xmm3, dword ptr [esp + 0x4c]
4335d307  0f28f8                   movaps   xmm7, xmm0
4335d30a  f30f10542438             movss    xmm2, dword ptr [esp + 0x38]
4335d310  0f28cb                   movaps   xmm1, xmm3
4335d313  f30f597c2414             mulss    xmm7, dword ptr [esp + 0x14]
4335d319  0f28f0                   movaps   xmm6, xmm0
4335d31c  8b44241c                 mov      eax, dword ptr [esp + 0x1c]
4335d320  f30f59ca                 mulss    xmm1, xmm2
4335d324  21bc24fc0b0000           and      dword ptr [esp + 0xbfc], edi
4335d32b  f30f59c3                 mulss    xmm0, xmm3
4335d32f  f30f118c24e00b0000       movss    dword ptr [esp + 0xbe0], xmm1
4335d338  f30f104c2440             movss    xmm1, dword ptr [esp + 0x40]
4335d33e  0f28e9                   movaps   xmm5, xmm1
4335d341  f30f59f2                 mulss    xmm6, xmm2
4335d345  f30f596c2414             mulss    xmm5, dword ptr [esp + 0x14]
4335d34b  0f28e1                   movaps   xmm4, xmm1
4335d34e  f30f59cb                 mulss    xmm1, xmm3
4335d352  f30f595c2414             mulss    xmm3, dword ptr [esp + 0x14]
4335d358  f30f59e2                 mulss    xmm4, xmm2
4335d35c  0f57d2                   xorps    xmm2, xmm2
4335d35f  f30f118c24f40b0000       movss    dword ptr [esp + 0xbf4], xmm1
4335d368  0f28d6                   movaps   xmm2, xmm6
4335d36b  0f28cf                   movaps   xmm1, xmm7
4335d36e  f30f118424f80b0000       movss    dword ptr [esp + 0xbf8], xmm0
4335d377  f30f594c2428             mulss    xmm1, dword ptr [esp + 0x28]
4335d37d  0f28c5                   movaps   xmm0, xmm5
4335d380  f30f59442428             mulss    xmm0, dword ptr [esp + 0x28]
4335d386  f30f58cc                 addss    xmm1, xmm4
4335d38a  f30f5cc6                 subss    xmm0, xmm6
4335d38e  0f1030                   movups   xmm6, xmmword ptr [eax]
4335d391  0f14d9                   unpcklps xmm3, xmm1
4335d394  f30f104c2428             movss    xmm1, dword ptr [esp + 0x28]
4335d39a  f30f59d1                 mulss    xmm2, xmm1
4335d39e  0f14d8                   unpcklps xmm3, xmm0
4335d3a1  0f299c2400010000         movaps   xmmword ptr [esp + 0x100], xmm3
4335d3a9  0f299c24d00b0000         movaps   xmmword ptr [esp + 0xbd0], xmm3
4335d3b1  f30f5cd5                 subss    xmm2, xmm5
4335d3b5  0f28d9                   movaps   xmm3, xmm1
4335d3b8  0f28cc                   movaps   xmm1, xmm4
4335d3bb  f30f594c2428             mulss    xmm1, dword ptr [esp + 0x28]
4335d3c1  0f571dd0034743           xorps    xmm3, xmmword ptr [0x434703d0]
4335d3c8  0f1060f0                 movups   xmm4, xmmword ptr [eax - 0x10]
4335d3cc  f30f58cf                 addss    xmm1, xmm7
4335d3d0  0f14d3                   unpcklps xmm2, xmm3
4335d3d3  0f283d401e4743           movaps   xmm7, xmmword ptr [0x43471e40]
4335d3da  0f14ca                   unpcklps xmm1, xmm2
4335d3dd  0f1050e0                 movups   xmm2, xmmword ptr [eax - 0x20]
4335d3e1  0f118c24e40b0000         movups   xmmword ptr [esp + 0xbe4], xmm1
4335d3e9  0f289c24f00b0000         movaps   xmm3, xmmword ptr [esp + 0xbf0]
4335d3f1  0f28ca                   movaps   xmm1, xmm2
4335d3f4  0f28ac24e00b0000         movaps   xmm5, xmmword ptr [esp + 0xbe0]
4335d3fc  0fc6caaa                 shufps   xmm1, xmm2, 0xaa
4335d400  0f59cb                   mulps    xmm1, xmm3
4335d403  8b44242c                 mov      eax, dword ptr [esp + 0x2c]
4335d407  0f28c2                   movaps   xmm0, xmm2
4335d40a  0fc6c255                 shufps   xmm0, xmm2, 0x55
4335d40e  0f59c5                   mulps    xmm0, xmm5
4335d411  6a44                     push     0x44
4335d413  56                       push     esi
4335d414  0f58c8                   addps    xmm1, xmm0
4335d417  0f28c2                   movaps   xmm0, xmm2
4335d41a  0fc6c200                 shufps   xmm0, xmm2, 0
4335d41e  0f54d7                   andps    xmm2, xmm7
4335d421  0f59842408010000         mulps    xmm0, xmmword ptr [esp + 0x108]
4335d429  0f58c8                   addps    xmm1, xmm0
4335d42c  0f28c4                   movaps   xmm0, xmm4
4335d42f  0fc6c455                 shufps   xmm0, xmm4, 0x55
4335d433  0f59c5                   mulps    xmm0, xmm5
4335d436  0f58ca                   addps    xmm1, xmm2
4335d439  0f1148ec                 movups   xmmword ptr [eax - 0x14], xmm1
4335d43d  0f28cc                   movaps   xmm1, xmm4
4335d440  0fc6ccaa                 shufps   xmm1, xmm4, 0xaa
4335d444  0f59cb                   mulps    xmm1, xmm3
4335d447  0f58c8                   addps    xmm1, xmm0
4335d44a  0f28c4                   movaps   xmm0, xmm4
4335d44d  0fc6c400                 shufps   xmm0, xmm4, 0
4335d451  0f54e7                   andps    xmm4, xmm7
4335d454  0f59842408010000         mulps    xmm0, xmmword ptr [esp + 0x108]
4335d45c  0f58c8                   addps    xmm1, xmm0
4335d45f  0f28c6                   movaps   xmm0, xmm6
4335d462  0fc6c655                 shufps   xmm0, xmm6, 0x55
4335d466  0f59c5                   mulps    xmm0, xmm5
4335d469  0f58cc                   addps    xmm1, xmm4
4335d46c  0f1148fc                 movups   xmmword ptr [eax - 4], xmm1
4335d470  0f28ce                   movaps   xmm1, xmm6
4335d473  0fc6ceaa                 shufps   xmm1, xmm6, 0xaa
4335d477  0f59cb                   mulps    xmm1, xmm3
4335d47a  0f58c8                   addps    xmm1, xmm0
4335d47d  0f28c6                   movaps   xmm0, xmm6
4335d480  0fc6c600                 shufps   xmm0, xmm6, 0
4335d484  0f54f7                   andps    xmm6, xmm7
4335d487  0f59842408010000         mulps    xmm0, xmmword ptr [esp + 0x108]
4335d48f  0f58c8                   addps    xmm1, xmm0
4335d492  0f58ce                   addps    xmm1, xmm6
4335d495  0f11480c                 movups   xmmword ptr [eax + 0xc], xmm1
4335d499  83c01c                   add      eax, 0x1c
4335d49c  50                       push     eax
4335d49d  e8feff1934               call     0x774fd4a0
4335d4a2  8b442438                 mov      eax, dword ptr [esp + 0x38]
4335d4a6  83c40c                   add      esp, 0xc
4335d4a9  f30f104e0c               movss    xmm1, dword ptr [esi + 0xc]
4335d4ae  f30f5948f0               mulss    xmm1, dword ptr [eax - 0x10]
4335d4b3  f30f1040ec               movss    xmm0, dword ptr [eax - 0x14]
4335d4b8  f30f594608               mulss    xmm0, dword ptr [esi + 8]
4335d4bd  f30f58c8                 addss    xmm1, xmm0
4335d4c1  f30f1040f4               movss    xmm0, dword ptr [eax - 0xc]
4335d4c6  f30f594610               mulss    xmm0, dword ptr [esi + 0x10]
4335d4cb  f30f58c8                 addss    xmm1, xmm0
4335d4cf  f30f5848f8               addss    xmm1, dword ptr [eax - 8]
4335d4d4  f30f114824               movss    dword ptr [eax + 0x24], xmm1
4335d4d9  f30f104e0c               movss    xmm1, dword ptr [esi + 0xc]
4335d4de  f30f5908                 mulss    xmm1, dword ptr [eax]
4335d4e2  f30f1040fc               movss    xmm0, dword ptr [eax - 4]
4335d4e7  f30f594608               mulss    xmm0, dword ptr [esi + 8]
4335d4ec  f30f58c8                 addss    xmm1, xmm0
4335d4f0  f30f104004               movss    xmm0, dword ptr [eax + 4]
4335d4f5  f30f594610               mulss    xmm0, dword ptr [esi + 0x10]
4335d4fa  f30f58c8                 addss    xmm1, xmm0
4335d4fe  f30f584808               addss    xmm1, dword ptr [eax + 8]
4335d503  f30f114828               movss    dword ptr [eax + 0x28], xmm1
4335d508  f30f106810               movss    xmm5, dword ptr [eax + 0x10]
4335d50d  f30f10400c               movss    xmm0, dword ptr [eax + 0xc]
4335d512  0f28cd                   movaps   xmm1, xmm5
4335d515  f30f594e0c               mulss    xmm1, dword ptr [esi + 0xc]
4335d51a  f30f594608               mulss    xmm0, dword ptr [esi + 8]
4335d51f  f30f106014               movss    xmm4, dword ptr [eax + 0x14]
4335d524  f30f58c8                 addss    xmm1, xmm0
4335d528  0f28c4                   movaps   xmm0, xmm4
4335d52b  f30f594610               mulss    xmm0, dword ptr [esi + 0x10]
4335d530  f30f58c8                 addss    xmm1, xmm0
4335d534  f30f584818               addss    xmm1, dword ptr [eax + 0x18]
4335d539  f30f11482c               movss    dword ptr [eax + 0x2c], xmm1
4335d53e  f30f104e14               movss    xmm1, dword ptr [esi + 0x14]
4335d543  f30f5948ec               mulss    xmm1, dword ptr [eax - 0x14]
4335d548  f30f104618               movss    xmm0, dword ptr [esi + 0x18]
4335d54d  f30f5940f0               mulss    xmm0, dword ptr [eax - 0x10]
4335d552  8b542420                 mov      edx, dword ptr [esp + 0x20]
4335d556  8b4c2418                 mov      ecx, dword ptr [esp + 0x18]
4335d55a  42                       inc      edx
4335d55b  8344241c30               add      dword ptr [esp + 0x1c], 0x30
4335d560  83c144                   add      ecx, 0x44
4335d563  f30f58c8                 addss    xmm1, xmm0
4335d567  89542420                 mov      dword ptr [esp + 0x20], edx
4335d56b  f30f10461c               movss    xmm0, dword ptr [esi + 0x1c]
4335d570  f30f5940f4               mulss    xmm0, dword ptr [eax - 0xc]
4335d575  894c2418                 mov      dword ptr [esp + 0x18], ecx
4335d579  f30f58c8                 addss    xmm1, xmm0
4335d57d  f30f5848f8               addss    xmm1, dword ptr [eax - 8]
4335d582  f30f114830               movss    dword ptr [eax + 0x30], xmm1
4335d587  f30f1000                 movss    xmm0, dword ptr [eax]
4335d58b  f30f594618               mulss    xmm0, dword ptr [esi + 0x18]
4335d590  f30f104e14               movss    xmm1, dword ptr [esi + 0x14]
4335d595  f30f5948fc               mulss    xmm1, dword ptr [eax - 4]
4335d59a  f30f58c8                 addss    xmm1, xmm0
4335d59e  f30f10461c               movss    xmm0, dword ptr [esi + 0x1c]
4335d5a3  f30f594004               mulss    xmm0, dword ptr [eax + 4]
4335d5a8  f30f58c8                 addss    xmm1, xmm0
4335d5ac  f30f584808               addss    xmm1, dword ptr [eax + 8]
4335d5b1  f30f114834               movss    dword ptr [eax + 0x34], xmm1
4335d5b6  f30f596e18               mulss    xmm5, dword ptr [esi + 0x18]
4335d5bb  f30f104614               movss    xmm0, dword ptr [esi + 0x14]
4335d5c0  f30f59400c               mulss    xmm0, dword ptr [eax + 0xc]
4335d5c5  f30f59661c               mulss    xmm4, dword ptr [esi + 0x1c]
4335d5ca  8b742444                 mov      esi, dword ptr [esp + 0x44]
4335d5ce  f30f58e8                 addss    xmm5, xmm0
4335d5d2  f30f58ec                 addss    xmm5, xmm4
4335d5d6  f30f586818               addss    xmm5, dword ptr [eax + 0x18]
4335d5db  f30f116838               movss    dword ptr [eax + 0x38], xmm5
4335d5e0  0590000000               add      eax, 0x90
4335d5e5  3b16                     cmp      edx, dword ptr [esi]
4335d5e7  8b542458                 mov      edx, dword ptr [esp + 0x58]
4335d5eb  8944242c                 mov      dword ptr [esp + 0x2c], eax
4335d5ef  0f8c75fcffff             jl       0x4335d26a
4335d5f5  eb02                     jmp      0x4335d5f9
4335d5f7  893e                     mov      dword ptr [esi], edi
4335d5f9  81442434a0030000         add      dword ptr [esp + 0x34], 0x3a0
4335d601  81c6c00a0000             add      esi, 0xac0
4335d607  836c246001               sub      dword ptr [esp + 0x60], 1
4335d60c  89742444                 mov      dword ptr [esp + 0x44], esi
4335d610  0f85c8fbffff             jne      0x4335d1de
4335d616  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4335d61a  33f6                     xor      esi, esi
4335d61c  80bfe100000000           cmp      byte ptr [edi + 0xe1], 0
4335d623  8974247c                 mov      dword ptr [esp + 0x7c], esi
4335d627  7462                     je       0x4335d68b
4335d629  39b7c4000000             cmp      dword ptr [edi + 0xc4], esi
4335d62f  745a                     je       0x4335d68b
4335d631  8b87f0000000             mov      eax, dword ptr [edi + 0xf0]
4335d637  85c0                     test     eax, eax
4335d639  7450                     je       0x4335d68b
4335d63b  f6405c80                 test     byte ptr [eax + 0x5c], 0x80
4335d63f  744a                     je       0x4335d68b
4335d641  8b4f04                   mov      ecx, dword ptr [edi + 4]
4335d644  85c9                     test     ecx, ecx
4335d646  750c                     jne      0x4335d654
4335d648  3dcf965994               cmp      eax, 0x945996cf
4335d64d  0e                       push     cs
4335d64e  8280b21005a5e8           add      byte ptr [eax - 0x5afaef4e], 0xe8
4335d654  e8d2b30500               call     0x433b8a2b
4335d655  d2b305008bc8             sal      byte ptr [ebx - 0x3774fffb], cl
4335d659  8bc8                     mov      ecx, eax
4335d65b  e867290800               call     0x433dffc7
4335d660  0f2f058cee4643           comiss   xmm0, dword ptr [0x4346ee8c]
4335d667  7622                     jbe      0x4335d68b
4335d669  8b942490000000           mov      edx, dword ptr [esp + 0x90]
4335d670  8d842470600000           lea      eax, [esp + 0x6070]
4335d677  8b4d08                   mov      ecx, dword ptr [ebp + 8]
4335d67a  50                       push     eax
4335d67b  8d87f0000000             lea      eax, [edi + 0xf0]
4335d681  50                       push     eax
4335d682  e8b45a0a00               call     0x4340313b
4335d687  8944247c                 mov      dword ptr [esp + 0x7c], eax
4335d68b  f30f100558f84643         movss    xmm0, dword ptr [0x4346f858]
4335d693  b9f0494743               mov      ecx, 0x434749f0
4335d698  33d2                     xor      edx, edx
4335d69a  894c2450                 mov      dword ptr [esp + 0x50], ecx
4335d69e  42                       inc      edx
4335d69f  c744244818000000         mov      dword ptr [esp + 0x48], 0x18
4335d6a7  f30f11842488000000       movss    dword ptr [esp + 0x88], xmm0
4335d6b0  8b09                     mov      ecx, dword ptr [ecx]
4335d6b2  894c2440                 mov      dword ptr [esp + 0x40], ecx
4335d6b6  83f913                   cmp      ecx, 0x13
4335d6b9  0f8d1a180000             jge      0x4335eed9
4335d6bf  69c190000000             imul     eax, ecx, 0x90
4335d6c5  8d8404f01c0000           lea      eax, [esp + eax + 0x1cf0]
4335d6cc  89442454                 mov      dword ptr [esp + 0x54], eax
4335d6d0  83f90b                   cmp      ecx, 0xb
4335d6d3  7411                     je       0x4335d6e6
4335d6d5  83f90c                   cmp      ecx, 0xc
4335d6d8  740c                     je       0x4335d6e6
4335d6da  8b4804                   mov      ecx, dword ptr [eax + 4]
4335d6dd  8bc2                     mov      eax, edx
4335d6df  8b4904                   mov      ecx, dword ptr [ecx + 4]
4335d6e2  d3e0                     shl      eax, cl
4335d6e4  eb05                     jmp      0x4335d6eb
4335d6e6  b800020000               mov      eax, 0x200
4335d6eb  89442420                 mov      dword ptr [esp + 0x20], eax
4335d6ef  8587c0000000             test     dword ptr [edi + 0xc0], eax
4335d6f5  0f841f120000             je       0x4335e91a
4335d6fb  8d8c240c030000           lea      ecx, [esp + 0x30c]
4335d702  e88e830700               call     0x433d5a95
4335d707  f30f1087c8000000         movss    xmm0, dword ptr [edi + 0xc8]
4335d70f  8b4d08                   mov      ecx, dword ptr [ebp + 8]
4335d712  8b87cc000000             mov      eax, dword ptr [edi + 0xcc]
4335d718  f30f101540224743         movss    xmm2, dword ptr [0x43472240]
4335d720  23442420                 and      eax, dword ptr [esp + 0x20]
4335d724  f30f11442478             movss    dword ptr [esp + 0x78], xmm0
4335d72a  8d91dc000000             lea      edx, [ecx + 0xdc]
4335d730  f30f108160010000         movss    xmm0, dword ptr [ecx + 0x160]
4335d738  8b4c2454                 mov      ecx, dword ptr [esp + 0x54]
4335d73c  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
4335d742  8944244c                 mov      dword ptr [esp + 0x4c], eax
4335d746  89542428                 mov      dword ptr [esp + 0x28], edx
4335d74a  8d7948                   lea      edi, [ecx + 0x48]
4335d74d  f30f1037                 movss    xmm6, dword ptr [edi]
4335d751  f30f104710               movss    xmm0, dword ptr [edi + 0x10]
4335d756  f30f104f14               movss    xmm1, dword ptr [edi + 0x14]
4335d75b  f30f58770c               addss    xmm6, dword ptr [edi + 0xc]
4335d760  f30f584704               addss    xmm0, dword ptr [edi + 4]
4335d765  f30f584f08               addss    xmm1, dword ptr [edi + 8]
4335d76a  83a4240003000000         and      dword ptr [esp + 0x300], 0
4335d772  89b42408030000           mov      dword ptr [esp + 0x308], esi
4335d779  f30f59f2                 mulss    xmm6, xmm2
4335d77d  897c2424                 mov      dword ptr [esp + 0x24], edi
4335d781  f30f59c2                 mulss    xmm0, xmm2
4335d785  f30f59ca                 mulss    xmm1, xmm2
4335d789  f30f11b424f4020000       movss    dword ptr [esp + 0x2f4], xmm6
4335d792  f30f118424f8020000       movss    dword ptr [esp + 0x2f8], xmm0
4335d79b  f30f118c24fc020000       movss    dword ptr [esp + 0x2fc], xmm1
4335d7a4  8b4104                   mov      eax, dword ptr [ecx + 4]
4335d7a7  f30f11b42484000000       movss    dword ptr [esp + 0x84], xmm6
4335d7b0  f30f1144242c             movss    dword ptr [esp + 0x2c], xmm0
4335d7b6  f30f114c2418             movss    dword ptr [esp + 0x18], xmm1
4335d7bc  8b4004                   mov      eax, dword ptr [eax + 4]
4335d7bf  89842404030000           mov      dword ptr [esp + 0x304], eax
4335d7c6  83794401                 cmp      dword ptr [ecx + 0x44], 1
4335d7ca  0f8555010000             jne      0x4335d925
4335d7d0  8bf2                     mov      esi, edx
4335d7d2  8dbc24a4070000           lea      edi, [esp + 0x7a4]
4335d7d9  8d9424a4070000           lea      edx, [esp + 0x7a4]
4335d7e0  8d8c2498200000           lea      ecx, [esp + 0x2098]
4335d7e7  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335d7e8  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335d7e9  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335d7ea  f30f118424b4070000       movss    dword ptr [esp + 0x7b4], xmm0
4335d7f3  0f28c1                   movaps   xmm0, xmm1
4335d7f6  f30f5c0514054743         subss    xmm0, dword ptr [0x43470514]
4335d7fe  f30f11b424b0070000       movss    dword ptr [esp + 0x7b0], xmm6
4335d807  f30f118424b8070000       movss    dword ptr [esp + 0x7b8], xmm0
4335d810  e8cdf30300               call     0x4339cbe2
4335d815  f30f108c24c0200000       movss    xmm1, dword ptr [esp + 0x20c0]
4335d81e  0f57ed                   xorps    xmm5, xmm5
4335d821  0f2fc8                   comiss   xmm1, xmm0
4335d824  8b4c2454                 mov      ecx, dword ptr [esp + 0x54]
4335d828  0f82fc000000             jb       0x4335d92a
4335d82e  8d4154                   lea      eax, [ecx + 0x54]
4335d831  f30f1020                 movss    xmm4, dword ptr [eax]
4335d835  8d7948                   lea      edi, [ecx + 0x48]
4335d838  f30f104804               movss    xmm1, dword ptr [eax + 4]
4335d83d  0f28c4                   movaps   xmm0, xmm4
4335d840  f30f5c494c               subss    xmm1, dword ptr [ecx + 0x4c]
4335d845  f30f5c07                 subss    xmm0, dword ptr [edi]
4335d849  f30f59cd                 mulss    xmm1, xmm5
4335d84d  f30f59c5                 mulss    xmm0, xmm5
4335d851  f30f58c8                 addss    xmm1, xmm0
4335d855  f30f104008               movss    xmm0, dword ptr [eax + 8]
4335d85a  f30f5c4150               subss    xmm0, dword ptr [ecx + 0x50]
4335d85f  f30f58c8                 addss    xmm1, xmm0
4335d863  0f2fcd                   comiss   xmm1, xmm5
4335d866  7304                     jae      0x4335d86c
4335d868  f30f1027                 movss    xmm4, dword ptr [edi]
4335d86c  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335d874  0f57c0                   xorps    xmm0, xmm0
4335d877  f30f59c5                 mulss    xmm0, xmm5
4335d87b  0f42c7                   cmovb    eax, edi
4335d87e  f30f59c9                 mulss    xmm1, xmm1
4335d882  f30f105f28               movss    xmm3, dword ptr [edi + 0x28]
4335d887  f30f10b42484000000       movss    xmm6, dword ptr [esp + 0x84]
4335d890  f30f58c8                 addss    xmm1, xmm0
4335d894  f30f103d04ff4643         movss    xmm7, dword ptr [0x4346ff04]
4335d89c  0f57c0                   xorps    xmm0, xmm0
4335d89f  f30f59c5                 mulss    xmm0, xmm5
4335d8a3  f30f58c8                 addss    xmm1, xmm0
4335d8a7  0f28c1                   movaps   xmm0, xmm1
4335d8aa  f30f104808               movss    xmm1, dword ptr [eax + 8]
4335d8af  f30f51c0                 sqrtss   xmm0, xmm0
4335d8b3  f30f5ed8                 divss    xmm3, xmm0
4335d8b7  f30f11842494030000       movss    dword ptr [esp + 0x394], xmm0
4335d8c0  f30f104004               movss    xmm0, dword ptr [eax + 4]
4335d8c5  0f28d3                   movaps   xmm2, xmm3
4335d8c8  f30f59d5                 mulss    xmm2, xmm5
4335d8cc  f30f58d9                 addss    xmm3, xmm1
4335d8d0  f30f104c2418             movss    xmm1, dword ptr [esp + 0x18]
4335d8d6  f30f58e2                 addss    xmm4, xmm2
4335d8da  f30f58d0                 addss    xmm2, xmm0
4335d8de  f30f1044242c             movss    xmm0, dword ptr [esp + 0x2c]
4335d8e4  f30f5cd9                 subss    xmm3, xmm1
4335d8e8  f30f5ce6                 subss    xmm4, xmm6
4335d8ec  f30f5cd0                 subss    xmm2, xmm0
4335d8f0  f30f59df                 mulss    xmm3, xmm7
4335d8f4  f30f59e7                 mulss    xmm4, xmm7
4335d8f8  f30f59d7                 mulss    xmm2, xmm7
4335d8fc  f30f58d9                 addss    xmm3, xmm1
4335d900  f30f58e6                 addss    xmm4, xmm6
4335d904  f30f58d0                 addss    xmm2, xmm0
4335d908  f30f119c24fc020000       movss    dword ptr [esp + 0x2fc], xmm3
4335d911  f30f11a424f4020000       movss    dword ptr [esp + 0x2f4], xmm4
4335d91a  f30f119424f8020000       movss    dword ptr [esp + 0x2f8], xmm2
4335d923  eb1e                     jmp      0x4335d943
4335d925  0f57ed                   xorps    xmm5, xmm5
4335d928  eb1d                     jmp      0x4335d947
4335d92a  f30f10b42484000000       movss    xmm6, dword ptr [esp + 0x84]
4335d933  f30f1044242c             movss    xmm0, dword ptr [esp + 0x2c]
4335d939  f30f104c2418             movss    xmm1, dword ptr [esp + 0x18]
4335d93f  8b7c2424                 mov      edi, dword ptr [esp + 0x24]
4335d943  8b542428                 mov      edx, dword ptr [esp + 0x28]
4335d947  837c244c00               cmp      dword ptr [esp + 0x4c], 0
4335d94c  0f84c10e0000             je       0x4335e813
4335d952  0f28d1                   movaps   xmm2, xmm1
4335d955  0f28e6                   movaps   xmm4, xmm6
4335d958  f30f5c22                 subss    xmm4, dword ptr [edx]
4335d95c  f30f5c5208               subss    xmm2, dword ptr [edx + 8]
4335d961  0f28d8                   movaps   xmm3, xmm0
4335d964  f30f5c5a04               subss    xmm3, dword ptr [edx + 4]
4335d969  0f28c4                   movaps   xmm0, xmm4
4335d96c  f30f59c4                 mulss    xmm0, xmm4
4335d970  0f28ca                   movaps   xmm1, xmm2
4335d973  f30f59ca                 mulss    xmm1, xmm2
4335d977  f30f58c8                 addss    xmm1, xmm0
4335d97b  0f28c3                   movaps   xmm0, xmm3
4335d97e  f30f59c3                 mulss    xmm0, xmm3
4335d982  f30f58c8                 addss    xmm1, xmm0
4335d986  0f28c1                   movaps   xmm0, xmm1
4335d989  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335d991  f30f51c0                 sqrtss   xmm0, xmm0
4335d995  f30f11842498030000       movss    dword ptr [esp + 0x398], xmm0
4335d99e  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335d9a6  f30f5ec8                 divss    xmm1, xmm0
4335d9aa  0f28f1                   movaps   xmm6, xmm1
4335d9ad  0f28c1                   movaps   xmm0, xmm1
4335d9b0  f30f59f4                 mulss    xmm6, xmm4
4335d9b4  f30f59c3                 mulss    xmm0, xmm3
4335d9b8  0f2ef5                   ucomiss  xmm6, xmm5
4335d9bb  f30f59ca                 mulss    xmm1, xmm2
4335d9bf  9f                       lahf     
4335d9c0  f30f11742414             movss    dword ptr [esp + 0x14], xmm6
4335d9c6  f30f11b424d8030000       movss    dword ptr [esp + 0x3d8], xmm6
4335d9cf  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
4335d9d5  f30f118424dc030000       movss    dword ptr [esp + 0x3dc], xmm0
4335d9de  f30f114c241c             movss    dword ptr [esp + 0x1c], xmm1
4335d9e4  f30f118c24e0030000       movss    dword ptr [esp + 0x3e0], xmm1
4335d9ed  f6c444                   test     ah, 0x44
4335d9f0  0f8a88000000             jp       0x4335da7e
4335d9f6  0f2ec5                   ucomiss  xmm0, xmm5
4335d9f9  9f                       lahf     
4335d9fa  f6c444                   test     ah, 0x44
4335d9fd  7a7f                     jp       0x4335da7e
4335d9ff  f30f1015d0034743         movss    xmm2, dword ptr [0x434703d0]
4335da07  0f57c0                   xorps    xmm0, xmm0
4335da0a  f30f10a42488000000       movss    xmm4, dword ptr [esp + 0x88]
4335da13  0f57ff                   xorps    xmm7, xmm7
4335da16  0f57f6                   xorps    xmm6, xmm6
4335da19  f30f117c2444             movss    dword ptr [esp + 0x44], xmm7
4335da1f  0f57ca                   xorps    xmm1, xmm2
4335da22  f30f11bc243c010000       movss    dword ptr [esp + 0x13c], xmm7
4335da2b  f30f11a4248c000000       movss    dword ptr [esp + 0x8c], xmm4
4335da34  f30f11a42440010000       movss    dword ptr [esp + 0x140], xmm4
4335da3d  f30f11742464             movss    dword ptr [esp + 0x64], xmm6
4335da43  f30f11b42444010000       movss    dword ptr [esp + 0x144], xmm6
4335da4c  f30f114c241c             movss    dword ptr [esp + 0x1c], xmm1
4335da52  f30f118c2430010000       movss    dword ptr [esp + 0x130], xmm1
4335da5b  f30f11442434             movss    dword ptr [esp + 0x34], xmm0
4335da61  f30f11842434010000       movss    dword ptr [esp + 0x134], xmm0
4335da6a  f30f11442460             movss    dword ptr [esp + 0x60], xmm0
4335da70  f30f11842438010000       movss    dword ptr [esp + 0x138], xmm0
4335da79  e989010000               jmp      0x4335dc07
4335da7e  0f28f8                   movaps   xmm7, xmm0
4335da81  0f28e1                   movaps   xmm4, xmm1
4335da84  f30f59c5                 mulss    xmm0, xmm5
4335da88  f30f59e5                 mulss    xmm4, xmm5
4335da8c  f30f5cfc                 subss    xmm7, xmm4
4335da90  f30f5ce6                 subss    xmm4, xmm6
4335da94  f30f59f5                 mulss    xmm6, xmm5
4335da98  f30f5cf0                 subss    xmm6, xmm0
4335da9c  0f28cf                   movaps   xmm1, xmm7
4335da9f  f30f59cf                 mulss    xmm1, xmm7
4335daa3  0f28c4                   movaps   xmm0, xmm4
4335daa6  f30f59c4                 mulss    xmm0, xmm4
4335daaa  f30f58c8                 addss    xmm1, xmm0
4335daae  0f28c6                   movaps   xmm0, xmm6
4335dab1  f30f59c6                 mulss    xmm0, xmm6
4335dab5  f30f58c8                 addss    xmm1, xmm0
4335dab9  0f28c1                   movaps   xmm0, xmm1
4335dabc  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335dac4  f30f51c0                 sqrtss   xmm0, xmm0
4335dac8  f30f1184249c030000       movss    dword ptr [esp + 0x39c], xmm0
4335dad1  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335dad9  f30f5ec8                 divss    xmm1, xmm0
4335dadd  f30f59e1                 mulss    xmm4, xmm1
4335dae1  f30f59f1                 mulss    xmm6, xmm1
4335dae5  0f28d4                   movaps   xmm2, xmm4
4335dae8  f30f59f9                 mulss    xmm7, xmm1
4335daec  f30f5954241c             mulss    xmm2, dword ptr [esp + 0x1c]
4335daf2  0f28c6                   movaps   xmm0, xmm6
4335daf5  f30f59442424             mulss    xmm0, dword ptr [esp + 0x24]
4335dafb  f30f117c2444             movss    dword ptr [esp + 0x44], xmm7
4335db01  f30f11bc243c010000       movss    dword ptr [esp + 0x13c], xmm7
4335db0a  f30f5cd0                 subss    xmm2, xmm0
4335db0e  f30f11a4248c000000       movss    dword ptr [esp + 0x8c], xmm4
4335db17  0f28c6                   movaps   xmm0, xmm6
4335db1a  f30f11a42440010000       movss    dword ptr [esp + 0x140], xmm4
4335db23  f30f59442414             mulss    xmm0, dword ptr [esp + 0x14]
4335db29  f30f11742464             movss    dword ptr [esp + 0x64], xmm6
4335db2f  f30f11b42444010000       movss    dword ptr [esp + 0x144], xmm6
4335db38  f30f11442434             movss    dword ptr [esp + 0x34], xmm0
4335db3e  0f28c7                   movaps   xmm0, xmm7
4335db41  f30f5944241c             mulss    xmm0, dword ptr [esp + 0x1c]
4335db47  f30f104c2434             movss    xmm1, dword ptr [esp + 0x34]
4335db4d  f30f5cc8                 subss    xmm1, xmm0
4335db51  0f28c4                   movaps   xmm0, xmm4
4335db54  f30f59442414             mulss    xmm0, dword ptr [esp + 0x14]
4335db5a  f30f114c2434             movss    dword ptr [esp + 0x34], xmm1
4335db60  0f28cf                   movaps   xmm1, xmm7
4335db63  f30f594c2424             mulss    xmm1, dword ptr [esp + 0x24]
4335db69  f30f105c2434             movss    xmm3, dword ptr [esp + 0x34]
4335db6f  f30f5cc8                 subss    xmm1, xmm0
4335db73  0f28c3                   movaps   xmm0, xmm3
4335db76  f30f59c3                 mulss    xmm0, xmm3
4335db7a  f30f114c2460             movss    dword ptr [esp + 0x60], xmm1
4335db80  0f28ca                   movaps   xmm1, xmm2
4335db83  f30f59ca                 mulss    xmm1, xmm2
4335db87  f30f58c8                 addss    xmm1, xmm0
4335db8b  f30f10442460             movss    xmm0, dword ptr [esp + 0x60]
4335db91  f30f59c0                 mulss    xmm0, xmm0
4335db95  f30f58c8                 addss    xmm1, xmm0
4335db99  0f28c1                   movaps   xmm0, xmm1
4335db9c  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335dba4  f30f51c0                 sqrtss   xmm0, xmm0
4335dba8  f30f118424a0030000       movss    dword ptr [esp + 0x3a0], xmm0
4335dbb1  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335dbb9  f30f5ec8                 divss    xmm1, xmm0
4335dbbd  0f28c2                   movaps   xmm0, xmm2
4335dbc0  f30f10542460             movss    xmm2, dword ptr [esp + 0x60]
4335dbc6  f30f59d1                 mulss    xmm2, xmm1
4335dbca  f30f59c1                 mulss    xmm0, xmm1
4335dbce  f30f59d9                 mulss    xmm3, xmm1
4335dbd2  f30f11542460             movss    dword ptr [esp + 0x60], xmm2
4335dbd8  f30f11942438010000       movss    dword ptr [esp + 0x138], xmm2
4335dbe1  f30f1015d0034743         movss    xmm2, dword ptr [0x434703d0]
4335dbe9  f30f1144241c             movss    dword ptr [esp + 0x1c], xmm0
4335dbef  f30f11842430010000       movss    dword ptr [esp + 0x130], xmm0
4335dbf8  f30f115c2434             movss    dword ptr [esp + 0x34], xmm3
4335dbfe  f30f119c2434010000       movss    dword ptr [esp + 0x134], xmm3
4335dc07  f30f104170               movss    xmm0, dword ptr [ecx + 0x70]
4335dc0c  0f2fc5                   comiss   xmm0, xmm5
4335dc0f  0f86ee050000             jbe      0x4335e203
4335dc15  8b5144                   mov      edx, dword ptr [ecx + 0x44]
4335dc18  8d42fc                   lea      eax, [edx - 4]
4335dc1b  83f803                   cmp      eax, 3
4335dc1e  0f8794000000             ja       0x4335dcb8
4335dc24  8bcf                     mov      ecx, edi
4335dc26  e80c100200               call     0x4337ec37
4335dc2b  8b442454                 mov      eax, dword ptr [esp + 0x54]
4335dc2f  f30f118c2498000000       movss    dword ptr [esp + 0x98], xmm1
4335dc38  f30f104f28               movss    xmm1, dword ptr [edi + 0x28]
4335dc3d  f30f11842494000000       movss    dword ptr [esp + 0x94], xmm0
4335dc46  0f28c1                   movaps   xmm0, xmm1
4335dc49  f30f59842494000000       mulss    xmm0, dword ptr [esp + 0x94]
4335dc52  8b5004                   mov      edx, dword ptr [eax + 4]
4335dc55  f30f1194249c000000       movss    dword ptr [esp + 0x9c], xmm2
4335dc5e  f30f58470c               addss    xmm0, dword ptr [edi + 0xc]
4335dc63  f30f118424dc000000       movss    dword ptr [esp + 0xdc], xmm0
4335dc6c  0f28c1                   movaps   xmm0, xmm1
4335dc6f  f30f59842498000000       mulss    xmm0, dword ptr [esp + 0x98]
4335dc78  f30f59ca                 mulss    xmm1, xmm2
4335dc7c  f30f584710               addss    xmm0, dword ptr [edi + 0x10]
4335dc81  f30f584f14               addss    xmm1, dword ptr [edi + 0x14]
4335dc86  f30f118424e0000000       movss    dword ptr [esp + 0xe0], xmm0
4335dc8f  f30f109424e0000000       movss    xmm2, dword ptr [esp + 0xe0]
4335dc98  f30f118c24e4000000       movss    dword ptr [esp + 0xe4], xmm1
4335dca1  f30f108c24dc000000       movss    xmm1, dword ptr [esp + 0xdc]
4335dcaa  f30f109c24e4000000       movss    xmm3, dword ptr [esp + 0xe4]
4335dcb3  e9e2070000               jmp      0x4335e49a
4335dcb8  8d7154                   lea      esi, [ecx + 0x54]
4335dcbb  89742414                 mov      dword ptr [esp + 0x14], esi
4335dcbf  83fa03                   cmp      edx, 3
4335dcc2  0f85f0010000             jne      0x4335deb8
4335dcc8  f30f1016                 movss    xmm2, dword ptr [esi]
4335dccc  f30f104e04               movss    xmm1, dword ptr [esi + 4]
4335dcd1  0f28c2                   movaps   xmm0, xmm2
4335dcd4  f30f5c07                 subss    xmm0, dword ptr [edi]
4335dcd8  f30f5c494c               subss    xmm1, dword ptr [ecx + 0x4c]
4335dcdd  f30f59c7                 mulss    xmm0, xmm7
4335dce1  f30f59cc                 mulss    xmm1, xmm4
4335dce5  f30f58c8                 addss    xmm1, xmm0
4335dce9  f30f104608               movss    xmm0, dword ptr [esi + 8]
4335dcee  f30f5c4150               subss    xmm0, dword ptr [ecx + 0x50]
4335dcf3  f30f59c6                 mulss    xmm0, xmm6
4335dcf7  f30f58c8                 addss    xmm1, xmm0
4335dcfb  0f2fcd                   comiss   xmm1, xmm5
4335dcfe  7304                     jae      0x4335dd04
4335dd00  f30f1017                 movss    xmm2, dword ptr [edi]
4335dd04  0f2fcd                   comiss   xmm1, xmm5
4335dd07  8b5104                   mov      edx, dword ptr [ecx + 4]
4335dd0a  8bc6                     mov      eax, esi
4335dd0c  8d8c240c030000           lea      ecx, [esp + 0x30c]
4335dd13  6a02                     push     2
4335dd15  8b5204                   mov      edx, dword ptr [edx + 4]
4335dd18  0f28cf                   movaps   xmm1, xmm7
4335dd1b  0f28c4                   movaps   xmm0, xmm4
4335dd1e  f30f59c4                 mulss    xmm0, xmm4
4335dd22  0f42c7                   cmovb    eax, edi
4335dd25  f30f59cf                 mulss    xmm1, xmm7
4335dd29  f30f58c8                 addss    xmm1, xmm0
4335dd2d  0f28c6                   movaps   xmm0, xmm6
4335dd30  f30f59c6                 mulss    xmm0, xmm6
4335dd34  f30f58c8                 addss    xmm1, xmm0
4335dd38  0f28c1                   movaps   xmm0, xmm1
4335dd3b  f30f104f28               movss    xmm1, dword ptr [edi + 0x28]
4335dd40  f30f51c0                 sqrtss   xmm0, xmm0
4335dd44  f30f5ec8                 divss    xmm1, xmm0
4335dd48  f30f118424a8030000       movss    dword ptr [esp + 0x3a8], xmm0
4335dd51  0f28c1                   movaps   xmm0, xmm1
4335dd54  f30f59c7                 mulss    xmm0, xmm7
4335dd58  f30f58c2                 addss    xmm0, xmm2
4335dd5c  f30f118424ec000000       movss    dword ptr [esp + 0xec], xmm0
4335dd65  0f28c1                   movaps   xmm0, xmm1
4335dd68  f30f59c4                 mulss    xmm0, xmm4
4335dd6c  f30f59ce                 mulss    xmm1, xmm6
4335dd70  f30f584004               addss    xmm0, dword ptr [eax + 4]
4335dd75  f30f584808               addss    xmm1, dword ptr [eax + 8]
4335dd7a  f30f118424f0000000       movss    dword ptr [esp + 0xf0], xmm0
4335dd83  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
4335dd8b  f30f109424f0000000       movss    xmm2, dword ptr [esp + 0xf0]
4335dd94  f30f118c24f4000000       movss    dword ptr [esp + 0xf4], xmm1
4335dd9d  f30f108c24ec000000       movss    xmm1, dword ptr [esp + 0xec]
4335dda6  f30f109c24f4000000       movss    xmm3, dword ptr [esp + 0xf4]
4335ddaf  e825990000               call     0x433676d9
4335ddb4  f30f1005d0034743         movss    xmm0, dword ptr [0x434703d0]
4335ddbc  8b442454                 mov      eax, dword ptr [esp + 0x54]
4335ddc0  f30f10642444             movss    xmm4, dword ptr [esp + 0x44]
4335ddc6  f30f1094248c000000       movss    xmm2, dword ptr [esp + 0x8c]
4335ddcf  0f57e0                   xorps    xmm4, xmm0
4335ddd2  f30f105c2464             movss    xmm3, dword ptr [esp + 0x64]
4335ddd8  0f57d0                   xorps    xmm2, xmm0
4335dddb  f30f102e                 movss    xmm5, dword ptr [esi]
4335dddf  0f57d8                   xorps    xmm3, xmm0
4335dde2  f30f104e04               movss    xmm1, dword ptr [esi + 4]
4335dde7  0f28c5                   movaps   xmm0, xmm5
4335ddea  f30f5c07                 subss    xmm0, dword ptr [edi]
4335ddee  f30f5c484c               subss    xmm1, dword ptr [eax + 0x4c]
4335ddf3  f30f59c4                 mulss    xmm0, xmm4
4335ddf7  f30f59ca                 mulss    xmm1, xmm2
4335ddfb  f30f58c8                 addss    xmm1, xmm0
4335ddff  f30f104608               movss    xmm0, dword ptr [esi + 8]
4335de04  f30f5c4050               subss    xmm0, dword ptr [eax + 0x50]
4335de09  f30f59c3                 mulss    xmm0, xmm3
4335de0d  f30f58c8                 addss    xmm1, xmm0
4335de11  0f57c0                   xorps    xmm0, xmm0
4335de14  0f2fc8                   comiss   xmm1, xmm0
4335de17  7304                     jae      0x4335de1d
4335de19  f30f102f                 movss    xmm5, dword ptr [edi]
4335de1d  0f28ca                   movaps   xmm1, xmm2
4335de20  8b5004                   mov      edx, dword ptr [eax + 4]
4335de23  f30f59ca                 mulss    xmm1, xmm2
4335de27  0f28c3                   movaps   xmm0, xmm3
4335de2a  0f42f7                   cmovb    esi, edi
4335de2d  f30f59c3                 mulss    xmm0, xmm3
4335de31  f30f58c8                 addss    xmm1, xmm0
4335de35  0f28c4                   movaps   xmm0, xmm4
4335de38  f30f59c4                 mulss    xmm0, xmm4
4335de3c  f30f58c8                 addss    xmm1, xmm0
4335de40  0f57c0                   xorps    xmm0, xmm0
4335de43  f30f10c1                 movss    xmm0, xmm1
4335de47  f30f104f28               movss    xmm1, dword ptr [edi + 0x28]
4335de4c  f30f51c0                 sqrtss   xmm0, xmm0
4335de50  f30f5ec8                 divss    xmm1, xmm0
4335de54  f30f118424a8030000       movss    dword ptr [esp + 0x3a8], xmm0
4335de5d  0f28c1                   movaps   xmm0, xmm1
4335de60  f30f59c4                 mulss    xmm0, xmm4
4335de64  f30f58c5                 addss    xmm0, xmm5
4335de68  f30f118424f4000000       movss    dword ptr [esp + 0xf4], xmm0
4335de71  0f28c1                   movaps   xmm0, xmm1
4335de74  f30f59cb                 mulss    xmm1, xmm3
4335de78  f30f59c2                 mulss    xmm0, xmm2
4335de7c  f30f584e08               addss    xmm1, dword ptr [esi + 8]
4335de81  f30f584604               addss    xmm0, dword ptr [esi + 4]
4335de86  f30f118c24fc000000       movss    dword ptr [esp + 0xfc], xmm1
4335de8f  f30f108c24f4000000       movss    xmm1, dword ptr [esp + 0xf4]
4335de98  f30f109c24fc000000       movss    xmm3, dword ptr [esp + 0xfc]
4335dea1  f30f118424f8000000       movss    dword ptr [esp + 0xf8], xmm0
4335deaa  f30f109424f8000000       movss    xmm2, dword ptr [esp + 0xf8]
4335deb3  e9e2050000               jmp      0x4335e49a
4335deb8  8db42430010000           lea      esi, [esp + 0x130]
4335debf  0f57fa                   xorps    xmm7, xmm2
4335dec2  8dbc24ac080000           lea      edi, [esp + 0x8ac]
4335dec9  0f57e2                   xorps    xmm4, xmm2
4335decc  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335decd  8d8424ac080000           lea      eax, [esp + 0x8ac]
4335ded4  0f57f2                   xorps    xmm6, xmm2
4335ded7  89442464                 mov      dword ptr [esp + 0x64], eax
4335dedb  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335dedc  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335dedd  8db4243c010000           lea      esi, [esp + 0x13c]
4335dee4  8dbc24b8080000           lea      edi, [esp + 0x8b8]
4335deeb  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335deec  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335deed  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335deee  f30f11bc24c4080000       movss    dword ptr [esp + 0x8c4], xmm7
4335def7  f30f11a424c8080000       movss    dword ptr [esp + 0x8c8], xmm4
4335df00  f30f11b424cc080000       movss    dword ptr [esp + 0x8cc], xmm6
4335df09  eb03                     jmp      0x4335df0e
4335df0b  0f57ed                   xorps    xmm5, xmm5
4335df0e  8bf0                     mov      esi, eax
4335df10  8d7c246c                 lea      edi, [esp + 0x6c]
4335df14  8b442414                 mov      eax, dword ptr [esp + 0x14]
4335df18  8d5148                   lea      edx, [ecx + 0x48]
4335df1b  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335df1c  f30f1030                 movss    xmm6, dword ptr [eax]
4335df20  f30f104804               movss    xmm1, dword ptr [eax + 4]
4335df25  0f28c6                   movaps   xmm0, xmm6
4335df28  f30f5c02                 subss    xmm0, dword ptr [edx]
4335df2c  f30f5c494c               subss    xmm1, dword ptr [ecx + 0x4c]
4335df31  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335df32  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335df33  f30f105c2470             movss    xmm3, dword ptr [esp + 0x70]
4335df39  f30f1054246c             movss    xmm2, dword ptr [esp + 0x6c]
4335df3f  f30f10642474             movss    xmm4, dword ptr [esp + 0x74]
4335df45  f30f59c2                 mulss    xmm0, xmm2
4335df49  f30f59cb                 mulss    xmm1, xmm3
4335df4d  f30f115c244c             movss    dword ptr [esp + 0x4c], xmm3
4335df53  f30f11542424             movss    dword ptr [esp + 0x24], xmm2
4335df59  f30f58c8                 addss    xmm1, xmm0
4335df5d  f30f104008               movss    xmm0, dword ptr [eax + 8]
4335df62  f30f5c4150               subss    xmm0, dword ptr [ecx + 0x50]
4335df67  f30f59c4                 mulss    xmm0, xmm4
4335df6b  f30f58c8                 addss    xmm1, xmm0
4335df6f  0f2fcd                   comiss   xmm1, xmm5
4335df72  7304                     jae      0x4335df78
4335df74  f30f1032                 movss    xmm6, dword ptr [edx]
4335df78  0f28cb                   movaps   xmm1, xmm3
4335df7b  8db424b4000000           lea      esi, [esp + 0xb4]
4335df82  f30f59cb                 mulss    xmm1, xmm3
4335df86  8dbc24a8000000           lea      edi, [esp + 0xa8]
4335df8d  0f42c2                   cmovb    eax, edx
4335df90  83794401                 cmp      dword ptr [ecx + 0x44], 1
4335df94  0f28c4                   movaps   xmm0, xmm4
4335df97  f30f59c4                 mulss    xmm0, xmm4
4335df9b  f30f58c8                 addss    xmm1, xmm0
4335df9f  0f28c2                   movaps   xmm0, xmm2
4335dfa2  f30f59c2                 mulss    xmm0, xmm2
4335dfa6  f30f58c8                 addss    xmm1, xmm0
4335dfaa  0f28c1                   movaps   xmm0, xmm1
4335dfad  f30f104a28               movss    xmm1, dword ptr [edx + 0x28]
4335dfb2  f30f51c0                 sqrtss   xmm0, xmm0
4335dfb6  f30f5ec8                 divss    xmm1, xmm0
4335dfba  f30f118424ac030000       movss    dword ptr [esp + 0x3ac], xmm0
4335dfc3  0f28c2                   movaps   xmm0, xmm2
4335dfc6  f30f59c1                 mulss    xmm0, xmm1
4335dfca  f30f58c6                 addss    xmm0, xmm6
4335dfce  f30f118424b4000000       movss    dword ptr [esp + 0xb4], xmm0
4335dfd7  0f28c3                   movaps   xmm0, xmm3
4335dfda  f30f59c1                 mulss    xmm0, xmm1
4335dfde  f30f59cc                 mulss    xmm1, xmm4
4335dfe2  f30f584004               addss    xmm0, dword ptr [eax + 4]
4335dfe7  f30f584808               addss    xmm1, dword ptr [eax + 8]
4335dfec  f30f118424b8000000       movss    dword ptr [esp + 0xb8], xmm0
4335dff5  f30f118c24bc000000       movss    dword ptr [esp + 0xbc], xmm1
4335dffe  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335dfff  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e000  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e001  0f85a2010000             jne      0x4335e1a9
4335e007  8b742428                 mov      esi, dword ptr [esp + 0x28]
4335e00b  8dbc24500e0000           lea      edi, [esp + 0xe50]
4335e012  8d9424500e0000           lea      edx, [esp + 0xe50]
4335e019  8d8c2498200000           lea      ecx, [esp + 0x2098]
4335e020  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e021  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e022  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e023  8db424b4000000           lea      esi, [esp + 0xb4]
4335e02a  8dbc245c0e0000           lea      edi, [esp + 0xe5c]
4335e031  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e032  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e033  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e034  e8a9eb0300               call     0x4339cbe2
4335e039  f30f108c24c0200000       movss    xmm1, dword ptr [esp + 0x20c0]
4335e042  0f2fc8                   comiss   xmm1, xmm0
4335e045  0f825a010000             jb       0x4335e1a5
4335e04b  f30f10542460             movss    xmm2, dword ptr [esp + 0x60]
4335e051  f30f58542474             addss    xmm2, dword ptr [esp + 0x74]
4335e057  f30f106c244c             movss    xmm5, dword ptr [esp + 0x4c]
4335e05d  f30f586c2434             addss    xmm5, dword ptr [esp + 0x34]
4335e063  f30f10642424             movss    xmm4, dword ptr [esp + 0x24]
4335e069  f30f5864241c             addss    xmm4, dword ptr [esp + 0x1c]
4335e06f  0f28c2                   movaps   xmm0, xmm2
4335e072  f30f101d14054743         movss    xmm3, dword ptr [0x43470514]
4335e07a  f30f59c2                 mulss    xmm0, xmm2
4335e07e  8b442414                 mov      eax, dword ptr [esp + 0x14]
4335e082  0f28cd                   movaps   xmm1, xmm5
4335e085  8b4c2454                 mov      ecx, dword ptr [esp + 0x54]
4335e089  f30f59cd                 mulss    xmm1, xmm5
4335e08d  8d5148                   lea      edx, [ecx + 0x48]
4335e090  f30f58c8                 addss    xmm1, xmm0
4335e094  0f28c4                   movaps   xmm0, xmm4
4335e097  f30f59c4                 mulss    xmm0, xmm4
4335e09b  f30f58c8                 addss    xmm1, xmm0
4335e09f  0f28c1                   movaps   xmm0, xmm1
4335e0a2  f30f104804               movss    xmm1, dword ptr [eax + 4]
4335e0a7  f30f51c0                 sqrtss   xmm0, xmm0
4335e0ab  f30f5c494c               subss    xmm1, dword ptr [ecx + 0x4c]
4335e0b0  f30f118424b0030000       movss    dword ptr [esp + 0x3b0], xmm0
4335e0b9  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335e0c1  f30f5ed8                 divss    xmm3, xmm0
4335e0c5  0f28f3                   movaps   xmm6, xmm3
4335e0c8  f30f59f4                 mulss    xmm6, xmm4
4335e0cc  0f28e3                   movaps   xmm4, xmm3
4335e0cf  f30f59da                 mulss    xmm3, xmm2
4335e0d3  f30f1010                 movss    xmm2, dword ptr [eax]
4335e0d7  0f28c2                   movaps   xmm0, xmm2
4335e0da  f30f59e5                 mulss    xmm4, xmm5
4335e0de  f30f5c02                 subss    xmm0, dword ptr [edx]
4335e0e2  f30f1174246c             movss    dword ptr [esp + 0x6c], xmm6
4335e0e8  f30f59cc                 mulss    xmm1, xmm4
4335e0ec  f30f11642470             movss    dword ptr [esp + 0x70], xmm4
4335e0f2  f30f59c6                 mulss    xmm0, xmm6
4335e0f6  f30f115c2474             movss    dword ptr [esp + 0x74], xmm3
4335e0fc  f30f58c8                 addss    xmm1, xmm0
4335e100  f30f104008               movss    xmm0, dword ptr [eax + 8]
4335e105  f30f5c4150               subss    xmm0, dword ptr [ecx + 0x50]
4335e10a  f30f59c3                 mulss    xmm0, xmm3
4335e10e  f30f58c8                 addss    xmm1, xmm0
4335e112  0f57c0                   xorps    xmm0, xmm0
4335e115  0f2fc8                   comiss   xmm1, xmm0
4335e118  7304                     jae      0x4335e11e
4335e11a  f30f1012                 movss    xmm2, dword ptr [edx]
4335e11e  0f28cc                   movaps   xmm1, xmm4
4335e121  8db424cc000000           lea      esi, [esp + 0xcc]
4335e128  f30f59cc                 mulss    xmm1, xmm4
4335e12c  8dbc24a8000000           lea      edi, [esp + 0xa8]
4335e133  0f42c2                   cmovb    eax, edx
4335e136  0f28c3                   movaps   xmm0, xmm3
4335e139  f30f59c3                 mulss    xmm0, xmm3
4335e13d  f30f58c8                 addss    xmm1, xmm0
4335e141  0f28c6                   movaps   xmm0, xmm6
4335e144  f30f59c6                 mulss    xmm0, xmm6
4335e148  f30f58c8                 addss    xmm1, xmm0
4335e14c  0f28c1                   movaps   xmm0, xmm1
4335e14f  f30f104a28               movss    xmm1, dword ptr [edx + 0x28]
4335e154  f30f51c0                 sqrtss   xmm0, xmm0
4335e158  f30f5ec8                 divss    xmm1, xmm0
4335e15c  f30f118424b4030000       movss    dword ptr [esp + 0x3b4], xmm0
4335e165  0f28c1                   movaps   xmm0, xmm1
4335e168  f30f59c6                 mulss    xmm0, xmm6
4335e16c  f30f58c2                 addss    xmm0, xmm2
4335e170  f30f118424cc000000       movss    dword ptr [esp + 0xcc], xmm0
4335e179  0f28c1                   movaps   xmm0, xmm1
4335e17c  f30f59c4                 mulss    xmm0, xmm4
4335e180  f30f59cb                 mulss    xmm1, xmm3
4335e184  f30f584004               addss    xmm0, dword ptr [eax + 4]
4335e189  f30f584808               addss    xmm1, dword ptr [eax + 8]
4335e18e  f30f118424d0000000       movss    dword ptr [esp + 0xd0], xmm0
4335e197  f30f118c24d4000000       movss    dword ptr [esp + 0xd4], xmm1
4335e1a0  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e1a1  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e1a2  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e1a3  eb04                     jmp      0x4335e1a9
4335e1a5  8b4c2454                 mov      ecx, dword ptr [esp + 0x54]
4335e1a9  8b5104                   mov      edx, dword ptr [ecx + 4]
4335e1ac  8d8c240c030000           lea      ecx, [esp + 0x30c]
4335e1b3  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
4335e1bb  f30f108c24a8000000       movss    xmm1, dword ptr [esp + 0xa8]
4335e1c4  f30f109424ac000000       movss    xmm2, dword ptr [esp + 0xac]
4335e1cd  8b5204                   mov      edx, dword ptr [edx + 4]
4335e1d0  f30f109c24b0000000       movss    xmm3, dword ptr [esp + 0xb0]
4335e1d9  6a02                     push     2
4335e1db  e8f9940000               call     0x433676d9
4335e1e0  8b442464                 mov      eax, dword ptr [esp + 0x64]
4335e1e4  8d8c24d0080000           lea      ecx, [esp + 0x8d0]
4335e1eb  83c00c                   add      eax, 0xc
4335e1ee  3bc1                     cmp      eax, ecx
4335e1f0  89442464                 mov      dword ptr [esp + 0x64], eax
4335e1f4  8b4c2454                 mov      ecx, dword ptr [esp + 0x54]
4335e1f8  0f850dfdffff             jne      0x4335df0b
4335e1fe  e9b0020000               jmp      0x4335e4b3
4335e203  8b4104                   mov      eax, dword ptr [ecx + 4]
4335e206  6a04                     push     4
4335e208  5e                       pop      esi
4335e209  8974241c                 mov      dword ptr [esp + 0x1c], esi
4335e20d  f30f105018               movss    xmm2, dword ptr [eax + 0x18]
4335e212  f30f58500c               addss    xmm2, dword ptr [eax + 0xc]
4335e217  f30f104810               movss    xmm1, dword ptr [eax + 0x10]
4335e21c  f30f104008               movss    xmm0, dword ptr [eax + 8]
4335e221  f30f118424c4020000       movss    dword ptr [esp + 0x2c4], xmm0
4335e22a  f30f118c24cc020000       movss    dword ptr [esp + 0x2cc], xmm1
4335e233  f30f591540224743         mulss    xmm2, dword ptr [0x43472240]
4335e23b  f30f119424c8020000       movss    dword ptr [esp + 0x2c8], xmm2
4335e244  f30f10481c               movss    xmm1, dword ptr [eax + 0x1c]
4335e249  f30f104014               movss    xmm0, dword ptr [eax + 0x14]
4335e24e  f30f118424d0020000       movss    dword ptr [esp + 0x2d0], xmm0
4335e257  f30f119424d4020000       movss    dword ptr [esp + 0x2d4], xmm2
4335e260  f30f118c24d8020000       movss    dword ptr [esp + 0x2d8], xmm1
4335e269  f30f104810               movss    xmm1, dword ptr [eax + 0x10]
4335e26e  f30f104014               movss    xmm0, dword ptr [eax + 0x14]
4335e273  f30f118424dc020000       movss    dword ptr [esp + 0x2dc], xmm0
4335e27c  f30f119424e0020000       movss    dword ptr [esp + 0x2e0], xmm2
4335e285  f30f118c24e4020000       movss    dword ptr [esp + 0x2e4], xmm1
4335e28e  f30f104008               movss    xmm0, dword ptr [eax + 8]
4335e293  f30f10481c               movss    xmm1, dword ptr [eax + 0x1c]
4335e298  8d8424cc020000           lea      eax, [esp + 0x2cc]
4335e29f  f30f118424e8020000       movss    dword ptr [esp + 0x2e8], xmm0
4335e2a8  f30f100528264743         movss    xmm0, dword ptr [0x43472628]
4335e2b0  f30f11442464             movss    dword ptr [esp + 0x64], xmm0
4335e2b6  f30f100544224743         movss    xmm0, dword ptr [0x43472244]
4335e2be  f30f119424ec020000       movss    dword ptr [esp + 0x2ec], xmm2
4335e2c7  f30f118c24f0020000       movss    dword ptr [esp + 0x2f0], xmm1
4335e2d0  f30f11442434             movss    dword ptr [esp + 0x34], xmm0
4335e2d6  f30f1068fc               movss    xmm5, dword ptr [eax - 4]
4335e2db  f30f596914               mulss    xmm5, dword ptr [ecx + 0x14]
4335e2e0  f30f104110               movss    xmm0, dword ptr [ecx + 0x10]
4335e2e5  f30f5940f8               mulss    xmm0, dword ptr [eax - 8]
4335e2ea  f30f58e8                 addss    xmm5, xmm0
4335e2ee  f30f104118               movss    xmm0, dword ptr [ecx + 0x18]
4335e2f3  f30f5900                 mulss    xmm0, dword ptr [eax]
4335e2f7  f30f58e8                 addss    xmm5, xmm0
4335e2fb  f30f58691c               addss    xmm5, dword ptr [ecx + 0x1c]
4335e300  f30f11ac24b0010000       movss    dword ptr [esp + 0x1b0], xmm5
4335e309  f30f105924               movss    xmm3, dword ptr [ecx + 0x24]
4335e30e  f30f5958fc               mulss    xmm3, dword ptr [eax - 4]
4335e313  f30f104120               movss    xmm0, dword ptr [ecx + 0x20]
4335e318  f30f5940f8               mulss    xmm0, dword ptr [eax - 8]
4335e31d  f30f58d8                 addss    xmm3, xmm0
4335e321  f30f104128               movss    xmm0, dword ptr [ecx + 0x28]
4335e326  f30f5900                 mulss    xmm0, dword ptr [eax]
4335e32a  f30f58d8                 addss    xmm3, xmm0
4335e32e  f30f58592c               addss    xmm3, dword ptr [ecx + 0x2c]
4335e333  f30f119c24b4010000       movss    dword ptr [esp + 0x1b4], xmm3
4335e33c  f30f1050fc               movss    xmm2, dword ptr [eax - 4]
4335e341  f30f595134               mulss    xmm2, dword ptr [ecx + 0x34]
4335e346  f30f104130               movss    xmm0, dword ptr [ecx + 0x30]
4335e34b  f30f5940f8               mulss    xmm0, dword ptr [eax - 8]
4335e350  f30f58d0                 addss    xmm2, xmm0
4335e354  f30f104138               movss    xmm0, dword ptr [ecx + 0x38]
4335e359  f30f5900                 mulss    xmm0, dword ptr [eax]
4335e35d  f30f58d0                 addss    xmm2, xmm0
4335e361  f30f58513c               addss    xmm2, dword ptr [ecx + 0x3c]
4335e366  f30f119424b8010000       movss    dword ptr [esp + 0x1b8], xmm2
4335e36f  f30f5c2a                 subss    xmm5, dword ptr [edx]
4335e373  f30f5c5a04               subss    xmm3, dword ptr [edx + 4]
4335e378  f30f5c5208               subss    xmm2, dword ptr [edx + 8]
4335e37d  0f28cd                   movaps   xmm1, xmm5
4335e380  f30f59cd                 mulss    xmm1, xmm5
4335e384  0f28c3                   movaps   xmm0, xmm3
4335e387  f30f59c3                 mulss    xmm0, xmm3
4335e38b  f30f59ef                 mulss    xmm5, xmm7
4335e38f  f30f58c8                 addss    xmm1, xmm0
4335e393  f30f59dc                 mulss    xmm3, xmm4
4335e397  0f28c2                   movaps   xmm0, xmm2
4335e39a  f30f59c2                 mulss    xmm0, xmm2
4335e39e  f30f58eb                 addss    xmm5, xmm3
4335e3a2  f30f59d6                 mulss    xmm2, xmm6
4335e3a6  f30f58c8                 addss    xmm1, xmm0
4335e3aa  f30f58ea                 addss    xmm5, xmm2
4335e3ae  0f28c1                   movaps   xmm0, xmm1
4335e3b1  f30f104c2464             movss    xmm1, dword ptr [esp + 0x64]
4335e3b7  f30f51c0                 sqrtss   xmm0, xmm0
4335e3bb  f30f5ee8                 divss    xmm5, xmm0
4335e3bf  f30f118424b8030000       movss    dword ptr [esp + 0x3b8], xmm0
4335e3c8  0f2fe9                   comiss   xmm5, xmm1
4335e3cb  761e                     jbe      0x4335e3eb
4335e3cd  8db424b0010000           lea      esi, [esp + 0x1b0]
4335e3d4  0f28cd                   movaps   xmm1, xmm5
4335e3d7  8dbc24c0000000           lea      edi, [esp + 0xc0]
4335e3de  f30f114c2464             movss    dword ptr [esp + 0x64], xmm1
4335e3e4  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e3e5  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e3e6  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e3e7  8b74241c                 mov      esi, dword ptr [esp + 0x1c]
4335e3eb  f30f10442434             movss    xmm0, dword ptr [esp + 0x34]
4335e3f1  0f2fc5                   comiss   xmm0, xmm5
4335e3f4  761b                     jbe      0x4335e411
4335e3f6  8db424b0010000           lea      esi, [esp + 0x1b0]
4335e3fd  f30f116c2434             movss    dword ptr [esp + 0x34], xmm5
4335e403  8dbc2418010000           lea      edi, [esp + 0x118]
4335e40a  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e40b  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e40c  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e40d  8b74241c                 mov      esi, dword ptr [esp + 0x1c]
4335e411  83c00c                   add      eax, 0xc
4335e414  83ee01                   sub      esi, 1
4335e417  8974241c                 mov      dword ptr [esp + 0x1c], esi
4335e41b  0f85b5feffff             jne      0x4335e2d6
4335e421  0f2e0d28264743           ucomiss  xmm1, dword ptr [0x43472628]
4335e428  9f                       lahf     
4335e429  f6c444                   test     ah, 0x44
4335e42c  7b3b                     jnp      0x4335e469
4335e42e  8b5104                   mov      edx, dword ptr [ecx + 4]
4335e431  8d8c240c030000           lea      ecx, [esp + 0x30c]
4335e438  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
4335e440  f30f108c24c0000000       movss    xmm1, dword ptr [esp + 0xc0]
4335e449  f30f109424c4000000       movss    xmm2, dword ptr [esp + 0xc4]
4335e452  8b5204                   mov      edx, dword ptr [edx + 4]
4335e455  f30f109c24c8000000       movss    xmm3, dword ptr [esp + 0xc8]
4335e45e  6a02                     push     2
4335e460  e874920000               call     0x433676d9
4335e465  8b4c2454                 mov      ecx, dword ptr [esp + 0x54]
4335e469  f30f10442434             movss    xmm0, dword ptr [esp + 0x34]
4335e46f  0f2e0544224743           ucomiss  xmm0, dword ptr [0x43472244]
4335e476  9f                       lahf     
4335e477  f6c444                   test     ah, 0x44
4335e47a  7b37                     jnp      0x4335e4b3
4335e47c  8b5104                   mov      edx, dword ptr [ecx + 4]
4335e47f  f30f108c2418010000       movss    xmm1, dword ptr [esp + 0x118]
4335e488  f30f1094241c010000       movss    xmm2, dword ptr [esp + 0x11c]
4335e491  f30f109c2420010000       movss    xmm3, dword ptr [esp + 0x120]
4335e49a  8b5204                   mov      edx, dword ptr [edx + 4]
4335e49d  8d8c240c030000           lea      ecx, [esp + 0x30c]
4335e4a4  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
4335e4ac  6a02                     push     2
4335e4ae  e826920000               call     0x433676d9
4335e4b3  8b8c2480000000           mov      ecx, dword ptr [esp + 0x80]
4335e4ba  f6817801000004           test     byte ptr [ecx + 0x178], 4
4335e4c1  0f85cb020000             jne      0x4335e792
4335e4c7  8b442428                 mov      eax, dword ptr [esp + 0x28]
4335e4cb  f30f10ac2484000000       movss    xmm5, dword ptr [esp + 0x84]
4335e4d4  f30f1074242c             movss    xmm6, dword ptr [esp + 0x2c]
4335e4da  0f28d5                   movaps   xmm2, xmm5
4335e4dd  f30f107c2418             movss    xmm7, dword ptr [esp + 0x18]
4335e4e3  0f28de                   movaps   xmm3, xmm6
4335e4e6  f30f5c5804               subss    xmm3, dword ptr [eax + 4]
4335e4eb  f30f5c10                 subss    xmm2, dword ptr [eax]
4335e4ef  0f28e7                   movaps   xmm4, xmm7
4335e4f2  8bb4240c030000           mov      esi, dword ptr [esp + 0x30c]
4335e4f9  f30f5c6008               subss    xmm4, dword ptr [eax + 8]
4335e4fe  8974241c                 mov      dword ptr [esp + 0x1c], esi
4335e502  0f28c3                   movaps   xmm0, xmm3
4335e505  0f28ca                   movaps   xmm1, xmm2
4335e508  f30f59c3                 mulss    xmm0, xmm3
4335e50c  f30f59ca                 mulss    xmm1, xmm2
4335e510  f30f58c8                 addss    xmm1, xmm0
4335e514  0f28c4                   movaps   xmm0, xmm4
4335e517  f30f59c4                 mulss    xmm0, xmm4
4335e51b  f30f58c8                 addss    xmm1, xmm0
4335e51f  0f28c1                   movaps   xmm0, xmm1
4335e522  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335e52a  f30f51c0                 sqrtss   xmm0, xmm0
4335e52e  0f11842400010000         movups   xmmword ptr [esp + 0x100], xmm0
4335e536  f30f118424bc030000       movss    dword ptr [esp + 0x3bc], xmm0
4335e53f  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335e547  f30f5ec8                 divss    xmm1, xmm0
4335e54b  0f28c1                   movaps   xmm0, xmm1
4335e54e  f30f59c2                 mulss    xmm0, xmm2
4335e552  0f28d1                   movaps   xmm2, xmm1
4335e555  f30f59d3                 mulss    xmm2, xmm3
4335e559  f30f109c2400010000       movss    xmm3, dword ptr [esp + 0x100]
4335e562  f30f595c2438             mulss    xmm3, dword ptr [esp + 0x38]
4335e568  f30f11442434             movss    dword ptr [esp + 0x34], xmm0
4335e56e  660f6e412c               movd     xmm0, dword ptr [ecx + 0x2c]
4335e573  0f5bc0                   cvtdq2ps xmm0, xmm0
4335e576  f30f59cc                 mulss    xmm1, xmm4
4335e57a  f30f590508f94643         mulss    xmm0, dword ptr [0x4346f908]
4335e582  f30f59d8                 mulss    xmm3, xmm0
4335e586  f30f59d8                 mulss    xmm3, xmm0
4335e58a  f30f115c2424             movss    dword ptr [esp + 0x24], xmm3
4335e590  3bb42410030000           cmp      esi, dword ptr [esp + 0x310]
4335e597  0f8476020000             je       0x4335e813
4335e59d  f30f101de0204743         movss    xmm3, dword ptr [0x434720e0]
4335e5a5  f30f10442434             movss    xmm0, dword ptr [esp + 0x34]
4335e5ab  f30f59c3                 mulss    xmm0, xmm3
4335e5af  f30f59d3                 mulss    xmm2, xmm3
4335e5b3  f30f59cb                 mulss    xmm1, xmm3
4335e5b7  f30f58c5                 addss    xmm0, xmm5
4335e5bb  f30f58d6                 addss    xmm2, xmm6
4335e5bf  f30f58cf                 addss    xmm1, xmm7
4335e5c3  f30f11442434             movss    dword ptr [esp + 0x34], xmm0
4335e5c9  f30f11542438             movss    dword ptr [esp + 0x38], xmm2
4335e5cf  f30f114c244c             movss    dword ptr [esp + 0x4c], xmm1
4335e5d5  8dbc24c40b0000           lea      edi, [esp + 0xbc4]
4335e5dc  8bd0                     mov      edx, eax
4335e5de  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e5df  8d8c24c40b0000           lea      ecx, [esp + 0xbc4]
4335e5e6  51                       push     ecx
4335e5e7  8d8c242c010000           lea      ecx, [esp + 0x12c]
4335e5ee  51                       push     ecx
4335e5ef  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e5f0  8d8c24d0010000           lea      ecx, [esp + 0x1d0]
4335e5f7  51                       push     ecx
4335e5f8  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335e5f9  8b742428                 mov      esi, dword ptr [esp + 0x28]
4335e5fd  8bce                     mov      ecx, esi
4335e5ff  83a4243401000000         and      dword ptr [esp + 0x134], 0
4335e607  f30f118424d4010000       movss    dword ptr [esp + 0x1d4], xmm0
4335e610  f30f119424d8010000       movss    dword ptr [esp + 0x1d8], xmm2
4335e619  f30f118c24dc010000       movss    dword ptr [esp + 0x1dc], xmm1
4335e622  e8e7720200               call     0x4338590e
4335e627  0f28c8                   movaps   xmm1, xmm0
4335e62a  0f57c0                   xorps    xmm0, xmm0
4335e62d  f30f5c4c2424             subss    xmm1, dword ptr [esp + 0x24]
4335e633  0f2fc1                   comiss   xmm0, xmm1
4335e636  7218                     jb       0x4335e650
4335e638  56                       push     esi
4335e639  8d8c2410030000           lea      ecx, [esp + 0x310]
4335e640  e8b0600500               call     0x433b46f5
4335e645  8bf0                     mov      esi, eax
4335e647  8944241c                 mov      dword ptr [esp + 0x1c], eax
4335e64b  e91a010000               jmp      0x4335e76a
4335e650  f30f10842428010000       movss    xmm0, dword ptr [esp + 0x128]
4335e659  0f57db                   xorps    xmm3, xmm3
4335e65c  f30f5c842400010000       subss    xmm0, dword ptr [esp + 0x100]
4335e665  f30f10942484000000       movss    xmm2, dword ptr [esp + 0x84]
4335e66e  f30f5c16                 subss    xmm2, dword ptr [esi]
4335e672  f30f59c9                 mulss    xmm1, xmm1
4335e676  0f540540034743           andps    xmm0, xmmword ptr [0x43470340]
4335e67d  f30f59c0                 mulss    xmm0, xmm0
4335e681  f30f59d2                 mulss    xmm2, xmm2
4335e685  f30f58c8                 addss    xmm1, xmm0
4335e689  f30f10442418             movss    xmm0, dword ptr [esp + 0x18]
4335e68f  f30f5c4608               subss    xmm0, dword ptr [esi + 8]
4335e694  f30f10d9                 movss    xmm3, xmm1
4335e698  f30f104c242c             movss    xmm1, dword ptr [esp + 0x2c]
4335e69e  f30f5c4e04               subss    xmm1, dword ptr [esi + 4]
4335e6a3  f30f59c0                 mulss    xmm0, xmm0
4335e6a7  f30f51db                 sqrtss   xmm3, xmm3
4335e6ab  f30f59c9                 mulss    xmm1, xmm1
4335e6af  f30f119c24c0030000       movss    dword ptr [esp + 0x3c0], xmm3
4335e6b8  f30f58d1                 addss    xmm2, xmm1
4335e6bc  f30f58d0                 addss    xmm2, xmm0
4335e6c0  0f28ca                   movaps   xmm1, xmm2
4335e6c3  f30f51c9                 sqrtss   xmm1, xmm1
4335e6c7  f30f5ed9                 divss    xmm3, xmm1
4335e6cb  f30f118c24c4030000       movss    dword ptr [esp + 0x3c4], xmm1
4335e6d4  f30f104c2478             movss    xmm1, dword ptr [esp + 0x78]
4335e6da  0f28c3                   movaps   xmm0, xmm3
4335e6dd  e8518f0000               call     0x43367633
4335e6e2  0f57c9                   xorps    xmm1, xmm1
4335e6e5  f30f10c8                 movss    xmm1, xmm0
4335e6e9  f30f10054cdd4643         movss    xmm0, dword ptr [0x4346dd4c]
4335e6f1  f30f5fc8                 maxss    xmm1, xmm0
4335e6f5  f30f100538274743         movss    xmm0, dword ptr [0x43472738]
4335e6fd  6a18                     push     0x18
4335e6ff  58                       pop      eax
4335e700  f30f5dc8                 minss    xmm1, xmm0
4335e704  f30f1006                 movss    xmm0, dword ptr [esi]
4335e708  f30f5c842484000000       subss    xmm0, dword ptr [esp + 0x84]
4335e711  f30f118c2424010000       movss    dword ptr [esp + 0x124], xmm1
4335e71a  f30f59c1                 mulss    xmm0, xmm1
4335e71e  f30f58842484000000       addss    xmm0, dword ptr [esp + 0x84]
4335e727  f30f1106                 movss    dword ptr [esi], xmm0
4335e72b  f30f104604               movss    xmm0, dword ptr [esi + 4]
4335e730  f30f5c44242c             subss    xmm0, dword ptr [esp + 0x2c]
4335e736  f30f59c1                 mulss    xmm0, xmm1
4335e73a  f30f5844242c             addss    xmm0, dword ptr [esp + 0x2c]
4335e740  f30f114604               movss    dword ptr [esi + 4], xmm0
4335e745  f30f104608               movss    xmm0, dword ptr [esi + 8]
4335e74a  f30f5c442418             subss    xmm0, dword ptr [esp + 0x18]
4335e750  f30f59c1                 mulss    xmm0, xmm1
4335e754  f30f58442418             addss    xmm0, dword ptr [esp + 0x18]
4335e75a  f30f114608               movss    dword ptr [esi + 8], xmm0
4335e75f  f30f114e0c               movss    dword ptr [esi + 0xc], xmm1
4335e764  03f0                     add      esi, eax
4335e766  8974241c                 mov      dword ptr [esp + 0x1c], esi
4335e76a  f30f104c244c             movss    xmm1, dword ptr [esp + 0x4c]
4335e770  f30f10442434             movss    xmm0, dword ptr [esp + 0x34]
4335e776  f30f10542438             movss    xmm2, dword ptr [esp + 0x38]
4335e77c  8b442428                 mov      eax, dword ptr [esp + 0x28]
4335e780  3bb42410030000           cmp      esi, dword ptr [esp + 0x310]
4335e787  0f8548feffff             jne      0x4335e5d5
4335e78d  e981000000               jmp      0x4335e813
4335e792  8b942410030000           mov      edx, dword ptr [esp + 0x310]
4335e799  8b8c240c030000           mov      ecx, dword ptr [esp + 0x30c]
4335e7a0  3bca                     cmp      ecx, edx
4335e7a2  746f                     je       0x4335e813
4335e7a4  f30f108c2484000000       movss    xmm1, dword ptr [esp + 0x84]
4335e7ad  83c108                   add      ecx, 8
4335e7b0  f30f1054242c             movss    xmm2, dword ptr [esp + 0x2c]
4335e7b6  f30f105c2418             movss    xmm3, dword ptr [esp + 0x18]
4335e7bc  f30f10642478             movss    xmm4, dword ptr [esp + 0x78]
4335e7c2  f30f1041f8               movss    xmm0, dword ptr [ecx - 8]
4335e7c7  f30f5cc1                 subss    xmm0, xmm1
4335e7cb  6a18                     push     0x18
4335e7cd  58                       pop      eax
4335e7ce  f30f59c4                 mulss    xmm0, xmm4
4335e7d2  f30f58c1                 addss    xmm0, xmm1
4335e7d6  f30f1141f8               movss    dword ptr [ecx - 8], xmm0
4335e7db  f30f1041fc               movss    xmm0, dword ptr [ecx - 4]
4335e7e0  f30f5cc2                 subss    xmm0, xmm2
4335e7e4  f30f59c4                 mulss    xmm0, xmm4
4335e7e8  f30f58c2                 addss    xmm0, xmm2
4335e7ec  f30f1141fc               movss    dword ptr [ecx - 4], xmm0
4335e7f1  f30f1001                 movss    xmm0, dword ptr [ecx]
4335e7f5  f30f5cc3                 subss    xmm0, xmm3
4335e7f9  f30f59c4                 mulss    xmm0, xmm4
4335e7fd  f30f58c3                 addss    xmm0, xmm3
4335e801  f30f1101                 movss    dword ptr [ecx], xmm0
4335e805  f30f116104               movss    dword ptr [ecx + 4], xmm4
4335e80a  03c8                     add      ecx, eax
4335e80c  8d41f8                   lea      eax, [ecx - 8]
4335e80f  3bc2                     cmp      eax, edx
4335e811  75af                     jne      0x4335e7c2
4335e813  8b742454                 mov      esi, dword ptr [esp + 0x54]
4335e817  837e4403                 cmp      dword ptr [esi + 0x44], 3
4335e81b  0f8593000000             jne      0x4335e8b4
4335e821  f30f108424641e0000       movss    xmm0, dword ptr [esp + 0x1e64]
4335e82a  8d9424d4010000           lea      edx, [esp + 0x1d4]
4335e831  f30f588424581e0000       addss    xmm0, dword ptr [esp + 0x1e58]
4335e83a  f30f100d40224743         movss    xmm1, dword ptr [0x43472240]
4335e842  8d8c24f4020000           lea      ecx, [esp + 0x2f4]
4335e849  f30f59c1                 mulss    xmm0, xmm1
4335e84d  f30f118424d4010000       movss    dword ptr [esp + 0x1d4], xmm0
4335e856  f30f108424681e0000       movss    xmm0, dword ptr [esp + 0x1e68]
4335e85f  f30f5884245c1e0000       addss    xmm0, dword ptr [esp + 0x1e5c]
4335e868  f30f59c1                 mulss    xmm0, xmm1
4335e86c  f30f118424d8010000       movss    dword ptr [esp + 0x1d8], xmm0
4335e875  f30f1084246c1e0000       movss    xmm0, dword ptr [esp + 0x1e6c]
4335e87e  f30f588424601e0000       addss    xmm0, dword ptr [esp + 0x1e60]
4335e887  f30f59c1                 mulss    xmm0, xmm1
4335e88b  f30f118424dc010000       movss    dword ptr [esp + 0x1dc], xmm0
4335e894  e88334feff               call     0x43341d1c
4335e899  f30f119424fc020000       movss    dword ptr [esp + 0x2fc], xmm2
4335e8a2  f30f118c24f8020000       movss    dword ptr [esp + 0x2f8], xmm1
4335e8ab  f30f118424f4020000       movss    dword ptr [esp + 0x2f4], xmm0
4335e8b4  8d8424f4020000           lea      eax, [esp + 0x2f4]
4335e8bb  50                       push     eax
4335e8bc  ffb42428010000           push     dword ptr [esp + 0x128]
4335e8c3  8d8c2458120000           lea      ecx, [esp + 0x1258]
4335e8ca  e89049fcff               call     0x4332325f
4335e8cf  8b842410030000           mov      eax, dword ptr [esp + 0x310]
4335e8d6  8bbc240c030000           mov      edi, dword ptr [esp + 0x30c]
4335e8dd  3bf8                     cmp      edi, eax
4335e8df  7423                     je       0x4335e904
4335e8e1  8bf0                     mov      esi, eax
4335e8e3  57                       push     edi
4335e8e4  ffb42428010000           push     dword ptr [esp + 0x128]
4335e8eb  8d8c2458120000           lea      ecx, [esp + 0x1258]
4335e8f2  e86849fcff               call     0x4332325f
4335e8f7  6a18                     push     0x18
4335e8f9  58                       pop      eax
4335e8fa  03f8                     add      edi, eax
4335e8fc  3bfe                     cmp      edi, esi
4335e8fe  75e3                     jne      0x4335e8e3
4335e900  8b742454                 mov      esi, dword ptr [esp + 0x54]
4335e904  8d8c240c030000           lea      ecx, [esp + 0x30c]
4335e90b  e87ee50600               call     0x433cce8e
4335e910  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4335e914  8b442420                 mov      eax, dword ptr [esp + 0x20]
4335e918  eb04                     jmp      0x4335e91e
4335e91a  8b742454                 mov      esi, dword ptr [esp + 0x54]
4335e91e  8587c4000000             test     dword ptr [edi + 0xc4], eax
4335e924  0f84af050000             je       0x4335eed9
4335e92a  f30f104670               movss    xmm0, dword ptr [esi + 0x70]
4335e92f  0f2f056cee4643           comiss   xmm0, dword ptr [0x4346ee6c]
4335e936  0f869d050000             jbe      0x4335eed9
4335e93c  8d8c246c020000           lea      ecx, [esp + 0x26c]
4335e943  e84d710700               call     0x433d5a95
4335e948  f30f104e4c               movss    xmm1, dword ptr [esi + 0x4c]
4335e94d  8d84246c020000           lea      eax, [esp + 0x26c]
4335e954  f30f105e58               movss    xmm3, dword ptr [esi + 0x58]
4335e959  f30f105650               movss    xmm2, dword ptr [esi + 0x50]
4335e95e  f30f58d9                 addss    xmm3, xmm1
4335e962  f30f10665c               movss    xmm4, dword ptr [esi + 0x5c]
4335e967  f30f104654               movss    xmm0, dword ptr [esi + 0x54]
4335e96c  f30f58e2                 addss    xmm4, xmm2
4335e970  f30f584648               addss    xmm0, dword ptr [esi + 0x48]
4335e975  ff74247c                 push     dword ptr [esp + 0x7c]
4335e979  f30f102d40224743         movss    xmm5, dword ptr [0x43472240]
4335e981  8b4d08                   mov      ecx, dword ptr [ebp + 8]
4335e984  8b942494000000           mov      edx, dword ptr [esp + 0x94]
4335e98b  81c1dc000000             add      ecx, 0xdc
4335e991  50                       push     eax
4335e992  8d8424e8010000           lea      eax, [esp + 0x1e8]
4335e999  f30f59c5                 mulss    xmm0, xmm5
4335e99d  50                       push     eax
4335e99e  f30f59dd                 mulss    xmm3, xmm5
4335e9a2  8d87f0000000             lea      eax, [edi + 0xf0]
4335e9a8  56                       push     esi
4335e9a9  f30f59e5                 mulss    xmm4, xmm5
4335e9ad  50                       push     eax
4335e9ae  f30f118424f4010000       movss    dword ptr [esp + 0x1f4], xmm0
4335e9b7  f30f119c24f8010000       movss    dword ptr [esp + 0x1f8], xmm3
4335e9c0  f30f11a424fc010000       movss    dword ptr [esp + 0x1fc], xmm4
4335e9c9  898c248c000000           mov      dword ptr [esp + 0x8c], ecx
4335e9d0  e8e2ef0900               call     0x433fd9b7
4335e9d5  8b8c246c020000           mov      ecx, dword ptr [esp + 0x26c]
4335e9dc  8b842470020000           mov      eax, dword ptr [esp + 0x270]
4335e9e3  894c2428                 mov      dword ptr [esp + 0x28], ecx
4335e9e7  89442424                 mov      dword ptr [esp + 0x24], eax
4335e9eb  3bc8                     cmp      ecx, eax
4335e9ed  0f84da040000             je       0x4335eecd
4335e9f3  2bc1                     sub      eax, ecx
4335e9f5  0f57c9                   xorps    xmm1, xmm1
4335e9f8  99                       cdq      
4335e9f9  0f57d2                   xorps    xmm2, xmm2
4335e9fc  f77c2448                 idiv     dword ptr [esp + 0x48]
4335ea00  0f57db                   xorps    xmm3, xmm3
4335ea03  85c0                     test     eax, eax
4335ea05  743f                     je       0x4335ea46
4335ea07  83c108                   add      ecx, 8
4335ea0a  8bd0                     mov      edx, eax
4335ea0c  f30f1041f8               movss    xmm0, dword ptr [ecx - 8]
4335ea11  f30f5c8720010000         subss    xmm0, dword ptr [edi + 0x120]
4335ea19  f30f58c8                 addss    xmm1, xmm0
4335ea1d  f30f1041fc               movss    xmm0, dword ptr [ecx - 4]
4335ea22  f30f5c8724010000         subss    xmm0, dword ptr [edi + 0x124]
4335ea2a  f30f58d0                 addss    xmm2, xmm0
4335ea2e  f30f1001                 movss    xmm0, dword ptr [ecx]
4335ea32  f30f5c8728010000         subss    xmm0, dword ptr [edi + 0x128]
4335ea3a  83c118                   add      ecx, 0x18
4335ea3d  f30f58d8                 addss    xmm3, xmm0
4335ea41  83ea01                   sub      edx, 1
4335ea44  75c6                     jne      0x4335ea0c
4335ea46  f30f102d14054743         movss    xmm5, dword ptr [0x43470514]
4335ea4e  33c9                     xor      ecx, ecx
4335ea50  660f6ec0                 movd     xmm0, eax
4335ea54  41                       inc      ecx
4335ea55  c1e81f                   shr      eax, 0x1f
4335ea58  f30fe6c0                 cvtdq2pd xmm0, xmm0
4335ea5c  f20f5804c500264743       addsd    xmm0, qword ptr [eax*8 + 0x43472600]
4335ea65  660f5ac0                 cvtpd2ps xmm0, xmm0
4335ea69  f30f5ee8                 divss    xmm5, xmm0
4335ea6d  0f28f5                   movaps   xmm6, xmm5
4335ea70  0f28fd                   movaps   xmm7, xmm5
4335ea73  f30f59f1                 mulss    xmm6, xmm1
4335ea77  f30f59fa                 mulss    xmm7, xmm2
4335ea7b  f30f58b720010000         addss    xmm6, dword ptr [edi + 0x120]
4335ea83  f30f59eb                 mulss    xmm5, xmm3
4335ea87  f30f58bf24010000         addss    xmm7, dword ptr [edi + 0x124]
4335ea8f  f30f58af28010000         addss    xmm5, dword ptr [edi + 0x128]
4335ea97  83a4246002000000         and      dword ptr [esp + 0x260], 0
4335ea9f  f30f11b42454020000       movss    dword ptr [esp + 0x254], xmm6
4335eaa8  f30f11bc2458020000       movss    dword ptr [esp + 0x258], xmm7
4335eab1  f30f11ac245c020000       movss    dword ptr [esp + 0x25c], xmm5
4335eaba  8b4604                   mov      eax, dword ptr [esi + 4]
4335eabd  8b4004                   mov      eax, dword ptr [eax + 4]
4335eac0  89842464020000           mov      dword ptr [esp + 0x264], eax
4335eac7  898c2468020000           mov      dword ptr [esp + 0x268], ecx
4335eace  8b8fcc000000             mov      ecx, dword ptr [edi + 0xcc]
4335ead4  8bc1                     mov      eax, ecx
4335ead6  23442420                 and      eax, dword ptr [esp + 0x20]
4335eada  a80e                     test     al, 0xe
4335eadc  7524                     jne      0x4335eb02
4335eade  f6c1c0                   test     cl, 0xc0
4335eae1  740e                     je       0x4335eaf1
4335eae3  8b442440                 mov      eax, dword ptr [esp + 0x40]
4335eae7  83f807                   cmp      eax, 7
4335eaea  7416                     je       0x4335eb02
4335eaec  83f808                   cmp      eax, 8
4335eaef  7411                     je       0x4335eb02
4335eaf1  8d8c246c020000           lea      ecx, [esp + 0x26c]
4335eaf8  e85c1f0800               call     0x433e0a59
4335eafd  e97b030000               jmp      0x4335ee7d
4335eb02  8b8c2480000000           mov      ecx, dword ptr [esp + 0x80]
4335eb09  f30f108fc8000000         movss    xmm1, dword ptr [edi + 0xc8]
4335eb11  f30f114c2438             movss    dword ptr [esp + 0x38], xmm1
4335eb17  f6817801000004           test     byte ptr [ecx + 0x178], 4
4335eb1e  0f85da020000             jne      0x4335edfe
4335eb24  8b442478                 mov      eax, dword ptr [esp + 0x78]
4335eb28  0f28d6                   movaps   xmm2, xmm6
4335eb2b  0f28df                   movaps   xmm3, xmm7
4335eb2e  8b742428                 mov      esi, dword ptr [esp + 0x28]
4335eb32  0f28e5                   movaps   xmm4, xmm5
4335eb35  f30f5c10                 subss    xmm2, dword ptr [eax]
4335eb39  f30f5c5804               subss    xmm3, dword ptr [eax + 4]
4335eb3e  f30f5c6008               subss    xmm4, dword ptr [eax + 8]
4335eb43  0f28ca                   movaps   xmm1, xmm2
4335eb46  f30f59ca                 mulss    xmm1, xmm2
4335eb4a  0f28c3                   movaps   xmm0, xmm3
4335eb4d  f30f59c3                 mulss    xmm0, xmm3
4335eb51  f30f11642424             movss    dword ptr [esp + 0x24], xmm4
4335eb57  f30f58c8                 addss    xmm1, xmm0
4335eb5b  0f28c4                   movaps   xmm0, xmm4
4335eb5e  f30f59c4                 mulss    xmm0, xmm4
4335eb62  f30f58c8                 addss    xmm1, xmm0
4335eb66  0f28c1                   movaps   xmm0, xmm1
4335eb69  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335eb71  f30f51c0                 sqrtss   xmm0, xmm0
4335eb75  0f11842400010000         movups   xmmword ptr [esp + 0x100], xmm0
4335eb7d  f30f118424c8030000       movss    dword ptr [esp + 0x3c8], xmm0
4335eb86  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335eb8e  f30f5ec8                 divss    xmm1, xmm0
4335eb92  0f57c0                   xorps    xmm0, xmm0
4335eb95  f30f2a412c               cvtsi2ss xmm0, dword ptr [ecx + 0x2c]
4335eb9a  8b4d08                   mov      ecx, dword ptr [ebp + 8]
4335eb9d  f30f10a160010000         movss    xmm4, dword ptr [ecx + 0x160]
4335eba5  f30f590508f94643         mulss    xmm0, dword ptr [0x4346f908]
4335ebad  f30f59a42400010000       mulss    xmm4, dword ptr [esp + 0x100]
4335ebb6  f30f59e0                 mulss    xmm4, xmm0
4335ebba  f30f59e0                 mulss    xmm4, xmm0
4335ebbe  0f28c1                   movaps   xmm0, xmm1
4335ebc1  f30f59c2                 mulss    xmm0, xmm2
4335ebc5  0f28d1                   movaps   xmm2, xmm1
4335ebc8  f30f594c2424             mulss    xmm1, dword ptr [esp + 0x24]
4335ebce  f30f5905e0204743         mulss    xmm0, dword ptr [0x434720e0]
4335ebd6  f30f590de0204743         mulss    xmm1, dword ptr [0x434720e0]
4335ebde  f30f59d3                 mulss    xmm2, xmm3
4335ebe2  f30f1164244c             movss    dword ptr [esp + 0x4c], xmm4
4335ebe8  f30f11442440             movss    dword ptr [esp + 0x40], xmm0
4335ebee  f30f5915e0204743         mulss    xmm2, dword ptr [0x434720e0]
4335ebf6  f30f114c2424             movss    dword ptr [esp + 0x24], xmm1
4335ebfc  f30f11542458             movss    dword ptr [esp + 0x58], xmm2
4335ec02  8dbc24340c0000           lea      edi, [esp + 0xc34]
4335ec09  8bd0                     mov      edx, eax
4335ec0b  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335ec0c  f30f58c6                 addss    xmm0, xmm6
4335ec10  8d8c24340c0000           lea      ecx, [esp + 0xc34]
4335ec17  51                       push     ecx
4335ec18  8d8c2430010000           lea      ecx, [esp + 0x130]
4335ec1f  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335ec20  51                       push     ecx
4335ec21  8d8c24f4010000           lea      ecx, [esp + 0x1f4]
4335ec28  51                       push     ecx
4335ec29  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335ec2a  8b742434                 mov      esi, dword ptr [esp + 0x34]
4335ec2e  8bce                     mov      ecx, esi
4335ec30  83a4243801000000         and      dword ptr [esp + 0x138], 0
4335ec38  f30f118424f8010000       movss    dword ptr [esp + 0x1f8], xmm0
4335ec41  0f28c2                   movaps   xmm0, xmm2
4335ec44  f30f58c7                 addss    xmm0, xmm7
4335ec48  f30f118424fc010000       movss    dword ptr [esp + 0x1fc], xmm0
4335ec51  0f28c1                   movaps   xmm0, xmm1
4335ec54  f30f58c5                 addss    xmm0, xmm5
4335ec58  f30f11842400020000       movss    dword ptr [esp + 0x200], xmm0
4335ec61  e8a86c0200               call     0x4338590e
4335ec66  0f28c8                   movaps   xmm1, xmm0
4335ec69  0f57c0                   xorps    xmm0, xmm0
4335ec6c  f30f5c4c244c             subss    xmm1, dword ptr [esp + 0x4c]
4335ec72  0f2fc1                   comiss   xmm0, xmm1
4335ec75  7218                     jb       0x4335ec8f
4335ec77  56                       push     esi
4335ec78  8d8c2470020000           lea      ecx, [esp + 0x270]
4335ec7f  e8715a0500               call     0x433b46f5
4335ec84  8bf0                     mov      esi, eax
4335ec86  89442428                 mov      dword ptr [esp + 0x28], eax
4335ec8a  e92c010000               jmp      0x4335edbb
4335ec8f  f30f1084242c010000       movss    xmm0, dword ptr [esp + 0x12c]
4335ec98  0f57db                   xorps    xmm3, xmm3
4335ec9b  f30f5c842400010000       subss    xmm0, dword ptr [esp + 0x100]
4335eca4  f30f10942454020000       movss    xmm2, dword ptr [esp + 0x254]
4335ecad  f30f5c16                 subss    xmm2, dword ptr [esi]
4335ecb1  f30f59c9                 mulss    xmm1, xmm1
4335ecb5  0f540540034743           andps    xmm0, xmmword ptr [0x43470340]
4335ecbc  f30f59c0                 mulss    xmm0, xmm0
4335ecc0  f30f59d2                 mulss    xmm2, xmm2
4335ecc4  f30f58c8                 addss    xmm1, xmm0
4335ecc8  f30f1084245c020000       movss    xmm0, dword ptr [esp + 0x25c]
4335ecd1  f30f5c4608               subss    xmm0, dword ptr [esi + 8]
4335ecd6  f30f10d9                 movss    xmm3, xmm1
4335ecda  f30f108c2458020000       movss    xmm1, dword ptr [esp + 0x258]
4335ece3  f30f5c4e04               subss    xmm1, dword ptr [esi + 4]
4335ece8  f30f59c0                 mulss    xmm0, xmm0
4335ecec  f30f51db                 sqrtss   xmm3, xmm3
4335ecf0  f30f59c9                 mulss    xmm1, xmm1
4335ecf4  f30f119c24cc030000       movss    dword ptr [esp + 0x3cc], xmm3
4335ecfd  f30f58d1                 addss    xmm2, xmm1
4335ed01  f30f58d0                 addss    xmm2, xmm0
4335ed05  0f28ca                   movaps   xmm1, xmm2
4335ed08  f30f51c9                 sqrtss   xmm1, xmm1
4335ed0c  f30f5ed9                 divss    xmm3, xmm1
4335ed10  f30f118c24d0030000       movss    dword ptr [esp + 0x3d0], xmm1
4335ed19  f30f104c2438             movss    xmm1, dword ptr [esp + 0x38]
4335ed1f  0f28c3                   movaps   xmm0, xmm3
4335ed22  e80c890000               call     0x43367633
4335ed27  0f57c9                   xorps    xmm1, xmm1
4335ed2a  f30f10c8                 movss    xmm1, xmm0
4335ed2e  f30f10054cdd4643         movss    xmm0, dword ptr [0x4346dd4c]
4335ed36  f30f5fc8                 maxss    xmm1, xmm0
4335ed3a  f30f100538274743         movss    xmm0, dword ptr [0x43472738]
4335ed42  6a18                     push     0x18
4335ed44  58                       pop      eax
4335ed45  f30f5dc8                 minss    xmm1, xmm0
4335ed49  f30f1006                 movss    xmm0, dword ptr [esi]
4335ed4d  f30f5c842454020000       subss    xmm0, dword ptr [esp + 0x254]
4335ed56  f30f118c24d8000000       movss    dword ptr [esp + 0xd8], xmm1
4335ed5f  f30f59c1                 mulss    xmm0, xmm1
4335ed63  f30f58842454020000       addss    xmm0, dword ptr [esp + 0x254]
4335ed6c  f30f1106                 movss    dword ptr [esi], xmm0
4335ed70  f30f104604               movss    xmm0, dword ptr [esi + 4]
4335ed75  f30f5c842458020000       subss    xmm0, dword ptr [esp + 0x258]
4335ed7e  f30f59c1                 mulss    xmm0, xmm1
4335ed82  f30f58842458020000       addss    xmm0, dword ptr [esp + 0x258]
4335ed8b  f30f114604               movss    dword ptr [esi + 4], xmm0
4335ed90  f30f104608               movss    xmm0, dword ptr [esi + 8]
4335ed95  f30f5c84245c020000       subss    xmm0, dword ptr [esp + 0x25c]
4335ed9e  f30f59c1                 mulss    xmm0, xmm1
4335eda2  f30f5884245c020000       addss    xmm0, dword ptr [esp + 0x25c]
4335edab  f30f114608               movss    dword ptr [esi + 8], xmm0
4335edb0  f30f114e0c               movss    dword ptr [esi + 0xc], xmm1
4335edb5  03f0                     add      esi, eax
4335edb7  89742428                 mov      dword ptr [esp + 0x28], esi
4335edbb  3bb42470020000           cmp      esi, dword ptr [esp + 0x270]
4335edc2  0f84b1000000             je       0x4335ee79
4335edc8  f30f10ac245c020000       movss    xmm5, dword ptr [esp + 0x25c]
4335edd1  f30f10bc2458020000       movss    xmm7, dword ptr [esp + 0x258]
4335edda  f30f10b42454020000       movss    xmm6, dword ptr [esp + 0x254]
4335ede3  f30f104c2424             movss    xmm1, dword ptr [esp + 0x24]
4335ede9  f30f10442440             movss    xmm0, dword ptr [esp + 0x40]
4335edef  f30f10542458             movss    xmm2, dword ptr [esp + 0x58]
4335edf5  8b442478                 mov      eax, dword ptr [esp + 0x78]
4335edf9  e904feffff               jmp      0x4335ec02
4335edfe  8b4c2428                 mov      ecx, dword ptr [esp + 0x28]
4335ee02  8b542424                 mov      edx, dword ptr [esp + 0x24]
4335ee06  83c108                   add      ecx, 8
4335ee09  6a18                     push     0x18
4335ee0b  5f                       pop      edi
4335ee0c  f30f1041f8               movss    xmm0, dword ptr [ecx - 8]
4335ee11  f30f5cc6                 subss    xmm0, xmm6
4335ee15  f30f59c1                 mulss    xmm0, xmm1
4335ee19  f30f58c6                 addss    xmm0, xmm6
4335ee1d  f30f1141f8               movss    dword ptr [ecx - 8], xmm0
4335ee22  f30f1041fc               movss    xmm0, dword ptr [ecx - 4]
4335ee27  f30f5c842458020000       subss    xmm0, dword ptr [esp + 0x258]
4335ee30  f30f59c1                 mulss    xmm0, xmm1
4335ee34  f30f58842458020000       addss    xmm0, dword ptr [esp + 0x258]
4335ee3d  f30f1141fc               movss    dword ptr [ecx - 4], xmm0
4335ee42  f30f1001                 movss    xmm0, dword ptr [ecx]
4335ee46  f30f5c84245c020000       subss    xmm0, dword ptr [esp + 0x25c]
4335ee4f  f30f59c1                 mulss    xmm0, xmm1
4335ee53  f30f5884245c020000       addss    xmm0, dword ptr [esp + 0x25c]
4335ee5c  f30f1101                 movss    dword ptr [ecx], xmm0
4335ee60  f30f114904               movss    dword ptr [ecx + 4], xmm1
4335ee65  03cf                     add      ecx, edi
4335ee67  8d41f8                   lea      eax, [ecx - 8]
4335ee6a  3bc2                     cmp      eax, edx
4335ee6c  740b                     je       0x4335ee79
4335ee6e  f30f10b42454020000       movss    xmm6, dword ptr [esp + 0x254]
4335ee77  eb93                     jmp      0x4335ee0c
4335ee79  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4335ee7d  8d842454020000           lea      eax, [esp + 0x254]
4335ee84  50                       push     eax
4335ee85  ffb424dc000000           push     dword ptr [esp + 0xdc]
4335ee8c  8d8c2458120000           lea      ecx, [esp + 0x1258]
4335ee93  e8c743fcff               call     0x4332325f
4335ee98  8b842470020000           mov      eax, dword ptr [esp + 0x270]
4335ee9f  8bb4246c020000           mov      esi, dword ptr [esp + 0x26c]
4335eea6  3bf0                     cmp      esi, eax
4335eea8  7423                     je       0x4335eecd
4335eeaa  8bf8                     mov      edi, eax
4335eeac  56                       push     esi
4335eead  ffb424dc000000           push     dword ptr [esp + 0xdc]
4335eeb4  8d8c2458120000           lea      ecx, [esp + 0x1258]
4335eebb  e89f43fcff               call     0x4332325f
4335eec0  6a18                     push     0x18
4335eec2  58                       pop      eax
4335eec3  03f0                     add      esi, eax
4335eec5  3bf7                     cmp      esi, edi
4335eec7  75e3                     jne      0x4335eeac
4335eec9  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4335eecd  8d8c246c020000           lea      ecx, [esp + 0x26c]
4335eed4  e8b5df0600               call     0x433cce8e
4335eed9  8b4c2450                 mov      ecx, dword ptr [esp + 0x50]
4335eedd  6a00                     push     0
4335eedf  5e                       pop      esi
4335eee0  83c104                   add      ecx, 4
4335eee3  894c2450                 mov      dword ptr [esp + 0x50], ecx
4335eee7  6a01                     push     1
4335eee9  5a                       pop      edx
4335eeea  81f9284a4743             cmp      ecx, 0x43474a28
4335eef0  0f85bae7ffff             jne      0x4335d6b0
4335eef6  8d8c24e0470000           lea      ecx, [esp + 0x47e0]
4335eefd  e8227f0300               call     0x43396e24
4335ef02  f687b800000006           test     byte ptr [edi + 0xb8], 6
4335ef09  b9ffffefff               mov      ecx, 0xffefffff
4335ef0e  6aff                     push     -1
4335ef10  58                       pop      eax
4335ef11  0f44c8                   cmove    ecx, eax
4335ef14  8974244c                 mov      dword ptr [esp + 0x4c], esi
4335ef18  8b842454120000           mov      eax, dword ptr [esp + 0x1254]
4335ef1f  2b842450120000           sub      eax, dword ptr [esp + 0x1250]
4335ef26  99                       cdq      
4335ef27  f77c2448                 idiv     dword ptr [esp + 0x48]
4335ef2b  894c2428                 mov      dword ptr [esp + 0x28], ecx
4335ef2f  89742424                 mov      dword ptr [esp + 0x24], esi
4335ef33  89742414                 mov      dword ptr [esp + 0x14], esi
4335ef37  85c0                     test     eax, eax
4335ef39  0f84d5170000             je       0x43360714
4335ef3f  8b7508                   mov      esi, dword ptr [ebp + 8]
4335ef42  8b8424d8000000           mov      eax, dword ptr [esp + 0xd8]
4335ef49  81c6dc000000             add      esi, 0xdc
4335ef4f  8b5518                   mov      edx, dword ptr [ebp + 0x18]
4335ef52  894c2428                 mov      dword ptr [esp + 0x28], ecx
4335ef56  8b4c2414                 mov      ecx, dword ptr [esp + 0x14]
4335ef5a  89742434                 mov      dword ptr [esp + 0x34], esi
4335ef5e  89442430                 mov      dword ptr [esp + 0x30], eax
4335ef62  6bf918                   imul     edi, ecx, 0x18
4335ef65  8d8c2448010000           lea      ecx, [esp + 0x148]
4335ef6c  03bc2450120000           add      edi, dword ptr [esp + 0x1250]
4335ef73  897c2444                 mov      dword ptr [esp + 0x44], edi
4335ef77  8b4714                   mov      eax, dword ptr [edi + 0x14]
4335ef7a  0bc2                     or       eax, edx
4335ef7c  8944247c                 mov      dword ptr [esp + 0x7c], eax
4335ef80  8b4710                   mov      eax, dword ptr [edi + 0x10]
4335ef83  89442440                 mov      dword ptr [esp + 0x40], eax
4335ef87  e82929fdff               call     0x433318b5
4335ef8c  838c243c020000ff         or       dword ptr [esp + 0x23c], 0xffffffff
4335ef94  8d8c24200f0000           lea      ecx, [esp + 0xf20]
4335ef9b  838c2448020000ff         or       dword ptr [esp + 0x248], 0xffffffff
4335efa3  33c0                     xor      eax, eax
4335efa5  668984242e020000         mov      word ptr [esp + 0x22e], ax
4335efad  89842444020000           mov      dword ptr [esp + 0x244], eax
4335efb4  c78424240200000000803f   mov      dword ptr [esp + 0x224], 0x3f800000
4335efbf  f30f101f                 movss    xmm3, dword ptr [edi]
4335efc3  f30f105704               movss    xmm2, dword ptr [edi + 4]
4335efc8  f30f5c1e                 subss    xmm3, dword ptr [esi]
4335efcc  f30f5c5604               subss    xmm2, dword ptr [esi + 4]
4335efd1  f30f106708               movss    xmm4, dword ptr [edi + 8]
4335efd6  f30f5c6608               subss    xmm4, dword ptr [esi + 8]
4335efdb  0fb605e0a34643           movzx    eax, byte ptr [0x4346a3e0]
4335efe2  0f28cb                   movaps   xmm1, xmm3
4335efe5  f30f59cb                 mulss    xmm1, xmm3
4335efe9  0f28c2                   movaps   xmm0, xmm2
4335efec  50                       push     eax
4335efed  f30f59c2                 mulss    xmm0, xmm2
4335eff1  8b4508                   mov      eax, dword ptr [ebp + 8]
4335eff4  f30f58c8                 addss    xmm1, xmm0
4335eff8  0f28c4                   movaps   xmm0, xmm4
4335effb  f30f59c4                 mulss    xmm0, xmm4
4335efff  ff700c                   push     dword ptr [eax + 0xc]
4335f002  f30f58c8                 addss    xmm1, xmm0
4335f006  0f28c1                   movaps   xmm0, xmm1
4335f009  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335f011  f30f51c0                 sqrtss   xmm0, xmm0
4335f015  f30f118424dc030000       movss    dword ptr [esp + 0x3dc], xmm0
4335f01e  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335f026  f30f5ec8                 divss    xmm1, xmm0
4335f02a  f30f59d9                 mulss    xmm3, xmm1
4335f02e  f30f59d1                 mulss    xmm2, xmm1
4335f032  f30f59e1                 mulss    xmm4, xmm1
4335f036  f30f119c248c000000       movss    dword ptr [esp + 0x8c], xmm3
4335f03f  f30f119c2408010000       movss    dword ptr [esp + 0x108], xmm3
4335f048  f30f11542468             movss    dword ptr [esp + 0x68], xmm2
4335f04e  f30f1194240c010000       movss    dword ptr [esp + 0x10c], xmm2
4335f057  f30f1164245c             movss    dword ptr [esp + 0x5c], xmm4
4335f05d  f30f11a42410010000       movss    dword ptr [esp + 0x110], xmm4
4335f066  e820c20800               call     0x433eb28b
4335f06b  f30f10a42484000000       movss    xmm4, dword ptr [esp + 0x84]
4335f074  f30f10542460             movss    xmm2, dword ptr [esp + 0x60]
4335f07a  0f28cc                   movaps   xmm1, xmm4
4335f07d  f30f10742454             movss    xmm6, dword ptr [esp + 0x54]
4335f083  0f28c2                   movaps   xmm0, xmm2
4335f086  f30f59c2                 mulss    xmm0, xmm2
4335f08a  f30f59cc                 mulss    xmm1, xmm4
4335f08e  f30f10ac24340f0000       movss    xmm5, dword ptr [esp + 0xf34]
4335f097  f30f58c8                 addss    xmm1, xmm0
4335f09b  0f28c6                   movaps   xmm0, xmm6
4335f09e  f30f59c6                 mulss    xmm0, xmm6
4335f0a2  f30f58c8                 addss    xmm1, xmm0
4335f0a6  0f28c1                   movaps   xmm0, xmm1
4335f0a9  f30f104e04               movss    xmm1, dword ptr [esi + 4]
4335f0ae  f30f51c0                 sqrtss   xmm0, xmm0
4335f0b2  f30f118424e4030000       movss    dword ptr [esp + 0x3e4], xmm0
4335f0bb  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335f0c3  f30f5ee8                 divss    xmm5, xmm0
4335f0c7  f30f1006                 movss    xmm0, dword ptr [esi]
4335f0cb  0f28dd                   movaps   xmm3, xmm5
4335f0ce  f30f59dc                 mulss    xmm3, xmm4
4335f0d2  0f28e5                   movaps   xmm4, xmm5
4335f0d5  f30f59e2                 mulss    xmm4, xmm2
4335f0d9  f30f105608               movss    xmm2, dword ptr [esi + 8]
4335f0de  f30f59ee                 mulss    xmm5, xmm6
4335f0e2  f30f118424f0030000       movss    dword ptr [esp + 0x3f0], xmm0
4335f0eb  f30f118c24f4030000       movss    dword ptr [esp + 0x3f4], xmm1
4335f0f4  f30f119424f8030000       movss    dword ptr [esp + 0x3f8], xmm2
4335f0fd  f30f119c2400040000       movss    dword ptr [esp + 0x400], xmm3
4335f106  f30f11a42404040000       movss    dword ptr [esp + 0x404], xmm4
4335f10f  f30f59e4                 mulss    xmm4, xmm4
4335f113  33d2                     xor      edx, edx
4335f115  42                       inc      edx
4335f116  33c9                     xor      ecx, ecx
4335f118  f30f59db                 mulss    xmm3, xmm3
4335f11c  0f57c0                   xorps    xmm0, xmm0
4335f11f  898c2430040000           mov      dword ptr [esp + 0x430], ecx
4335f126  f30f11ac2408040000       movss    dword ptr [esp + 0x408], xmm5
4335f12f  f30f59ed                 mulss    xmm5, xmm5
4335f133  88942434040000           mov      byte ptr [esp + 0x434], dl
4335f13a  f30f58e3                 addss    xmm4, xmm3
4335f13e  0f29842410040000         movaps   xmmword ptr [esp + 0x410], xmm0
4335f146  0f57db                   xorps    xmm3, xmm3
4335f149  0f29842420040000         movaps   xmmword ptr [esp + 0x420], xmm0
4335f151  88942435040000           mov      byte ptr [esp + 0x435], dl
4335f158  f30f58e5                 addss    xmm4, xmm5
4335f15c  0f2ee3                   ucomiss  xmm4, xmm3
4335f15f  9f                       lahf     
4335f160  f6c444                   test     ah, 0x44
4335f163  7a07                     jp       0x4335f16c
4335f165  888c2435040000           mov      byte ptr [esp + 0x435], cl
4335f16c  f30f102514054743         movss    xmm4, dword ptr [0x43470514]
4335f174  8bf9                     mov      edi, ecx
4335f176  c7442448ffffff7f         mov      dword ptr [esp + 0x48], 0x7fffffff
4335f17e  8bc1                     mov      eax, ecx
4335f180  f30f11642420             movss    dword ptr [esp + 0x20], xmm4
4335f186  897c241c                 mov      dword ptr [esp + 0x1c], edi
4335f18a  894c2450                 mov      dword ptr [esp + 0x50], ecx
4335f18e  8b80b0494743             mov      eax, dword ptr [eax + 0x434749b0]
4335f194  3b8424e01c0000           cmp      eax, dword ptr [esp + 0x1ce0]
4335f19b  0f83c8000000             jae      0x4335f269
4335f1a1  8b7c2448                 mov      edi, dword ptr [esp + 0x48]
4335f1a5  8d8c24f01c0000           lea      ecx, [esp + 0x1cf0]
4335f1ac  69c090000000             imul     eax, eax, 0x90
4335f1b2  03c8                     add      ecx, eax
4335f1b4  894c2438                 mov      dword ptr [esp + 0x38], ecx
4335f1b8  8d7140                   lea      esi, [ecx + 0x40]
4335f1bb  8b4604                   mov      eax, dword ptr [esi + 4]
4335f1be  83e00f                   and      eax, 0xf
4335f1c1  393c8570494743           cmp      dword ptr [eax*4 + 0x43474970], edi
4335f1c8  8b7c241c                 mov      edi, dword ptr [esp + 0x1c]
4335f1cc  0f8797000000             ja       0x4335f269
4335f1d2  c78424240200000000803f   mov      dword ptr [esp + 0x224], 0x3f800000
4335f1dd  8d8424f8010000           lea      eax, [esp + 0x1f8]
4335f1e4  f30f104630               movss    xmm0, dword ptr [esi + 0x30]
4335f1e9  0f2fc3                   comiss   xmm0, xmm3
4335f1ec  50                       push     eax
4335f1ed  7610                     jbe      0x4335f1ff
4335f1ef  8bd6                     mov      edx, esi
4335f1f1  8d8c24f4030000           lea      ecx, [esp + 0x3f4]
4335f1f8  e80c9c0900               call     0x433f8e09
4335f1fd  eb13                     jmp      0x4335f212
4335f1ff  8b5104                   mov      edx, dword ptr [ecx + 4]
4335f202  8d4110                   lea      eax, [ecx + 0x10]
4335f205  50                       push     eax
4335f206  8d8c24f8030000           lea      ecx, [esp + 0x3f8]
4335f20d  e87c080400               call     0x4339fa8e
4335f212  f30f10642420             movss    xmm4, dword ptr [esp + 0x20]
4335f218  33d2                     xor      edx, edx
4335f21a  42                       inc      edx
4335f21b  85c0                     test     eax, eax
4335f21d  782e                     js       0x4335f24d
4335f21f  0f2fa42424020000         comiss   xmm4, dword ptr [esp + 0x224]
4335f227  7624                     jbe      0x4335f24d
4335f229  f30f10a42424020000       movss    xmm4, dword ptr [esp + 0x224]
4335f232  8b7c2438                 mov      edi, dword ptr [esp + 0x38]
4335f236  f30f11642420             movss    dword ptr [esp + 0x20], xmm4
4335f23c  897c241c                 mov      dword ptr [esp + 0x1c], edi
4335f240  395604                   cmp      dword ptr [esi + 4], edx
4335f243  7521                     jne      0x4335f266
4335f245  c744244802000000         mov      dword ptr [esp + 0x48], 2
4335f24d  8b442450                 mov      eax, dword ptr [esp + 0x50]
4335f251  0f57db                   xorps    xmm3, xmm3
4335f254  83c004                   add      eax, 4
4335f257  89442450                 mov      dword ptr [esp + 0x50], eax
4335f25b  83f83c                   cmp      eax, 0x3c
4335f25e  0f822affffff             jb       0x4335f18e
4335f264  eb03                     jmp      0x4335f269
4335f266  0f57db                   xorps    xmm3, xmm3
4335f269  85ff                     test     edi, edi
4335f26b  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4335f26f  0f847e130000             je       0x433605f3
4335f275  f30f108c2400040000       movss    xmm1, dword ptr [esp + 0x400]
4335f27e  f30f10842404040000       movss    xmm0, dword ptr [esp + 0x404]
4335f287  f30f10942408040000       movss    xmm2, dword ptr [esp + 0x408]
4335f290  8b44241c                 mov      eax, dword ptr [esp + 0x1c]
4335f294  f30f59cc                 mulss    xmm1, xmm4
4335f298  f30f59c4                 mulss    xmm0, xmm4
4335f29c  8b4844                   mov      ecx, dword ptr [eax + 0x44]
4335f29f  f30f588c24f0030000       addss    xmm1, dword ptr [esp + 0x3f0]
4335f2a8  f30f59d4                 mulss    xmm2, xmm4
4335f2ac  898c243c020000           mov      dword ptr [esp + 0x23c], ecx
4335f2b3  f30f588424f4030000       addss    xmm0, dword ptr [esp + 0x3f4]
4335f2bc  8b00                     mov      eax, dword ptr [eax]
4335f2be  f30f589424f8030000       addss    xmm2, dword ptr [esp + 0x3f8]
4335f2c7  89842448020000           mov      dword ptr [esp + 0x248], eax
4335f2ce  f30f118c2404020000       movss    dword ptr [esp + 0x204], xmm1
4335f2d7  f30f11842408020000       movss    dword ptr [esp + 0x208], xmm0
4335f2e0  f30f1194240c020000       movss    dword ptr [esp + 0x20c], xmm2
4335f2e9  3b4c2440                 cmp      ecx, dword ptr [esp + 0x40]
4335f2ed  0f8500130000             jne      0x433605f3
4335f2f3  8b44247c                 mov      eax, dword ptr [esp + 0x7c]
4335f2f7  23c2                     and      eax, edx
4335f2f9  89442440                 mov      dword ptr [esp + 0x40], eax
4335f2fd  0f84ff030000             je       0x4335f702
4335f303  8b4508                   mov      eax, dword ptr [ebp + 8]
4335f306  0f57ff                   xorps    xmm7, xmm7
4335f309  f30f117c2420             movss    dword ptr [esp + 0x20], xmm7
4335f30f  83b8d80000001f           cmp      dword ptr [eax + 0xd8], 0x1f
4335f316  0f842e010000             je       0x4335f44a
4335f31c  8b542434                 mov      edx, dword ptr [esp + 0x34]
4335f320  f30f5c0a                 subss    xmm1, dword ptr [edx]
4335f324  f30f5c4204               subss    xmm0, dword ptr [edx + 4]
4335f329  f30f5c5208               subss    xmm2, dword ptr [edx + 8]
4335f32e  f30f59c9                 mulss    xmm1, xmm1
4335f332  f30f59c0                 mulss    xmm0, xmm0
4335f336  f30f59d2                 mulss    xmm2, xmm2
4335f33a  f30f58c8                 addss    xmm1, xmm0
4335f33e  f30f58ca                 addss    xmm1, xmm2
4335f342  0f28c1                   movaps   xmm0, xmm1
4335f345  0f57c9                   xorps    xmm1, xmm1
4335f348  f30f51c0                 sqrtss   xmm0, xmm0
4335f34c  f30f118424e8030000       movss    dword ptr [esp + 0x3e8], xmm0
4335f355  f30f5905941d4743         mulss    xmm0, dword ptr [0x43471d94]
4335f35d  f30f5ac8                 cvtss2sd xmm1, xmm0
4335f361  f30f108424380f0000       movss    xmm0, dword ptr [esp + 0xf38]
4335f36a  0f5ac0                   cvtps2pd xmm0, xmm0
4335f36d  e85ec01a34               call     0x7750b3d0
4335f372  f30f108c24400f0000       movss    xmm1, dword ptr [esp + 0xf40]
4335f37b  ffb4243c020000           push     dword ptr [esp + 0x23c]
4335f382  8b8c2494000000           mov      ecx, dword ptr [esp + 0x94]
4335f389  0f5ac9                   cvtps2pd xmm1, xmm1
4335f38c  f20f59c1                 mulsd    xmm0, xmm1
4335f390  f20f5ac0                 cvtsd2ss xmm0, xmm0
4335f394  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
4335f39a  e8efd30900               call     0x433fc78e
4335f39f  84c0                     test     al, al
4335f3a1  741f                     je       0x4335f3c2
4335f3a3  f30f1084243c0f0000       movss    xmm0, dword ptr [esp + 0xf3c]
4335f3ac  f30f590540224743         mulss    xmm0, dword ptr [0x43472240]
4335f3b4  f30f59442420             mulss    xmm0, dword ptr [esp + 0x20]
4335f3ba  f30f11442420             movss    dword ptr [esp + 0x20], xmm0
4335f3c0  eb06                     jmp      0x4335f3c8
4335f3c2  f30f10442420             movss    xmm0, dword ptr [esp + 0x20]
4335f3c8  660f6e9fd0000000         movd     xmm3, dword ptr [edi + 0xd0]
4335f3d0  8b7708                   mov      esi, dword ptr [edi + 8]
4335f3d3  f30f2cc8                 cvttss2si ecx, xmm0
4335f3d7  0f5bdb                   cvtdq2ps xmm3, xmm3
4335f3da  85c9                     test     ecx, ecx
4335f3dc  7f07                     jg       0x4335f3e5
4335f3de  baffffff7f               mov      edx, 0x7fffffff
4335f3e3  eb12                     jmp      0x4335f3f7
4335f3e5  8d46ff                   lea      eax, [esi - 1]
4335f3e8  03c1                     add      eax, ecx
4335f3ea  99                       cdq      
4335f3eb  f7f9                     idiv     ecx
4335f3ed  33c9                     xor      ecx, ecx
4335f3ef  41                       inc      ecx
4335f3f0  3bc1                     cmp      eax, ecx
4335f3f2  8bd1                     mov      edx, ecx
4335f3f4  0f4fd0                   cmovg    edx, eax
4335f3f7  660f6ece                 movd     xmm1, esi
4335f3fb  0f28c3                   movaps   xmm0, xmm3
4335f3fe  660f6ed2                 movd     xmm2, edx
4335f402  0f5bc9                   cvtdq2ps xmm1, xmm1
4335f405  0f5bd2                   cvtdq2ps xmm2, xmm2
4335f408  f30f5eca                 divss    xmm1, xmm2
4335f40c  e82408fdff               call     0x4332fc35
4335f411  8b8c243c020000           mov      ecx, dword ptr [esp + 0x23c]
4335f418  0f28f8                   movaps   xmm7, xmm0
4335f41b  f30f10442420             movss    xmm0, dword ptr [esp + 0x20]
4335f421  0f57db                   xorps    xmm3, xmm3
4335f424  0f2ec3                   ucomiss  xmm0, xmm3
4335f427  9f                       lahf     
4335f428  33d2                     xor      edx, edx
4335f42a  f6c444                   test     ah, 0x44
4335f42d  7b06                     jnp      0x4335f435
4335f42f  f30f5ef8                 divss    xmm7, xmm0
4335f433  eb0e                     jmp      0x4335f443
4335f435  8bc1                     mov      eax, ecx
4335f437  83e00f                   and      eax, 0xf
4335f43a  f30f103c8540454743       movss    xmm7, dword ptr [eax*4 + 0x43474540]
4335f443  42                       inc      edx
4335f444  f30f117c2420             movss    dword ptr [esp + 0x20], xmm7
4335f44a  f30f10ac24340f0000       movss    xmm5, dword ptr [esp + 0xf34]
4335f453  8b442434                 mov      eax, dword ptr [esp + 0x34]
4335f457  0f28f5                   movaps   xmm6, xmm5
4335f45a  f30f59b42484000000       mulss    xmm6, dword ptr [esp + 0x84]
4335f463  0f28e5                   movaps   xmm4, xmm5
4335f466  f30f59642460             mulss    xmm4, dword ptr [esp + 0x60]
4335f46c  f30f596c2454             mulss    xmm5, dword ptr [esp + 0x54]
4335f472  3bca                     cmp      ecx, edx
4335f474  0f84dd000000             je       0x4335f557
4335f47a  8bf0                     mov      esi, eax
4335f47c  8dbc248c070000           lea      edi, [esp + 0x78c]
4335f483  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335f484  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335f485  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335f486  f30f104004               movss    xmm0, dword ptr [eax + 4]
4335f48b  8dbc24a0270000           lea      edi, [esp + 0x27a0]
4335f492  f30f104808               movss    xmm1, dword ptr [eax + 8]
4335f497  f30f58e0                 addss    xmm4, xmm0
4335f49b  f30f5830                 addss    xmm6, dword ptr [eax]
4335f49f  f30f58e9                 addss    xmm5, xmm1
4335f4a3  33c0                     xor      eax, eax
4335f4a5  89442450                 mov      dword ptr [esp + 0x50], eax
4335f4a9  f30f11a4249c070000       movss    dword ptr [esp + 0x79c], xmm4
4335f4b2  f30f11b42498070000       movss    dword ptr [esp + 0x798], xmm6
4335f4bb  f30f11ac24a0070000       movss    dword ptr [esp + 0x7a0], xmm5
4335f4c4  8bc8                     mov      ecx, eax
4335f4c6  894c2448                 mov      dword ptr [esp + 0x48], ecx
4335f4ca  3907                     cmp      dword ptr [edi], eax
4335f4cc  0f861d110000             jbe      0x433605ef
4335f4d2  8db780000000             lea      esi, [edi + 0x80]
4335f4d8  f30f1006                 movss    xmm0, dword ptr [esi]
4335f4dc  0f2fc3                   comiss   xmm0, xmm3
4335f4df  7633                     jbe      0x4335f514
4335f4e1  8b46d4                   mov      eax, dword ptr [esi - 0x2c]
4335f4e4  83e00f                   and      eax, 0xf
4335f4e7  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
4335f4f0  0f2fc7                   comiss   xmm0, xmm7
4335f4f3  721f                     jb       0x4335f514
4335f4f5  8d4ed8                   lea      ecx, [esi - 0x28]
4335f4f8  8d94248c070000           lea      edx, [esp + 0x78c]
4335f4ff  e8ded60300               call     0x4339cbe2
4335f504  f30f100e                 movss    xmm1, dword ptr [esi]
4335f508  0f2fc8                   comiss   xmm1, xmm0
4335f50b  7322                     jae      0x4335f52f
4335f50d  8b4c2448                 mov      ecx, dword ptr [esp + 0x48]
4335f511  0f57db                   xorps    xmm3, xmm3
4335f514  41                       inc      ecx
4335f515  81c690000000             add      esi, 0x90
4335f51b  894c2448                 mov      dword ptr [esp + 0x48], ecx
4335f51f  3b0f                     cmp      ecx, dword ptr [edi]
4335f521  0f83c8100000             jae      0x433605ef
4335f527  f30f107c2420             movss    xmm7, dword ptr [esp + 0x20]
4335f52d  eba9                     jmp      0x4335f4d8
4335f52f  8b542450                 mov      edx, dword ptr [esp + 0x50]
4335f533  81c7c00a0000             add      edi, 0xac0
4335f539  42                       inc      edx
4335f53a  89542450                 mov      dword ptr [esp + 0x50], edx
4335f53e  83fa03                   cmp      edx, 3
4335f541  0f8db0010000             jge      0x4335f6f7
4335f547  f30f107c2420             movss    xmm7, dword ptr [esp + 0x20]
4335f54d  0f57db                   xorps    xmm3, xmm3
4335f550  33c0                     xor      eax, eax
4335f552  e96dffffff               jmp      0x4335f4c4
4335f557  f30f1000                 movss    xmm0, dword ptr [eax]
4335f55b  33c9                     xor      ecx, ecx
4335f55d  f30f104804               movss    xmm1, dword ptr [eax + 4]
4335f562  f30f105008               movss    xmm2, dword ptr [eax + 8]
4335f567  f30f11a424940a0000       movss    dword ptr [esp + 0xa94], xmm4
4335f570  f30f11b424900a0000       movss    dword ptr [esp + 0xa90], xmm6
4335f579  f30f59e4                 mulss    xmm4, xmm4
4335f57d  898c24c00a0000           mov      dword ptr [esp + 0xac0], ecx
4335f584  f30f59f6                 mulss    xmm6, xmm6
4335f588  889424c40a0000           mov      byte ptr [esp + 0xac4], dl
4335f58f  f30f11ac24980a0000       movss    dword ptr [esp + 0xa98], xmm5
4335f598  f30f59ed                 mulss    xmm5, xmm5
4335f59c  889424c50a0000           mov      byte ptr [esp + 0xac5], dl
4335f5a3  f30f58e6                 addss    xmm4, xmm6
4335f5a7  f30f118424800a0000       movss    dword ptr [esp + 0xa80], xmm0
4335f5b0  0f57c0                   xorps    xmm0, xmm0
4335f5b3  f30f118c24840a0000       movss    dword ptr [esp + 0xa84], xmm1
4335f5bc  f30f119424880a0000       movss    dword ptr [esp + 0xa88], xmm2
4335f5c5  0f298424a00a0000         movaps   xmmword ptr [esp + 0xaa0], xmm0
4335f5cd  0f298424b00a0000         movaps   xmmword ptr [esp + 0xab0], xmm0
4335f5d5  f30f58e5                 addss    xmm4, xmm5
4335f5d9  0f2ee3                   ucomiss  xmm4, xmm3
4335f5dc  9f                       lahf     
4335f5dd  f6c444                   test     ah, 0x44
4335f5e0  7a07                     jp       0x4335f5e9
4335f5e2  888c24c50a0000           mov      byte ptr [esp + 0xac5], cl
4335f5e9  894c2448                 mov      dword ptr [esp + 0x48], ecx
4335f5ed  8db424b4270000           lea      esi, [esp + 0x27b4]
4335f5f4  838c24dc0c0000ff         or       dword ptr [esp + 0xcdc], 0xffffffff
4335f5fc  8d8424980c0000           lea      eax, [esp + 0xc98]
4335f603  838c24e80c0000ff         or       dword ptr [esp + 0xce8], 0xffffffff
4335f60b  50                       push     eax
4335f60c  898c24e80c0000           mov      dword ptr [esp + 0xce8], ecx
4335f613  8d460c                   lea      eax, [esi + 0xc]
4335f616  c78424c80c00000000803f   mov      dword ptr [esp + 0xcc8], 0x3f800000
4335f621  8d8c24840a0000           lea      ecx, [esp + 0xa84]
4335f628  66c78424d20c00000000     mov      word ptr [esp + 0xcd2], 0
4335f632  8b16                     mov      edx, dword ptr [esi]
4335f634  50                       push     eax
4335f635  e854040400               call     0x4339fa8e
4335f63a  85c0                     test     eax, eax
4335f63c  0f88b10f0000             js       0x433605f3
4335f642  f30f108424c40c0000       movss    xmm0, dword ptr [esp + 0xcc4]
4335f64b  33c9                     xor      ecx, ecx
4335f64d  8bc1                     mov      eax, ecx
4335f64f  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
4335f655  89442420                 mov      dword ptr [esp + 0x20], eax
4335f659  394eec                   cmp      dword ptr [esi - 0x14], ecx
4335f65c  767f                     jbe      0x4335f6dd
4335f65e  8bce                     mov      ecx, esi
4335f660  0f57c9                   xorps    xmm1, xmm1
4335f663  894c241c                 mov      dword ptr [esp + 0x1c], ecx
4335f667  8b11                     mov      edx, dword ptr [ecx]
4335f669  f30f104230               movss    xmm0, dword ptr [edx + 0x30]
4335f66e  0f2fc1                   comiss   xmm0, xmm1
4335f671  7654                     jbe      0x4335f6c7
4335f673  837a0403                 cmp      dword ptr [edx + 4], 3
4335f677  7406                     je       0x4335f67f
4335f679  837a0402                 cmp      dword ptr [edx + 4], 2
4335f67d  7548                     jne      0x4335f6c7
4335f67f  8d8424980c0000           lea      eax, [esp + 0xc98]
4335f686  c78424c40c00000000803f   mov      dword ptr [esp + 0xcc4], 0x3f800000
4335f691  8b11                     mov      edx, dword ptr [ecx]
4335f693  50                       push     eax
4335f694  8d410c                   lea      eax, [ecx + 0xc]
4335f697  50                       push     eax
4335f698  8d8c24880a0000           lea      ecx, [esp + 0xa88]
4335f69f  e8ea030400               call     0x4339fa8e
4335f6a4  85c0                     test     eax, eax
4335f6a6  7814                     js       0x4335f6bc
4335f6a8  f30f10442438             movss    xmm0, dword ptr [esp + 0x38]
4335f6ae  0f2f8424c40c0000         comiss   xmm0, dword ptr [esp + 0xcc4]
4335f6b6  0f87370f0000             ja       0x433605f3
4335f6bc  8b442420                 mov      eax, dword ptr [esp + 0x20]
4335f6c0  0f57c9                   xorps    xmm1, xmm1
4335f6c3  8b4c241c                 mov      ecx, dword ptr [esp + 0x1c]
4335f6c7  40                       inc      eax
4335f6c8  81c190000000             add      ecx, 0x90
4335f6ce  89442420                 mov      dword ptr [esp + 0x20], eax
4335f6d2  894c241c                 mov      dword ptr [esp + 0x1c], ecx
4335f6d6  3b46ec                   cmp      eax, dword ptr [esi - 0x14]
4335f6d9  728c                     jb       0x4335f667
4335f6db  33c9                     xor      ecx, ecx
4335f6dd  8b442448                 mov      eax, dword ptr [esp + 0x48]
4335f6e1  81c6c00a0000             add      esi, 0xac0
4335f6e7  40                       inc      eax
4335f6e8  89442448                 mov      dword ptr [esp + 0x48], eax
4335f6ec  83f803                   cmp      eax, 3
4335f6ef  0f8cfffeffff             jl       0x4335f5f4
4335f6f5  eb04                     jmp      0x4335f6fb
4335f6f7  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4335f6fb  8b8c243c020000           mov      ecx, dword ptr [esp + 0x23c]
4335f702  660f6e8fd0000000         movd     xmm1, dword ptr [edi + 0xd0]
4335f70a  83e10f                   and      ecx, 0xf
4335f70d  0f5bc9                   cvtdq2ps xmm1, xmm1
4335f710  33c0                     xor      eax, eax
4335f712  8b542434                 mov      edx, dword ptr [esp + 0x34]
4335f716  89842420080000           mov      dword ptr [esp + 0x820], eax
4335f71d  89842424080000           mov      dword ptr [esp + 0x824], eax
4335f724  89842428080000           mov      dword ptr [esp + 0x828], eax
4335f72b  8d8424200f0000           lea      eax, [esp + 0xf20]
4335f732  0f280590f24643           movaps   xmm0, xmmword ptr [0x4346f290]
4335f739  f30f5e0c8d40454743       divss    xmm1, dword ptr [ecx*4 + 0x43474540]
4335f742  8b0d08584743             mov      ecx, dword ptr [0x43475808]
4335f748  50                       push     eax
4335f749  8d842420080000           lea      eax, [esp + 0x820]
4335f750  c784242008000004044743   mov      dword ptr [esp + 0x820], 0x43470404
4335f75b  50                       push     eax
4335f75c  8d84240c020000           lea      eax, [esp + 0x20c]
4335f763  50                       push     eax
4335f764  0f11842438080000         movups   xmmword ptr [esp + 0x838], xmm0
4335f76c  f30f118c2448080000       movss    dword ptr [esp + 0x848], xmm1
4335f775  e8b1a5fcff               call     0x43329d2b
4335f77a  f30f2c8424280f0000       cvttss2si eax, dword ptr [esp + 0xf28]
4335f783  85c0                     test     eax, eax
4335f785  0f8e680e0000             jle      0x433605f3
4335f78b  ffb4243c020000           push     dword ptr [esp + 0x23c]
4335f792  8d8c24240f0000           lea      ecx, [esp + 0xf24]
4335f799  ffb42494000000           push     dword ptr [esp + 0x94]
4335f7a0  e828a70800               call     0x433e9ecd
4335f7a5  8b742444                 mov      esi, dword ptr [esp + 0x44]
4335f7a9  8dbc2448010000           lea      edi, [esp + 0x148]
4335f7b0  33c9                     xor      ecx, ecx
4335f7b2  41                       inc      ecx
4335f7b3  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335f7b4  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335f7b5  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335f7b6  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4335f7ba  8bb42480000000           mov      esi, dword ptr [esp + 0x80]
4335f7c1  89842464010000           mov      dword ptr [esp + 0x164], eax
4335f7c8  8b842448020000           mov      eax, dword ptr [esp + 0x248]
4335f7cf  89842468010000           mov      dword ptr [esp + 0x168], eax
4335f7d6  8b84243c020000           mov      eax, dword ptr [esp + 0x23c]
4335f7dd  8984246c010000           mov      dword ptr [esp + 0x16c], eax
4335f7e4  8b44247c                 mov      eax, dword ptr [esp + 0x7c]
4335f7e8  89842470010000           mov      dword ptr [esp + 0x170], eax
4335f7ef  8b8424240f0000           mov      eax, dword ptr [esp + 0xf24]
4335f7f6  d1e8                     shr      eax, 1
4335f7f8  c78424740100000000803f   mov      dword ptr [esp + 0x174], 0x3f800000
4335f803  84c1                     test     cl, al
4335f805  7424                     je       0x4335f82b
4335f807  8b5704                   mov      edx, dword ptr [edi + 4]
4335f80a  83e23f                   and      edx, 0x3f
4335f80d  8bca                     mov      ecx, edx
4335f80f  c1e905                   shr      ecx, 5
4335f812  6a1f                     push     0x1f
4335f814  58                       pop      eax
4335f815  23d0                     and      edx, eax
4335f817  8b848eac010000           mov      eax, dword ptr [esi + ecx*4 + 0x1ac]
4335f81e  0fabd0                   bts      eax, edx
4335f821  89848eac010000           mov      dword ptr [esi + ecx*4 + 0x1ac], eax
4335f828  33c9                     xor      ecx, ecx
4335f82a  41                       inc      ecx
4335f82b  ff87e8000000             inc      dword ptr [edi + 0xe8]
4335f831  f6867801000010           test     byte ptr [esi + 0x178], 0x10
4335f838  8bb42464010000           mov      esi, dword ptr [esp + 0x164]
4335f83f  0f846e0c0000             je       0x433604b3
4335f845  3bb7d0000000             cmp      esi, dword ptr [edi + 0xd0]
4335f84b  0f8c620c0000             jl       0x433604b3
4335f851  8b4508                   mov      eax, dword ptr [ebp + 8]
4335f854  83b8d80000001f           cmp      dword ptr [eax + 0xd8], 0x1f
4335f85b  750e                     jne      0x4335f86b
4335f85d  0f57ed                   xorps    xmm5, xmm5
4335f860  f30f116c2420             movss    dword ptr [esp + 0x20], xmm5
4335f866  e98f000000               jmp      0x4335f8fa
4335f86b  8b4708                   mov      eax, dword ptr [edi + 8]
4335f86e  85f6                     test     esi, esi
4335f870  7f07                     jg       0x4335f879
4335f872  baffffff7f               mov      edx, 0x7fffffff
4335f877  eb0d                     jmp      0x4335f886
4335f879  48                       dec      eax
4335f87a  03c6                     add      eax, esi
4335f87c  99                       cdq      
4335f87d  f7fe                     idiv     esi
4335f87f  8bd1                     mov      edx, ecx
4335f881  3bc1                     cmp      eax, ecx
4335f883  0f4fd0                   cmovg    edx, eax
4335f886  8b84246c010000           mov      eax, dword ptr [esp + 0x16c]
4335f88d  660f6ec6                 movd     xmm0, esi
4335f891  83e00f                   and      eax, 0xf
4335f894  0f5bc0                   cvtdq2ps xmm0, xmm0
4335f897  660f6e4f08               movd     xmm1, dword ptr [edi + 8]
4335f89c  f30f5e048540454743       divss    xmm0, dword ptr [eax*4 + 0x43474540]
4335f8a5  0f5bc9                   cvtdq2ps xmm1, xmm1
4335f8a8  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
4335f8ae  660f6ec2                 movd     xmm0, edx
4335f8b2  0f5bc0                   cvtdq2ps xmm0, xmm0
4335f8b5  f30f5ec8                 divss    xmm1, xmm0
4335f8b9  660f6e87d0000000         movd     xmm0, dword ptr [edi + 0xd0]
4335f8c1  0f5bc0                   cvtdq2ps xmm0, xmm0
4335f8c4  e86c03fdff               call     0x4332fc35
4335f8c9  f30f104c2438             movss    xmm1, dword ptr [esp + 0x38]
4335f8cf  0f57ed                   xorps    xmm5, xmm5
4335f8d2  0f2ecd                   ucomiss  xmm1, xmm5
4335f8d5  9f                       lahf     
4335f8d6  f6c444                   test     ah, 0x44
4335f8d9  7b06                     jnp      0x4335f8e1
4335f8db  f30f5ec1                 divss    xmm0, xmm1
4335f8df  eb13                     jmp      0x4335f8f4
4335f8e1  8b84246c010000           mov      eax, dword ptr [esp + 0x16c]
4335f8e8  83e00f                   and      eax, 0xf
4335f8eb  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
4335f8f4  f30f11442420             movss    dword ptr [esp + 0x20], xmm0
4335f8fa  837c244000               cmp      dword ptr [esp + 0x40], 0
4335f8ff  f30f108424340f0000       movss    xmm0, dword ptr [esp + 0xf34]
4335f908  0f84ab050000             je       0x4335feb9
4335f90e  f30f108c2484000000       movss    xmm1, dword ptr [esp + 0x84]
4335f917  33c9                     xor      ecx, ecx
4335f919  8bb4243c020000           mov      esi, dword ptr [esp + 0x23c]
4335f920  0f2ecd                   ucomiss  xmm1, xmm5
4335f923  89b424a0000000           mov      dword ptr [esp + 0xa0], esi
4335f92a  894c247c                 mov      dword ptr [esp + 0x7c], ecx
4335f92e  f30f118424a4000000       movss    dword ptr [esp + 0xa4], xmm0
4335f937  f30f10442460             movss    xmm0, dword ptr [esp + 0x60]
4335f93d  9f                       lahf     
4335f93e  f6c444                   test     ah, 0x44
4335f941  7a5d                     jp       0x4335f9a0
4335f943  0f2ec5                   ucomiss  xmm0, xmm5
4335f946  9f                       lahf     
4335f947  f6c444                   test     ah, 0x44
4335f94a  7a54                     jp       0x4335f9a0
4335f94c  f30f10942488000000       movss    xmm2, dword ptr [esp + 0x88]
4335f955  0f57ff                   xorps    xmm7, xmm7
4335f958  f30f10442454             movss    xmm0, dword ptr [esp + 0x54]
4335f95e  0f57f6                   xorps    xmm6, xmm6
4335f961  0f5705d0034743           xorps    xmm0, xmmword ptr [0x434703d0]
4335f968  0f57e4                   xorps    xmm4, xmm4
4335f96b  f30f117c2440             movss    dword ptr [esp + 0x40], xmm7
4335f971  0f57c9                   xorps    xmm1, xmm1
4335f974  f30f11bc24f4000000       movss    dword ptr [esp + 0xf4], xmm7
4335f97d  f30f11542418             movss    dword ptr [esp + 0x18], xmm2
4335f983  f30f119424f8000000       movss    dword ptr [esp + 0xf8], xmm2
4335f98c  f30f1174242c             movss    dword ptr [esp + 0x2c], xmm6
4335f992  f30f11b424fc000000       movss    dword ptr [esp + 0xfc], xmm6
4335f99b  e948010000               jmp      0x4335fae8
4335f9a0  f30f10642454             movss    xmm4, dword ptr [esp + 0x54]
4335f9a6  0f28d0                   movaps   xmm2, xmm0
4335f9a9  f30f59c5                 mulss    xmm0, xmm5
4335f9ad  0f28d9                   movaps   xmm3, xmm1
4335f9b0  f30f59e5                 mulss    xmm4, xmm5
4335f9b4  f30f59dd                 mulss    xmm3, xmm5
4335f9b8  f30f5cd4                 subss    xmm2, xmm4
4335f9bc  f30f103514054743         movss    xmm6, dword ptr [0x43470514]
4335f9c4  f30f5ce1                 subss    xmm4, xmm1
4335f9c8  f30f5cd8                 subss    xmm3, xmm0
4335f9cc  0f28ca                   movaps   xmm1, xmm2
4335f9cf  f30f59ca                 mulss    xmm1, xmm2
4335f9d3  0f28c4                   movaps   xmm0, xmm4
4335f9d6  f30f59c4                 mulss    xmm0, xmm4
4335f9da  f30f58c8                 addss    xmm1, xmm0
4335f9de  0f28c3                   movaps   xmm0, xmm3
4335f9e1  f30f59c3                 mulss    xmm0, xmm3
4335f9e5  f30f58c8                 addss    xmm1, xmm0
4335f9e9  0f28c1                   movaps   xmm0, xmm1
4335f9ec  f30f51c0                 sqrtss   xmm0, xmm0
4335f9f0  f30f118424ec030000       movss    dword ptr [esp + 0x3ec], xmm0
4335f9f9  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335fa01  f30f5ef0                 divss    xmm6, xmm0
4335fa05  0f28ce                   movaps   xmm1, xmm6
4335fa08  0f28fe                   movaps   xmm7, xmm6
4335fa0b  f30f59cc                 mulss    xmm1, xmm4
4335fa0f  f30f10642454             movss    xmm4, dword ptr [esp + 0x54]
4335fa15  f30f59fa                 mulss    xmm7, xmm2
4335fa19  f30f10542460             movss    xmm2, dword ptr [esp + 0x60]
4335fa1f  f30f59f3                 mulss    xmm6, xmm3
4335fa23  0f28c2                   movaps   xmm0, xmm2
4335fa26  f30f109c2484000000       movss    xmm3, dword ptr [esp + 0x84]
4335fa2f  f30f59e1                 mulss    xmm4, xmm1
4335fa33  f30f59c6                 mulss    xmm0, xmm6
4335fa37  f30f59de                 mulss    xmm3, xmm6
4335fa3b  f30f5ce0                 subss    xmm4, xmm0
4335fa3f  f30f114c2418             movss    dword ptr [esp + 0x18], xmm1
4335fa45  f30f10442454             movss    xmm0, dword ptr [esp + 0x54]
4335fa4b  f30f59c7                 mulss    xmm0, xmm7
4335fa4f  f30f59d7                 mulss    xmm2, xmm7
4335fa53  f30f5cd8                 subss    xmm3, xmm0
4335fa57  f30f118c24f8000000       movss    dword ptr [esp + 0xf8], xmm1
4335fa60  f30f10842484000000       movss    xmm0, dword ptr [esp + 0x84]
4335fa69  f30f59c1                 mulss    xmm0, xmm1
4335fa6d  0f28cc                   movaps   xmm1, xmm4
4335fa70  f30f59cc                 mulss    xmm1, xmm4
4335fa74  f30f5cd0                 subss    xmm2, xmm0
4335fa78  f30f117c2440             movss    dword ptr [esp + 0x40], xmm7
4335fa7e  0f28c3                   movaps   xmm0, xmm3
4335fa81  f30f11bc24f4000000       movss    dword ptr [esp + 0xf4], xmm7
4335fa8a  f30f59c3                 mulss    xmm0, xmm3
4335fa8e  f30f1174242c             movss    dword ptr [esp + 0x2c], xmm6
4335fa94  f30f11b424fc000000       movss    dword ptr [esp + 0xfc], xmm6
4335fa9d  f30f58c8                 addss    xmm1, xmm0
4335faa1  0f28c2                   movaps   xmm0, xmm2
4335faa4  f30f59c2                 mulss    xmm0, xmm2
4335faa8  f30f58c8                 addss    xmm1, xmm0
4335faac  0f28c1                   movaps   xmm0, xmm1
4335faaf  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335fab7  f30f51c0                 sqrtss   xmm0, xmm0
4335fabb  f30f11842474060000       movss    dword ptr [esp + 0x674], xmm0
4335fac4  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335facc  f30f5ec8                 divss    xmm1, xmm0
4335fad0  0f28c1                   movaps   xmm0, xmm1
4335fad3  f30f59c4                 mulss    xmm0, xmm4
4335fad7  0f28e1                   movaps   xmm4, xmm1
4335fada  f30f59ca                 mulss    xmm1, xmm2
4335fade  f30f10542418             movss    xmm2, dword ptr [esp + 0x18]
4335fae4  f30f59e3                 mulss    xmm4, xmm3
4335fae8  8b842480000000           mov      eax, dword ptr [esp + 0x80]
4335faef  051c110000               add      eax, 0x111c
4335faf4  f30f118c24f0000000       movss    dword ptr [esp + 0xf0], xmm1
4335fafd  f30f114c2458             movss    dword ptr [esp + 0x58], xmm1
4335fb03  f30f11a424ec000000       movss    dword ptr [esp + 0xec], xmm4
4335fb0c  f30f11642438             movss    dword ptr [esp + 0x38], xmm4
4335fb12  f30f118424e8000000       movss    dword ptr [esp + 0xe8], xmm0
4335fb1b  f30f1184248c000000       movss    dword ptr [esp + 0x8c], xmm0
4335fb24  89442478                 mov      dword ptr [esp + 0x78], eax
4335fb28  c744246420000000         mov      dword ptr [esp + 0x64], 0x20
4335fb30  eb03                     jmp      0x4335fb35
4335fb32  0f57ed                   xorps    xmm5, xmm5
4335fb35  f30f594004               mulss    xmm0, dword ptr [eax + 4]
4335fb3a  0f28df                   movaps   xmm3, xmm7
4335fb3d  f30f5918                 mulss    xmm3, dword ptr [eax]
4335fb41  f30f5910                 mulss    xmm2, dword ptr [eax]
4335fb45  f30f589c2484000000       addss    xmm3, dword ptr [esp + 0x84]
4335fb4e  f30f58542460             addss    xmm2, dword ptr [esp + 0x60]
4335fb54  f30f58d8                 addss    xmm3, xmm0
4335fb58  0f28c4                   movaps   xmm0, xmm4
4335fb5b  f30f594004               mulss    xmm0, dword ptr [eax + 4]
4335fb60  0f28e6                   movaps   xmm4, xmm6
4335fb63  f30f5920                 mulss    xmm4, dword ptr [eax]
4335fb67  f30f58d0                 addss    xmm2, xmm0
4335fb6b  0f28c1                   movaps   xmm0, xmm1
4335fb6e  f30f594004               mulss    xmm0, dword ptr [eax + 4]
4335fb73  0f28cb                   movaps   xmm1, xmm3
4335fb76  8b442434                 mov      eax, dword ptr [esp + 0x34]
4335fb7a  f30f59cb                 mulss    xmm1, xmm3
4335fb7e  f30f58642454             addss    xmm4, dword ptr [esp + 0x54]
4335fb84  f30f58e0                 addss    xmm4, xmm0
4335fb88  0f28c2                   movaps   xmm0, xmm2
4335fb8b  f30f59c2                 mulss    xmm0, xmm2
4335fb8f  f30f58c8                 addss    xmm1, xmm0
4335fb93  0f28c4                   movaps   xmm0, xmm4
4335fb96  f30f59c4                 mulss    xmm0, xmm4
4335fb9a  f30f58c8                 addss    xmm1, xmm0
4335fb9e  0f28c1                   movaps   xmm0, xmm1
4335fba1  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335fba9  f30f51c0                 sqrtss   xmm0, xmm0
4335fbad  f30f11842478060000       movss    dword ptr [esp + 0x678], xmm0
4335fbb6  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335fbbe  f30f5ec8                 divss    xmm1, xmm0
4335fbc2  f30f108424a4000000       movss    xmm0, dword ptr [esp + 0xa4]
4335fbcb  f30f59e1                 mulss    xmm4, xmm1
4335fbcf  0f28f1                   movaps   xmm6, xmm1
4335fbd2  f30f59f3                 mulss    xmm6, xmm3
4335fbd6  0f28d9                   movaps   xmm3, xmm1
4335fbd9  f30f59da                 mulss    xmm3, xmm2
4335fbdd  f30f59e0                 mulss    xmm4, xmm0
4335fbe1  f30f59f0                 mulss    xmm6, xmm0
4335fbe5  f30f59d8                 mulss    xmm3, xmm0
4335fbe9  83fe01                   cmp      esi, 1
4335fbec  0f842a010000             je       0x4335fd1c
4335fbf2  8bf0                     mov      esi, eax
4335fbf4  894c2450                 mov      dword ptr [esp + 0x50], ecx
4335fbf8  8dbc24bc070000           lea      edi, [esp + 0x7bc]
4335fbff  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335fc00  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335fc01  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4335fc02  f30f104004               movss    xmm0, dword ptr [eax + 4]
4335fc07  8dbc24a0270000           lea      edi, [esp + 0x27a0]
4335fc0e  f30f104808               movss    xmm1, dword ptr [eax + 8]
4335fc13  f30f58c3                 addss    xmm0, xmm3
4335fc17  f30f5830                 addss    xmm6, dword ptr [eax]
4335fc1b  f30f58cc                 addss    xmm1, xmm4
4335fc1f  f30f118424cc070000       movss    dword ptr [esp + 0x7cc], xmm0
4335fc28  f30f11b424c8070000       movss    dword ptr [esp + 0x7c8], xmm6
4335fc31  f30f118c24d0070000       movss    dword ptr [esp + 0x7d0], xmm1
4335fc3a  8bd1                     mov      edx, ecx
4335fc3c  89542448                 mov      dword ptr [esp + 0x48], edx
4335fc40  390f                     cmp      dword ptr [edi], ecx
4335fc42  7655                     jbe      0x4335fc99
4335fc44  8db780000000             lea      esi, [edi + 0x80]
4335fc4a  f30f1006                 movss    xmm0, dword ptr [esi]
4335fc4e  0f2fc5                   comiss   xmm0, xmm5
4335fc51  7635                     jbe      0x4335fc88
4335fc53  8b46d4                   mov      eax, dword ptr [esi - 0x2c]
4335fc56  83e00f                   and      eax, 0xf
4335fc59  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
4335fc62  0f2f442420               comiss   xmm0, dword ptr [esp + 0x20]
4335fc67  721f                     jb       0x4335fc88
4335fc69  8d4ed8                   lea      ecx, [esi - 0x28]
4335fc6c  8d9424bc070000           lea      edx, [esp + 0x7bc]
4335fc73  e86acf0300               call     0x4339cbe2
4335fc78  f30f100e                 movss    xmm1, dword ptr [esi]
4335fc7c  0f2fc8                   comiss   xmm1, xmm0
4335fc7f  7379                     jae      0x4335fcfa
4335fc81  8b542448                 mov      edx, dword ptr [esp + 0x48]
4335fc85  0f57ed                   xorps    xmm5, xmm5
4335fc88  42                       inc      edx
4335fc89  81c690000000             add      esi, 0x90
4335fc8f  89542448                 mov      dword ptr [esp + 0x48], edx
4335fc93  3b17                     cmp      edx, dword ptr [edi]
4335fc95  72b3                     jb       0x4335fc4a
4335fc97  33c9                     xor      ecx, ecx
4335fc99  8ad1                     mov      dl, cl
4335fc9b  8b74247c                 mov      esi, dword ptr [esp + 0x7c]
4335fc9f  84d2                     test     dl, dl
4335fca1  f30f1084248c000000       movss    xmm0, dword ptr [esp + 0x8c]
4335fcaa  f30f1074242c             movss    xmm6, dword ptr [esp + 0x2c]
4335fcb0  f30f104c2458             movss    xmm1, dword ptr [esp + 0x58]
4335fcb6  f30f107c2440             movss    xmm7, dword ptr [esp + 0x40]
4335fcbc  8d4601                   lea      eax, [esi + 1]
4335fcbf  f30f10542418             movss    xmm2, dword ptr [esp + 0x18]
4335fcc5  0f44c6                   cmove    eax, esi
4335fcc8  f30f10642438             movss    xmm4, dword ptr [esp + 0x38]
4335fcce  8bd0                     mov      edx, eax
4335fcd0  8b442478                 mov      eax, dword ptr [esp + 0x78]
4335fcd4  8bb424a0000000           mov      esi, dword ptr [esp + 0xa0]
4335fcdb  83c020                   add      eax, 0x20
4335fcde  836c246401               sub      dword ptr [esp + 0x64], 1
4335fce3  8954247c                 mov      dword ptr [esp + 0x7c], edx
4335fce7  89442478                 mov      dword ptr [esp + 0x78], eax
4335fceb  0f8541feffff             jne      0x4335fb32
4335fcf1  660f6ec2                 movd     xmm0, edx
4335fcf5  e99e070000               jmp      0x43360498
4335fcfa  8b442450                 mov      eax, dword ptr [esp + 0x50]
4335fcfe  81c7c00a0000             add      edi, 0xac0
4335fd04  40                       inc      eax
4335fd05  89442450                 mov      dword ptr [esp + 0x50], eax
4335fd09  83f803                   cmp      eax, 3
4335fd0c  0f8d9e010000             jge      0x4335feb0
4335fd12  0f57ed                   xorps    xmm5, xmm5
4335fd15  33c9                     xor      ecx, ecx
4335fd17  e91effffff               jmp      0x4335fc3a
4335fd1c  f30f1000                 movss    xmm0, dword ptr [eax]
4335fd20  f30f104804               movss    xmm1, dword ptr [eax + 4]
4335fd25  f30f105008               movss    xmm2, dword ptr [eax + 8]
4335fd2a  f30f119c24e40a0000       movss    dword ptr [esp + 0xae4], xmm3
4335fd33  f30f11b424e00a0000       movss    dword ptr [esp + 0xae0], xmm6
4335fd3c  f30f59db                 mulss    xmm3, xmm3
4335fd40  898c24100b0000           mov      dword ptr [esp + 0xb10], ecx
4335fd47  f30f59f6                 mulss    xmm6, xmm6
4335fd4b  c68424140b000001         mov      byte ptr [esp + 0xb14], 1
4335fd53  f30f11a424e80a0000       movss    dword ptr [esp + 0xae8], xmm4
4335fd5c  f30f59e4                 mulss    xmm4, xmm4
4335fd60  c68424150b000001         mov      byte ptr [esp + 0xb15], 1
4335fd68  f30f58de                 addss    xmm3, xmm6
4335fd6c  f30f118424d00a0000       movss    dword ptr [esp + 0xad0], xmm0
4335fd75  0f57c0                   xorps    xmm0, xmm0
4335fd78  f30f118c24d40a0000       movss    dword ptr [esp + 0xad4], xmm1
4335fd81  f30f119424d80a0000       movss    dword ptr [esp + 0xad8], xmm2
4335fd8a  0f298424f00a0000         movaps   xmmword ptr [esp + 0xaf0], xmm0
4335fd92  0f298424000b0000         movaps   xmmword ptr [esp + 0xb00], xmm0
4335fd9a  f30f58dc                 addss    xmm3, xmm4
4335fd9e  0f2edd                   ucomiss  xmm3, xmm5
4335fda1  9f                       lahf     
4335fda2  f6c444                   test     ah, 0x44
4335fda5  7a07                     jp       0x4335fdae
4335fda7  888c24150b0000           mov      byte ptr [esp + 0xb15], cl
4335fdae  8bf9                     mov      edi, ecx
4335fdb0  8db424b4270000           lea      esi, [esp + 0x27b4]
4335fdb7  897c2448                 mov      dword ptr [esp + 0x48], edi
4335fdbb  838c24340d0000ff         or       dword ptr [esp + 0xd34], 0xffffffff
4335fdc3  8d8424f00c0000           lea      eax, [esp + 0xcf0]
4335fdca  838c24400d0000ff         or       dword ptr [esp + 0xd40], 0xffffffff
4335fdd2  50                       push     eax
4335fdd3  898c24400d0000           mov      dword ptr [esp + 0xd40], ecx
4335fdda  8d460c                   lea      eax, [esi + 0xc]
4335fddd  c78424200d00000000803f   mov      dword ptr [esp + 0xd20], 0x3f800000
4335fde8  8d8c24d40a0000           lea      ecx, [esp + 0xad4]
4335fdef  66c784242a0d00000000     mov      word ptr [esp + 0xd2a], 0
4335fdf9  8b16                     mov      edx, dword ptr [esi]
4335fdfb  50                       push     eax
4335fdfc  e88dfc0300               call     0x4339fa8e
4335fe01  85c0                     test     eax, eax
4335fe03  0f888efeffff             js       0x4335fc97
4335fe09  f30f1084241c0d0000       movss    xmm0, dword ptr [esp + 0xd1c]
4335fe12  33c9                     xor      ecx, ecx
4335fe14  8bc1                     mov      eax, ecx
4335fe16  f30f11442450             movss    dword ptr [esp + 0x50], xmm0
4335fe1c  8944241c                 mov      dword ptr [esp + 0x1c], eax
4335fe20  394eec                   cmp      dword ptr [esi - 0x14], ecx
4335fe23  7677                     jbe      0x4335fe9c
4335fe25  8bfe                     mov      edi, esi
4335fe27  0f57c9                   xorps    xmm1, xmm1
4335fe2a  8b0f                     mov      ecx, dword ptr [edi]
4335fe2c  f30f104130               movss    xmm0, dword ptr [ecx + 0x30]
4335fe31  0f2fc1                   comiss   xmm0, xmm1
4335fe34  7650                     jbe      0x4335fe86
4335fe36  83790403                 cmp      dword ptr [ecx + 4], 3
4335fe3a  7406                     je       0x4335fe42
4335fe3c  83790402                 cmp      dword ptr [ecx + 4], 2
4335fe40  7544                     jne      0x4335fe86
4335fe42  8d8424f00c0000           lea      eax, [esp + 0xcf0]
4335fe49  c784241c0d00000000803f   mov      dword ptr [esp + 0xd1c], 0x3f800000
4335fe54  8b17                     mov      edx, dword ptr [edi]
4335fe56  8d8c24d00a0000           lea      ecx, [esp + 0xad0]
4335fe5d  50                       push     eax
4335fe5e  8d470c                   lea      eax, [edi + 0xc]
4335fe61  50                       push     eax
4335fe62  e827fc0300               call     0x4339fa8e
4335fe67  85c0                     test     eax, eax
4335fe69  7814                     js       0x4335fe7f
4335fe6b  f30f10442450             movss    xmm0, dword ptr [esp + 0x50]
4335fe71  0f2f84241c0d0000         comiss   xmm0, dword ptr [esp + 0xd1c]
4335fe79  0f8718feffff             ja       0x4335fc97
4335fe7f  8b44241c                 mov      eax, dword ptr [esp + 0x1c]
4335fe83  0f57c9                   xorps    xmm1, xmm1
4335fe86  40                       inc      eax
4335fe87  81c790000000             add      edi, 0x90
4335fe8d  8944241c                 mov      dword ptr [esp + 0x1c], eax
4335fe91  3b46ec                   cmp      eax, dword ptr [esi - 0x14]
4335fe94  7294                     jb       0x4335fe2a
4335fe96  8b7c2448                 mov      edi, dword ptr [esp + 0x48]
4335fe9a  33c9                     xor      ecx, ecx
4335fe9c  47                       inc      edi
4335fe9d  81c6c00a0000             add      esi, 0xac0
4335fea3  897c2448                 mov      dword ptr [esp + 0x48], edi
4335fea7  83ff03                   cmp      edi, 3
4335feaa  0f8c0bffffff             jl       0x4335fdbb
4335feb0  b201                     mov      dl, 1
4335feb2  33c9                     xor      ecx, ecx
4335feb4  e9e2fdffff               jmp      0x4335fc9b
4335feb9  8b84243c020000           mov      eax, dword ptr [esp + 0x23c]
4335fec0  f30f107c2460             movss    xmm7, dword ptr [esp + 0x60]
4335fec6  f30f118424a0000000       movss    dword ptr [esp + 0xa0], xmm0
4335fecf  f30f10842484000000       movss    xmm0, dword ptr [esp + 0x84]
4335fed8  0f2ec5                   ucomiss  xmm0, xmm5
4335fedb  89442468                 mov      dword ptr [esp + 0x68], eax
4335fedf  9f                       lahf     
4335fee0  f6c444                   test     ah, 0x44
4335fee3  7a78                     jp       0x4335ff5d
4335fee5  0f2efd                   ucomiss  xmm7, xmm5
4335fee8  9f                       lahf     
4335fee9  f6c444                   test     ah, 0x44
4335feec  7a6f                     jp       0x4335ff5d
4335feee  0f57c0                   xorps    xmm0, xmm0
4335fef1  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
4335fef7  f30f118424dc000000       movss    dword ptr [esp + 0xdc], xmm0
4335ff00  f30f10842488000000       movss    xmm0, dword ptr [esp + 0x88]
4335ff09  f30f11442458             movss    dword ptr [esp + 0x58], xmm0
4335ff0f  f30f118424e0000000       movss    dword ptr [esp + 0xe0], xmm0
4335ff18  0f57c0                   xorps    xmm0, xmm0
4335ff1b  f30f11442450             movss    dword ptr [esp + 0x50], xmm0
4335ff21  f30f118424e4000000       movss    dword ptr [esp + 0xe4], xmm0
4335ff2a  f30f10442454             movss    xmm0, dword ptr [esp + 0x54]
4335ff30  0f5705d0034743           xorps    xmm0, xmmword ptr [0x434703d0]
4335ff37  f30f11442440             movss    dword ptr [esp + 0x40], xmm0
4335ff3d  f30f11842418010000       movss    dword ptr [esp + 0x118], xmm0
4335ff46  0f57c0                   xorps    xmm0, xmm0
4335ff49  f30f1144247c             movss    dword ptr [esp + 0x7c], xmm0
4335ff4f  f30f11842420010000       movss    dword ptr [esp + 0x120], xmm0
4335ff58  e95b010000               jmp      0x433600b8
4335ff5d  f30f10642454             movss    xmm4, dword ptr [esp + 0x54]
4335ff63  0f28d8                   movaps   xmm3, xmm0
4335ff66  f30f59e5                 mulss    xmm4, xmm5
4335ff6a  0f28d7                   movaps   xmm2, xmm7
4335ff6d  f30f59dd                 mulss    xmm3, xmm5
4335ff71  f30f5cd4                 subss    xmm2, xmm4
4335ff75  f30f5ce0                 subss    xmm4, xmm0
4335ff79  0f28c7                   movaps   xmm0, xmm7
4335ff7c  f30f59c5                 mulss    xmm0, xmm5
4335ff80  0f28ca                   movaps   xmm1, xmm2
4335ff83  f30f5cd8                 subss    xmm3, xmm0
4335ff87  f30f59ca                 mulss    xmm1, xmm2
4335ff8b  0f28c4                   movaps   xmm0, xmm4
4335ff8e  f30f59c4                 mulss    xmm0, xmm4
4335ff92  f30f58c8                 addss    xmm1, xmm0
4335ff96  0f28c3                   movaps   xmm0, xmm3
4335ff99  f30f59c3                 mulss    xmm0, xmm3
4335ff9d  f30f58c8                 addss    xmm1, xmm0
4335ffa1  0f28c1                   movaps   xmm0, xmm1
4335ffa4  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4335ffac  f30f51c0                 sqrtss   xmm0, xmm0
4335ffb0  f30f11842490030000       movss    dword ptr [esp + 0x390], xmm0
4335ffb9  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4335ffc1  f30f5ec8                 divss    xmm1, xmm0
4335ffc5  0f28f1                   movaps   xmm6, xmm1
4335ffc8  0f28e9                   movaps   xmm5, xmm1
4335ffcb  f30f59cb                 mulss    xmm1, xmm3
4335ffcf  f30f59f4                 mulss    xmm6, xmm4
4335ffd3  0f28c1                   movaps   xmm0, xmm1
4335ffd6  f30f59ea                 mulss    xmm5, xmm2
4335ffda  f30f59c7                 mulss    xmm0, xmm7
4335ffde  0f28d9                   movaps   xmm3, xmm1
4335ffe1  0f28e6                   movaps   xmm4, xmm6
4335ffe4  f30f114c2450             movss    dword ptr [esp + 0x50], xmm1
4335ffea  f30f59642454             mulss    xmm4, dword ptr [esp + 0x54]
4335fff0  0f28d5                   movaps   xmm2, xmm5
4335fff3  f30f118c24e4000000       movss    dword ptr [esp + 0xe4], xmm1
4335fffc  f30f108c2484000000       movss    xmm1, dword ptr [esp + 0x84]
43360005  f30f5ce0                 subss    xmm4, xmm0
43360009  f30f59d9                 mulss    xmm3, xmm1
4336000d  0f28c5                   movaps   xmm0, xmm5
43360010  f30f59d7                 mulss    xmm2, xmm7
43360014  f30f59442454             mulss    xmm0, dword ptr [esp + 0x54]
4336001a  f30f116c2438             movss    dword ptr [esp + 0x38], xmm5
43360020  f30f11ac24dc000000       movss    dword ptr [esp + 0xdc], xmm5
43360029  f30f5cd8                 subss    xmm3, xmm0
4336002d  f30f11742458             movss    dword ptr [esp + 0x58], xmm6
43360033  0f28c6                   movaps   xmm0, xmm6
43360036  f30f11b424e0000000       movss    dword ptr [esp + 0xe0], xmm6
4336003f  f30f59c1                 mulss    xmm0, xmm1
43360043  0f28cc                   movaps   xmm1, xmm4
43360046  f30f59cc                 mulss    xmm1, xmm4
4336004a  f30f5cd0                 subss    xmm2, xmm0
4336004e  0f28c3                   movaps   xmm0, xmm3
43360051  f30f59c3                 mulss    xmm0, xmm3
43360055  f30f58c8                 addss    xmm1, xmm0
43360059  0f28c2                   movaps   xmm0, xmm2
4336005c  f30f59c2                 mulss    xmm0, xmm2
43360060  f30f58c8                 addss    xmm1, xmm0
43360064  0f28c1                   movaps   xmm0, xmm1
43360067  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4336006f  f30f51c0                 sqrtss   xmm0, xmm0
43360073  f30f1184247c060000       movss    dword ptr [esp + 0x67c], xmm0
4336007c  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43360084  f30f5ec8                 divss    xmm1, xmm0
43360088  0f28c1                   movaps   xmm0, xmm1
4336008b  f30f59c4                 mulss    xmm0, xmm4
4336008f  f30f11442440             movss    dword ptr [esp + 0x40], xmm0
43360095  f30f11842418010000       movss    dword ptr [esp + 0x118], xmm0
4336009e  0f28c1                   movaps   xmm0, xmm1
433600a1  f30f59ca                 mulss    xmm1, xmm2
433600a5  f30f59c3                 mulss    xmm0, xmm3
433600a9  f30f114c247c             movss    dword ptr [esp + 0x7c], xmm1
433600af  f30f118c2420010000       movss    dword ptr [esp + 0x120], xmm1
433600b8  8b8c2490000000           mov      ecx, dword ptr [esp + 0x90]
433600bf  8364241c00               and      dword ptr [esp + 0x1c], 0
433600c4  83c108                   add      ecx, 8
433600c7  f30f1184241c010000       movss    dword ptr [esp + 0x11c], xmm0
433600d0  f30f11442448             movss    dword ptr [esp + 0x48], xmm0
433600d6  8b01                     mov      eax, dword ptr [ecx]
433600d8  ff5028                   call     dword ptr [eax + 0x28]
433600db  85c0                     test     eax, eax
433600dd  750c                     jne      0x433600eb
433600df  9e                       sahf     
433600e0  b8e77ea2b1               mov      eax, 0xb1a27ee7
433600e5  cb                       retf     
433600eb  8bc8                     mov      ecx, eax
433600ed  e839890500               call     0x433b8a2b
433600f2  8b842480000000           mov      eax, dword ptr [esp + 0x80]
433600f9  051c110000               add      eax, 0x111c
433600fe  c784248c00000020000000   mov      dword ptr [esp + 0x8c], 0x20
43360109  89442464                 mov      dword ptr [esp + 0x64], eax
4336010d  f30f1038                 movss    xmm7, dword ptr [eax]
43360111  33c9                     xor      ecx, ecx
43360113  f30f104804               movss    xmm1, dword ptr [eax + 4]
43360118  0f28df                   movaps   xmm3, xmm7
4336011b  f30f595c2438             mulss    xmm3, dword ptr [esp + 0x38]
43360121  0f28c1                   movaps   xmm0, xmm1
43360124  8b442434                 mov      eax, dword ptr [esp + 0x34]
43360128  f30f59442440             mulss    xmm0, dword ptr [esp + 0x40]
4336012e  0f28f7                   movaps   xmm6, xmm7
43360131  f30f589c2484000000       addss    xmm3, dword ptr [esp + 0x84]
4336013a  f30f59742458             mulss    xmm6, dword ptr [esp + 0x58]
43360140  f30f597c2450             mulss    xmm7, dword ptr [esp + 0x50]
43360146  f30f58742460             addss    xmm6, dword ptr [esp + 0x60]
4336014c  f30f58d8                 addss    xmm3, xmm0
43360150  f30f10ac24a0000000       movss    xmm5, dword ptr [esp + 0xa0]
43360159  f30f587c2454             addss    xmm7, dword ptr [esp + 0x54]
4336015f  0f28c1                   movaps   xmm0, xmm1
43360162  f30f594c247c             mulss    xmm1, dword ptr [esp + 0x7c]
43360168  f30f59442448             mulss    xmm0, dword ptr [esp + 0x48]
4336016e  f30f58f9                 addss    xmm7, xmm1
43360172  0f28cb                   movaps   xmm1, xmm3
43360175  f30f59cb                 mulss    xmm1, xmm3
43360179  f30f58f0                 addss    xmm6, xmm0
4336017d  0f28c6                   movaps   xmm0, xmm6
43360180  f30f59c6                 mulss    xmm0, xmm6
43360184  f30f58c8                 addss    xmm1, xmm0
43360188  0f28c7                   movaps   xmm0, xmm7
4336018b  f30f59c7                 mulss    xmm0, xmm7
4336018f  f30f58c8                 addss    xmm1, xmm0
43360193  0f28c1                   movaps   xmm0, xmm1
43360196  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4336019e  f30f51c0                 sqrtss   xmm0, xmm0
433601a2  f30f11842464030000       movss    dword ptr [esp + 0x364], xmm0
433601ab  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433601b3  f30f5ec8                 divss    xmm1, xmm0
433601b7  0f28d1                   movaps   xmm2, xmm1
433601ba  f30f59f1                 mulss    xmm6, xmm1
433601be  f30f59d3                 mulss    xmm2, xmm3
433601c2  f30f59f9                 mulss    xmm7, xmm1
433601c6  0f28c6                   movaps   xmm0, xmm6
433601c9  f30f59c6                 mulss    xmm0, xmm6
433601cd  0f28ca                   movaps   xmm1, xmm2
433601d0  f30f59ca                 mulss    xmm1, xmm2
433601d4  f30f58c8                 addss    xmm1, xmm0
433601d8  0f28c7                   movaps   xmm0, xmm7
433601db  f30f59c7                 mulss    xmm0, xmm7
433601df  f30f58c8                 addss    xmm1, xmm0
433601e3  0f28c1                   movaps   xmm0, xmm1
433601e6  f30f104804               movss    xmm1, dword ptr [eax + 4]
433601eb  f30f51c0                 sqrtss   xmm0, xmm0
433601ef  f30f11842468030000       movss    dword ptr [esp + 0x368], xmm0
433601f8  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43360200  f30f5ee8                 divss    xmm5, xmm0
43360204  f30f1000                 movss    xmm0, dword ptr [eax]
43360208  0f28dd                   movaps   xmm3, xmm5
4336020b  0f28e5                   movaps   xmm4, xmm5
4336020e  f30f59e6                 mulss    xmm4, xmm6
43360212  f30f59da                 mulss    xmm3, xmm2
43360216  f30f105008               movss    xmm2, dword ptr [eax + 8]
4336021b  f30f11a42454040000       movss    dword ptr [esp + 0x454], xmm4
43360224  f30f59ef                 mulss    xmm5, xmm7
43360228  898c2480040000           mov      dword ptr [esp + 0x480], ecx
4336022f  f30f119c2450040000       movss    dword ptr [esp + 0x450], xmm3
43360238  f30f59e4                 mulss    xmm4, xmm4
4336023c  c684248404000001         mov      byte ptr [esp + 0x484], 1
43360244  f30f59db                 mulss    xmm3, xmm3
43360248  c684248504000001         mov      byte ptr [esp + 0x485], 1
43360250  f30f11ac2458040000       movss    dword ptr [esp + 0x458], xmm5
43360259  f30f59ed                 mulss    xmm5, xmm5
4336025d  f30f58e3                 addss    xmm4, xmm3
43360261  f30f118c2444040000       movss    dword ptr [esp + 0x444], xmm1
4336026a  0f57c9                   xorps    xmm1, xmm1
4336026d  f30f11842440040000       movss    dword ptr [esp + 0x440], xmm0
43360276  0f57c0                   xorps    xmm0, xmm0
43360279  f30f11942448040000       movss    dword ptr [esp + 0x448], xmm2
43360282  0f29842460040000         movaps   xmmword ptr [esp + 0x460], xmm0
4336028a  0f29842470040000         movaps   xmmword ptr [esp + 0x470], xmm0
43360292  f30f58e5                 addss    xmm4, xmm5
43360296  0f2ee1                   ucomiss  xmm4, xmm1
43360299  9f                       lahf     
4336029a  f6c444                   test     ah, 0x44
4336029d  7a07                     jp       0x433602a6
4336029f  888c2485040000           mov      byte ptr [esp + 0x485], cl
433602a6  f30f101514054743         movss    xmm2, dword ptr [0x43470514]
433602ae  8bd1                     mov      edx, ecx
433602b0  838c241c0a0000ff         or       dword ptr [esp + 0xa1c], 0xffffffff
433602b8  8bc1                     mov      eax, ecx
433602ba  838c24280a0000ff         or       dword ptr [esp + 0xa28], 0xffffffff
433602c2  c78424a4000000ffffff7f   mov      dword ptr [esp + 0xa4], 0x7fffffff
433602cd  8bbc24a4000000           mov      edi, dword ptr [esp + 0xa4]
433602d4  c78424040a00000000803f   mov      dword ptr [esp + 0xa04], 0x3f800000
433602df  66898c240e0a0000         mov      word ptr [esp + 0xa0e], cx
433602e7  898c24240a0000           mov      dword ptr [esp + 0xa24], ecx
433602ee  f30f11542418             movss    dword ptr [esp + 0x18], xmm2
433602f4  8954242c                 mov      dword ptr [esp + 0x2c], edx
433602f8  89442478                 mov      dword ptr [esp + 0x78], eax
433602fc  8b80b0494743             mov      eax, dword ptr [eax + 0x434749b0]
43360302  3b8424e01c0000           cmp      eax, dword ptr [esp + 0x1ce0]
43360309  0f83c0000000             jae      0x433603cf
4336030f  69c090000000             imul     eax, eax, 0x90
43360315  8d8c24f01c0000           lea      ecx, [esp + 0x1cf0]
4336031c  03c8                     add      ecx, eax
4336031e  898c24a4000000           mov      dword ptr [esp + 0xa4], ecx
43360325  8d7140                   lea      esi, [ecx + 0x40]
43360328  8b4604                   mov      eax, dword ptr [esi + 4]
4336032b  83e00f                   and      eax, 0xf
4336032e  393c8570494743           cmp      dword ptr [eax*4 + 0x43474970], edi
43360335  0f8794000000             ja       0x433603cf
4336033b  c78424040a00000000803f   mov      dword ptr [esp + 0xa04], 0x3f800000
43360346  8d8424d8090000           lea      eax, [esp + 0x9d8]
4336034d  f30f104630               movss    xmm0, dword ptr [esi + 0x30]
43360352  0f2fc1                   comiss   xmm0, xmm1
43360355  50                       push     eax
43360356  7610                     jbe      0x43360368
43360358  8bd6                     mov      edx, esi
4336035a  8d8c2444040000           lea      ecx, [esp + 0x444]
43360361  e8a38a0900               call     0x433f8e09
43360366  eb13                     jmp      0x4336037b
43360368  8b5104                   mov      edx, dword ptr [ecx + 4]
4336036b  8d4110                   lea      eax, [ecx + 0x10]
4336036e  50                       push     eax
4336036f  8d8c2448040000           lea      ecx, [esp + 0x448]
43360376  e813f70300               call     0x4339fa8e
4336037b  f30f10542418             movss    xmm2, dword ptr [esp + 0x18]
43360381  85c0                     test     eax, eax
43360383  782f                     js       0x433603b4
43360385  0f2f9424040a0000         comiss   xmm2, dword ptr [esp + 0xa04]
4336038d  7625                     jbe      0x433603b4
4336038f  837e0401                 cmp      dword ptr [esi + 4], 1
43360393  f30f109424040a0000       movss    xmm2, dword ptr [esp + 0xa04]
4336039c  8b9424a4000000           mov      edx, dword ptr [esp + 0xa4]
433603a3  f30f11542418             movss    dword ptr [esp + 0x18], xmm2
433603a9  8954242c                 mov      dword ptr [esp + 0x2c], edx
433603ad  7520                     jne      0x433603cf
433603af  6a02                     push     2
433603b1  5f                       pop      edi
433603b2  eb04                     jmp      0x433603b8
433603b4  8b54242c                 mov      edx, dword ptr [esp + 0x2c]
433603b8  8b442478                 mov      eax, dword ptr [esp + 0x78]
433603bc  0f57c9                   xorps    xmm1, xmm1
433603bf  83c004                   add      eax, 4
433603c2  89442478                 mov      dword ptr [esp + 0x78], eax
433603c6  83f83c                   cmp      eax, 0x3c
433603c9  0f822dffffff             jb       0x433602fc
433603cf  85d2                     test     edx, edx
433603d1  0f84a0000000             je       0x43360477
433603d7  f30f10842450040000       movss    xmm0, dword ptr [esp + 0x450]
433603e0  8b4a44                   mov      ecx, dword ptr [edx + 0x44]
433603e3  f30f59c2                 mulss    xmm0, xmm2
433603e7  898c241c0a0000           mov      dword ptr [esp + 0xa1c], ecx
433603ee  8b02                     mov      eax, dword ptr [edx]
433603f0  898424280a0000           mov      dword ptr [esp + 0xa28], eax
433603f7  f30f58842440040000       addss    xmm0, dword ptr [esp + 0x440]
43360400  8b4508                   mov      eax, dword ptr [ebp + 8]
43360403  f30f118424e4090000       movss    dword ptr [esp + 0x9e4], xmm0
4336040c  f30f10842454040000       movss    xmm0, dword ptr [esp + 0x454]
43360415  f30f59c2                 mulss    xmm0, xmm2
43360419  f30f58842444040000       addss    xmm0, dword ptr [esp + 0x444]
43360422  f30f118424e8090000       movss    dword ptr [esp + 0x9e8], xmm0
4336042b  f30f10842458040000       movss    xmm0, dword ptr [esp + 0x458]
43360434  f30f59c2                 mulss    xmm0, xmm2
43360438  f30f58842448040000       addss    xmm0, dword ptr [esp + 0x448]
43360441  f30f118424ec090000       movss    dword ptr [esp + 0x9ec], xmm0
4336044a  83b89c01000001           cmp      dword ptr [eax + 0x19c], 1
43360451  7f19                     jg       0x4336046c
43360453  394c2468                 cmp      dword ptr [esp + 0x68], ecx
43360457  7413                     je       0x4336046c
43360459  83e10f                   and      ecx, 0xf
4336045c  f30f10048d40454743       movss    xmm0, dword ptr [ecx*4 + 0x43474540]
43360465  0f2f442420               comiss   xmm0, dword ptr [esp + 0x20]
4336046a  720b                     jb       0x43360477
4336046c  8b74241c                 mov      esi, dword ptr [esp + 0x1c]
43360470  46                       inc      esi
43360471  8974241c                 mov      dword ptr [esp + 0x1c], esi
43360475  eb04                     jmp      0x4336047b
43360477  8b74241c                 mov      esi, dword ptr [esp + 0x1c]
4336047b  8b442464                 mov      eax, dword ptr [esp + 0x64]
4336047f  83c020                   add      eax, 0x20
43360482  83ac248c00000001         sub      dword ptr [esp + 0x8c], 1
4336048a  89442464                 mov      dword ptr [esp + 0x64], eax
4336048e  0f8579fcffff             jne      0x4336010d
43360494  660f6ec6                 movd     xmm0, esi
43360498  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4336049c  0f5bc0                   cvtdq2ps xmm0, xmm0
4336049f  f30f590528f64643         mulss    xmm0, dword ptr [0x4346f628]
433604a7  f30f114738               movss    dword ptr [edi + 0x38], xmm0
433604ac  8bb42464010000           mov      esi, dword ptr [esp + 0x164]
433604b3  8b4708                   mov      eax, dword ptr [edi + 8]
433604b6  f30f108c2474010000       movss    xmm1, dword ptr [esp + 0x174]
433604bf  f30f590da0044743         mulss    xmm1, dword ptr [0x434704a0]
433604c7  89442468                 mov      dword ptr [esp + 0x68], eax
433604cb  83c005                   add      eax, 5
433604ce  6a7f                     push     0x7f
433604d0  5a                       pop      edx
433604d1  3bc2                     cmp      eax, edx
433604d3  8bca                     mov      ecx, edx
433604d5  8bd6                     mov      edx, esi
433604d7  0f42c8                   cmovb    ecx, eax
433604da  8b842470010000           mov      eax, dword ptr [esp + 0x170]
433604e1  3bce                     cmp      ecx, esi
433604e3  89442420                 mov      dword ptr [esp + 0x20], eax
433604e7  6a7f                     push     0x7f
433604e9  0f42d1                   cmovb    edx, ecx
433604ec  83e27f                   and      edx, 0x7f
433604ef  8bca                     mov      ecx, edx
433604f1  81c980000000             or       ecx, 0x80
433604f7  2402                     and      al, 2
433604f9  f30f2dc1                 cvtss2si eax, xmm1
433604fd  0f45ca                   cmovne   ecx, edx
43360500  5a                       pop      edx
43360501  85c0                     test     eax, eax
43360503  7904                     jns      0x43360509
43360505  33c0                     xor      eax, eax
43360507  eb05                     jmp      0x4336050e
43360509  3bc2                     cmp      eax, edx
4336050b  0f4fc2                   cmovg    eax, edx
4336050e  23c2                     and      eax, edx
43360510  c78424a00100000f000000   mov      dword ptr [esp + 0x1a0], 0xf
4336051b  c1e008                   shl      eax, 8
4336051e  0bc1                     or       eax, ecx
43360520  33c9                     xor      ecx, ecx
43360522  41                       inc      ecx
43360523  8bd0                     mov      edx, eax
43360525  204c2420                 and      byte ptr [esp + 0x20], cl
43360529  81ca00800000             or       edx, 0x8000
4336052f  807c242000               cmp      byte ptr [esp + 0x20], 0
43360534  0f44d0                   cmove    edx, eax
43360537  83a4248401000000         and      dword ptr [esp + 0x184], 0
4336053f  899424a0000000           mov      dword ptr [esp + 0xa0], edx
43360546  85f6                     test     esi, esi
43360548  7f07                     jg       0x43360551
4336054a  baffffff7f               mov      edx, 0x7fffffff
4336054f  eb11                     jmp      0x43360562
43360551  8b442468                 mov      eax, dword ptr [esp + 0x68]
43360555  48                       dec      eax
43360556  03c6                     add      eax, esi
43360558  99                       cdq      
43360559  f7fe                     idiv     esi
4336055b  8bd1                     mov      edx, ecx
4336055d  3bc1                     cmp      eax, ecx
4336055f  0f4fd0                   cmovg    edx, eax
43360562  6a0f                     push     0xf
43360564  58                       pop      eax
43360565  ff742430                 push     dword ptr [esp + 0x30]
43360569  2bc2                     sub      eax, edx
4336056b  8d8c2490010000           lea      ecx, [esp + 0x190]
43360572  89842490010000           mov      dword ptr [esp + 0x190], eax
43360579  8d942488010000           lea      edx, [esp + 0x188]
43360580  8d8424a4010000           lea      eax, [esp + 0x1a4]
43360587  50                       push     eax
43360588  e833e60100               call     0x4337ebc0
4336058d  8b94246c010000           mov      edx, dword ptr [esp + 0x16c]
43360594  8b00                     mov      eax, dword ptr [eax]
43360596  83e00f                   and      eax, 0xf
43360599  c1e010                   shl      eax, 0x10
4336059c  0b8424a0000000           or       eax, dword ptr [esp + 0xa0]
433605a3  80bfdd00000000           cmp      byte ptr [edi + 0xdd], 0
433605aa  740f                     je       0x433605bb
433605ac  83fa02                   cmp      edx, 2
433605af  7405                     je       0x433605b6
433605b1  83fa03                   cmp      edx, 3
433605b4  7505                     jne      0x433605bb
433605b6  0d00001000               or       eax, 0x100000
433605bb  f30f10842474010000       movss    xmm0, dword ptr [esp + 0x174]
433605c4  0f2f87d4000000           comiss   xmm0, dword ptr [edi + 0xd4]
433605cb  7205                     jb       0x433605d2
433605cd  0d00002000               or       eax, 0x200000
433605d2  8b8c2464010000           mov      ecx, dword ptr [esp + 0x164]
433605d9  3b8fd0000000             cmp      ecx, dword ptr [edi + 0xd0]
433605df  7c05                     jl       0x433605e6
433605e1  0d00004000               or       eax, 0x400000
433605e6  8984247c010000           mov      dword ptr [esp + 0x17c], eax
433605ed  eb1b                     jmp      0x4336060a
433605ef  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
433605f3  f30f10842474010000       movss    xmm0, dword ptr [esp + 0x174]
433605fc  8b94246c010000           mov      edx, dword ptr [esp + 0x16c]
43360603  8b8c2464010000           mov      ecx, dword ptr [esp + 0x164]
4336060a  8b742444                 mov      esi, dword ptr [esp + 0x44]
4336060e  f6461402                 test     byte ptr [esi + 0x14], 2
43360612  750a                     jne      0x4336061e
43360614  8974244c                 mov      dword ptr [esp + 0x4c], esi
43360618  894c2424                 mov      dword ptr [esp + 0x24], ecx
4336061c  eb04                     jmp      0x43360622
4336061e  8b74244c                 mov      esi, dword ptr [esp + 0x4c]
43360622  85c9                     test     ecx, ecx
43360624  0f84b8000000             je       0x433606e2
4336062a  3b8fd0000000             cmp      ecx, dword ptr [edi + 0xd0]
43360630  0f8ca1000000             jl       0x433606d7
43360636  0f2f87d4000000           comiss   xmm0, dword ptr [edi + 0xd4]
4336063d  727c                     jb       0x433606bb
4336063f  80bfdd00000000           cmp      byte ptr [edi + 0xdd], 0
43360646  742d                     je       0x43360675
43360648  8b442428                 mov      eax, dword ptr [esp + 0x28]
4336064c  a900001000               test     eax, 0x100000
43360651  7422                     je       0x43360675
43360653  33c9                     xor      ecx, ecx
43360655  41                       inc      ecx
43360656  3bd1                     cmp      edx, ecx
43360658  751b                     jne      0x43360675
4336065a  848c2470010000           test     byte ptr [esp + 0x170], cl
43360661  7412                     je       0x43360675
43360663  f687b800000008           test     byte ptr [edi + 0xb8], 8
4336066a  7409                     je       0x43360675
4336066c  25ffffefff               and      eax, 0xffefffff
43360671  89442428                 mov      dword ptr [esp + 0x28], eax
43360675  8b4c2444                 mov      ecx, dword ptr [esp + 0x44]
43360679  8dbc2454010000           lea      edi, [esp + 0x154]
43360680  8b442424                 mov      eax, dword ptr [esp + 0x24]
43360684  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43360685  6a0e                     push     0xe
43360687  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43360688  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43360689  8bbc24e8470000           mov      edi, dword ptr [esp + 0x47e8]
43360690  8db4244c010000           lea      esi, [esp + 0x14c]
43360697  89842464010000           mov      dword ptr [esp + 0x164], eax
4336069e  f30f10410c               movss    xmm0, dword ptr [ecx + 0xc]
433606a3  59                       pop      ecx
433606a4  8d4738                   lea      eax, [edi + 0x38]
433606a7  f30f11842478010000       movss    dword ptr [esp + 0x178], xmm0
433606b0  898424e4470000           mov      dword ptr [esp + 0x47e4], eax
433606b7  f3a5                     rep movsd dword ptr es:[edi], dword ptr [esi]
433606b9  eb27                     jmp      0x433606e2
433606bb  8b8c2480000000           mov      ecx, dword ptr [esp + 0x80]
433606c2  8b8178010000             mov      eax, dword ptr [ecx + 0x178]
433606c8  a809                     test     al, 9
433606ca  750b                     jne      0x433606d7
433606cc  0d00010000               or       eax, 0x100
433606d1  898178010000             mov      dword ptr [ecx + 0x178], eax
433606d7  818c247001000080000000   or       dword ptr [esp + 0x170], 0x80
433606e2  8b842454120000           mov      eax, dword ptr [esp + 0x1254]
433606e9  2b842450120000           sub      eax, dword ptr [esp + 0x1250]
433606f0  6a18                     push     0x18
433606f2  5e                       pop      esi
433606f3  99                       cdq      
433606f4  f7fe                     idiv     esi
433606f6  8b4c2414                 mov      ecx, dword ptr [esp + 0x14]
433606fa  8b742434                 mov      esi, dword ptr [esp + 0x34]
433606fe  41                       inc      ecx
433606ff  8b5518                   mov      edx, dword ptr [ebp + 0x18]
43360702  894c2414                 mov      dword ptr [esp + 0x14], ecx
43360706  3bc8                     cmp      ecx, eax
43360708  0f8254e8ffff             jb       0x4335ef62
4336070e  8b4c2428                 mov      ecx, dword ptr [esp + 0x28]
43360712  33f6                     xor      esi, esi
43360714  8b8424e0470000           mov      eax, dword ptr [esp + 0x47e0]
4336071b  3b8424e4470000           cmp      eax, dword ptr [esp + 0x47e4]
43360722  0f8441010000             je       0x43360869
43360728  8bd0                     mov      edx, eax
4336072a  8b4034                   mov      eax, dword ptr [eax + 0x34]
4336072d  23c1                     and      eax, ecx
4336072f  89542418                 mov      dword ptr [esp + 0x18], edx
43360733  89442430                 mov      dword ptr [esp + 0x30], eax
43360737  8bc2                     mov      eax, edx
43360739  8b7c2430                 mov      edi, dword ptr [esp + 0x30]
4336073d  89442420                 mov      dword ptr [esp + 0x20], eax
43360741  eb04                     jmp      0x43360747
43360743  8b442420                 mov      eax, dword ptr [esp + 0x20]
43360747  8b5034                   mov      edx, dword ptr [eax + 0x34]
4336074a  23d1                     and      edx, ecx
4336074c  8b4c2428                 mov      ecx, dword ptr [esp + 0x28]
43360750  3bd7                     cmp      edx, edi
43360752  0f46442418               cmovbe   eax, dword ptr [esp + 0x18]
43360757  8344242038               add      dword ptr [esp + 0x20], 0x38
4336075c  3bd7                     cmp      edx, edi
4336075e  89442418                 mov      dword ptr [esp + 0x18], eax
43360762  8b8424e4470000           mov      eax, dword ptr [esp + 0x47e4]
43360769  0f46d7                   cmovbe   edx, edi
4336076c  8bfa                     mov      edi, edx
4336076e  39442420                 cmp      dword ptr [esp + 0x20], eax
43360772  75cf                     jne      0x43360743
43360774  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
43360778  33c9                     xor      ecx, ecx
4336077a  41                       inc      ecx
4336077b  89742414                 mov      dword ptr [esp + 0x14], esi
4336077f  80bfdd00000000           cmp      byte ptr [edi + 0xdd], 0
43360786  746a                     je       0x433607f2
43360788  8b542418                 mov      edx, dword ptr [esp + 0x18]
4336078c  394a24                   cmp      dword ptr [edx + 0x24], ecx
4336078f  7561                     jne      0x433607f2
43360791  8bbc24e0470000           mov      edi, dword ptr [esp + 0x47e0]
43360798  8bd6                     mov      edx, esi
4336079a  8b4724                   mov      eax, dword ptr [edi + 0x24]
4336079d  83e802                   sub      eax, 2
433607a0  3bc1                     cmp      eax, ecx
433607a2  770e                     ja       0x433607b2
433607a4  85d2                     test     edx, edx
433607a6  7408                     je       0x433607b0
433607a8  8b4734                   mov      eax, dword ptr [edi + 0x34]
433607ab  3b4234                   cmp      eax, dword ptr [edx + 0x34]
433607ae  7602                     jbe      0x433607b2
433607b0  8bd7                     mov      edx, edi
433607b2  8b8424e4470000           mov      eax, dword ptr [esp + 0x47e4]
433607b9  83c738                   add      edi, 0x38
433607bc  3bf8                     cmp      edi, eax
433607be  75da                     jne      0x4336079a
433607c0  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
433607c4  85d2                     test     edx, edx
433607c6  89542414                 mov      dword ptr [esp + 0x14], edx
433607ca  8b9424e0470000           mov      edx, dword ptr [esp + 0x47e0]
433607d1  7426                     je       0x433607f9
433607d3  8b742414                 mov      esi, dword ptr [esp + 0x14]
433607d7  83c744                   add      edi, 0x44
433607da  6a0e                     push     0xe
433607dc  59                       pop      ecx
433607dd  f3a5                     rep movsd dword ptr es:[edi], dword ptr [esi]
433607df  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
433607e3  33c9                     xor      ecx, ecx
433607e5  33f6                     xor      esi, esi
433607e7  830f08                   or       dword ptr [edi], 8
433607ea  41                       inc      ecx
433607eb  8b8424e4470000           mov      eax, dword ptr [esp + 0x47e4]
433607f2  8b9424e0470000           mov      edx, dword ptr [esp + 0x47e0]
433607f9  80bfdc00000000           cmp      byte ptr [edi + 0xdc], 0
43360800  745b                     je       0x4336085d
43360802  8b7c2418                 mov      edi, dword ptr [esp + 0x18]
43360806  844f28                   test     byte ptr [edi + 0x28], cl
43360809  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4336080d  744e                     je       0x4336085d
4336080f  3bd0                     cmp      edx, eax
43360811  744a                     je       0x4336085d
43360813  844a28                   test     byte ptr [edx + 0x28], cl
43360816  7515                     jne      0x4336082d
43360818  85f6                     test     esi, esi
4336081a  740f                     je       0x4336082b
4336081c  8b4234                   mov      eax, dword ptr [edx + 0x34]
4336081f  3b4634                   cmp      eax, dword ptr [esi + 0x34]
43360822  8b8424e4470000           mov      eax, dword ptr [esp + 0x47e4]
43360829  7602                     jbe      0x4336082d
4336082b  8bf2                     mov      esi, edx
4336082d  83c238                   add      edx, 0x38
43360830  3bd0                     cmp      edx, eax
43360832  75df                     jne      0x43360813
43360834  85f6                     test     esi, esi
43360836  7425                     je       0x4336085d
43360838  3b742414                 cmp      esi, dword ptr [esp + 0x14]
4336083c  741f                     je       0x4336085d
4336083e  8b07                     mov      eax, dword ptr [edi]
43360840  6a0e                     push     0xe
43360842  59                       pop      ecx
43360843  a808                     test     al, 8
43360845  7408                     je       0x4336084f
43360847  83c77c                   add      edi, 0x7c
4336084a  83c810                   or       eax, 0x10
4336084d  eb06                     jmp      0x43360855
4336084f  83c744                   add      edi, 0x44
43360852  83c808                   or       eax, 8
43360855  f3a5                     rep movsd dword ptr es:[edi], dword ptr [esi]
43360857  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
4336085b  8907                     mov      dword ptr [edi], eax
4336085d  8b742418                 mov      esi, dword ptr [esp + 0x18]
43360861  83c70c                   add      edi, 0xc
43360864  6a0e                     push     0xe
43360866  59                       pop      ecx
43360867  f3a5                     rep movsd dword ptr es:[edi], dword ptr [esi]
43360869  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
4336086d  8b5628                   mov      edx, dword ptr [esi + 0x28]
43360870  89542414                 mov      dword ptr [esp + 0x14], edx
43360874  85d2                     test     edx, edx
43360876  0f84bf390000             je       0x4336423b
4336087c  f6463402                 test     byte ptr [esi + 0x34], 2
43360880  0f84b5390000             je       0x4336423b
43360886  8d460c                   lea      eax, [esi + 0xc]
43360889  83c618                   add      esi, 0x18
4336088c  8d7c246c                 lea      edi, [esp + 0x6c]
43360890  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43360891  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43360892  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43360893  8bf0                     mov      esi, eax
43360895  8dbc2494000000           lea      edi, [esp + 0x94]
4336089c  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336089d  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336089e  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336089f  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
433608a3  8b4e24                   mov      ecx, dword ptr [esi + 0x24]
433608a6  8b4630                   mov      eax, dword ptr [esi + 0x30]
433608a9  89442430                 mov      dword ptr [esp + 0x30], eax
433608ad  894c2468                 mov      dword ptr [esp + 0x68], ecx
433608b1  85c9                     test     ecx, ecx
433608b3  7f0a                     jg       0x433608bf
433608b5  33c9                     xor      ecx, ecx
433608b7  bfffffff7f               mov      edi, 0x7fffffff
433608bc  41                       inc      ecx
433608bd  eb17                     jmp      0x433608d6
433608bf  8b4608                   mov      eax, dword ptr [esi + 8]
433608c2  48                       dec      eax
433608c3  03c1                     add      eax, ecx
433608c5  99                       cdq      
433608c6  f7f9                     idiv     ecx
433608c8  8b542414                 mov      edx, dword ptr [esp + 0x14]
433608cc  33c9                     xor      ecx, ecx
433608ce  41                       inc      ecx
433608cf  3bc1                     cmp      eax, ecx
433608d1  8bf9                     mov      edi, ecx
433608d3  0f4ff8                   cmovg    edi, eax
433608d6  85d2                     test     edx, edx
433608d8  7f0b                     jg       0x433608e5
433608da  b8ffffff7f               mov      eax, 0x7fffffff
433608df  89442444                 mov      dword ptr [esp + 0x44], eax
433608e3  eb1e                     jmp      0x43360903
433608e5  8b4608                   mov      eax, dword ptr [esi + 8]
433608e8  48                       dec      eax
433608e9  03c2                     add      eax, edx
433608eb  99                       cdq      
433608ec  f77c2414                 idiv     dword ptr [esp + 0x14]
433608f0  8bd1                     mov      edx, ecx
433608f2  3bc1                     cmp      eax, ecx
433608f4  0f4fd0                   cmovg    edx, eax
433608f7  89542444                 mov      dword ptr [esp + 0x44], edx
433608fb  8b542414                 mov      edx, dword ptr [esp + 0x14]
433608ff  8b442444                 mov      eax, dword ptr [esp + 0x44]
43360903  3bf8                     cmp      edi, eax
43360905  0f8447050000             je       0x43360e52
4336090b  0fb605e0a34643           movzx    eax, byte ptr [0x4346a3e0]
43360912  8d8c2410100000           lea      ecx, [esp + 0x1010]
43360919  33ff                     xor      edi, edi
4336091b  0f57c0                   xorps    xmm0, xmm0
4336091e  897c2434                 mov      dword ptr [esp + 0x34], edi
43360922  8b7d08                   mov      edi, dword ptr [ebp + 8]
43360925  50                       push     eax
43360926  f30f1144242c             movss    dword ptr [esp + 0x2c], xmm0
4336092c  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
43360934  ff770c                   push     dword ptr [edi + 0xc]
43360937  f30f11442434             movss    dword ptr [esp + 0x34], xmm0
4336093d  e849a90800               call     0x433eb28b
43360942  f30f10842494000000       movss    xmm0, dword ptr [esp + 0x94]
4336094b  8d87dc000000             lea      eax, [edi + 0xdc]
43360951  f30f108c2498000000       movss    xmm1, dword ptr [esp + 0x98]
4336095a  0f57db                   xorps    xmm3, xmm3
4336095d  f30f10ac249c000000       movss    xmm5, dword ptr [esp + 0x9c]
43360966  f30f5c44246c             subss    xmm0, dword ptr [esp + 0x6c]
4336096c  f30f5c4c2470             subss    xmm1, dword ptr [esp + 0x70]
43360972  f30f5c6c2474             subss    xmm5, dword ptr [esp + 0x74]
43360978  f30f1054242c             movss    xmm2, dword ptr [esp + 0x2c]
4336097e  89442440                 mov      dword ptr [esp + 0x40], eax
43360982  f30f11442458             movss    dword ptr [esp + 0x58], xmm0
43360988  f30f114c2448             movss    dword ptr [esp + 0x48], xmm1
4336098e  f30f116c2450             movss    dword ptr [esp + 0x50], xmm5
43360994  c744243804000000         mov      dword ptr [esp + 0x38], 4
4336099c  838c241c070000ff         or       dword ptr [esp + 0x71c], 0xffffffff
433609a4  f30f58d3                 addss    xmm2, xmm3
433609a8  838c2428070000ff         or       dword ptr [esp + 0x728], 0xffffffff
433609b0  0f28f8                   movaps   xmm7, xmm0
433609b3  0f28f1                   movaps   xmm6, xmm1
433609b6  c78424040700000000803f   mov      dword ptr [esp + 0x704], 0x3f800000
433609c1  33d2                     xor      edx, edx
433609c3  33c9                     xor      ecx, ecx
433609c5  668994240e070000         mov      word ptr [esp + 0x70e], dx
433609cd  41                       inc      ecx
433609ce  f30f591540224743         mulss    xmm2, dword ptr [0x43472240]
433609d6  89942424070000           mov      dword ptr [esp + 0x724], edx
433609dd  f30f1020                 movss    xmm4, dword ptr [eax]
433609e1  f30f105804               movss    xmm3, dword ptr [eax + 4]
433609e6  f30f59fa                 mulss    xmm7, xmm2
433609ea  f30f59f2                 mulss    xmm6, xmm2
433609ee  f30f587c246c             addss    xmm7, dword ptr [esp + 0x6c]
433609f4  f30f11542418             movss    dword ptr [esp + 0x18], xmm2
433609fa  f30f58742470             addss    xmm6, dword ptr [esp + 0x70]
43360a00  f30f596c2418             mulss    xmm5, dword ptr [esp + 0x18]
43360a06  f30f105008               movss    xmm2, dword ptr [eax + 8]
43360a0b  f30f5cfc                 subss    xmm7, xmm4
43360a0f  f30f11a42490040000       movss    dword ptr [esp + 0x490], xmm4
43360a18  f30f586c2474             addss    xmm5, dword ptr [esp + 0x74]
43360a1e  f30f5cf3                 subss    xmm6, xmm3
43360a22  f30f119c2494040000       movss    dword ptr [esp + 0x494], xmm3
43360a2b  f30f11942498040000       movss    dword ptr [esp + 0x498], xmm2
43360a34  0f28cf                   movaps   xmm1, xmm7
43360a37  899424d0040000           mov      dword ptr [esp + 0x4d0], edx
43360a3e  f30f59cf                 mulss    xmm1, xmm7
43360a42  888c24d4040000           mov      byte ptr [esp + 0x4d4], cl
43360a49  f30f5cea                 subss    xmm5, xmm2
43360a4d  888c24d5040000           mov      byte ptr [esp + 0x4d5], cl
43360a54  0f28c6                   movaps   xmm0, xmm6
43360a57  f30f59c6                 mulss    xmm0, xmm6
43360a5b  f30f58c8                 addss    xmm1, xmm0
43360a5f  0f28c5                   movaps   xmm0, xmm5
43360a62  f30f59c5                 mulss    xmm0, xmm5
43360a66  f30f58c8                 addss    xmm1, xmm0
43360a6a  0f28c1                   movaps   xmm0, xmm1
43360a6d  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43360a75  f30f51c0                 sqrtss   xmm0, xmm0
43360a79  f30f118424a4000000       movss    dword ptr [esp + 0xa4], xmm0
43360a82  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43360a8a  f30f5ec8                 divss    xmm1, xmm0
43360a8e  f30f59f9                 mulss    xmm7, xmm1
43360a92  f30f59f1                 mulss    xmm6, xmm1
43360a96  f30f59e9                 mulss    xmm5, xmm1
43360a9a  0f28cf                   movaps   xmm1, xmm7
43360a9d  f30f59cf                 mulss    xmm1, xmm7
43360aa1  0f28c6                   movaps   xmm0, xmm6
43360aa4  f30f59c6                 mulss    xmm0, xmm6
43360aa8  f30f58c8                 addss    xmm1, xmm0
43360aac  0f28c5                   movaps   xmm0, xmm5
43360aaf  f30f59c5                 mulss    xmm0, xmm5
43360ab3  f30f58c8                 addss    xmm1, xmm0
43360ab7  0f28c1                   movaps   xmm0, xmm1
43360aba  f30f108c2424100000       movss    xmm1, dword ptr [esp + 0x1024]
43360ac3  f30f51c0                 sqrtss   xmm0, xmm0
43360ac7  f30f11842484000000       movss    dword ptr [esp + 0x84], xmm0
43360ad0  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43360ad8  f30f5ec8                 divss    xmm1, xmm0
43360adc  0f57c0                   xorps    xmm0, xmm0
43360adf  f30f59f9                 mulss    xmm7, xmm1
43360ae3  f30f59f1                 mulss    xmm6, xmm1
43360ae7  f30f59e9                 mulss    xmm5, xmm1
43360aeb  0f57c9                   xorps    xmm1, xmm1
43360aee  f30f11bc24a0040000       movss    dword ptr [esp + 0x4a0], xmm7
43360af7  f30f11b424a4040000       movss    dword ptr [esp + 0x4a4], xmm6
43360b00  f30f59ff                 mulss    xmm7, xmm7
43360b04  f30f59f6                 mulss    xmm6, xmm6
43360b08  f30f11ac24a8040000       movss    dword ptr [esp + 0x4a8], xmm5
43360b11  f30f59ed                 mulss    xmm5, xmm5
43360b15  f30f58fe                 addss    xmm7, xmm6
43360b19  0f298424b0040000         movaps   xmmword ptr [esp + 0x4b0], xmm0
43360b21  0f298424c0040000         movaps   xmmword ptr [esp + 0x4c0], xmm0
43360b29  f30f58fd                 addss    xmm7, xmm5
43360b2d  0f2ef9                   ucomiss  xmm7, xmm1
43360b30  9f                       lahf     
43360b31  f6c444                   test     ah, 0x44
43360b34  7a07                     jp       0x43360b3d
43360b36  889424d5040000           mov      byte ptr [esp + 0x4d5], dl
43360b3d  f30f101514054743         movss    xmm2, dword ptr [0x43470514]
43360b45  8bca                     mov      ecx, edx
43360b47  c7442424ffffff7f         mov      dword ptr [esp + 0x24], 0x7fffffff
43360b4f  8bc2                     mov      eax, edx
43360b51  f30f11542414             movss    dword ptr [esp + 0x14], xmm2
43360b57  894c2420                 mov      dword ptr [esp + 0x20], ecx
43360b5b  8954244c                 mov      dword ptr [esp + 0x4c], edx
43360b5f  8b80b0494743             mov      eax, dword ptr [eax + 0x434749b0]
43360b65  3b8424e01c0000           cmp      eax, dword ptr [esp + 0x1ce0]
43360b6c  0f83b4000000             jae      0x43360c26
43360b72  8b542424                 mov      edx, dword ptr [esp + 0x24]
43360b76  8dbc24f01c0000           lea      edi, [esp + 0x1cf0]
43360b7d  69c090000000             imul     eax, eax, 0x90
43360b83  03f8                     add      edi, eax
43360b85  8b4744                   mov      eax, dword ptr [edi + 0x44]
43360b88  83e00f                   and      eax, 0xf
43360b8b  39148570494743           cmp      dword ptr [eax*4 + 0x43474970], edx
43360b92  0f878e000000             ja       0x43360c26
43360b98  c78424040700000000803f   mov      dword ptr [esp + 0x704], 0x3f800000
43360ba3  8d8424d8060000           lea      eax, [esp + 0x6d8]
43360baa  f30f104770               movss    xmm0, dword ptr [edi + 0x70]
43360baf  8d8c2490040000           lea      ecx, [esp + 0x490]
43360bb6  0f2fc1                   comiss   xmm0, xmm1
43360bb9  50                       push     eax
43360bba  760a                     jbe      0x43360bc6
43360bbc  8d5740                   lea      edx, [edi + 0x40]
43360bbf  e845820900               call     0x433f8e09
43360bc4  eb0c                     jmp      0x43360bd2
43360bc6  8b5704                   mov      edx, dword ptr [edi + 4]
43360bc9  8d4710                   lea      eax, [edi + 0x10]
43360bcc  50                       push     eax
43360bcd  e8bcee0300               call     0x4339fa8e
43360bd2  f30f10542414             movss    xmm2, dword ptr [esp + 0x14]
43360bd8  85c0                     test     eax, eax
43360bda  782f                     js       0x43360c0b
43360bdc  0f2f942404070000         comiss   xmm2, dword ptr [esp + 0x704]
43360be4  7625                     jbe      0x43360c0b
43360be6  837f4401                 cmp      dword ptr [edi + 0x44], 1
43360bea  8bcf                     mov      ecx, edi
43360bec  f30f10942404070000       movss    xmm2, dword ptr [esp + 0x704]
43360bf5  f30f11542414             movss    dword ptr [esp + 0x14], xmm2
43360bfb  894c2420                 mov      dword ptr [esp + 0x20], ecx
43360bff  7525                     jne      0x43360c26
43360c01  c744242402000000         mov      dword ptr [esp + 0x24], 2
43360c09  eb04                     jmp      0x43360c0f
43360c0b  8b4c2420                 mov      ecx, dword ptr [esp + 0x20]
43360c0f  8b44244c                 mov      eax, dword ptr [esp + 0x4c]
43360c13  0f57c9                   xorps    xmm1, xmm1
43360c16  83c004                   add      eax, 4
43360c19  8944244c                 mov      dword ptr [esp + 0x4c], eax
43360c1d  83f83c                   cmp      eax, 0x3c
43360c20  0f8239ffffff             jb       0x43360b5f
43360c26  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
43360c2a  85c9                     test     ecx, ecx
43360c2c  0f8469010000             je       0x43360d9b
43360c32  f30f108424a0040000       movss    xmm0, dword ptr [esp + 0x4a0]
43360c3b  8b4944                   mov      ecx, dword ptr [ecx + 0x44]
43360c3e  8b442420                 mov      eax, dword ptr [esp + 0x20]
43360c42  f30f59c2                 mulss    xmm0, xmm2
43360c46  898c241c070000           mov      dword ptr [esp + 0x71c], ecx
43360c4d  83e10f                   and      ecx, 0xf
43360c50  8b00                     mov      eax, dword ptr [eax]
43360c52  f30f58842490040000       addss    xmm0, dword ptr [esp + 0x490]
43360c5b  89842428070000           mov      dword ptr [esp + 0x728], eax
43360c62  8b442430                 mov      eax, dword ptr [esp + 0x30]
43360c66  83e00f                   and      eax, 0xf
43360c69  f30f118424e4060000       movss    dword ptr [esp + 0x6e4], xmm0
43360c72  f30f108424a4040000       movss    xmm0, dword ptr [esp + 0x4a4]
43360c7b  f30f59c2                 mulss    xmm0, xmm2
43360c7f  f30f58842494040000       addss    xmm0, dword ptr [esp + 0x494]
43360c88  f30f118424e8060000       movss    dword ptr [esp + 0x6e8], xmm0
43360c91  f30f108424a8040000       movss    xmm0, dword ptr [esp + 0x4a8]
43360c9a  f30f59c2                 mulss    xmm0, xmm2
43360c9e  f30f58842498040000       addss    xmm0, dword ptr [esp + 0x498]
43360ca7  f30f118424ec060000       movss    dword ptr [esp + 0x6ec], xmm0
43360cb0  f30f10048d40454743       movss    xmm0, dword ptr [ecx*4 + 0x43474540]
43360cb9  0f2f048540454743         comiss   xmm0, dword ptr [eax*4 + 0x43474540]
43360cc1  0f82d4000000             jb       0x43360d9b
43360cc7  0f280590f24643           movaps   xmm0, xmmword ptr [0x4346f290]
43360cce  33c0                     xor      eax, eax
43360cd0  8b542440                 mov      edx, dword ptr [esp + 0x40]
43360cd4  8b0d08584743             mov      ecx, dword ptr [0x43475808]
43360cda  89842444080000           mov      dword ptr [esp + 0x844], eax
43360ce1  89842448080000           mov      dword ptr [esp + 0x848], eax
43360ce8  8984244c080000           mov      dword ptr [esp + 0x84c], eax
43360cef  8d842410100000           lea      eax, [esp + 0x1010]
43360cf6  50                       push     eax
43360cf7  8d842444080000           lea      eax, [esp + 0x844]
43360cfe  c78424640800000000803f   mov      dword ptr [esp + 0x864], 0x3f800000
43360d09  50                       push     eax
43360d0a  8d8424ec060000           lea      eax, [esp + 0x6ec]
43360d11  c784244808000004044743   mov      dword ptr [esp + 0x848], 0x43470404
43360d1c  50                       push     eax
43360d1d  0f1184245c080000         movups   xmmword ptr [esp + 0x85c], xmm0
43360d25  e80190fcff               call     0x43329d2b
43360d2a  f30f2c842418100000       cvttss2si eax, dword ptr [esp + 0x1018]
43360d33  85c0                     test     eax, eax
43360d35  7464                     je       0x43360d9b
43360d37  ffb4241c070000           push     dword ptr [esp + 0x71c]
43360d3e  8d8c2414100000           lea      ecx, [esp + 0x1014]
43360d45  ffb42494000000           push     dword ptr [esp + 0x94]
43360d4c  e87c910800               call     0x433e9ecd
43360d51  8bf8                     mov      edi, eax
43360d53  85ff                     test     edi, edi
43360d55  7444                     je       0x43360d9b
43360d57  3bbed0000000             cmp      edi, dword ptr [esi + 0xd0]
43360d5d  7c3c                     jl       0x43360d9b
43360d5f  85ff                     test     edi, edi
43360d61  7f07                     jg       0x43360d6a
43360d63  baffffff7f               mov      edx, 0x7fffffff
43360d68  eb13                     jmp      0x43360d7d
43360d6a  8b4608                   mov      eax, dword ptr [esi + 8]
43360d6d  33c9                     xor      ecx, ecx
43360d6f  48                       dec      eax
43360d70  41                       inc      ecx
43360d71  03c7                     add      eax, edi
43360d73  99                       cdq      
43360d74  f7ff                     idiv     edi
43360d76  8bd1                     mov      edx, ecx
43360d78  3bc1                     cmp      eax, ecx
43360d7a  0f4fd0                   cmovg    edx, eax
43360d7d  3b542444                 cmp      edx, dword ptr [esp + 0x44]
43360d81  7f18                     jg       0x43360d9b
43360d83  f30f10542418             movss    xmm2, dword ptr [esp + 0x18]
43360d89  f30f105c2428             movss    xmm3, dword ptr [esp + 0x28]
43360d8f  f30f1154242c             movss    dword ptr [esp + 0x2c], xmm2
43360d95  897c2434                 mov      dword ptr [esp + 0x34], edi
43360d99  eb16                     jmp      0x43360db1
43360d9b  f30f105c2418             movss    xmm3, dword ptr [esp + 0x18]
43360da1  8b7c2434                 mov      edi, dword ptr [esp + 0x34]
43360da5  f30f1054242c             movss    xmm2, dword ptr [esp + 0x2c]
43360dab  f30f115c2428             movss    dword ptr [esp + 0x28], xmm3
43360db1  836c243801               sub      dword ptr [esp + 0x38], 1
43360db6  f30f10442458             movss    xmm0, dword ptr [esp + 0x58]
43360dbc  f30f104c2448             movss    xmm1, dword ptr [esp + 0x48]
43360dc2  f30f106c2450             movss    xmm5, dword ptr [esp + 0x50]
43360dc8  8b442440                 mov      eax, dword ptr [esp + 0x40]
43360dcc  0f85cafbffff             jne      0x4336099c
43360dd2  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
43360dda  0f2ed0                   ucomiss  xmm2, xmm0
43360ddd  9f                       lahf     
43360dde  f6c444                   test     ah, 0x44
43360de1  7b67                     jnp      0x43360e4a
43360de3  f30f58d0                 addss    xmm2, xmm0
43360de7  f30f10442458             movss    xmm0, dword ptr [esp + 0x58]
43360ded  f30f591540224743         mulss    xmm2, dword ptr [0x43472240]
43360df5  f30f59c2                 mulss    xmm0, xmm2
43360df9  f30f5844246c             addss    xmm0, dword ptr [esp + 0x6c]
43360dff  f30f11460c               movss    dword ptr [esi + 0xc], xmm0
43360e04  0f28c1                   movaps   xmm0, xmm1
43360e07  f30f59c2                 mulss    xmm0, xmm2
43360e0b  0f57c9                   xorps    xmm1, xmm1
43360e0e  f30f2acf                 cvtsi2ss xmm1, edi
43360e12  f30f58442470             addss    xmm0, dword ptr [esp + 0x70]
43360e18  f30f114610               movss    dword ptr [esi + 0x10], xmm0
43360e1d  0f28c5                   movaps   xmm0, xmm5
43360e20  f30f59c2                 mulss    xmm0, xmm2
43360e24  f30f58442474             addss    xmm0, dword ptr [esp + 0x74]
43360e2a  f30f114614               movss    dword ptr [esi + 0x14], xmm0
43360e2f  f30f10463c               movss    xmm0, dword ptr [esi + 0x3c]
43360e34  f30f59c2                 mulss    xmm0, xmm2
43360e38  f30f11463c               movss    dword ptr [esi + 0x3c], xmm0
43360e3d  0f57c0                   xorps    xmm0, xmm0
43360e40  f30f2a4628               cvtsi2ss xmm0, dword ptr [esi + 0x28]
43360e45  e988000000               jmp      0x43360ed2
43360e4a  8b7e28                   mov      edi, dword ptr [esi + 0x28]
43360e4d  e993000000               jmp      0x43360ee5
43360e52  f30f10842494000000       movss    xmm0, dword ptr [esp + 0x94]
43360e5b  0f57c9                   xorps    xmm1, xmm1
43360e5e  f30f5c44246c             subss    xmm0, dword ptr [esp + 0x6c]
43360e64  f30f101540224743         movss    xmm2, dword ptr [0x43472240]
43360e6c  f30f2a4c2468             cvtsi2ss xmm1, dword ptr [esp + 0x68]
43360e72  f30f59c2                 mulss    xmm0, xmm2
43360e76  f30f5844246c             addss    xmm0, dword ptr [esp + 0x6c]
43360e7c  f30f11460c               movss    dword ptr [esi + 0xc], xmm0
43360e81  f30f10842498000000       movss    xmm0, dword ptr [esp + 0x98]
43360e8a  f30f5c442470             subss    xmm0, dword ptr [esp + 0x70]
43360e90  f30f59c2                 mulss    xmm0, xmm2
43360e94  f30f58442470             addss    xmm0, dword ptr [esp + 0x70]
43360e9a  f30f114610               movss    dword ptr [esi + 0x10], xmm0
43360e9f  f30f1084249c000000       movss    xmm0, dword ptr [esp + 0x9c]
43360ea8  f30f5c442474             subss    xmm0, dword ptr [esp + 0x74]
43360eae  f30f59c2                 mulss    xmm0, xmm2
43360eb2  f30f58442474             addss    xmm0, dword ptr [esp + 0x74]
43360eb8  f30f114614               movss    dword ptr [esi + 0x14], xmm0
43360ebd  f30f10463c               movss    xmm0, dword ptr [esi + 0x3c]
43360ec2  f30f59c2                 mulss    xmm0, xmm2
43360ec6  f30f11463c               movss    dword ptr [esi + 0x3c], xmm0
43360ecb  0f57c0                   xorps    xmm0, xmm0
43360ece  f30f2ac2                 cvtsi2ss xmm0, edx
43360ed2  f30f5cc1                 subss    xmm0, xmm1
43360ed6  f30f59c2                 mulss    xmm0, xmm2
43360eda  f30f58c1                 addss    xmm0, xmm1
43360ede  f30f2cf8                 cvttss2si edi, xmm0
43360ee2  897e28                   mov      dword ptr [esi + 0x28], edi
43360ee5  8b4508                   mov      eax, dword ptr [ebp + 8]
43360ee8  6a1f                     push     0x1f
43360eea  59                       pop      ecx
43360eeb  3988d8000000             cmp      dword ptr [eax + 0xd8], ecx
43360ef1  7508                     jne      0x43360efb
43360ef3  0f57c0                   xorps    xmm0, xmm0
43360ef6  e985000000               jmp      0x43360f80
43360efb  8b4608                   mov      eax, dword ptr [esi + 8]
43360efe  85ff                     test     edi, edi
43360f00  7f07                     jg       0x43360f09
43360f02  baffffff7f               mov      edx, 0x7fffffff
43360f07  eb10                     jmp      0x43360f19
43360f09  48                       dec      eax
43360f0a  33c9                     xor      ecx, ecx
43360f0c  03c7                     add      eax, edi
43360f0e  41                       inc      ecx
43360f0f  99                       cdq      
43360f10  f7ff                     idiv     edi
43360f12  8bd1                     mov      edx, ecx
43360f14  3bc1                     cmp      eax, ecx
43360f16  0f4fd0                   cmovg    edx, eax
43360f19  8b4630                   mov      eax, dword ptr [esi + 0x30]
43360f1c  660f6e4e08               movd     xmm1, dword ptr [esi + 8]
43360f21  83e00f                   and      eax, 0xf
43360f24  660f6ec7                 movd     xmm0, edi
43360f28  0f5bc0                   cvtdq2ps xmm0, xmm0
43360f2b  660f6ed2                 movd     xmm2, edx
43360f2f  f30f5e048540454743       divss    xmm0, dword ptr [eax*4 + 0x43474540]
43360f38  0f5bc9                   cvtdq2ps xmm1, xmm1
43360f3b  0f5bd2                   cvtdq2ps xmm2, xmm2
43360f3e  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
43360f44  660f6e86d0000000         movd     xmm0, dword ptr [esi + 0xd0]
43360f4c  f30f5eca                 divss    xmm1, xmm2
43360f50  0f5bc0                   cvtdq2ps xmm0, xmm0
43360f53  e8ddecfcff               call     0x4332fc35
43360f58  f30f104c2430             movss    xmm1, dword ptr [esp + 0x30]
43360f5e  0f2e0d6cee4643           ucomiss  xmm1, dword ptr [0x4346ee6c]
43360f65  9f                       lahf     
43360f66  f6c444                   test     ah, 0x44
43360f69  7b06                     jnp      0x43360f71
43360f6b  f30f5ec1                 divss    xmm0, xmm1
43360f6f  eb0f                     jmp      0x43360f80
43360f71  8b4630                   mov      eax, dword ptr [esi + 0x30]
43360f74  83e00f                   and      eax, 0xf
43360f77  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
43360f80  8b7d08                   mov      edi, dword ptr [ebp + 8]
43360f83  8d9424680e0000           lea      edx, [esp + 0xe68]
43360f8a  f30f11442420             movss    dword ptr [esp + 0x20], xmm0
43360f90  8b4f0c                   mov      ecx, dword ptr [edi + 0xc]
43360f93  e8b57c0600               call     0x433c8c4d
43360f98  f30f10660c               movss    xmm4, dword ptr [esi + 0xc]
43360f9d  81c7dc000000             add      edi, 0xdc
43360fa3  f30f105e10               movss    xmm3, dword ptr [esi + 0x10]
43360fa8  33d2                     xor      edx, edx
43360faa  f30f105614               movss    xmm2, dword ptr [esi + 0x14]
43360faf  42                       inc      edx
43360fb0  f30f102d14054743         movss    xmm5, dword ptr [0x43470514]
43360fb8  0f28fd                   movaps   xmm7, xmm5
43360fbb  8b4630                   mov      eax, dword ptr [esi + 0x30]
43360fbe  f30f5c27                 subss    xmm4, dword ptr [edi]
43360fc2  f30f5c5f04               subss    xmm3, dword ptr [edi + 4]
43360fc7  f30f5c5708               subss    xmm2, dword ptr [edi + 8]
43360fcc  897c2454                 mov      dword ptr [esp + 0x54], edi
43360fd0  8944247c                 mov      dword ptr [esp + 0x7c], eax
43360fd4  0f28cc                   movaps   xmm1, xmm4
43360fd7  0f28c3                   movaps   xmm0, xmm3
43360fda  f30f59cc                 mulss    xmm1, xmm4
43360fde  f30f59c3                 mulss    xmm0, xmm3
43360fe2  f30f58c8                 addss    xmm1, xmm0
43360fe6  0f28c2                   movaps   xmm0, xmm2
43360fe9  f30f59c2                 mulss    xmm0, xmm2
43360fed  f30f58c8                 addss    xmm1, xmm0
43360ff1  0f28c1                   movaps   xmm0, xmm1
43360ff4  f30f108c24700e0000       movss    xmm1, dword ptr [esp + 0xe70]
43360ffd  f30f51c0                 sqrtss   xmm0, xmm0
43361001  f30f1184246c030000       movss    dword ptr [esp + 0x36c], xmm0
4336100a  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43361012  f30f5ef8                 divss    xmm7, xmm0
43361016  0f28c7                   movaps   xmm0, xmm7
43361019  0f28f7                   movaps   xmm6, xmm7
4336101c  f30f59c4                 mulss    xmm0, xmm4
43361020  f30f59f3                 mulss    xmm6, xmm3
43361024  f30f59fa                 mulss    xmm7, xmm2
43361028  f30f11442418             movss    dword ptr [esp + 0x18], xmm0
4336102e  f30f11742460             movss    dword ptr [esp + 0x60], xmm6
43361034  f30f117c2450             movss    dword ptr [esp + 0x50], xmm7
4336103a  845634                   test     byte ptr [esi + 0x34], dl
4336103d  0f84a7050000             je       0x433615ea
43361043  33c9                     xor      ecx, ecx
43361045  f30f114c2430             movss    dword ptr [esp + 0x30], xmm1
4336104b  0f57ed                   xorps    xmm5, xmm5
4336104e  894c2434                 mov      dword ptr [esp + 0x34], ecx
43361052  0f2ec5                   ucomiss  xmm0, xmm5
43361055  9f                       lahf     
43361056  f6c444                   test     ah, 0x44
43361059  7a66                     jp       0x433610c1
4336105b  0f2ef5                   ucomiss  xmm6, xmm5
4336105e  9f                       lahf     
4336105f  f6c444                   test     ah, 0x44
43361062  7a5d                     jp       0x433610c1
43361064  0f57c9                   xorps    xmm1, xmm1
43361067  0f57d2                   xorps    xmm2, xmm2
4336106a  f30f114c2414             movss    dword ptr [esp + 0x14], xmm1
43361070  0f28f7                   movaps   xmm6, xmm7
43361073  0f5735d0034743           xorps    xmm6, xmmword ptr [0x434703d0]
4336107a  f30f118c24c0000000       movss    dword ptr [esp + 0xc0], xmm1
43361083  f30f108c2488000000       movss    xmm1, dword ptr [esp + 0x88]
4336108c  f30f114c2444             movss    dword ptr [esp + 0x44], xmm1
43361092  f30f118c24c4000000       movss    dword ptr [esp + 0xc4], xmm1
4336109b  0f57c9                   xorps    xmm1, xmm1
4336109e  f30f1154242c             movss    dword ptr [esp + 0x2c], xmm2
433610a4  f30f119424c8000000       movss    dword ptr [esp + 0xc8], xmm2
433610ad  f30f114c2424             movss    dword ptr [esp + 0x24], xmm1
433610b3  f30f118c24d0000000       movss    dword ptr [esp + 0xd0], xmm1
433610bc  e959010000               jmp      0x4336121a
433610c1  0f28d8                   movaps   xmm3, xmm0
433610c4  0f28e7                   movaps   xmm4, xmm7
433610c7  f30f59e5                 mulss    xmm4, xmm5
433610cb  0f28d6                   movaps   xmm2, xmm6
433610ce  f30f59dd                 mulss    xmm3, xmm5
433610d2  f30f5cd4                 subss    xmm2, xmm4
433610d6  f30f5ce0                 subss    xmm4, xmm0
433610da  0f28c6                   movaps   xmm0, xmm6
433610dd  f30f59c5                 mulss    xmm0, xmm5
433610e1  f30f103514054743         movss    xmm6, dword ptr [0x43470514]
433610e9  0f28ca                   movaps   xmm1, xmm2
433610ec  f30f5cd8                 subss    xmm3, xmm0
433610f0  f30f59ca                 mulss    xmm1, xmm2
433610f4  0f28c4                   movaps   xmm0, xmm4
433610f7  f30f59c4                 mulss    xmm0, xmm4
433610fb  f30f58c8                 addss    xmm1, xmm0
433610ff  0f28c3                   movaps   xmm0, xmm3
43361102  f30f59c3                 mulss    xmm0, xmm3
43361106  f30f58c8                 addss    xmm1, xmm0
4336110a  0f28c1                   movaps   xmm0, xmm1
4336110d  f30f104c2460             movss    xmm1, dword ptr [esp + 0x60]
43361113  f30f51c0                 sqrtss   xmm0, xmm0
43361117  f30f11842498010000       movss    dword ptr [esp + 0x198], xmm0
43361120  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43361128  f30f5ef0                 divss    xmm6, xmm0
4336112c  0f28c6                   movaps   xmm0, xmm6
4336112f  f30f59c2                 mulss    xmm0, xmm2
43361133  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
43361139  f30f10542414             movss    xmm2, dword ptr [esp + 0x14]
4336113f  f30f118424c0000000       movss    dword ptr [esp + 0xc0], xmm0
43361148  0f28c6                   movaps   xmm0, xmm6
4336114b  f30f59c4                 mulss    xmm0, xmm4
4336114f  f30f59f3                 mulss    xmm6, xmm3
43361153  f30f105c2418             movss    xmm3, dword ptr [esp + 0x18]
43361159  0f28e0                   movaps   xmm4, xmm0
4336115c  f30f11442444             movss    dword ptr [esp + 0x44], xmm0
43361162  f30f118424c4000000       movss    dword ptr [esp + 0xc4], xmm0
4336116b  0f28c6                   movaps   xmm0, xmm6
4336116e  f30f59c1                 mulss    xmm0, xmm1
43361172  f30f59e7                 mulss    xmm4, xmm7
43361176  f30f59de                 mulss    xmm3, xmm6
4336117a  f30f5ce0                 subss    xmm4, xmm0
4336117e  f30f1174242c             movss    dword ptr [esp + 0x2c], xmm6
43361184  0f28c2                   movaps   xmm0, xmm2
43361187  f30f11b424c8000000       movss    dword ptr [esp + 0xc8], xmm6
43361190  f30f59c7                 mulss    xmm0, xmm7
43361194  f30f59d1                 mulss    xmm2, xmm1
43361198  f30f5cd8                 subss    xmm3, xmm0
4336119c  0f28cc                   movaps   xmm1, xmm4
4336119f  f30f10442418             movss    xmm0, dword ptr [esp + 0x18]
433611a5  f30f59442444             mulss    xmm0, dword ptr [esp + 0x44]
433611ab  f30f59cc                 mulss    xmm1, xmm4
433611af  f30f5cd0                 subss    xmm2, xmm0
433611b3  0f28c3                   movaps   xmm0, xmm3
433611b6  f30f59c3                 mulss    xmm0, xmm3
433611ba  f30f58c8                 addss    xmm1, xmm0
433611be  0f28c2                   movaps   xmm0, xmm2
433611c1  f30f59c2                 mulss    xmm0, xmm2
433611c5  f30f58c8                 addss    xmm1, xmm0
433611c9  0f28c1                   movaps   xmm0, xmm1
433611cc  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
433611d4  f30f51c0                 sqrtss   xmm0, xmm0
433611d8  f30f1184249c010000       movss    dword ptr [esp + 0x19c], xmm0
433611e1  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433611e9  f30f5ec8                 divss    xmm1, xmm0
433611ed  f30f10442418             movss    xmm0, dword ptr [esp + 0x18]
433611f3  0f28f1                   movaps   xmm6, xmm1
433611f6  f30f59f4                 mulss    xmm6, xmm4
433611fa  0f28e1                   movaps   xmm4, xmm1
433611fd  f30f59e3                 mulss    xmm4, xmm3
43361201  f30f59ca                 mulss    xmm1, xmm2
43361205  f30f1054242c             movss    xmm2, dword ptr [esp + 0x2c]
4336120b  f30f11642424             movss    dword ptr [esp + 0x24], xmm4
43361211  f30f11a424d0000000       movss    dword ptr [esp + 0xd0], xmm4
4336121a  8b842480000000           mov      eax, dword ptr [esp + 0x80]
43361221  051c110000               add      eax, 0x111c
43361226  f30f118c24d4000000       movss    dword ptr [esp + 0xd4], xmm1
4336122f  8bf0                     mov      esi, eax
43361231  f30f114c244c             movss    dword ptr [esp + 0x4c], xmm1
43361237  f30f11b424cc000000       movss    dword ptr [esp + 0xcc], xmm6
43361240  f30f11742448             movss    dword ptr [esp + 0x48], xmm6
43361246  89842480000000           mov      dword ptr [esp + 0x80], eax
4336124d  89742440                 mov      dword ptr [esp + 0x40], esi
43361251  c744245820000000         mov      dword ptr [esp + 0x58], 0x20
43361259  eb03                     jmp      0x4336125e
4336125b  0f57ed                   xorps    xmm5, xmm5
4336125e  f30f1026                 movss    xmm4, dword ptr [esi]
43361262  0f28dc                   movaps   xmm3, xmm4
43361265  f30f104e04               movss    xmm1, dword ptr [esi + 4]
4336126a  f30f595c2414             mulss    xmm3, dword ptr [esp + 0x14]
43361270  f30f58d8                 addss    xmm3, xmm0
43361274  0f28c1                   movaps   xmm0, xmm1
43361277  f30f59c6                 mulss    xmm0, xmm6
4336127b  0f28f4                   movaps   xmm6, xmm4
4336127e  f30f59742444             mulss    xmm6, dword ptr [esp + 0x44]
43361284  f30f58d8                 addss    xmm3, xmm0
43361288  0f28c1                   movaps   xmm0, xmm1
4336128b  f30f59442424             mulss    xmm0, dword ptr [esp + 0x24]
43361291  f30f58742460             addss    xmm6, dword ptr [esp + 0x60]
43361297  f30f594c244c             mulss    xmm1, dword ptr [esp + 0x4c]
4336129d  f30f59e2                 mulss    xmm4, xmm2
433612a1  f30f58f0                 addss    xmm6, xmm0
433612a5  f30f58e7                 addss    xmm4, xmm7
433612a9  0f28c6                   movaps   xmm0, xmm6
433612ac  f30f59c6                 mulss    xmm0, xmm6
433612b0  f30f58e1                 addss    xmm4, xmm1
433612b4  0f28cb                   movaps   xmm1, xmm3
433612b7  f30f59cb                 mulss    xmm1, xmm3
433612bb  f30f58c8                 addss    xmm1, xmm0
433612bf  0f28c4                   movaps   xmm0, xmm4
433612c2  f30f59c4                 mulss    xmm0, xmm4
433612c6  f30f58c8                 addss    xmm1, xmm0
433612ca  0f28c1                   movaps   xmm0, xmm1
433612cd  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
433612d5  f30f51c0                 sqrtss   xmm0, xmm0
433612d9  f30f11842480010000       movss    dword ptr [esp + 0x180], xmm0
433612e2  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433612ea  f30f5ec8                 divss    xmm1, xmm0
433612ee  f30f10442430             movss    xmm0, dword ptr [esp + 0x30]
433612f4  f30f59d9                 mulss    xmm3, xmm1
433612f8  f30f59f1                 mulss    xmm6, xmm1
433612fc  f30f59e1                 mulss    xmm4, xmm1
43361300  f30f59d8                 mulss    xmm3, xmm0
43361304  f30f59f0                 mulss    xmm6, xmm0
43361308  f30f59e0                 mulss    xmm4, xmm0
4336130c  3954247c                 cmp      dword ptr [esp + 0x7c], edx
43361310  0f842a010000             je       0x43361440
43361316  8bf7                     mov      esi, edi
43361318  894c2438                 mov      dword ptr [esp + 0x38], ecx
4336131c  8dbc24d4070000           lea      edi, [esp + 0x7d4]
43361323  8d9424a0270000           lea      edx, [esp + 0x27a0]
4336132a  89542428                 mov      dword ptr [esp + 0x28], edx
4336132e  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336132f  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43361330  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43361331  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
43361335  f30f104f04               movss    xmm1, dword ptr [edi + 4]
4336133a  f30f105708               movss    xmm2, dword ptr [edi + 8]
4336133f  f30f58ce                 addss    xmm1, xmm6
43361343  f30f1007                 movss    xmm0, dword ptr [edi]
43361347  f30f58d4                 addss    xmm2, xmm4
4336134b  f30f58c3                 addss    xmm0, xmm3
4336134f  f30f118c24e4070000       movss    dword ptr [esp + 0x7e4], xmm1
43361358  f30f119424e8070000       movss    dword ptr [esp + 0x7e8], xmm2
43361361  f30f118424e0070000       movss    dword ptr [esp + 0x7e0], xmm0
4336136a  8bc1                     mov      eax, ecx
4336136c  8944241c                 mov      dword ptr [esp + 0x1c], eax
43361370  390a                     cmp      dword ptr [edx], ecx
43361372  7659                     jbe      0x433613cd
43361374  8db280000000             lea      esi, [edx + 0x80]
4336137a  f30f1006                 movss    xmm0, dword ptr [esi]
4336137e  0f2fc5                   comiss   xmm0, xmm5
43361381  7639                     jbe      0x433613bc
43361383  8b46d4                   mov      eax, dword ptr [esi - 0x2c]
43361386  83e00f                   and      eax, 0xf
43361389  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
43361392  0f2f442420               comiss   xmm0, dword ptr [esp + 0x20]
43361397  721f                     jb       0x433613b8
43361399  8d4ed8                   lea      ecx, [esi - 0x28]
4336139c  8d9424d4070000           lea      edx, [esp + 0x7d4]
433613a3  e83ab80300               call     0x4339cbe2
433613a8  f30f100e                 movss    xmm1, dword ptr [esi]
433613ac  0f2fc8                   comiss   xmm1, xmm0
433613af  8b542428                 mov      edx, dword ptr [esp + 0x28]
433613b3  7365                     jae      0x4336141a
433613b5  0f57ed                   xorps    xmm5, xmm5
433613b8  8b44241c                 mov      eax, dword ptr [esp + 0x1c]
433613bc  40                       inc      eax
433613bd  81c690000000             add      esi, 0x90
433613c3  8944241c                 mov      dword ptr [esp + 0x1c], eax
433613c7  3b02                     cmp      eax, dword ptr [edx]
433613c9  72af                     jb       0x4336137a
433613cb  33c9                     xor      ecx, ecx
433613cd  33d2                     xor      edx, edx
433613cf  884c243f                 mov      byte ptr [esp + 0x3f], cl
433613d3  42                       inc      edx
433613d4  8b742434                 mov      esi, dword ptr [esp + 0x34]
433613d8  807c243f00               cmp      byte ptr [esp + 0x3f], 0
433613dd  f30f107c2450             movss    xmm7, dword ptr [esp + 0x50]
433613e3  f30f1054242c             movss    xmm2, dword ptr [esp + 0x2c]
433613e9  f30f10442418             movss    xmm0, dword ptr [esp + 0x18]
433613ef  8d4601                   lea      eax, [esi + 1]
433613f2  f30f10742448             movss    xmm6, dword ptr [esp + 0x48]
433613f8  0f44c6                   cmove    eax, esi
433613fb  8b742440                 mov      esi, dword ptr [esp + 0x40]
433613ff  83c620                   add      esi, 0x20
43361402  89442434                 mov      dword ptr [esp + 0x34], eax
43361406  836c245801               sub      dword ptr [esp + 0x58], 1
4336140b  89742440                 mov      dword ptr [esp + 0x40], esi
4336140f  0f8546feffff             jne      0x4336125b
43361415  e966070000               jmp      0x43361b80
4336141a  8b742438                 mov      esi, dword ptr [esp + 0x38]
4336141e  81c2c00a0000             add      edx, 0xac0
43361424  46                       inc      esi
43361425  89542428                 mov      dword ptr [esp + 0x28], edx
43361429  89742438                 mov      dword ptr [esp + 0x38], esi
4336142d  83fe03                   cmp      esi, 3
43361430  0f8da6010000             jge      0x433615dc
43361436  0f57ed                   xorps    xmm5, xmm5
43361439  33c9                     xor      ecx, ecx
4336143b  e92affffff               jmp      0x4336136a
43361440  f30f1007                 movss    xmm0, dword ptr [edi]
43361444  f30f104f04               movss    xmm1, dword ptr [edi + 4]
43361449  f30f105708               movss    xmm2, dword ptr [edi + 8]
4336144e  f30f119c24300b0000       movss    dword ptr [esp + 0xb30], xmm3
43361457  f30f11b424340b0000       movss    dword ptr [esp + 0xb34], xmm6
43361460  f30f59db                 mulss    xmm3, xmm3
43361464  898c24600b0000           mov      dword ptr [esp + 0xb60], ecx
4336146b  f30f59f6                 mulss    xmm6, xmm6
4336146f  889424640b0000           mov      byte ptr [esp + 0xb64], dl
43361476  f30f11a424380b0000       movss    dword ptr [esp + 0xb38], xmm4
4336147f  f30f59e4                 mulss    xmm4, xmm4
43361483  889424650b0000           mov      byte ptr [esp + 0xb65], dl
4336148a  f30f58de                 addss    xmm3, xmm6
4336148e  f30f118424200b0000       movss    dword ptr [esp + 0xb20], xmm0
43361497  0f57c0                   xorps    xmm0, xmm0
4336149a  f30f118c24240b0000       movss    dword ptr [esp + 0xb24], xmm1
433614a3  f30f119424280b0000       movss    dword ptr [esp + 0xb28], xmm2
433614ac  0f298424400b0000         movaps   xmmword ptr [esp + 0xb40], xmm0
433614b4  0f298424500b0000         movaps   xmmword ptr [esp + 0xb50], xmm0
433614bc  f30f58dc                 addss    xmm3, xmm4
433614c0  0f2edd                   ucomiss  xmm3, xmm5
433614c3  9f                       lahf     
433614c4  f6c444                   test     ah, 0x44
433614c7  7a07                     jp       0x433614d0
433614c9  888c24650b0000           mov      byte ptr [esp + 0xb65], cl
433614d0  894c2438                 mov      dword ptr [esp + 0x38], ecx
433614d4  8db424b4270000           lea      esi, [esp + 0x27b4]
433614db  838c248c0d0000ff         or       dword ptr [esp + 0xd8c], 0xffffffff
433614e3  8d8424480d0000           lea      eax, [esp + 0xd48]
433614ea  838c24980d0000ff         or       dword ptr [esp + 0xd98], 0xffffffff
433614f2  50                       push     eax
433614f3  898c24980d0000           mov      dword ptr [esp + 0xd98], ecx
433614fa  8d460c                   lea      eax, [esi + 0xc]
433614fd  c78424780d00000000803f   mov      dword ptr [esp + 0xd78], 0x3f800000
43361508  8d8c24240b0000           lea      ecx, [esp + 0xb24]
4336150f  66c78424820d00000000     mov      word ptr [esp + 0xd82], 0
43361519  8b16                     mov      edx, dword ptr [esi]
4336151b  50                       push     eax
4336151c  e86de50300               call     0x4339fa8e
43361521  85c0                     test     eax, eax
43361523  0f88a2feffff             js       0x433613cb
43361529  f30f108424740d0000       movss    xmm0, dword ptr [esp + 0xd74]
43361532  33c9                     xor      ecx, ecx
43361534  8bc1                     mov      eax, ecx
43361536  f30f11442468             movss    dword ptr [esp + 0x68], xmm0
4336153c  8944241c                 mov      dword ptr [esp + 0x1c], eax
43361540  394eec                   cmp      dword ptr [esi - 0x14], ecx
43361543  767f                     jbe      0x433615c4
43361545  8bce                     mov      ecx, esi
43361547  0f57c9                   xorps    xmm1, xmm1
4336154a  894c2428                 mov      dword ptr [esp + 0x28], ecx
4336154e  8b11                     mov      edx, dword ptr [ecx]
43361550  f30f104230               movss    xmm0, dword ptr [edx + 0x30]
43361555  0f2fc1                   comiss   xmm0, xmm1
43361558  7654                     jbe      0x433615ae
4336155a  837a0403                 cmp      dword ptr [edx + 4], 3
4336155e  7406                     je       0x43361566
43361560  837a0402                 cmp      dword ptr [edx + 4], 2
43361564  7548                     jne      0x433615ae
43361566  8d8424480d0000           lea      eax, [esp + 0xd48]
4336156d  c78424740d00000000803f   mov      dword ptr [esp + 0xd74], 0x3f800000
43361578  8b11                     mov      edx, dword ptr [ecx]
4336157a  50                       push     eax
4336157b  8d410c                   lea      eax, [ecx + 0xc]
4336157e  50                       push     eax
4336157f  8d8c24280b0000           lea      ecx, [esp + 0xb28]
43361586  e803e50300               call     0x4339fa8e
4336158b  85c0                     test     eax, eax
4336158d  7814                     js       0x433615a3
4336158f  f30f10442468             movss    xmm0, dword ptr [esp + 0x68]
43361595  0f2f8424740d0000         comiss   xmm0, dword ptr [esp + 0xd74]
4336159d  0f8728feffff             ja       0x433613cb
433615a3  8b44241c                 mov      eax, dword ptr [esp + 0x1c]
433615a7  0f57c9                   xorps    xmm1, xmm1
433615aa  8b4c2428                 mov      ecx, dword ptr [esp + 0x28]
433615ae  40                       inc      eax
433615af  81c190000000             add      ecx, 0x90
433615b5  8944241c                 mov      dword ptr [esp + 0x1c], eax
433615b9  894c2428                 mov      dword ptr [esp + 0x28], ecx
433615bd  3b46ec                   cmp      eax, dword ptr [esi - 0x14]
433615c0  728c                     jb       0x4336154e
433615c2  33c9                     xor      ecx, ecx
433615c4  8b442438                 mov      eax, dword ptr [esp + 0x38]
433615c8  81c6c00a0000             add      esi, 0xac0
433615ce  40                       inc      eax
433615cf  89442438                 mov      dword ptr [esp + 0x38], eax
433615d3  83f803                   cmp      eax, 3
433615d6  0f8cfffeffff             jl       0x433614db
433615dc  33d2                     xor      edx, edx
433615de  42                       inc      edx
433615df  33c9                     xor      ecx, ecx
433615e1  8854243f                 mov      byte ptr [esp + 0x3f], dl
433615e5  e9eafdffff               jmp      0x433613d4
433615ea  f30f114c2430             movss    dword ptr [esp + 0x30], xmm1
433615f0  0f57c9                   xorps    xmm1, xmm1
433615f3  0f2ec1                   ucomiss  xmm0, xmm1
433615f6  9f                       lahf     
433615f7  f6c444                   test     ah, 0x44
433615fa  7a75                     jp       0x43361671
433615fc  0f2ef1                   ucomiss  xmm6, xmm1
433615ff  9f                       lahf     
43361600  f6c444                   test     ah, 0x44
43361603  7a6c                     jp       0x43361671
43361605  0f57c0                   xorps    xmm0, xmm0
43361608  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
4336160e  f30f118424cc000000       movss    dword ptr [esp + 0xcc], xmm0
43361617  f30f10842488000000       movss    xmm0, dword ptr [esp + 0x88]
43361620  f30f11442444             movss    dword ptr [esp + 0x44], xmm0
43361626  f30f118424d0000000       movss    dword ptr [esp + 0xd0], xmm0
4336162f  0f57c0                   xorps    xmm0, xmm0
43361632  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
43361638  f30f118424d4000000       movss    dword ptr [esp + 0xd4], xmm0
43361641  0f28c7                   movaps   xmm0, xmm7
43361644  0f5705d0034743           xorps    xmm0, xmmword ptr [0x434703d0]
4336164b  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
43361651  f30f118424c0000000       movss    dword ptr [esp + 0xc0], xmm0
4336165a  0f57c0                   xorps    xmm0, xmm0
4336165d  f30f11442440             movss    dword ptr [esp + 0x40], xmm0
43361663  f30f118424c8000000       movss    dword ptr [esp + 0xc8], xmm0
4336166c  e954010000               jmp      0x433617c5
43361671  0f28d8                   movaps   xmm3, xmm0
43361674  0f28e7                   movaps   xmm4, xmm7
43361677  f30f59e1                 mulss    xmm4, xmm1
4336167b  0f28d6                   movaps   xmm2, xmm6
4336167e  f30f59d9                 mulss    xmm3, xmm1
43361682  f30f5cd4                 subss    xmm2, xmm4
43361686  f30f5ce0                 subss    xmm4, xmm0
4336168a  0f28c6                   movaps   xmm0, xmm6
4336168d  f30f59c1                 mulss    xmm0, xmm1
43361691  0f28ca                   movaps   xmm1, xmm2
43361694  f30f5cd8                 subss    xmm3, xmm0
43361698  f30f59ca                 mulss    xmm1, xmm2
4336169c  0f28c4                   movaps   xmm0, xmm4
4336169f  f30f59c4                 mulss    xmm0, xmm4
433616a3  f30f58c8                 addss    xmm1, xmm0
433616a7  0f28c3                   movaps   xmm0, xmm3
433616aa  f30f59c3                 mulss    xmm0, xmm3
433616ae  f30f58c8                 addss    xmm1, xmm0
433616b2  0f28c1                   movaps   xmm0, xmm1
433616b5  0f28cd                   movaps   xmm1, xmm5
433616b8  f30f51c0                 sqrtss   xmm0, xmm0
433616bc  f30f11842480010000       movss    dword ptr [esp + 0x180], xmm0
433616c5  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433616cd  f30f5ec8                 divss    xmm1, xmm0
433616d1  0f28c1                   movaps   xmm0, xmm1
433616d4  f30f59c2                 mulss    xmm0, xmm2
433616d8  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
433616de  f30f118424cc000000       movss    dword ptr [esp + 0xcc], xmm0
433616e7  0f28c1                   movaps   xmm0, xmm1
433616ea  f30f59c4                 mulss    xmm0, xmm4
433616ee  f30f59cb                 mulss    xmm1, xmm3
433616f2  f30f105c2418             movss    xmm3, dword ptr [esp + 0x18]
433616f8  0f28e0                   movaps   xmm4, xmm0
433616fb  f30f11442444             movss    dword ptr [esp + 0x44], xmm0
43361701  f30f118424d0000000       movss    dword ptr [esp + 0xd0], xmm0
4336170a  0f28c1                   movaps   xmm0, xmm1
4336170d  f30f59c6                 mulss    xmm0, xmm6
43361711  f30f59d9                 mulss    xmm3, xmm1
43361715  f30f114c2438             movss    dword ptr [esp + 0x38], xmm1
4336171b  f30f118c24d4000000       movss    dword ptr [esp + 0xd4], xmm1
43361724  f30f104c2414             movss    xmm1, dword ptr [esp + 0x14]
4336172a  f30f59e7                 mulss    xmm4, xmm7
4336172e  0f28d1                   movaps   xmm2, xmm1
43361731  f30f59d6                 mulss    xmm2, xmm6
43361735  f30f5ce0                 subss    xmm4, xmm0
43361739  0f28c1                   movaps   xmm0, xmm1
4336173c  f30f59c7                 mulss    xmm0, xmm7
43361740  f30f5cd8                 subss    xmm3, xmm0
43361744  0f28cc                   movaps   xmm1, xmm4
43361747  f30f10442418             movss    xmm0, dword ptr [esp + 0x18]
4336174d  f30f59442444             mulss    xmm0, dword ptr [esp + 0x44]
43361753  f30f59cc                 mulss    xmm1, xmm4
43361757  f30f5cd0                 subss    xmm2, xmm0
4336175b  0f28c3                   movaps   xmm0, xmm3
4336175e  f30f59c3                 mulss    xmm0, xmm3
43361762  f30f58c8                 addss    xmm1, xmm0
43361766  0f28c2                   movaps   xmm0, xmm2
43361769  f30f59c2                 mulss    xmm0, xmm2
4336176d  f30f58c8                 addss    xmm1, xmm0
43361771  0f28c1                   movaps   xmm0, xmm1
43361774  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4336177c  f30f51c0                 sqrtss   xmm0, xmm0
43361780  f30f1184249c010000       movss    dword ptr [esp + 0x19c], xmm0
43361789  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43361791  f30f5ec8                 divss    xmm1, xmm0
43361795  0f28c1                   movaps   xmm0, xmm1
43361798  f30f59c4                 mulss    xmm0, xmm4
4336179c  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
433617a2  f30f118424c0000000       movss    dword ptr [esp + 0xc0], xmm0
433617ab  0f28c1                   movaps   xmm0, xmm1
433617ae  f30f59ca                 mulss    xmm1, xmm2
433617b2  f30f59c3                 mulss    xmm0, xmm3
433617b6  f30f114c2440             movss    dword ptr [esp + 0x40], xmm1
433617bc  f30f118c24c8000000       movss    dword ptr [esp + 0xc8], xmm1
433617c5  8b8c2490000000           mov      ecx, dword ptr [esp + 0x90]
433617cc  8364243400               and      dword ptr [esp + 0x34], 0
433617d1  83c108                   add      ecx, 8
433617d4  f30f118424c4000000       movss    dword ptr [esp + 0xc4], xmm0
433617dd  f30f1144244c             movss    dword ptr [esp + 0x4c], xmm0
433617e3  8b01                     mov      eax, dword ptr [ecx]
433617e5  ff5028                   call     dword ptr [eax + 0x28]
433617e8  85c0                     test     eax, eax
433617ea  750c                     jne      0x433617f8
433617ec  2031                     and      byte ptr [ecx], dh
433617ee  e8bc7baa82               call     0xc5e093af
433617f3  ef                       out      dx, eax
433617f4  f5                       cmc      
433617f5  0d05688bc8               or       eax, 0xc88b6805
433617f8  8bc8                     mov      ecx, eax
433617fa  e82c720500               call     0x433b8a2b
433617ff  8b842480000000           mov      eax, dword ptr [esp + 0x80]
43361806  0f57ff                   xorps    xmm7, xmm7
43361809  051c110000               add      eax, 0x111c
4336180e  c744246420000000         mov      dword ptr [esp + 0x64], 0x20
43361816  8bc8                     mov      ecx, eax
43361818  89842480000000           mov      dword ptr [esp + 0x80], eax
4336181f  894c2478                 mov      dword ptr [esp + 0x78], ecx
43361823  f30f10642414             movss    xmm4, dword ptr [esp + 0x14]
43361829  f30f5921                 mulss    xmm4, dword ptr [ecx]
4336182d  f30f10442424             movss    xmm0, dword ptr [esp + 0x24]
43361833  f30f594104               mulss    xmm0, dword ptr [ecx + 4]
43361838  f30f58642418             addss    xmm4, dword ptr [esp + 0x18]
4336183e  f30f106c2444             movss    xmm5, dword ptr [esp + 0x44]
43361844  f30f5929                 mulss    xmm5, dword ptr [ecx]
43361848  f30f10542438             movss    xmm2, dword ptr [esp + 0x38]
4336184e  f30f5911                 mulss    xmm2, dword ptr [ecx]
43361852  f30f58e0                 addss    xmm4, xmm0
43361856  f30f586c2460             addss    xmm5, dword ptr [esp + 0x60]
4336185c  f30f1044244c             movss    xmm0, dword ptr [esp + 0x4c]
43361862  f30f594104               mulss    xmm0, dword ptr [ecx + 4]
43361867  f30f58542450             addss    xmm2, dword ptr [esp + 0x50]
4336186d  0f28cc                   movaps   xmm1, xmm4
43361870  f30f103514054743         movss    xmm6, dword ptr [0x43470514]
43361878  f30f58e8                 addss    xmm5, xmm0
4336187c  f30f59cc                 mulss    xmm1, xmm4
43361880  f30f10442440             movss    xmm0, dword ptr [esp + 0x40]
43361886  f30f594104               mulss    xmm0, dword ptr [ecx + 4]
4336188b  33c9                     xor      ecx, ecx
4336188d  f30f58d0                 addss    xmm2, xmm0
43361891  0f28c5                   movaps   xmm0, xmm5
43361894  f30f59c5                 mulss    xmm0, xmm5
43361898  f30f58c8                 addss    xmm1, xmm0
4336189c  0f28c2                   movaps   xmm0, xmm2
4336189f  f30f59c2                 mulss    xmm0, xmm2
433618a3  f30f58c8                 addss    xmm1, xmm0
433618a7  0f28c1                   movaps   xmm0, xmm1
433618aa  f30f51c0                 sqrtss   xmm0, xmm0
433618ae  f30f11842498010000       movss    dword ptr [esp + 0x198], xmm0
433618b7  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433618bf  f30f5ef0                 divss    xmm6, xmm0
433618c3  0f28de                   movaps   xmm3, xmm6
433618c6  f30f59dc                 mulss    xmm3, xmm4
433618ca  0f28e6                   movaps   xmm4, xmm6
433618cd  f30f59e5                 mulss    xmm4, xmm5
433618d1  0f28cb                   movaps   xmm1, xmm3
433618d4  f30f59f2                 mulss    xmm6, xmm2
433618d8  f30f59cb                 mulss    xmm1, xmm3
433618dc  0f28c4                   movaps   xmm0, xmm4
433618df  f30f59c4                 mulss    xmm0, xmm4
433618e3  f30f105708               movss    xmm2, dword ptr [edi + 8]
433618e8  f30f58c8                 addss    xmm1, xmm0
433618ec  0f28c6                   movaps   xmm0, xmm6
433618ef  f30f59c6                 mulss    xmm0, xmm6
433618f3  f30f58c8                 addss    xmm1, xmm0
433618f7  0f28c1                   movaps   xmm0, xmm1
433618fa  f30f104c2430             movss    xmm1, dword ptr [esp + 0x30]
43361900  f30f51c0                 sqrtss   xmm0, xmm0
43361904  f30f11842470030000       movss    dword ptr [esp + 0x370], xmm0
4336190d  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43361915  f30f5ec8                 divss    xmm1, xmm0
43361919  f30f1007                 movss    xmm0, dword ptr [edi]
4336191d  0f28e9                   movaps   xmm5, xmm1
43361920  f30f59f1                 mulss    xmm6, xmm1
43361924  f30f59eb                 mulss    xmm5, xmm3
43361928  0f28d9                   movaps   xmm3, xmm1
4336192b  f30f104f04               movss    xmm1, dword ptr [edi + 4]
43361930  f30f59dc                 mulss    xmm3, xmm4
43361934  898c2420050000           mov      dword ptr [esp + 0x520], ecx
4336193b  f30f11ac24f0040000       movss    dword ptr [esp + 0x4f0], xmm5
43361944  f30f59ed                 mulss    xmm5, xmm5
43361948  c684242405000001         mov      byte ptr [esp + 0x524], 1
43361950  f30f119c24f4040000       movss    dword ptr [esp + 0x4f4], xmm3
43361959  f30f59db                 mulss    xmm3, xmm3
4336195d  c684242505000001         mov      byte ptr [esp + 0x525], 1
43361965  f30f11b424f8040000       movss    dword ptr [esp + 0x4f8], xmm6
4336196e  f30f59f6                 mulss    xmm6, xmm6
43361972  f30f58dd                 addss    xmm3, xmm5
43361976  f30f118c24e4040000       movss    dword ptr [esp + 0x4e4], xmm1
4336197f  0f57c9                   xorps    xmm1, xmm1
43361982  f30f118424e0040000       movss    dword ptr [esp + 0x4e0], xmm0
4336198b  f30f119424e8040000       movss    dword ptr [esp + 0x4e8], xmm2
43361994  0f29bc2400050000         movaps   xmmword ptr [esp + 0x500], xmm7
4336199c  0f29bc2410050000         movaps   xmmword ptr [esp + 0x510], xmm7
433619a4  f30f58de                 addss    xmm3, xmm6
433619a8  0f2ed9                   ucomiss  xmm3, xmm1
433619ab  9f                       lahf     
433619ac  f6c444                   test     ah, 0x44
433619af  7a07                     jp       0x433619b8
433619b1  888c2425050000           mov      byte ptr [esp + 0x525], cl
433619b8  f30f101514054743         movss    xmm2, dword ptr [0x43470514]
433619c0  beffffff7f               mov      esi, 0x7fffffff
433619c5  838c24c4090000ff         or       dword ptr [esp + 0x9c4], 0xffffffff
433619cd  8bc1                     mov      eax, ecx
433619cf  838c24d0090000ff         or       dword ptr [esp + 0x9d0], 0xffffffff
433619d7  c78424ac0900000000803f   mov      dword ptr [esp + 0x9ac], 0x3f800000
433619e2  66898c24b6090000         mov      word ptr [esp + 0x9b6], cx
433619ea  898c24cc090000           mov      dword ptr [esp + 0x9cc], ecx
433619f1  f30f1154241c             movss    dword ptr [esp + 0x1c], xmm2
433619f7  894c2448                 mov      dword ptr [esp + 0x48], ecx
433619fb  894c2458                 mov      dword ptr [esp + 0x58], ecx
433619ff  8b80b0494743             mov      eax, dword ptr [eax + 0x434749b0]
43361a05  3b8424e01c0000           cmp      eax, dword ptr [esp + 0x1ce0]
43361a0c  0f83ab000000             jae      0x43361abd
43361a12  69c090000000             imul     eax, eax, 0x90
43361a18  8d9424f01c0000           lea      edx, [esp + 0x1cf0]
43361a1f  03d0                     add      edx, eax
43361a21  89542468                 mov      dword ptr [esp + 0x68], edx
43361a25  8b4244                   mov      eax, dword ptr [edx + 0x44]
43361a28  83e00f                   and      eax, 0xf
43361a2b  39348570494743           cmp      dword ptr [eax*4 + 0x43474970], esi
43361a32  0f8785000000             ja       0x43361abd
43361a38  c78424ac0900000000803f   mov      dword ptr [esp + 0x9ac], 0x3f800000
43361a43  8d842480090000           lea      eax, [esp + 0x980]
43361a4a  f30f104270               movss    xmm0, dword ptr [edx + 0x70]
43361a4f  8d8c24e0040000           lea      ecx, [esp + 0x4e0]
43361a56  0f2fc1                   comiss   xmm0, xmm1
43361a59  50                       push     eax
43361a5a  760a                     jbe      0x43361a66
43361a5c  8d5240                   lea      edx, [edx + 0x40]
43361a5f  e8a5730900               call     0x433f8e09
43361a64  eb0c                     jmp      0x43361a72
43361a66  8d4210                   lea      eax, [edx + 0x10]
43361a69  8b5204                   mov      edx, dword ptr [edx + 4]
43361a6c  50                       push     eax
43361a6d  e81ce00300               call     0x4339fa8e
43361a72  f30f1054241c             movss    xmm2, dword ptr [esp + 0x1c]
43361a78  85c0                     test     eax, eax
43361a7a  782a                     js       0x43361aa6
43361a7c  0f2f9424ac090000         comiss   xmm2, dword ptr [esp + 0x9ac]
43361a84  7620                     jbe      0x43361aa6
43361a86  8b442468                 mov      eax, dword ptr [esp + 0x68]
43361a8a  f30f109424ac090000       movss    xmm2, dword ptr [esp + 0x9ac]
43361a93  f30f1154241c             movss    dword ptr [esp + 0x1c], xmm2
43361a99  89442448                 mov      dword ptr [esp + 0x48], eax
43361a9d  83784401                 cmp      dword ptr [eax + 0x44], 1
43361aa1  751a                     jne      0x43361abd
43361aa3  6a02                     push     2
43361aa5  5e                       pop      esi
43361aa6  8b442458                 mov      eax, dword ptr [esp + 0x58]
43361aaa  0f57c9                   xorps    xmm1, xmm1
43361aad  83c004                   add      eax, 4
43361ab0  89442458                 mov      dword ptr [esp + 0x58], eax
43361ab4  83f83c                   cmp      eax, 0x3c
43361ab7  0f8242ffffff             jb       0x433619ff
43361abd  8b442448                 mov      eax, dword ptr [esp + 0x48]
43361ac1  85c0                     test     eax, eax
43361ac3  0f849a000000             je       0x43361b63
43361ac9  8b4844                   mov      ecx, dword ptr [eax + 0x44]
43361acc  0f28c2                   movaps   xmm0, xmm2
43361acf  f30f598424f0040000       mulss    xmm0, dword ptr [esp + 0x4f0]
43361ad8  898c24c4090000           mov      dword ptr [esp + 0x9c4], ecx
43361adf  8b00                     mov      eax, dword ptr [eax]
43361ae1  898424d0090000           mov      dword ptr [esp + 0x9d0], eax
43361ae8  f30f588424e0040000       addss    xmm0, dword ptr [esp + 0x4e0]
43361af1  8b4508                   mov      eax, dword ptr [ebp + 8]
43361af4  f30f1184248c090000       movss    dword ptr [esp + 0x98c], xmm0
43361afd  0f28c2                   movaps   xmm0, xmm2
43361b00  f30f598424f4040000       mulss    xmm0, dword ptr [esp + 0x4f4]
43361b09  f30f599424f8040000       mulss    xmm2, dword ptr [esp + 0x4f8]
43361b12  f30f588424e4040000       addss    xmm0, dword ptr [esp + 0x4e4]
43361b1b  f30f589424e8040000       addss    xmm2, dword ptr [esp + 0x4e8]
43361b24  f30f11842490090000       movss    dword ptr [esp + 0x990], xmm0
43361b2d  f30f11942494090000       movss    dword ptr [esp + 0x994], xmm2
43361b36  83b89c01000001           cmp      dword ptr [eax + 0x19c], 1
43361b3d  7f19                     jg       0x43361b58
43361b3f  394c247c                 cmp      dword ptr [esp + 0x7c], ecx
43361b43  7413                     je       0x43361b58
43361b45  83e10f                   and      ecx, 0xf
43361b48  f30f10048d40454743       movss    xmm0, dword ptr [ecx*4 + 0x43474540]
43361b51  0f2f442420               comiss   xmm0, dword ptr [esp + 0x20]
43361b56  720b                     jb       0x43361b63
43361b58  8b442434                 mov      eax, dword ptr [esp + 0x34]
43361b5c  40                       inc      eax
43361b5d  89442434                 mov      dword ptr [esp + 0x34], eax
43361b61  eb04                     jmp      0x43361b67
43361b63  8b442434                 mov      eax, dword ptr [esp + 0x34]
43361b67  8b4c2478                 mov      ecx, dword ptr [esp + 0x78]
43361b6b  0f57ff                   xorps    xmm7, xmm7
43361b6e  83c120                   add      ecx, 0x20
43361b71  836c246401               sub      dword ptr [esp + 0x64], 1
43361b76  894c2478                 mov      dword ptr [esp + 0x78], ecx
43361b7a  0f85a3fcffff             jne      0x43361823
43361b80  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
43361b84  660f6ec0                 movd     xmm0, eax
43361b88  0f5bc0                   cvtdq2ps xmm0, xmm0
43361b8b  f30f590528f64643         mulss    xmm0, dword ptr [0x4346f628]
43361b93  f30f114638               movss    dword ptr [esi + 0x38], xmm0
43361b98  f60608                   test     byte ptr [esi], 8
43361b9b  0f849a260000             je       0x4336423b
43361ba1  f6466c02                 test     byte ptr [esi + 0x6c], 2
43361ba5  0f8422130000             je       0x43362ecd
43361bab  8d4644                   lea      eax, [esi + 0x44]
43361bae  83c650                   add      esi, 0x50
43361bb1  8d7c246c                 lea      edi, [esp + 0x6c]
43361bb5  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43361bb6  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43361bb7  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43361bb8  8bf0                     mov      esi, eax
43361bba  8dbc2494000000           lea      edi, [esp + 0x94]
43361bc1  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43361bc2  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43361bc3  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43361bc4  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
43361bc8  8b4e5c                   mov      ecx, dword ptr [esi + 0x5c]
43361bcb  8b4668                   mov      eax, dword ptr [esi + 0x68]
43361bce  898424a0000000           mov      dword ptr [esp + 0xa0], eax
43361bd5  85c9                     test     ecx, ecx
43361bd7  7f0a                     jg       0x43361be3
43361bd9  33c9                     xor      ecx, ecx
43361bdb  bfffffff7f               mov      edi, 0x7fffffff
43361be0  41                       inc      ecx
43361be1  eb13                     jmp      0x43361bf6
43361be3  8b4608                   mov      eax, dword ptr [esi + 8]
43361be6  48                       dec      eax
43361be7  03c1                     add      eax, ecx
43361be9  99                       cdq      
43361bea  f7f9                     idiv     ecx
43361bec  33c9                     xor      ecx, ecx
43361bee  41                       inc      ecx
43361bef  3bc1                     cmp      eax, ecx
43361bf1  8bf9                     mov      edi, ecx
43361bf3  0f4ff8                   cmovg    edi, eax
43361bf6  8b5660                   mov      edx, dword ptr [esi + 0x60]
43361bf9  89542430                 mov      dword ptr [esp + 0x30], edx
43361bfd  85d2                     test     edx, edx
43361bff  7f07                     jg       0x43361c08
43361c01  baffffff7f               mov      edx, 0x7fffffff
43361c06  eb12                     jmp      0x43361c1a
43361c08  8b4608                   mov      eax, dword ptr [esi + 8]
43361c0b  4a                       dec      edx
43361c0c  03c2                     add      eax, edx
43361c0e  99                       cdq      
43361c0f  f77c2430                 idiv     dword ptr [esp + 0x30]
43361c13  8bd1                     mov      edx, ecx
43361c15  3bc1                     cmp      eax, ecx
43361c17  0f4fd0                   cmovg    edx, eax
43361c1a  89542438                 mov      dword ptr [esp + 0x38], edx
43361c1e  3bfa                     cmp      edi, edx
43361c20  0f8466050000             je       0x4336218c
43361c26  0fb605e0a34643           movzx    eax, byte ptr [0x4346a3e0]
43361c2d  8d8c24d0100000           lea      ecx, [esp + 0x10d0]
43361c34  8364243400               and      dword ptr [esp + 0x34], 0
43361c39  0f57c0                   xorps    xmm0, xmm0
43361c3c  50                       push     eax
43361c3d  8b4508                   mov      eax, dword ptr [ebp + 8]
43361c40  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
43361c46  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
43361c4e  f30f1144241c             movss    dword ptr [esp + 0x1c], xmm0
43361c54  ff700c                   push     dword ptr [eax + 0xc]
43361c57  e82f960800               call     0x433eb28b
43361c5c  f30f1084249c000000       movss    xmm0, dword ptr [esp + 0x9c]
43361c65  f30f109c2494000000       movss    xmm3, dword ptr [esp + 0x94]
43361c6e  f30f10b42498000000       movss    xmm6, dword ptr [esp + 0x98]
43361c77  f30f5c442474             subss    xmm0, dword ptr [esp + 0x74]
43361c7d  f30f5c5c246c             subss    xmm3, dword ptr [esp + 0x6c]
43361c83  f30f5c742470             subss    xmm6, dword ptr [esp + 0x70]
43361c89  f30f10542418             movss    xmm2, dword ptr [esp + 0x18]
43361c8f  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
43361c93  f30f11442450             movss    dword ptr [esp + 0x50], xmm0
43361c99  0f57c0                   xorps    xmm0, xmm0
43361c9c  f30f115c2458             movss    dword ptr [esp + 0x58], xmm3
43361ca2  f30f11742448             movss    dword ptr [esp + 0x48], xmm6
43361ca8  c744244004000000         mov      dword ptr [esp + 0x40], 4
43361cb0  838c2474070000ff         or       dword ptr [esp + 0x774], 0xffffffff
43361cb8  0f28ca                   movaps   xmm1, xmm2
43361cbb  f30f58c8                 addss    xmm1, xmm0
43361cbf  838c2480070000ff         or       dword ptr [esp + 0x780], 0xffffffff
43361cc7  33d2                     xor      edx, edx
43361cc9  c784245c0700000000803f   mov      dword ptr [esp + 0x75c], 0x3f800000
43361cd4  6689942466070000         mov      word ptr [esp + 0x766], dx
43361cdc  33c9                     xor      ecx, ecx
43361cde  8994247c070000           mov      dword ptr [esp + 0x77c], edx
43361ce5  41                       inc      ecx
43361ce6  f30f1007                 movss    xmm0, dword ptr [edi]
43361cea  f30f590d40224743         mulss    xmm1, dword ptr [0x43472240]
43361cf2  f30f107f08               movss    xmm7, dword ptr [edi + 8]
43361cf7  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
43361cfd  0f28e1                   movaps   xmm4, xmm1
43361d00  f30f114c2428             movss    dword ptr [esp + 0x28], xmm1
43361d06  0f28e9                   movaps   xmm5, xmm1
43361d09  f30f59e3                 mulss    xmm4, xmm3
43361d0d  0f28d1                   movaps   xmm2, xmm1
43361d10  f30f59ee                 mulss    xmm5, xmm6
43361d14  f30f5864246c             addss    xmm4, dword ptr [esp + 0x6c]
43361d1a  f30f59542450             mulss    xmm2, dword ptr [esp + 0x50]
43361d20  f30f586c2470             addss    xmm5, dword ptr [esp + 0x70]
43361d26  f30f103514054743         movss    xmm6, dword ptr [0x43470514]
43361d2e  f30f58542474             addss    xmm2, dword ptr [esp + 0x74]
43361d34  f30f5ce0                 subss    xmm4, xmm0
43361d38  f30f104704               movss    xmm0, dword ptr [edi + 4]
43361d3d  f30f11442468             movss    dword ptr [esp + 0x68], xmm0
43361d43  f30f5ce8                 subss    xmm5, xmm0
43361d47  f30f11bc2438050000       movss    dword ptr [esp + 0x538], xmm7
43361d50  89942470050000           mov      dword ptr [esp + 0x570], edx
43361d57  f30f5cd7                 subss    xmm2, xmm7
43361d5b  888c2474050000           mov      byte ptr [esp + 0x574], cl
43361d62  0f28cc                   movaps   xmm1, xmm4
43361d65  f30f59cc                 mulss    xmm1, xmm4
43361d69  0f28c5                   movaps   xmm0, xmm5
43361d6c  f30f59c5                 mulss    xmm0, xmm5
43361d70  f30f58c8                 addss    xmm1, xmm0
43361d74  0f28c2                   movaps   xmm0, xmm2
43361d77  f30f59c2                 mulss    xmm0, xmm2
43361d7b  f30f58c8                 addss    xmm1, xmm0
43361d7f  0f28c1                   movaps   xmm0, xmm1
43361d82  f30f51c0                 sqrtss   xmm0, xmm0
43361d86  f30f11442460             movss    dword ptr [esp + 0x60], xmm0
43361d8c  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43361d94  f30f5ef0                 divss    xmm6, xmm0
43361d98  0f28de                   movaps   xmm3, xmm6
43361d9b  f30f59dc                 mulss    xmm3, xmm4
43361d9f  0f28e6                   movaps   xmm4, xmm6
43361da2  f30f59e5                 mulss    xmm4, xmm5
43361da6  0f28cb                   movaps   xmm1, xmm3
43361da9  f30f59f2                 mulss    xmm6, xmm2
43361dad  f30f59cb                 mulss    xmm1, xmm3
43361db1  0f28c4                   movaps   xmm0, xmm4
43361db4  f30f59c4                 mulss    xmm0, xmm4
43361db8  f30f109424e4100000       movss    xmm2, dword ptr [esp + 0x10e4]
43361dc1  f30f58c8                 addss    xmm1, xmm0
43361dc5  0f28c6                   movaps   xmm0, xmm6
43361dc8  f30f59c6                 mulss    xmm0, xmm6
43361dcc  f30f58c8                 addss    xmm1, xmm0
43361dd0  0f28c1                   movaps   xmm0, xmm1
43361dd3  f30f51c0                 sqrtss   xmm0, xmm0
43361dd7  f30f11842474030000       movss    dword ptr [esp + 0x374], xmm0
43361de0  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43361de8  f30f5ed0                 divss    xmm2, xmm0
43361dec  0f28ca                   movaps   xmm1, xmm2
43361def  0f28c2                   movaps   xmm0, xmm2
43361df2  f30f59cb                 mulss    xmm1, xmm3
43361df6  f30f105c2430             movss    xmm3, dword ptr [esp + 0x30]
43361dfc  f30f119c2430050000       movss    dword ptr [esp + 0x530], xmm3
43361e05  f30f105c2468             movss    xmm3, dword ptr [esp + 0x68]
43361e0b  f30f59c4                 mulss    xmm0, xmm4
43361e0f  f30f59d6                 mulss    xmm2, xmm6
43361e13  f30f119c2434050000       movss    dword ptr [esp + 0x534], xmm3
43361e1c  0f57db                   xorps    xmm3, xmm3
43361e1f  f30f118c2440050000       movss    dword ptr [esp + 0x540], xmm1
43361e28  f30f11842444050000       movss    dword ptr [esp + 0x544], xmm0
43361e31  f30f11942448050000       movss    dword ptr [esp + 0x548], xmm2
43361e3a  0f299c2450050000         movaps   xmmword ptr [esp + 0x550], xmm3
43361e42  0f299c2460050000         movaps   xmmword ptr [esp + 0x560], xmm3
43361e4a  f30f59c9                 mulss    xmm1, xmm1
43361e4e  f30f59c0                 mulss    xmm0, xmm0
43361e52  888c2475050000           mov      byte ptr [esp + 0x575], cl
43361e59  f30f59d2                 mulss    xmm2, xmm2
43361e5d  f30f58c8                 addss    xmm1, xmm0
43361e61  f30f58ca                 addss    xmm1, xmm2
43361e65  0f57d2                   xorps    xmm2, xmm2
43361e68  0f2eca                   ucomiss  xmm1, xmm2
43361e6b  9f                       lahf     
43361e6c  f6c444                   test     ah, 0x44
43361e6f  7a07                     jp       0x43361e78
43361e71  88942475050000           mov      byte ptr [esp + 0x575], dl
43361e78  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43361e80  8bc2                     mov      eax, edx
43361e82  c7442430ffffff7f         mov      dword ptr [esp + 0x30], 0x7fffffff
43361e8a  8b7c2430                 mov      edi, dword ptr [esp + 0x30]
43361e8e  f30f114c2414             movss    dword ptr [esp + 0x14], xmm1
43361e94  8954244c                 mov      dword ptr [esp + 0x4c], edx
43361e98  89442424                 mov      dword ptr [esp + 0x24], eax
43361e9c  8b80b0494743             mov      eax, dword ptr [eax + 0x434749b0]
43361ea2  3b8424e01c0000           cmp      eax, dword ptr [esp + 0x1ce0]
43361ea9  0f83b4000000             jae      0x43361f63
43361eaf  69c090000000             imul     eax, eax, 0x90
43361eb5  8d8c24f01c0000           lea      ecx, [esp + 0x1cf0]
43361ebc  03c8                     add      ecx, eax
43361ebe  894c2430                 mov      dword ptr [esp + 0x30], ecx
43361ec2  8d7140                   lea      esi, [ecx + 0x40]
43361ec5  8b4604                   mov      eax, dword ptr [esi + 4]
43361ec8  83e00f                   and      eax, 0xf
43361ecb  393c8570494743           cmp      dword ptr [eax*4 + 0x43474970], edi
43361ed2  0f878b000000             ja       0x43361f63
43361ed8  c784245c0700000000803f   mov      dword ptr [esp + 0x75c], 0x3f800000
43361ee3  8d842430070000           lea      eax, [esp + 0x730]
43361eea  f30f104630               movss    xmm0, dword ptr [esi + 0x30]
43361eef  0f2fc2                   comiss   xmm0, xmm2
43361ef2  50                       push     eax
43361ef3  7610                     jbe      0x43361f05
43361ef5  8bd6                     mov      edx, esi
43361ef7  8d8c2434050000           lea      ecx, [esp + 0x534]
43361efe  e8066f0900               call     0x433f8e09
43361f03  eb13                     jmp      0x43361f18
43361f05  8b5104                   mov      edx, dword ptr [ecx + 4]
43361f08  8d4110                   lea      eax, [ecx + 0x10]
43361f0b  50                       push     eax
43361f0c  8d8c2438050000           lea      ecx, [esp + 0x538]
43361f13  e876db0300               call     0x4339fa8e
43361f18  f30f104c2414             movss    xmm1, dword ptr [esp + 0x14]
43361f1e  85c0                     test     eax, eax
43361f20  782a                     js       0x43361f4c
43361f22  0f2f8c245c070000         comiss   xmm1, dword ptr [esp + 0x75c]
43361f2a  7620                     jbe      0x43361f4c
43361f2c  837e0401                 cmp      dword ptr [esi + 4], 1
43361f30  f30f108c245c070000       movss    xmm1, dword ptr [esp + 0x75c]
43361f39  8b442430                 mov      eax, dword ptr [esp + 0x30]
43361f3d  f30f114c2414             movss    dword ptr [esp + 0x14], xmm1
43361f43  8944244c                 mov      dword ptr [esp + 0x4c], eax
43361f47  751a                     jne      0x43361f63
43361f49  6a02                     push     2
43361f4b  5f                       pop      edi
43361f4c  8b442424                 mov      eax, dword ptr [esp + 0x24]
43361f50  0f57d2                   xorps    xmm2, xmm2
43361f53  83c004                   add      eax, 4
43361f56  89442424                 mov      dword ptr [esp + 0x24], eax
43361f5a  83f83c                   cmp      eax, 0x3c
43361f5d  0f8239ffffff             jb       0x43361e9c
43361f63  8b54244c                 mov      edx, dword ptr [esp + 0x4c]
43361f67  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
43361f6b  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
43361f6f  85d2                     test     edx, edx
43361f71  0f846e010000             je       0x433620e5
43361f77  f30f10842440050000       movss    xmm0, dword ptr [esp + 0x540]
43361f80  8b4a44                   mov      ecx, dword ptr [edx + 0x44]
43361f83  f30f59c1                 mulss    xmm0, xmm1
43361f87  898c2474070000           mov      dword ptr [esp + 0x774], ecx
43361f8e  83e10f                   and      ecx, 0xf
43361f91  8b02                     mov      eax, dword ptr [edx]
43361f93  89842480070000           mov      dword ptr [esp + 0x780], eax
43361f9a  f30f58842430050000       addss    xmm0, dword ptr [esp + 0x530]
43361fa3  8b8424a0000000           mov      eax, dword ptr [esp + 0xa0]
43361faa  83e00f                   and      eax, 0xf
43361fad  f30f1184243c070000       movss    dword ptr [esp + 0x73c], xmm0
43361fb6  f30f10842444050000       movss    xmm0, dword ptr [esp + 0x544]
43361fbf  f30f59c1                 mulss    xmm0, xmm1
43361fc3  f30f58842434050000       addss    xmm0, dword ptr [esp + 0x534]
43361fcc  f30f11842440070000       movss    dword ptr [esp + 0x740], xmm0
43361fd5  f30f10842448050000       movss    xmm0, dword ptr [esp + 0x548]
43361fde  f30f59c1                 mulss    xmm0, xmm1
43361fe2  f30f58842438050000       addss    xmm0, dword ptr [esp + 0x538]
43361feb  f30f11842444070000       movss    dword ptr [esp + 0x744], xmm0
43361ff4  f30f10048d40454743       movss    xmm0, dword ptr [ecx*4 + 0x43474540]
43361ffd  0f2f048540454743         comiss   xmm0, dword ptr [eax*4 + 0x43474540]
43362005  0f82da000000             jb       0x433620e5
4336200b  0f280590f24643           movaps   xmm0, xmmword ptr [0x4346f290]
43362012  33c0                     xor      eax, eax
43362014  8b0d08584743             mov      ecx, dword ptr [0x43475808]
4336201a  8bd7                     mov      edx, edi
4336201c  89842468080000           mov      dword ptr [esp + 0x868], eax
43362023  8984246c080000           mov      dword ptr [esp + 0x86c], eax
4336202a  89842470080000           mov      dword ptr [esp + 0x870], eax
43362031  8d8424d0100000           lea      eax, [esp + 0x10d0]
43362038  50                       push     eax
43362039  8d842468080000           lea      eax, [esp + 0x868]
43362040  c78424880800000000803f   mov      dword ptr [esp + 0x888], 0x3f800000
4336204b  50                       push     eax
4336204c  8d842444070000           lea      eax, [esp + 0x744]
43362053  c784246c08000004044743   mov      dword ptr [esp + 0x86c], 0x43470404
4336205e  50                       push     eax
4336205f  0f11842480080000         movups   xmmword ptr [esp + 0x880], xmm0
43362067  e8bf7cfcff               call     0x43329d2b
4336206c  f30f2c8424d8100000       cvttss2si eax, dword ptr [esp + 0x10d8]
43362075  85c0                     test     eax, eax
43362077  746c                     je       0x433620e5
43362079  ffb42474070000           push     dword ptr [esp + 0x774]
43362080  8d8c24d4100000           lea      ecx, [esp + 0x10d4]
43362087  ffb42494000000           push     dword ptr [esp + 0x94]
4336208e  e83a7e0800               call     0x433e9ecd
43362093  8bc8                     mov      ecx, eax
43362095  894c2430                 mov      dword ptr [esp + 0x30], ecx
43362099  85c9                     test     ecx, ecx
4336209b  7448                     je       0x433620e5
4336209d  3b8ed0000000             cmp      ecx, dword ptr [esi + 0xd0]
433620a3  7c40                     jl       0x433620e5
433620a5  85c9                     test     ecx, ecx
433620a7  7f07                     jg       0x433620b0
433620a9  baffffff7f               mov      edx, 0x7fffffff
433620ae  eb17                     jmp      0x433620c7
433620b0  8b4608                   mov      eax, dword ptr [esi + 8]
433620b3  48                       dec      eax
433620b4  03c1                     add      eax, ecx
433620b6  99                       cdq      
433620b7  f7f9                     idiv     ecx
433620b9  33c9                     xor      ecx, ecx
433620bb  41                       inc      ecx
433620bc  3bc1                     cmp      eax, ecx
433620be  8bd1                     mov      edx, ecx
433620c0  8b4c2430                 mov      ecx, dword ptr [esp + 0x30]
433620c4  0f4fd0                   cmovg    edx, eax
433620c7  3b542438                 cmp      edx, dword ptr [esp + 0x38]
433620cb  7f18                     jg       0x433620e5
433620cd  f30f10542428             movss    xmm2, dword ptr [esp + 0x28]
433620d3  f30f1044242c             movss    xmm0, dword ptr [esp + 0x2c]
433620d9  f30f11542418             movss    dword ptr [esp + 0x18], xmm2
433620df  894c2434                 mov      dword ptr [esp + 0x34], ecx
433620e3  eb16                     jmp      0x433620fb
433620e5  f30f10442428             movss    xmm0, dword ptr [esp + 0x28]
433620eb  8b4c2434                 mov      ecx, dword ptr [esp + 0x34]
433620ef  f30f10542418             movss    xmm2, dword ptr [esp + 0x18]
433620f5  f30f1144242c             movss    dword ptr [esp + 0x2c], xmm0
433620fb  836c244001               sub      dword ptr [esp + 0x40], 1
43362100  f30f105c2458             movss    xmm3, dword ptr [esp + 0x58]
43362106  f30f10742448             movss    xmm6, dword ptr [esp + 0x48]
4336210c  0f859efbffff             jne      0x43361cb0
43362112  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
4336211a  0f2ed0                   ucomiss  xmm2, xmm0
4336211d  9f                       lahf     
4336211e  f6c444                   test     ah, 0x44
43362121  0f8bfc000000             jnp      0x43362223
43362127  f30f58d0                 addss    xmm2, xmm0
4336212b  0f57c9                   xorps    xmm1, xmm1
4336212e  f30f2ac9                 cvtsi2ss xmm1, ecx
43362132  f30f591540224743         mulss    xmm2, dword ptr [0x43472240]
4336213a  0f28c2                   movaps   xmm0, xmm2
4336213d  f30f59c3                 mulss    xmm0, xmm3
43362141  f30f5844246c             addss    xmm0, dword ptr [esp + 0x6c]
43362147  f30f114644               movss    dword ptr [esi + 0x44], xmm0
4336214c  0f28c2                   movaps   xmm0, xmm2
4336214f  f30f59c6                 mulss    xmm0, xmm6
43362153  f30f58442470             addss    xmm0, dword ptr [esp + 0x70]
43362159  f30f114648               movss    dword ptr [esi + 0x48], xmm0
4336215e  0f28c2                   movaps   xmm0, xmm2
43362161  f30f59442450             mulss    xmm0, dword ptr [esp + 0x50]
43362167  f30f58442474             addss    xmm0, dword ptr [esp + 0x74]
4336216d  f30f11464c               movss    dword ptr [esi + 0x4c], xmm0
43362172  0f28c2                   movaps   xmm0, xmm2
43362175  f30f594674               mulss    xmm0, dword ptr [esi + 0x74]
4336217a  f30f114674               movss    dword ptr [esi + 0x74], xmm0
4336217f  0f57c0                   xorps    xmm0, xmm0
43362182  f30f2a4660               cvtsi2ss xmm0, dword ptr [esi + 0x60]
43362187  e984000000               jmp      0x43362210
4336218c  f30f10842494000000       movss    xmm0, dword ptr [esp + 0x94]
43362195  0f57c9                   xorps    xmm1, xmm1
43362198  f30f5c44246c             subss    xmm0, dword ptr [esp + 0x6c]
4336219e  f30f101540224743         movss    xmm2, dword ptr [0x43472240]
433621a6  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
433621aa  f30f59c2                 mulss    xmm0, xmm2
433621ae  f30f5844246c             addss    xmm0, dword ptr [esp + 0x6c]
433621b4  f30f114644               movss    dword ptr [esi + 0x44], xmm0
433621b9  f30f10842498000000       movss    xmm0, dword ptr [esp + 0x98]
433621c2  f30f5c442470             subss    xmm0, dword ptr [esp + 0x70]
433621c8  f30f59c2                 mulss    xmm0, xmm2
433621cc  f30f58442470             addss    xmm0, dword ptr [esp + 0x70]
433621d2  f30f114648               movss    dword ptr [esi + 0x48], xmm0
433621d7  f30f1084249c000000       movss    xmm0, dword ptr [esp + 0x9c]
433621e0  f30f5c442474             subss    xmm0, dword ptr [esp + 0x74]
433621e6  f30f59c2                 mulss    xmm0, xmm2
433621ea  f30f58442474             addss    xmm0, dword ptr [esp + 0x74]
433621f0  f30f11464c               movss    dword ptr [esi + 0x4c], xmm0
433621f5  f30f104674               movss    xmm0, dword ptr [esi + 0x74]
433621fa  f30f59c2                 mulss    xmm0, xmm2
433621fe  f30f114674               movss    dword ptr [esi + 0x74], xmm0
43362203  0f57c0                   xorps    xmm0, xmm0
43362206  f30f2a4e5c               cvtsi2ss xmm1, dword ptr [esi + 0x5c]
4336220b  f30f2a4660               cvtsi2ss xmm0, dword ptr [esi + 0x60]
43362210  f30f5cc1                 subss    xmm0, xmm1
43362214  f30f59c2                 mulss    xmm0, xmm2
43362218  f30f58c1                 addss    xmm0, xmm1
4336221c  f30f2cc0                 cvttss2si eax, xmm0
43362220  894660                   mov      dword ptr [esi + 0x60], eax
43362223  8b5508                   mov      edx, dword ptr [ebp + 8]
43362226  6a1f                     push     0x1f
43362228  58                       pop      eax
43362229  3982d8000000             cmp      dword ptr [edx + 0xd8], eax
4336222f  7508                     jne      0x43362239
43362231  0f57c0                   xorps    xmm0, xmm0
43362234  e990000000               jmp      0x433622c9
43362239  8b4e60                   mov      ecx, dword ptr [esi + 0x60]
4336223c  8b4608                   mov      eax, dword ptr [esi + 8]
4336223f  894c2430                 mov      dword ptr [esp + 0x30], ecx
43362243  85c9                     test     ecx, ecx
43362245  7f07                     jg       0x4336224e
43362247  baffffff7f               mov      edx, 0x7fffffff
4336224c  eb14                     jmp      0x43362262
4336224e  48                       dec      eax
4336224f  03c1                     add      eax, ecx
43362251  99                       cdq      
43362252  f7f9                     idiv     ecx
43362254  33c9                     xor      ecx, ecx
43362256  41                       inc      ecx
43362257  3bc1                     cmp      eax, ecx
43362259  8bd1                     mov      edx, ecx
4336225b  8b4c2430                 mov      ecx, dword ptr [esp + 0x30]
4336225f  0f4fd0                   cmovg    edx, eax
43362262  8b4668                   mov      eax, dword ptr [esi + 0x68]
43362265  660f6e4e08               movd     xmm1, dword ptr [esi + 8]
4336226a  83e00f                   and      eax, 0xf
4336226d  660f6ec1                 movd     xmm0, ecx
43362271  0f5bc0                   cvtdq2ps xmm0, xmm0
43362274  660f6ed2                 movd     xmm2, edx
43362278  f30f5e048540454743       divss    xmm0, dword ptr [eax*4 + 0x43474540]
43362281  0f5bc9                   cvtdq2ps xmm1, xmm1
43362284  0f5bd2                   cvtdq2ps xmm2, xmm2
43362287  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
4336228d  660f6e86d0000000         movd     xmm0, dword ptr [esi + 0xd0]
43362295  f30f5eca                 divss    xmm1, xmm2
43362299  0f5bc0                   cvtdq2ps xmm0, xmm0
4336229c  e894d9fcff               call     0x4332fc35
433622a1  f30f104c2430             movss    xmm1, dword ptr [esp + 0x30]
433622a7  0f2e0d6cee4643           ucomiss  xmm1, dword ptr [0x4346ee6c]
433622ae  9f                       lahf     
433622af  f6c444                   test     ah, 0x44
433622b2  7b06                     jnp      0x433622ba
433622b4  f30f5ec1                 divss    xmm0, xmm1
433622b8  eb0f                     jmp      0x433622c9
433622ba  8b4668                   mov      eax, dword ptr [esi + 0x68]
433622bd  83e00f                   and      eax, 0xf
433622c0  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
433622c9  8b4d08                   mov      ecx, dword ptr [ebp + 8]
433622cc  8d9424840e0000           lea      edx, [esp + 0xe84]
433622d3  f30f11442420             movss    dword ptr [esp + 0x20], xmm0
433622d9  8b490c                   mov      ecx, dword ptr [ecx + 0xc]
433622dc  e86c690600               call     0x433c8c4d
433622e1  f30f106e44               movss    xmm5, dword ptr [esi + 0x44]
433622e6  33d2                     xor      edx, edx
433622e8  f30f105648               movss    xmm2, dword ptr [esi + 0x48]
433622ed  42                       inc      edx
433622ee  f30f5c2f                 subss    xmm5, dword ptr [edi]
433622f2  f30f5c5704               subss    xmm2, dword ptr [edi + 4]
433622f7  f30f107e4c               movss    xmm7, dword ptr [esi + 0x4c]
433622fc  f30f5c7f08               subss    xmm7, dword ptr [edi + 8]
43362301  8b4668                   mov      eax, dword ptr [esi + 0x68]
43362304  0f28cd                   movaps   xmm1, xmm5
43362307  8984248c000000           mov      dword ptr [esp + 0x8c], eax
4336230e  0f28c2                   movaps   xmm0, xmm2
43362311  f30f59cd                 mulss    xmm1, xmm5
43362315  f30f59c2                 mulss    xmm0, xmm2
43362319  f30f58c8                 addss    xmm1, xmm0
4336231d  0f28c7                   movaps   xmm0, xmm7
43362320  f30f59c7                 mulss    xmm0, xmm7
43362324  f30f58c8                 addss    xmm1, xmm0
43362328  0f28c1                   movaps   xmm0, xmm1
4336232b  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43362333  f30f51c0                 sqrtss   xmm0, xmm0
43362337  f30f11842478030000       movss    dword ptr [esp + 0x378], xmm0
43362340  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43362348  f30f5ec8                 divss    xmm1, xmm0
4336234c  f30f1084248c0e0000       movss    xmm0, dword ptr [esp + 0xe8c]
43362355  f30f59e9                 mulss    xmm5, xmm1
43362359  f30f59d1                 mulss    xmm2, xmm1
4336235d  f30f59f9                 mulss    xmm7, xmm1
43362361  f30f116c247c             movss    dword ptr [esp + 0x7c], xmm5
43362367  f30f11542478             movss    dword ptr [esp + 0x78], xmm2
4336236d  f30f117c2464             movss    dword ptr [esp + 0x64], xmm7
43362373  84566c                   test     byte ptr [esi + 0x6c], dl
43362376  0f84c3050000             je       0x4336293f
4336237c  33c9                     xor      ecx, ecx
4336237e  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
43362384  0f57db                   xorps    xmm3, xmm3
43362387  894c2458                 mov      dword ptr [esp + 0x58], ecx
4336238b  0f2eeb                   ucomiss  xmm5, xmm3
4336238e  9f                       lahf     
4336238f  f6c444                   test     ah, 0x44
43362392  0f8a84000000             jp       0x4336241c
43362398  0f2ed3                   ucomiss  xmm2, xmm3
4336239b  9f                       lahf     
4336239c  f6c444                   test     ah, 0x44
4336239f  7a7b                     jp       0x4336241c
433623a1  0f57c0                   xorps    xmm0, xmm0
433623a4  f30f11442418             movss    dword ptr [esp + 0x18], xmm0
433623aa  f30f118424a8000000       movss    dword ptr [esp + 0xa8], xmm0
433623b3  f30f10842488000000       movss    xmm0, dword ptr [esp + 0x88]
433623bc  f30f1144244c             movss    dword ptr [esp + 0x4c], xmm0
433623c2  f30f118424ac000000       movss    dword ptr [esp + 0xac], xmm0
433623cb  0f57c0                   xorps    xmm0, xmm0
433623ce  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
433623d4  f30f118424b0000000       movss    dword ptr [esp + 0xb0], xmm0
433623dd  0f28c7                   movaps   xmm0, xmm7
433623e0  0f5705d0034743           xorps    xmm0, xmmword ptr [0x434703d0]
433623e7  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
433623ed  f30f118424b4000000       movss    dword ptr [esp + 0xb4], xmm0
433623f6  0f57c0                   xorps    xmm0, xmm0
433623f9  f30f1144242c             movss    dword ptr [esp + 0x2c], xmm0
433623ff  f30f118424b8000000       movss    dword ptr [esp + 0xb8], xmm0
43362408  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
4336240e  f30f118424bc000000       movss    dword ptr [esp + 0xbc], xmm0
43362417  e97e010000               jmp      0x4336259a
4336241c  0f28f7                   movaps   xmm6, xmm7
4336241f  0f28ca                   movaps   xmm1, xmm2
43362422  f30f59f3                 mulss    xmm6, xmm3
43362426  0f28e5                   movaps   xmm4, xmm5
43362429  f30f59e3                 mulss    xmm4, xmm3
4336242d  0f28c2                   movaps   xmm0, xmm2
43362430  f30f59c3                 mulss    xmm0, xmm3
43362434  f30f5cce                 subss    xmm1, xmm6
43362438  f30f5cf5                 subss    xmm6, xmm5
4336243c  f30f5ce0                 subss    xmm4, xmm0
43362440  f30f114c2418             movss    dword ptr [esp + 0x18], xmm1
43362446  f30f59c9                 mulss    xmm1, xmm1
4336244a  0f28c6                   movaps   xmm0, xmm6
4336244d  f30f59c6                 mulss    xmm0, xmm6
43362451  f30f58c8                 addss    xmm1, xmm0
43362455  0f28c4                   movaps   xmm0, xmm4
43362458  f30f59c4                 mulss    xmm0, xmm4
4336245c  f30f58c8                 addss    xmm1, xmm0
43362460  0f28c1                   movaps   xmm0, xmm1
43362463  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4336246b  f30f51c0                 sqrtss   xmm0, xmm0
4336246f  f30f11842494010000       movss    dword ptr [esp + 0x194], xmm0
43362478  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43362480  f30f5ec8                 divss    xmm1, xmm0
43362484  f30f10442418             movss    xmm0, dword ptr [esp + 0x18]
4336248a  f30f59c1                 mulss    xmm0, xmm1
4336248e  f30f59e1                 mulss    xmm4, xmm1
43362492  f30f59f1                 mulss    xmm6, xmm1
43362496  f30f11442418             movss    dword ptr [esp + 0x18], xmm0
4336249c  f30f104c2418             movss    xmm1, dword ptr [esp + 0x18]
433624a2  f30f118424a8000000       movss    dword ptr [esp + 0xa8], xmm0
433624ab  f30f11642414             movss    dword ptr [esp + 0x14], xmm4
433624b1  f30f10442414             movss    xmm0, dword ptr [esp + 0x14]
433624b7  f30f59c2                 mulss    xmm0, xmm2
433624bb  f30f11a424b0000000       movss    dword ptr [esp + 0xb0], xmm4
433624c4  0f28e6                   movaps   xmm4, xmm6
433624c7  f30f59e7                 mulss    xmm4, xmm7
433624cb  f30f1174244c             movss    dword ptr [esp + 0x4c], xmm6
433624d1  f30f11b424ac000000       movss    dword ptr [esp + 0xac], xmm6
433624da  f30f5ce0                 subss    xmm4, xmm0
433624de  f30f10442414             movss    xmm0, dword ptr [esp + 0x14]
433624e4  f30f59c5                 mulss    xmm0, xmm5
433624e8  f30f1144242c             movss    dword ptr [esp + 0x2c], xmm0
433624ee  0f28c1                   movaps   xmm0, xmm1
433624f1  f30f105c242c             movss    xmm3, dword ptr [esp + 0x2c]
433624f7  f30f59c7                 mulss    xmm0, xmm7
433624fb  f30f5cd8                 subss    xmm3, xmm0
433624ff  0f28c6                   movaps   xmm0, xmm6
43362502  f30f59c5                 mulss    xmm0, xmm5
43362506  f30f115c242c             movss    dword ptr [esp + 0x2c], xmm3
4336250c  0f28d9                   movaps   xmm3, xmm1
4336250f  f30f1074242c             movss    xmm6, dword ptr [esp + 0x2c]
43362515  0f28cc                   movaps   xmm1, xmm4
43362518  f30f59da                 mulss    xmm3, xmm2
4336251c  f30f59cc                 mulss    xmm1, xmm4
43362520  f30f5cd8                 subss    xmm3, xmm0
43362524  0f28c6                   movaps   xmm0, xmm6
43362527  f30f59c6                 mulss    xmm0, xmm6
4336252b  f30f58c8                 addss    xmm1, xmm0
4336252f  0f28c3                   movaps   xmm0, xmm3
43362532  f30f59c3                 mulss    xmm0, xmm3
43362536  f30f58c8                 addss    xmm1, xmm0
4336253a  0f28c1                   movaps   xmm0, xmm1
4336253d  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43362545  f30f51c0                 sqrtss   xmm0, xmm0
43362549  f30f11842488010000       movss    dword ptr [esp + 0x188], xmm0
43362552  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4336255a  f30f5ec8                 divss    xmm1, xmm0
4336255e  f30f59d9                 mulss    xmm3, xmm1
43362562  f30f59e1                 mulss    xmm4, xmm1
43362566  f30f59f1                 mulss    xmm6, xmm1
4336256a  f30f115c2438             movss    dword ptr [esp + 0x38], xmm3
43362570  f30f119c24bc000000       movss    dword ptr [esp + 0xbc], xmm3
43362579  0f57db                   xorps    xmm3, xmm3
4336257c  f30f11642424             movss    dword ptr [esp + 0x24], xmm4
43362582  f30f11a424b4000000       movss    dword ptr [esp + 0xb4], xmm4
4336258b  f30f1174242c             movss    dword ptr [esp + 0x2c], xmm6
43362591  f30f11b424b8000000       movss    dword ptr [esp + 0xb8], xmm6
4336259a  8b842480000000           mov      eax, dword ptr [esp + 0x80]
433625a1  89442448                 mov      dword ptr [esp + 0x48], eax
433625a5  c744245020000000         mov      dword ptr [esp + 0x50], 0x20
433625ad  eb03                     jmp      0x433625b2
433625af  0f57db                   xorps    xmm3, xmm3
433625b2  f30f1030                 movss    xmm6, dword ptr [eax]
433625b6  0f28e6                   movaps   xmm4, xmm6
433625b9  f30f104804               movss    xmm1, dword ptr [eax + 4]
433625be  0f28c1                   movaps   xmm0, xmm1
433625c1  f30f59642418             mulss    xmm4, dword ptr [esp + 0x18]
433625c7  f30f59442424             mulss    xmm0, dword ptr [esp + 0x24]
433625cd  f30f58e5                 addss    xmm4, xmm5
433625d1  0f28ee                   movaps   xmm5, xmm6
433625d4  f30f596c244c             mulss    xmm5, dword ptr [esp + 0x4c]
433625da  f30f59742414             mulss    xmm6, dword ptr [esp + 0x14]
433625e0  f30f58e0                 addss    xmm4, xmm0
433625e4  0f28c1                   movaps   xmm0, xmm1
433625e7  f30f58ea                 addss    xmm5, xmm2
433625eb  f30f5944242c             mulss    xmm0, dword ptr [esp + 0x2c]
433625f1  f30f58f7                 addss    xmm6, xmm7
433625f5  f30f594c2438             mulss    xmm1, dword ptr [esp + 0x38]
433625fb  f30f58e8                 addss    xmm5, xmm0
433625ff  f30f58f1                 addss    xmm6, xmm1
43362603  0f28cc                   movaps   xmm1, xmm4
43362606  f30f59cc                 mulss    xmm1, xmm4
4336260a  0f28c5                   movaps   xmm0, xmm5
4336260d  f30f59c5                 mulss    xmm0, xmm5
43362611  f30f58c8                 addss    xmm1, xmm0
43362615  0f28c6                   movaps   xmm0, xmm6
43362618  f30f59c6                 mulss    xmm0, xmm6
4336261c  f30f58c8                 addss    xmm1, xmm0
43362620  0f28c1                   movaps   xmm0, xmm1
43362623  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4336262b  f30f51c0                 sqrtss   xmm0, xmm0
4336262f  f30f11842490010000       movss    dword ptr [esp + 0x190], xmm0
43362638  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43362640  f30f5ec8                 divss    xmm1, xmm0
43362644  f30f10442430             movss    xmm0, dword ptr [esp + 0x30]
4336264a  f30f59e1                 mulss    xmm4, xmm1
4336264e  f30f59e9                 mulss    xmm5, xmm1
43362652  f30f59f1                 mulss    xmm6, xmm1
43362656  f30f59e0                 mulss    xmm4, xmm0
4336265a  f30f59e8                 mulss    xmm5, xmm0
4336265e  f30f59f0                 mulss    xmm6, xmm0
43362662  3994248c000000           cmp      dword ptr [esp + 0x8c], edx
43362669  0f8426010000             je       0x43362795
4336266f  8bf7                     mov      esi, edi
43362671  894c2440                 mov      dword ptr [esp + 0x40], ecx
43362675  8dbc24ec070000           lea      edi, [esp + 0x7ec]
4336267c  8d9424a0270000           lea      edx, [esp + 0x27a0]
43362683  8954241c                 mov      dword ptr [esp + 0x1c], edx
43362687  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43362688  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43362689  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336268a  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
4336268e  f30f104f04               movss    xmm1, dword ptr [edi + 4]
43362693  f30f105708               movss    xmm2, dword ptr [edi + 8]
43362698  f30f58e9                 addss    xmm5, xmm1
4336269c  f30f1007                 movss    xmm0, dword ptr [edi]
433626a0  f30f58d6                 addss    xmm2, xmm6
433626a4  f30f58c4                 addss    xmm0, xmm4
433626a8  f30f11ac24fc070000       movss    dword ptr [esp + 0x7fc], xmm5
433626b1  f30f11942400080000       movss    dword ptr [esp + 0x800], xmm2
433626ba  f30f118424f8070000       movss    dword ptr [esp + 0x7f8], xmm0
433626c3  8bc1                     mov      eax, ecx
433626c5  89442444                 mov      dword ptr [esp + 0x44], eax
433626c9  390a                     cmp      dword ptr [edx], ecx
433626cb  7659                     jbe      0x43362726
433626cd  8db280000000             lea      esi, [edx + 0x80]
433626d3  f30f1006                 movss    xmm0, dword ptr [esi]
433626d7  0f2fc3                   comiss   xmm0, xmm3
433626da  7639                     jbe      0x43362715
433626dc  8b46d4                   mov      eax, dword ptr [esi - 0x2c]
433626df  83e00f                   and      eax, 0xf
433626e2  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
433626eb  0f2f442420               comiss   xmm0, dword ptr [esp + 0x20]
433626f0  721f                     jb       0x43362711
433626f2  8d4ed8                   lea      ecx, [esi - 0x28]
433626f5  8d9424ec070000           lea      edx, [esp + 0x7ec]
433626fc  e8e1a40300               call     0x4339cbe2
43362701  f30f100e                 movss    xmm1, dword ptr [esi]
43362705  0f2fc8                   comiss   xmm1, xmm0
43362708  8b54241c                 mov      edx, dword ptr [esp + 0x1c]
4336270c  7361                     jae      0x4336276f
4336270e  0f57db                   xorps    xmm3, xmm3
43362711  8b442444                 mov      eax, dword ptr [esp + 0x44]
43362715  40                       inc      eax
43362716  81c690000000             add      esi, 0x90
4336271c  89442444                 mov      dword ptr [esp + 0x44], eax
43362720  3b02                     cmp      eax, dword ptr [edx]
43362722  72af                     jb       0x433626d3
43362724  33c9                     xor      ecx, ecx
43362726  33d2                     xor      edx, edx
43362728  884c243f                 mov      byte ptr [esp + 0x3f], cl
4336272c  42                       inc      edx
4336272d  8b742458                 mov      esi, dword ptr [esp + 0x58]
43362731  807c243f00               cmp      byte ptr [esp + 0x3f], 0
43362736  f30f10542478             movss    xmm2, dword ptr [esp + 0x78]
4336273c  f30f106c247c             movss    xmm5, dword ptr [esp + 0x7c]
43362742  f30f107c2464             movss    xmm7, dword ptr [esp + 0x64]
43362748  8d4601                   lea      eax, [esi + 1]
4336274b  0f44c6                   cmove    eax, esi
4336274e  8bf0                     mov      esi, eax
43362750  8b442448                 mov      eax, dword ptr [esp + 0x48]
43362754  83c020                   add      eax, 0x20
43362757  89742458                 mov      dword ptr [esp + 0x58], esi
4336275b  836c245001               sub      dword ptr [esp + 0x50], 1
43362760  89442448                 mov      dword ptr [esp + 0x48], eax
43362764  0f8545feffff             jne      0x433625af
4336276a  e946070000               jmp      0x43362eb5
4336276f  8b742440                 mov      esi, dword ptr [esp + 0x40]
43362773  81c2c00a0000             add      edx, 0xac0
43362779  46                       inc      esi
4336277a  8954241c                 mov      dword ptr [esp + 0x1c], edx
4336277e  89742440                 mov      dword ptr [esp + 0x40], esi
43362782  83fe03                   cmp      esi, 3
43362785  0f8da6010000             jge      0x43362931
4336278b  0f57db                   xorps    xmm3, xmm3
4336278e  33c9                     xor      ecx, ecx
43362790  e92effffff               jmp      0x433626c3
43362795  f30f1007                 movss    xmm0, dword ptr [edi]
43362799  f30f104f04               movss    xmm1, dword ptr [edi + 4]
4336279e  f30f105708               movss    xmm2, dword ptr [edi + 8]
433627a3  f30f11a424800b0000       movss    dword ptr [esp + 0xb80], xmm4
433627ac  f30f11ac24840b0000       movss    dword ptr [esp + 0xb84], xmm5
433627b5  f30f59e4                 mulss    xmm4, xmm4
433627b9  898c24b00b0000           mov      dword ptr [esp + 0xbb0], ecx
433627c0  f30f59ed                 mulss    xmm5, xmm5
433627c4  889424b40b0000           mov      byte ptr [esp + 0xbb4], dl
433627cb  f30f11b424880b0000       movss    dword ptr [esp + 0xb88], xmm6
433627d4  f30f59f6                 mulss    xmm6, xmm6
433627d8  889424b50b0000           mov      byte ptr [esp + 0xbb5], dl
433627df  f30f58e5                 addss    xmm4, xmm5
433627e3  f30f118424700b0000       movss    dword ptr [esp + 0xb70], xmm0
433627ec  0f57c0                   xorps    xmm0, xmm0
433627ef  f30f118c24740b0000       movss    dword ptr [esp + 0xb74], xmm1
433627f8  f30f119424780b0000       movss    dword ptr [esp + 0xb78], xmm2
43362801  0f298424900b0000         movaps   xmmword ptr [esp + 0xb90], xmm0
43362809  0f298424a00b0000         movaps   xmmword ptr [esp + 0xba0], xmm0
43362811  f30f58e6                 addss    xmm4, xmm6
43362815  0f2ee3                   ucomiss  xmm4, xmm3
43362818  9f                       lahf     
43362819  f6c444                   test     ah, 0x44
4336281c  7a07                     jp       0x43362825
4336281e  888c24b50b0000           mov      byte ptr [esp + 0xbb5], cl
43362825  894c2440                 mov      dword ptr [esp + 0x40], ecx
43362829  8db424b4270000           lea      esi, [esp + 0x27b4]
43362830  838c24e40d0000ff         or       dword ptr [esp + 0xde4], 0xffffffff
43362838  8d8424a00d0000           lea      eax, [esp + 0xda0]
4336283f  838c24f00d0000ff         or       dword ptr [esp + 0xdf0], 0xffffffff
43362847  50                       push     eax
43362848  898c24f00d0000           mov      dword ptr [esp + 0xdf0], ecx
4336284f  8d460c                   lea      eax, [esi + 0xc]
43362852  c78424d00d00000000803f   mov      dword ptr [esp + 0xdd0], 0x3f800000
4336285d  8d8c24740b0000           lea      ecx, [esp + 0xb74]
43362864  66c78424da0d00000000     mov      word ptr [esp + 0xdda], 0
4336286e  8b16                     mov      edx, dword ptr [esi]
43362870  50                       push     eax
43362871  e818d20300               call     0x4339fa8e
43362876  85c0                     test     eax, eax
43362878  0f88a6feffff             js       0x43362724
4336287e  f30f108424cc0d0000       movss    xmm0, dword ptr [esp + 0xdcc]
43362887  33c9                     xor      ecx, ecx
43362889  8bc1                     mov      eax, ecx
4336288b  f30f11442468             movss    dword ptr [esp + 0x68], xmm0
43362891  89442444                 mov      dword ptr [esp + 0x44], eax
43362895  394eec                   cmp      dword ptr [esi - 0x14], ecx
43362898  767f                     jbe      0x43362919
4336289a  8bce                     mov      ecx, esi
4336289c  0f57c9                   xorps    xmm1, xmm1
4336289f  894c241c                 mov      dword ptr [esp + 0x1c], ecx
433628a3  8b11                     mov      edx, dword ptr [ecx]
433628a5  f30f104230               movss    xmm0, dword ptr [edx + 0x30]
433628aa  0f2fc1                   comiss   xmm0, xmm1
433628ad  7654                     jbe      0x43362903
433628af  837a0403                 cmp      dword ptr [edx + 4], 3
433628b3  7406                     je       0x433628bb
433628b5  837a0402                 cmp      dword ptr [edx + 4], 2
433628b9  7548                     jne      0x43362903
433628bb  8d8424a00d0000           lea      eax, [esp + 0xda0]
433628c2  c78424cc0d00000000803f   mov      dword ptr [esp + 0xdcc], 0x3f800000
433628cd  8b11                     mov      edx, dword ptr [ecx]
433628cf  50                       push     eax
433628d0  8d410c                   lea      eax, [ecx + 0xc]
433628d3  50                       push     eax
433628d4  8d8c24780b0000           lea      ecx, [esp + 0xb78]
433628db  e8aed10300               call     0x4339fa8e
433628e0  85c0                     test     eax, eax
433628e2  7814                     js       0x433628f8
433628e4  f30f10442468             movss    xmm0, dword ptr [esp + 0x68]
433628ea  0f2f8424cc0d0000         comiss   xmm0, dword ptr [esp + 0xdcc]
433628f2  0f872cfeffff             ja       0x43362724
433628f8  8b442444                 mov      eax, dword ptr [esp + 0x44]
433628fc  0f57c9                   xorps    xmm1, xmm1
433628ff  8b4c241c                 mov      ecx, dword ptr [esp + 0x1c]
43362903  40                       inc      eax
43362904  81c190000000             add      ecx, 0x90
4336290a  89442444                 mov      dword ptr [esp + 0x44], eax
4336290e  894c241c                 mov      dword ptr [esp + 0x1c], ecx
43362912  3b46ec                   cmp      eax, dword ptr [esi - 0x14]
43362915  728c                     jb       0x433628a3
43362917  33c9                     xor      ecx, ecx
43362919  8b442440                 mov      eax, dword ptr [esp + 0x40]
4336291d  81c6c00a0000             add      esi, 0xac0
43362923  40                       inc      eax
43362924  89442440                 mov      dword ptr [esp + 0x40], eax
43362928  83f803                   cmp      eax, 3
4336292b  0f8cfffeffff             jl       0x43362830
43362931  33d2                     xor      edx, edx
43362933  42                       inc      edx
43362934  33c9                     xor      ecx, ecx
43362936  8854243f                 mov      byte ptr [esp + 0x3f], dl
4336293a  e9eefdffff               jmp      0x4336272d
4336293f  0f57c9                   xorps    xmm1, xmm1
43362942  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
43362948  0f2ee9                   ucomiss  xmm5, xmm1
4336294b  9f                       lahf     
4336294c  f6c444                   test     ah, 0x44
4336294f  0f8a84000000             jp       0x433629d9
43362955  0f2ed1                   ucomiss  xmm2, xmm1
43362958  9f                       lahf     
43362959  f6c444                   test     ah, 0x44
4336295c  7a7b                     jp       0x433629d9
4336295e  0f57c0                   xorps    xmm0, xmm0
43362961  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
43362967  f30f118424b4000000       movss    dword ptr [esp + 0xb4], xmm0
43362970  f30f10842488000000       movss    xmm0, dword ptr [esp + 0x88]
43362979  f30f1144244c             movss    dword ptr [esp + 0x4c], xmm0
4336297f  f30f118424b8000000       movss    dword ptr [esp + 0xb8], xmm0
43362988  0f57c0                   xorps    xmm0, xmm0
4336298b  f30f11442440             movss    dword ptr [esp + 0x40], xmm0
43362991  f30f118424bc000000       movss    dword ptr [esp + 0xbc], xmm0
4336299a  0f28c7                   movaps   xmm0, xmm7
4336299d  0f5705d0034743           xorps    xmm0, xmmword ptr [0x434703d0]
433629a4  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
433629aa  f30f118424a8000000       movss    dword ptr [esp + 0xa8], xmm0
433629b3  0f57c0                   xorps    xmm0, xmm0
433629b6  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
433629bc  f30f118424ac000000       movss    dword ptr [esp + 0xac], xmm0
433629c5  f30f11442458             movss    dword ptr [esp + 0x58], xmm0
433629cb  f30f118424b0000000       movss    dword ptr [esp + 0xb0], xmm0
433629d4  e951010000               jmp      0x43362b2a
433629d9  0f28e7                   movaps   xmm4, xmm7
433629dc  0f28da                   movaps   xmm3, xmm2
433629df  f30f59e1                 mulss    xmm4, xmm1
433629e3  0f28f5                   movaps   xmm6, xmm5
433629e6  f30f59f1                 mulss    xmm6, xmm1
433629ea  0f28c2                   movaps   xmm0, xmm2
433629ed  f30f59c1                 mulss    xmm0, xmm1
433629f1  f30f5cdc                 subss    xmm3, xmm4
433629f5  f30f5ce5                 subss    xmm4, xmm5
433629f9  f30f5cf0                 subss    xmm6, xmm0
433629fd  0f28cb                   movaps   xmm1, xmm3
43362a00  f30f59cb                 mulss    xmm1, xmm3
43362a04  0f28c4                   movaps   xmm0, xmm4
43362a07  f30f59c4                 mulss    xmm0, xmm4
43362a0b  f30f58c8                 addss    xmm1, xmm0
43362a0f  0f28c6                   movaps   xmm0, xmm6
43362a12  f30f59c6                 mulss    xmm0, xmm6
43362a16  f30f58c8                 addss    xmm1, xmm0
43362a1a  0f28c1                   movaps   xmm0, xmm1
43362a1d  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43362a25  f30f51c0                 sqrtss   xmm0, xmm0
43362a29  f30f11842490010000       movss    dword ptr [esp + 0x190], xmm0
43362a32  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43362a3a  f30f5ec8                 divss    xmm1, xmm0
43362a3e  f30f59d9                 mulss    xmm3, xmm1
43362a42  f30f59f1                 mulss    xmm6, xmm1
43362a46  f30f59e1                 mulss    xmm4, xmm1
43362a4a  f30f115c2414             movss    dword ptr [esp + 0x14], xmm3
43362a50  0f28c6                   movaps   xmm0, xmm6
43362a53  f30f104c2414             movss    xmm1, dword ptr [esp + 0x14]
43362a59  f30f59c2                 mulss    xmm0, xmm2
43362a5d  f30f119c24b4000000       movss    dword ptr [esp + 0xb4], xmm3
43362a66  0f28dc                   movaps   xmm3, xmm4
43362a69  f30f59df                 mulss    xmm3, xmm7
43362a6d  f30f11742440             movss    dword ptr [esp + 0x40], xmm6
43362a73  f30f11b424bc000000       movss    dword ptr [esp + 0xbc], xmm6
43362a7c  f30f5cd8                 subss    xmm3, xmm0
43362a80  f30f59f5                 mulss    xmm6, xmm5
43362a84  0f28c1                   movaps   xmm0, xmm1
43362a87  f30f1164244c             movss    dword ptr [esp + 0x4c], xmm4
43362a8d  f30f59c7                 mulss    xmm0, xmm7
43362a91  0f28f9                   movaps   xmm7, xmm1
43362a94  f30f59fa                 mulss    xmm7, xmm2
43362a98  0f28cb                   movaps   xmm1, xmm3
43362a9b  f30f5cf0                 subss    xmm6, xmm0
43362a9f  f30f59cb                 mulss    xmm1, xmm3
43362aa3  0f28c4                   movaps   xmm0, xmm4
43362aa6  f30f11a424b8000000       movss    dword ptr [esp + 0xb8], xmm4
43362aaf  f30f59c5                 mulss    xmm0, xmm5
43362ab3  f30f5cf8                 subss    xmm7, xmm0
43362ab7  0f28c6                   movaps   xmm0, xmm6
43362aba  f30f59c6                 mulss    xmm0, xmm6
43362abe  f30f58c8                 addss    xmm1, xmm0
43362ac2  0f28c7                   movaps   xmm0, xmm7
43362ac5  f30f59c7                 mulss    xmm0, xmm7
43362ac9  f30f58c8                 addss    xmm1, xmm0
43362acd  0f28c1                   movaps   xmm0, xmm1
43362ad0  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43362ad8  f30f51c0                 sqrtss   xmm0, xmm0
43362adc  f30f11842488010000       movss    dword ptr [esp + 0x188], xmm0
43362ae5  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43362aed  f30f5ec8                 divss    xmm1, xmm0
43362af1  f30f59d9                 mulss    xmm3, xmm1
43362af5  f30f59f1                 mulss    xmm6, xmm1
43362af9  f30f59f9                 mulss    xmm7, xmm1
43362afd  f30f115c2424             movss    dword ptr [esp + 0x24], xmm3
43362b03  f30f119c24a8000000       movss    dword ptr [esp + 0xa8], xmm3
43362b0c  f30f11742438             movss    dword ptr [esp + 0x38], xmm6
43362b12  f30f11b424ac000000       movss    dword ptr [esp + 0xac], xmm6
43362b1b  f30f117c2458             movss    dword ptr [esp + 0x58], xmm7
43362b21  f30f11bc24b0000000       movss    dword ptr [esp + 0xb0], xmm7
43362b2a  8b8c2490000000           mov      ecx, dword ptr [esp + 0x90]
43362b31  83c108                   add      ecx, 8
43362b34  8b01                     mov      eax, dword ptr [ecx]
43362b36  ff5028                   call     dword ptr [eax + 0x28]
43362b39  85c0                     test     eax, eax
43362b3b  750c                     jne      0x43362b49
43362b3d  7648                     jbe      0x43362b87
43362b3f  298b98149457             sub      dword ptr [ebx + 0x57941498], ecx
43362b45  793d                     jns      0x43362b84
43362b47  2af6                     sub      dh, dh
43362b49  8bc8                     mov      ecx, eax
43362b4b  e8db5e0500               call     0x433b8a2b
43362b50  8b842480000000           mov      eax, dword ptr [esp + 0x80]
43362b57  0f57ff                   xorps    xmm7, xmm7
43362b5a  8944241c                 mov      dword ptr [esp + 0x1c], eax
43362b5e  33f6                     xor      esi, esi
43362b60  c744242820000000         mov      dword ptr [esp + 0x28], 0x20
43362b68  f30f1028                 movss    xmm5, dword ptr [eax]
43362b6c  33c9                     xor      ecx, ecx
43362b6e  f30f104804               movss    xmm1, dword ptr [eax + 4]
43362b73  0f28d5                   movaps   xmm2, xmm5
43362b76  f30f59542414             mulss    xmm2, dword ptr [esp + 0x14]
43362b7c  0f28c1                   movaps   xmm0, xmm1
43362b7f  f30f59442424             mulss    xmm0, dword ptr [esp + 0x24]
43362b84  240f                     and      al, 0xf
43362b85  0f28f5                   movaps   xmm6, xmm5
43362b86  28f5                     sub      ch, dh
43362b87  f5                       cmc      
43362b88  f30f5974244c             mulss    xmm6, dword ptr [esp + 0x4c]
43362b8e  f30f5854247c             addss    xmm2, dword ptr [esp + 0x7c]
43362b94  f30f596c2440             mulss    xmm5, dword ptr [esp + 0x40]
43362b9a  f30f58742478             addss    xmm6, dword ptr [esp + 0x78]
43362ba0  f30f10642430             movss    xmm4, dword ptr [esp + 0x30]
43362ba6  f30f586c2464             addss    xmm5, dword ptr [esp + 0x64]
43362bac  f30f58d0                 addss    xmm2, xmm0
43362bb0  0f28c1                   movaps   xmm0, xmm1
43362bb3  f30f59442438             mulss    xmm0, dword ptr [esp + 0x38]
43362bb9  f30f594c2458             mulss    xmm1, dword ptr [esp + 0x58]
43362bbf  f30f58f0                 addss    xmm6, xmm0
43362bc3  f30f58e9                 addss    xmm5, xmm1
43362bc7  0f28ca                   movaps   xmm1, xmm2
43362bca  f30f59ca                 mulss    xmm1, xmm2
43362bce  0f28c6                   movaps   xmm0, xmm6
43362bd1  f30f59c6                 mulss    xmm0, xmm6
43362bd5  f30f58c8                 addss    xmm1, xmm0
43362bd9  0f28c5                   movaps   xmm0, xmm5
43362bdc  f30f59c5                 mulss    xmm0, xmm5
43362be0  f30f58c8                 addss    xmm1, xmm0
43362be4  0f28c1                   movaps   xmm0, xmm1
43362be7  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43362bef  f30f51c0                 sqrtss   xmm0, xmm0
43362bf3  f30f11842494010000       movss    dword ptr [esp + 0x194], xmm0
43362bfc  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43362c04  f30f5ec8                 divss    xmm1, xmm0
43362c08  f30f59f1                 mulss    xmm6, xmm1
43362c0c  f30f59d1                 mulss    xmm2, xmm1
43362c10  f30f59e9                 mulss    xmm5, xmm1
43362c14  0f28c6                   movaps   xmm0, xmm6
43362c17  f30f59c6                 mulss    xmm0, xmm6
43362c1b  0f28ca                   movaps   xmm1, xmm2
43362c1e  f30f59ca                 mulss    xmm1, xmm2
43362c22  f30f58c8                 addss    xmm1, xmm0
43362c26  0f28c5                   movaps   xmm0, xmm5
43362c29  f30f59c5                 mulss    xmm0, xmm5
43362c2d  f30f58c8                 addss    xmm1, xmm0
43362c31  0f28c1                   movaps   xmm0, xmm1
43362c34  f30f104f04               movss    xmm1, dword ptr [edi + 4]
43362c39  f30f51c0                 sqrtss   xmm0, xmm0
43362c3d  f30f1184247c030000       movss    dword ptr [esp + 0x37c], xmm0
43362c46  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43362c4e  f30f5ee0                 divss    xmm4, xmm0
43362c52  f30f1007                 movss    xmm0, dword ptr [edi]
43362c56  f30f59f4                 mulss    xmm6, xmm4
43362c5a  0f28dc                   movaps   xmm3, xmm4
43362c5d  f30f59da                 mulss    xmm3, xmm2
43362c61  f30f105708               movss    xmm2, dword ptr [edi + 8]
43362c66  f30f11b42494050000       movss    dword ptr [esp + 0x594], xmm6
43362c6f  f30f59e5                 mulss    xmm4, xmm5
43362c73  898c24c0050000           mov      dword ptr [esp + 0x5c0], ecx
43362c7a  f30f119c2490050000       movss    dword ptr [esp + 0x590], xmm3
43362c83  f30f59f6                 mulss    xmm6, xmm6
43362c87  c68424c405000001         mov      byte ptr [esp + 0x5c4], 1
43362c8f  f30f59db                 mulss    xmm3, xmm3
43362c93  c68424c505000001         mov      byte ptr [esp + 0x5c5], 1
43362c9b  f30f11a42498050000       movss    dword ptr [esp + 0x598], xmm4
43362ca4  f30f59e4                 mulss    xmm4, xmm4
43362ca8  f30f58f3                 addss    xmm6, xmm3
43362cac  f30f118c2484050000       movss    dword ptr [esp + 0x584], xmm1
43362cb5  0f57c9                   xorps    xmm1, xmm1
43362cb8  f30f11842480050000       movss    dword ptr [esp + 0x580], xmm0
43362cc1  f30f11942488050000       movss    dword ptr [esp + 0x588], xmm2
43362cca  0f29bc24a0050000         movaps   xmmword ptr [esp + 0x5a0], xmm7
43362cd2  0f29bc24b0050000         movaps   xmmword ptr [esp + 0x5b0], xmm7
43362cda  f30f58f4                 addss    xmm6, xmm4
43362cde  0f2ef1                   ucomiss  xmm6, xmm1
43362ce1  9f                       lahf     
43362ce2  f6c444                   test     ah, 0x44
43362ce5  7a07                     jp       0x43362cee
43362ce7  888c24c5050000           mov      byte ptr [esp + 0x5c5], cl
43362cee  f30f101514054743         movss    xmm2, dword ptr [0x43470514]
43362cf6  bfffffff7f               mov      edi, 0x7fffffff
43362cfb  838c2414090000ff         or       dword ptr [esp + 0x914], 0xffffffff
43362d03  8bc1                     mov      eax, ecx
43362d05  838c2420090000ff         or       dword ptr [esp + 0x920], 0xffffffff
43362d0d  c78424fc0800000000803f   mov      dword ptr [esp + 0x8fc], 0x3f800000
43362d18  66898c2406090000         mov      word ptr [esp + 0x906], cx
43362d20  898c241c090000           mov      dword ptr [esp + 0x91c], ecx
43362d27  f30f11542444             movss    dword ptr [esp + 0x44], xmm2
43362d2d  894c2450                 mov      dword ptr [esp + 0x50], ecx
43362d31  894c2448                 mov      dword ptr [esp + 0x48], ecx
43362d35  8b80b0494743             mov      eax, dword ptr [eax + 0x434749b0]
43362d3b  3b8424e01c0000           cmp      eax, dword ptr [esp + 0x1ce0]
43362d42  0f83ab000000             jae      0x43362df3
43362d48  69c090000000             imul     eax, eax, 0x90
43362d4e  8d9424f01c0000           lea      edx, [esp + 0x1cf0]
43362d55  03d0                     add      edx, eax
43362d57  89542468                 mov      dword ptr [esp + 0x68], edx
43362d5b  8b4244                   mov      eax, dword ptr [edx + 0x44]
43362d5e  83e00f                   and      eax, 0xf
43362d61  393c8570494743           cmp      dword ptr [eax*4 + 0x43474970], edi
43362d68  0f8785000000             ja       0x43362df3
43362d6e  c78424fc0800000000803f   mov      dword ptr [esp + 0x8fc], 0x3f800000
43362d79  8d8424d0080000           lea      eax, [esp + 0x8d0]
43362d80  f30f104270               movss    xmm0, dword ptr [edx + 0x70]
43362d85  8d8c2480050000           lea      ecx, [esp + 0x580]
43362d8c  0f2fc1                   comiss   xmm0, xmm1
43362d8f  50                       push     eax
43362d90  760a                     jbe      0x43362d9c
43362d92  8d5240                   lea      edx, [edx + 0x40]
43362d95  e86f600900               call     0x433f8e09
43362d9a  eb0c                     jmp      0x43362da8
43362d9c  8d4210                   lea      eax, [edx + 0x10]
43362d9f  8b5204                   mov      edx, dword ptr [edx + 4]
43362da2  50                       push     eax
43362da3  e8e6cc0300               call     0x4339fa8e
43362da8  f30f10542444             movss    xmm2, dword ptr [esp + 0x44]
43362dae  85c0                     test     eax, eax
43362db0  782a                     js       0x43362ddc
43362db2  0f2f9424fc080000         comiss   xmm2, dword ptr [esp + 0x8fc]
43362dba  7620                     jbe      0x43362ddc
43362dbc  8b442468                 mov      eax, dword ptr [esp + 0x68]
43362dc0  f30f109424fc080000       movss    xmm2, dword ptr [esp + 0x8fc]
43362dc9  f30f11542444             movss    dword ptr [esp + 0x44], xmm2
43362dcf  89442450                 mov      dword ptr [esp + 0x50], eax
43362dd3  83784401                 cmp      dword ptr [eax + 0x44], 1
43362dd7  751a                     jne      0x43362df3
43362dd9  6a02                     push     2
43362ddb  5f                       pop      edi
43362ddc  8b442448                 mov      eax, dword ptr [esp + 0x48]
43362de0  0f57c9                   xorps    xmm1, xmm1
43362de3  83c004                   add      eax, 4
43362de6  89442448                 mov      dword ptr [esp + 0x48], eax
43362dea  83f83c                   cmp      eax, 0x3c
43362ded  0f8242ffffff             jb       0x43362d35
43362df3  8b442450                 mov      eax, dword ptr [esp + 0x50]
43362df7  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
43362dfb  85c0                     test     eax, eax
43362dfd  0f8499000000             je       0x43362e9c
43362e03  f30f10842490050000       movss    xmm0, dword ptr [esp + 0x590]
43362e0c  8b4844                   mov      ecx, dword ptr [eax + 0x44]
43362e0f  f30f59c2                 mulss    xmm0, xmm2
43362e13  898c2414090000           mov      dword ptr [esp + 0x914], ecx
43362e1a  8b00                     mov      eax, dword ptr [eax]
43362e1c  89842420090000           mov      dword ptr [esp + 0x920], eax
43362e23  f30f58842480050000       addss    xmm0, dword ptr [esp + 0x580]
43362e2c  8b4508                   mov      eax, dword ptr [ebp + 8]
43362e2f  f30f118424dc080000       movss    dword ptr [esp + 0x8dc], xmm0
43362e38  f30f10842494050000       movss    xmm0, dword ptr [esp + 0x594]
43362e41  f30f59c2                 mulss    xmm0, xmm2
43362e45  f30f58842484050000       addss    xmm0, dword ptr [esp + 0x584]
43362e4e  f30f118424e0080000       movss    dword ptr [esp + 0x8e0], xmm0
43362e57  f30f10842498050000       movss    xmm0, dword ptr [esp + 0x598]
43362e60  f30f59c2                 mulss    xmm0, xmm2
43362e64  f30f58842488050000       addss    xmm0, dword ptr [esp + 0x588]
43362e6d  f30f118424e4080000       movss    dword ptr [esp + 0x8e4], xmm0
43362e76  83b89c01000001           cmp      dword ptr [eax + 0x19c], 1
43362e7d  7f1c                     jg       0x43362e9b
43362e7f  398c248c000000           cmp      dword ptr [esp + 0x8c], ecx
43362e86  7413                     je       0x43362e9b
43362e88  83e10f                   and      ecx, 0xf
43362e8b  f30f10048d40454743       movss    xmm0, dword ptr [ecx*4 + 0x43474540]
43362e94  0f2f442420               comiss   xmm0, dword ptr [esp + 0x20]
43362e99  7201                     jb       0x43362e9c
43362e9b  46                       inc      esi
43362e9c  8b44241c                 mov      eax, dword ptr [esp + 0x1c]
43362ea0  0f57ff                   xorps    xmm7, xmm7
43362ea3  83c020                   add      eax, 0x20
43362ea6  836c242801               sub      dword ptr [esp + 0x28], 1
43362eab  8944241c                 mov      dword ptr [esp + 0x1c], eax
43362eaf  0f85b3fcffff             jne      0x43362b68
43362eb5  660f6ec6                 movd     xmm0, esi
43362eb9  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
43362ebd  0f5bc0                   cvtdq2ps xmm0, xmm0
43362ec0  f30f590528f64643         mulss    xmm0, dword ptr [0x4346f628]
43362ec8  f30f114670               movss    dword ptr [esi + 0x70], xmm0
43362ecd  f60610                   test     byte ptr [esi], 0x10
43362ed0  0f8465130000             je       0x4336423b
43362ed6  f686a400000002           test     byte ptr [esi + 0xa4], 2
43362edd  0f8458130000             je       0x4336423b
43362ee3  8d467c                   lea      eax, [esi + 0x7c]
43362ee6  81c688000000             add      esi, 0x88
43362eec  8d7c246c                 lea      edi, [esp + 0x6c]
43362ef0  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43362ef1  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43362ef2  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43362ef3  8bf0                     mov      esi, eax
43362ef5  8dbc2494000000           lea      edi, [esp + 0x94]
43362efc  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43362efd  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43362efe  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
43362eff  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
43362f03  8b8e94000000             mov      ecx, dword ptr [esi + 0x94]
43362f09  8b86a0000000             mov      eax, dword ptr [esi + 0xa0]
43362f0f  898424a0000000           mov      dword ptr [esp + 0xa0], eax
43362f16  85c9                     test     ecx, ecx
43362f18  7f0a                     jg       0x43362f24
43362f1a  33c9                     xor      ecx, ecx
43362f1c  bfffffff7f               mov      edi, 0x7fffffff
43362f21  41                       inc      ecx
43362f22  eb13                     jmp      0x43362f37
43362f24  8b4608                   mov      eax, dword ptr [esi + 8]
43362f27  48                       dec      eax
43362f28  03c1                     add      eax, ecx
43362f2a  99                       cdq      
43362f2b  f7f9                     idiv     ecx
43362f2d  33c9                     xor      ecx, ecx
43362f2f  41                       inc      ecx
43362f30  3bc1                     cmp      eax, ecx
43362f32  8bf9                     mov      edi, ecx
43362f34  0f4ff8                   cmovg    edi, eax
43362f37  8b9698000000             mov      edx, dword ptr [esi + 0x98]
43362f3d  89542430                 mov      dword ptr [esp + 0x30], edx
43362f41  85d2                     test     edx, edx
43362f43  7f07                     jg       0x43362f4c
43362f45  baffffff7f               mov      edx, 0x7fffffff
43362f4a  eb12                     jmp      0x43362f5e
43362f4c  8b4608                   mov      eax, dword ptr [esi + 8]
43362f4f  4a                       dec      edx
43362f50  03c2                     add      eax, edx
43362f52  99                       cdq      
43362f53  f77c2430                 idiv     dword ptr [esp + 0x30]
43362f57  8bd1                     mov      edx, ecx
43362f59  3bc1                     cmp      eax, ecx
43362f5b  0f4fd0                   cmovg    edx, eax
43362f5e  89542438                 mov      dword ptr [esp + 0x38], edx
43362f62  3bfa                     cmp      edi, edx
43362f64  0f8475050000             je       0x433634df
43362f6a  0fb605e0a34643           movzx    eax, byte ptr [0x4346a3e0]
43362f71  8d8c2490110000           lea      ecx, [esp + 0x1190]
43362f78  8364243400               and      dword ptr [esp + 0x34], 0
43362f7d  0f57c0                   xorps    xmm0, xmm0
43362f80  50                       push     eax
43362f81  8b4508                   mov      eax, dword ptr [ebp + 8]
43362f84  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
43362f8a  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
43362f92  f30f1144241c             movss    dword ptr [esp + 0x1c], xmm0
43362f98  ff700c                   push     dword ptr [eax + 0xc]
43362f9b  e8eb820800               call     0x433eb28b
43362fa0  f30f1084249c000000       movss    xmm0, dword ptr [esp + 0x9c]
43362fa9  f30f109c2494000000       movss    xmm3, dword ptr [esp + 0x94]
43362fb2  f30f10ac2498000000       movss    xmm5, dword ptr [esp + 0x98]
43362fbb  f30f5c442474             subss    xmm0, dword ptr [esp + 0x74]
43362fc1  f30f5c5c246c             subss    xmm3, dword ptr [esp + 0x6c]
43362fc7  f30f5c6c2470             subss    xmm5, dword ptr [esp + 0x70]
43362fcd  f30f10542418             movss    xmm2, dword ptr [esp + 0x18]
43362fd3  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
43362fd7  f30f11442450             movss    dword ptr [esp + 0x50], xmm0
43362fdd  0f57c0                   xorps    xmm0, xmm0
43362fe0  f30f115c2458             movss    dword ptr [esp + 0x58], xmm3
43362fe6  f30f116c2448             movss    dword ptr [esp + 0x48], xmm5
43362fec  c744244004000000         mov      dword ptr [esp + 0x40], 4
43362ff4  838c24c4060000ff         or       dword ptr [esp + 0x6c4], 0xffffffff
43362ffc  0f28ca                   movaps   xmm1, xmm2
43362fff  f30f58c8                 addss    xmm1, xmm0
43363003  838c24d0060000ff         or       dword ptr [esp + 0x6d0], 0xffffffff
4336300b  33d2                     xor      edx, edx
4336300d  c78424ac0600000000803f   mov      dword ptr [esp + 0x6ac], 0x3f800000
43363018  66899424b6060000         mov      word ptr [esp + 0x6b6], dx
43363020  33c9                     xor      ecx, ecx
43363022  899424cc060000           mov      dword ptr [esp + 0x6cc], edx
43363029  41                       inc      ecx
4336302a  f30f1007                 movss    xmm0, dword ptr [edi]
4336302e  f30f590d40224743         mulss    xmm1, dword ptr [0x43472240]
43363036  f30f107f08               movss    xmm7, dword ptr [edi + 8]
4336303b  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
43363041  0f28f1                   movaps   xmm6, xmm1
43363044  f30f114c2428             movss    dword ptr [esp + 0x28], xmm1
4336304a  0f28e1                   movaps   xmm4, xmm1
4336304d  f30f59f3                 mulss    xmm6, xmm3
43363051  0f28d1                   movaps   xmm2, xmm1
43363054  f30f59e5                 mulss    xmm4, xmm5
43363058  f30f5874246c             addss    xmm6, dword ptr [esp + 0x6c]
4336305e  f30f59542450             mulss    xmm2, dword ptr [esp + 0x50]
43363064  f30f58642470             addss    xmm4, dword ptr [esp + 0x70]
4336306a  f30f102d14054743         movss    xmm5, dword ptr [0x43470514]
43363072  f30f58542474             addss    xmm2, dword ptr [esp + 0x74]
43363078  f30f5cf0                 subss    xmm6, xmm0
4336307c  f30f104704               movss    xmm0, dword ptr [edi + 4]
43363081  f30f11442468             movss    dword ptr [esp + 0x68], xmm0
43363087  f30f5ce0                 subss    xmm4, xmm0
4336308b  f30f11bc24d8050000       movss    dword ptr [esp + 0x5d8], xmm7
43363094  89942410060000           mov      dword ptr [esp + 0x610], edx
4336309b  f30f5cd7                 subss    xmm2, xmm7
4336309f  888c2414060000           mov      byte ptr [esp + 0x614], cl
433630a6  0f28ce                   movaps   xmm1, xmm6
433630a9  f30f59ce                 mulss    xmm1, xmm6
433630ad  0f28c4                   movaps   xmm0, xmm4
433630b0  f30f59c4                 mulss    xmm0, xmm4
433630b4  f30f58c8                 addss    xmm1, xmm0
433630b8  0f28c2                   movaps   xmm0, xmm2
433630bb  f30f59c2                 mulss    xmm0, xmm2
433630bf  f30f58c8                 addss    xmm1, xmm0
433630c3  0f28c1                   movaps   xmm0, xmm1
433630c6  f30f51c0                 sqrtss   xmm0, xmm0
433630ca  f30f11842480030000       movss    dword ptr [esp + 0x380], xmm0
433630d3  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433630db  f30f5ee8                 divss    xmm5, xmm0
433630df  0f28dd                   movaps   xmm3, xmm5
433630e2  f30f59f5                 mulss    xmm6, xmm5
433630e6  f30f59dc                 mulss    xmm3, xmm4
433630ea  0f28ce                   movaps   xmm1, xmm6
433630ed  f30f59ea                 mulss    xmm5, xmm2
433630f1  0f28c3                   movaps   xmm0, xmm3
433630f4  f30f59ce                 mulss    xmm1, xmm6
433630f8  f30f59c3                 mulss    xmm0, xmm3
433630fc  f30f109424a4110000       movss    xmm2, dword ptr [esp + 0x11a4]
43363105  f30f58c8                 addss    xmm1, xmm0
43363109  0f28c5                   movaps   xmm0, xmm5
4336310c  f30f59c5                 mulss    xmm0, xmm5
43363110  f30f58c8                 addss    xmm1, xmm0
43363114  0f28c1                   movaps   xmm0, xmm1
43363117  f30f51c0                 sqrtss   xmm0, xmm0
4336311b  f30f11842484030000       movss    dword ptr [esp + 0x384], xmm0
43363124  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4336312c  f30f5ed0                 divss    xmm2, xmm0
43363130  0f28c2                   movaps   xmm0, xmm2
43363133  0f28ca                   movaps   xmm1, xmm2
43363136  f30f59c3                 mulss    xmm0, xmm3
4336313a  f30f105c2430             movss    xmm3, dword ptr [esp + 0x30]
43363140  f30f59ce                 mulss    xmm1, xmm6
43363144  f30f119c24d0050000       movss    dword ptr [esp + 0x5d0], xmm3
4336314d  f30f105c2468             movss    xmm3, dword ptr [esp + 0x68]
43363153  f30f59d5                 mulss    xmm2, xmm5
43363157  f30f119c24d4050000       movss    dword ptr [esp + 0x5d4], xmm3
43363160  0f57db                   xorps    xmm3, xmm3
43363163  f30f118c24e0050000       movss    dword ptr [esp + 0x5e0], xmm1
4336316c  f30f118424e4050000       movss    dword ptr [esp + 0x5e4], xmm0
43363175  f30f119424e8050000       movss    dword ptr [esp + 0x5e8], xmm2
4336317e  0f299c24f0050000         movaps   xmmword ptr [esp + 0x5f0], xmm3
43363186  0f299c2400060000         movaps   xmmword ptr [esp + 0x600], xmm3
4336318e  f30f59c9                 mulss    xmm1, xmm1
43363192  f30f59c0                 mulss    xmm0, xmm0
43363196  f30f58c8                 addss    xmm1, xmm0
4336319a  f30f59d2                 mulss    xmm2, xmm2
4336319e  888c2415060000           mov      byte ptr [esp + 0x615], cl
433631a5  f30f58ca                 addss    xmm1, xmm2
433631a9  0f57d2                   xorps    xmm2, xmm2
433631ac  0f2eca                   ucomiss  xmm1, xmm2
433631af  9f                       lahf     
433631b0  f6c444                   test     ah, 0x44
433631b3  7a07                     jp       0x433631bc
433631b5  88942415060000           mov      byte ptr [esp + 0x615], dl
433631bc  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
433631c4  8bc2                     mov      eax, edx
433631c6  c7442430ffffff7f         mov      dword ptr [esp + 0x30], 0x7fffffff
433631ce  8b7c2430                 mov      edi, dword ptr [esp + 0x30]
433631d2  f30f114c2414             movss    dword ptr [esp + 0x14], xmm1
433631d8  8954244c                 mov      dword ptr [esp + 0x4c], edx
433631dc  89442424                 mov      dword ptr [esp + 0x24], eax
433631e0  8b80b0494743             mov      eax, dword ptr [eax + 0x434749b0]
433631e6  3b8424e01c0000           cmp      eax, dword ptr [esp + 0x1ce0]
433631ed  0f83b4000000             jae      0x433632a7
433631f3  69c090000000             imul     eax, eax, 0x90
433631f9  8d8c24f01c0000           lea      ecx, [esp + 0x1cf0]
43363200  03c8                     add      ecx, eax
43363202  894c2430                 mov      dword ptr [esp + 0x30], ecx
43363206  8d7140                   lea      esi, [ecx + 0x40]
43363209  8b4604                   mov      eax, dword ptr [esi + 4]
4336320c  83e00f                   and      eax, 0xf
4336320f  393c8570494743           cmp      dword ptr [eax*4 + 0x43474970], edi
43363216  0f878b000000             ja       0x433632a7
4336321c  c78424ac0600000000803f   mov      dword ptr [esp + 0x6ac], 0x3f800000
43363227  8d842480060000           lea      eax, [esp + 0x680]
4336322e  f30f104630               movss    xmm0, dword ptr [esi + 0x30]
43363233  0f2fc2                   comiss   xmm0, xmm2
43363236  50                       push     eax
43363237  7610                     jbe      0x43363249
43363239  8bd6                     mov      edx, esi
4336323b  8d8c24d4050000           lea      ecx, [esp + 0x5d4]
43363242  e8c25b0900               call     0x433f8e09
43363247  eb13                     jmp      0x4336325c
43363249  8b5104                   mov      edx, dword ptr [ecx + 4]
4336324c  8d4110                   lea      eax, [ecx + 0x10]
4336324f  50                       push     eax
43363250  8d8c24d8050000           lea      ecx, [esp + 0x5d8]
43363257  e832c80300               call     0x4339fa8e
4336325c  f30f104c2414             movss    xmm1, dword ptr [esp + 0x14]
43363262  85c0                     test     eax, eax
43363264  782a                     js       0x43363290
43363266  0f2f8c24ac060000         comiss   xmm1, dword ptr [esp + 0x6ac]
4336326e  7620                     jbe      0x43363290
43363270  837e0401                 cmp      dword ptr [esi + 4], 1
43363274  f30f108c24ac060000       movss    xmm1, dword ptr [esp + 0x6ac]
4336327d  8b442430                 mov      eax, dword ptr [esp + 0x30]
43363281  f30f114c2414             movss    dword ptr [esp + 0x14], xmm1
43363287  8944244c                 mov      dword ptr [esp + 0x4c], eax
4336328b  751a                     jne      0x433632a7
4336328d  6a02                     push     2
4336328f  5f                       pop      edi
43363290  8b442424                 mov      eax, dword ptr [esp + 0x24]
43363294  0f57d2                   xorps    xmm2, xmm2
43363297  83c004                   add      eax, 4
4336329a  89442424                 mov      dword ptr [esp + 0x24], eax
4336329e  83f83c                   cmp      eax, 0x3c
433632a1  0f8239ffffff             jb       0x433631e0
433632a7  8b54244c                 mov      edx, dword ptr [esp + 0x4c]
433632ab  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
433632af  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
433632b3  85d2                     test     edx, edx
433632b5  0f846e010000             je       0x43363429
433632bb  f30f108424e0050000       movss    xmm0, dword ptr [esp + 0x5e0]
433632c4  8b4a44                   mov      ecx, dword ptr [edx + 0x44]
433632c7  f30f59c1                 mulss    xmm0, xmm1
433632cb  898c24c4060000           mov      dword ptr [esp + 0x6c4], ecx
433632d2  83e10f                   and      ecx, 0xf
433632d5  8b02                     mov      eax, dword ptr [edx]
433632d7  898424d0060000           mov      dword ptr [esp + 0x6d0], eax
433632de  f30f588424d0050000       addss    xmm0, dword ptr [esp + 0x5d0]
433632e7  8b8424a0000000           mov      eax, dword ptr [esp + 0xa0]
433632ee  83e00f                   and      eax, 0xf
433632f1  f30f1184248c060000       movss    dword ptr [esp + 0x68c], xmm0
433632fa  f30f108424e4050000       movss    xmm0, dword ptr [esp + 0x5e4]
43363303  f30f59c1                 mulss    xmm0, xmm1
43363307  f30f588424d4050000       addss    xmm0, dword ptr [esp + 0x5d4]
43363310  f30f11842490060000       movss    dword ptr [esp + 0x690], xmm0
43363319  f30f108424e8050000       movss    xmm0, dword ptr [esp + 0x5e8]
43363322  f30f59c1                 mulss    xmm0, xmm1
43363326  f30f588424d8050000       addss    xmm0, dword ptr [esp + 0x5d8]
4336332f  f30f11842494060000       movss    dword ptr [esp + 0x694], xmm0
43363338  f30f10048d40454743       movss    xmm0, dword ptr [ecx*4 + 0x43474540]
43363341  0f2f048540454743         comiss   xmm0, dword ptr [eax*4 + 0x43474540]
43363349  0f82da000000             jb       0x43363429
4336334f  0f280590f24643           movaps   xmm0, xmmword ptr [0x4346f290]
43363356  33c0                     xor      eax, eax
43363358  8b0d08584743             mov      ecx, dword ptr [0x43475808]
4336335e  8bd7                     mov      edx, edi
43363360  8984248c080000           mov      dword ptr [esp + 0x88c], eax
43363367  89842490080000           mov      dword ptr [esp + 0x890], eax
4336336e  89842494080000           mov      dword ptr [esp + 0x894], eax
43363375  8d842490110000           lea      eax, [esp + 0x1190]
4336337c  50                       push     eax
4336337d  8d84248c080000           lea      eax, [esp + 0x88c]
43363384  c78424ac0800000000803f   mov      dword ptr [esp + 0x8ac], 0x3f800000
4336338f  50                       push     eax
43363390  8d842494060000           lea      eax, [esp + 0x694]
43363397  c784249008000004044743   mov      dword ptr [esp + 0x890], 0x43470404
433633a2  50                       push     eax
433633a3  0f118424a4080000         movups   xmmword ptr [esp + 0x8a4], xmm0
433633ab  e87b69fcff               call     0x43329d2b
433633b0  f30f2c842498110000       cvttss2si eax, dword ptr [esp + 0x1198]
433633b9  85c0                     test     eax, eax
433633bb  746c                     je       0x43363429
433633bd  ffb424c4060000           push     dword ptr [esp + 0x6c4]
433633c4  8d8c2494110000           lea      ecx, [esp + 0x1194]
433633cb  ffb42494000000           push     dword ptr [esp + 0x94]
433633d2  e8f66a0800               call     0x433e9ecd
433633d7  8bc8                     mov      ecx, eax
433633d9  894c2430                 mov      dword ptr [esp + 0x30], ecx
433633dd  85c9                     test     ecx, ecx
433633df  7448                     je       0x43363429
433633e1  3b8ed0000000             cmp      ecx, dword ptr [esi + 0xd0]
433633e7  7c40                     jl       0x43363429
433633e9  85c9                     test     ecx, ecx
433633eb  7f07                     jg       0x433633f4
433633ed  baffffff7f               mov      edx, 0x7fffffff
433633f2  eb17                     jmp      0x4336340b
433633f4  8b4608                   mov      eax, dword ptr [esi + 8]
433633f7  48                       dec      eax
433633f8  03c1                     add      eax, ecx
433633fa  99                       cdq      
433633fb  f7f9                     idiv     ecx
433633fd  33c9                     xor      ecx, ecx
433633ff  41                       inc      ecx
43363400  3bc1                     cmp      eax, ecx
43363402  8bd1                     mov      edx, ecx
43363404  8b4c2430                 mov      ecx, dword ptr [esp + 0x30]
43363408  0f4fd0                   cmovg    edx, eax
4336340b  3b542438                 cmp      edx, dword ptr [esp + 0x38]
4336340f  7f18                     jg       0x43363429
43363411  f30f10542428             movss    xmm2, dword ptr [esp + 0x28]
43363417  f30f1044242c             movss    xmm0, dword ptr [esp + 0x2c]
4336341d  f30f11542418             movss    dword ptr [esp + 0x18], xmm2
43363423  894c2434                 mov      dword ptr [esp + 0x34], ecx
43363427  eb16                     jmp      0x4336343f
43363429  f30f10442428             movss    xmm0, dword ptr [esp + 0x28]
4336342f  8b4c2434                 mov      ecx, dword ptr [esp + 0x34]
43363433  f30f10542418             movss    xmm2, dword ptr [esp + 0x18]
43363439  f30f1144242c             movss    dword ptr [esp + 0x2c], xmm0
4336343f  836c244001               sub      dword ptr [esp + 0x40], 1
43363444  f30f105c2458             movss    xmm3, dword ptr [esp + 0x58]
4336344a  f30f106c2448             movss    xmm5, dword ptr [esp + 0x48]
43363450  0f859efbffff             jne      0x43362ff4
43363456  f30f100514054743         movss    xmm0, dword ptr [0x43470514]
4336345e  0f2ed0                   ucomiss  xmm2, xmm0
43363461  9f                       lahf     
43363462  f6c444                   test     ah, 0x44
43363465  0f8b20010000             jnp      0x4336358b
4336346b  f30f58d0                 addss    xmm2, xmm0
4336346f  0f57c9                   xorps    xmm1, xmm1
43363472  f30f2ac9                 cvtsi2ss xmm1, ecx
43363476  f30f591540224743         mulss    xmm2, dword ptr [0x43472240]
4336347e  0f28c2                   movaps   xmm0, xmm2
43363481  f30f59c3                 mulss    xmm0, xmm3
43363485  f30f5844246c             addss    xmm0, dword ptr [esp + 0x6c]
4336348b  f30f11467c               movss    dword ptr [esi + 0x7c], xmm0
43363490  0f28c2                   movaps   xmm0, xmm2
43363493  f30f59c5                 mulss    xmm0, xmm5
43363497  f30f58442470             addss    xmm0, dword ptr [esp + 0x70]
4336349d  f30f118680000000         movss    dword ptr [esi + 0x80], xmm0
433634a5  0f28c2                   movaps   xmm0, xmm2
433634a8  f30f59442450             mulss    xmm0, dword ptr [esp + 0x50]
433634ae  f30f58442474             addss    xmm0, dword ptr [esp + 0x74]
433634b4  f30f118684000000         movss    dword ptr [esi + 0x84], xmm0
433634bc  0f28c2                   movaps   xmm0, xmm2
433634bf  f30f5986ac000000         mulss    xmm0, dword ptr [esi + 0xac]
433634c7  f30f1186ac000000         movss    dword ptr [esi + 0xac], xmm0
433634cf  0f57c0                   xorps    xmm0, xmm0
433634d2  f30f2a8698000000         cvtsi2ss xmm0, dword ptr [esi + 0x98]
433634da  e996000000               jmp      0x43363575
433634df  f30f10842494000000       movss    xmm0, dword ptr [esp + 0x94]
433634e8  0f57c9                   xorps    xmm1, xmm1
433634eb  f30f5c44246c             subss    xmm0, dword ptr [esp + 0x6c]
433634f1  f30f101540224743         movss    xmm2, dword ptr [0x43472240]
433634f9  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
433634fd  f30f59c2                 mulss    xmm0, xmm2
43363501  f30f5844246c             addss    xmm0, dword ptr [esp + 0x6c]
43363507  f30f11467c               movss    dword ptr [esi + 0x7c], xmm0
4336350c  f30f10842498000000       movss    xmm0, dword ptr [esp + 0x98]
43363515  f30f5c442470             subss    xmm0, dword ptr [esp + 0x70]
4336351b  f30f59c2                 mulss    xmm0, xmm2
4336351f  f30f58442470             addss    xmm0, dword ptr [esp + 0x70]
43363525  f30f118680000000         movss    dword ptr [esi + 0x80], xmm0
4336352d  f30f1084249c000000       movss    xmm0, dword ptr [esp + 0x9c]
43363536  f30f5c442474             subss    xmm0, dword ptr [esp + 0x74]
4336353c  f30f59c2                 mulss    xmm0, xmm2
43363540  f30f58442474             addss    xmm0, dword ptr [esp + 0x74]
43363546  f30f118684000000         movss    dword ptr [esi + 0x84], xmm0
4336354e  f30f1086ac000000         movss    xmm0, dword ptr [esi + 0xac]
43363556  f30f59c2                 mulss    xmm0, xmm2
4336355a  f30f1186ac000000         movss    dword ptr [esi + 0xac], xmm0
43363562  0f57c0                   xorps    xmm0, xmm0
43363565  f30f2a8e94000000         cvtsi2ss xmm1, dword ptr [esi + 0x94]
4336356d  f30f2a8698000000         cvtsi2ss xmm0, dword ptr [esi + 0x98]
43363575  f30f5cc1                 subss    xmm0, xmm1
43363579  f30f59c2                 mulss    xmm0, xmm2
4336357d  f30f58c1                 addss    xmm0, xmm1
43363581  f30f2cc0                 cvttss2si eax, xmm0
43363585  898698000000             mov      dword ptr [esi + 0x98], eax
4336358b  8b5508                   mov      edx, dword ptr [ebp + 8]
4336358e  6a1f                     push     0x1f
43363590  58                       pop      eax
43363591  3982d8000000             cmp      dword ptr [edx + 0xd8], eax
43363597  7508                     jne      0x433635a1
43363599  0f57c0                   xorps    xmm0, xmm0
4336359c  e999000000               jmp      0x4336363a
433635a1  8b8e98000000             mov      ecx, dword ptr [esi + 0x98]
433635a7  8b4608                   mov      eax, dword ptr [esi + 8]
433635aa  894c2430                 mov      dword ptr [esp + 0x30], ecx
433635ae  85c9                     test     ecx, ecx
433635b0  7f07                     jg       0x433635b9
433635b2  baffffff7f               mov      edx, 0x7fffffff
433635b7  eb14                     jmp      0x433635cd
433635b9  48                       dec      eax
433635ba  03c1                     add      eax, ecx
433635bc  99                       cdq      
433635bd  f7f9                     idiv     ecx
433635bf  33c9                     xor      ecx, ecx
433635c1  41                       inc      ecx
433635c2  3bc1                     cmp      eax, ecx
433635c4  8bd1                     mov      edx, ecx
433635c6  8b4c2430                 mov      ecx, dword ptr [esp + 0x30]
433635ca  0f4fd0                   cmovg    edx, eax
433635cd  8b86a0000000             mov      eax, dword ptr [esi + 0xa0]
433635d3  660f6e4e08               movd     xmm1, dword ptr [esi + 8]
433635d8  83e00f                   and      eax, 0xf
433635db  660f6ec1                 movd     xmm0, ecx
433635df  0f5bc0                   cvtdq2ps xmm0, xmm0
433635e2  660f6ed2                 movd     xmm2, edx
433635e6  f30f5e048540454743       divss    xmm0, dword ptr [eax*4 + 0x43474540]
433635ef  0f5bc9                   cvtdq2ps xmm1, xmm1
433635f2  0f5bd2                   cvtdq2ps xmm2, xmm2
433635f5  f30f11442430             movss    dword ptr [esp + 0x30], xmm0
433635fb  660f6e86d0000000         movd     xmm0, dword ptr [esi + 0xd0]
43363603  f30f5eca                 divss    xmm1, xmm2
43363607  0f5bc0                   cvtdq2ps xmm0, xmm0
4336360a  e826c6fcff               call     0x4332fc35
4336360f  f30f104c2430             movss    xmm1, dword ptr [esp + 0x30]
43363615  0f2e0d6cee4643           ucomiss  xmm1, dword ptr [0x4346ee6c]
4336361c  9f                       lahf     
4336361d  f6c444                   test     ah, 0x44
43363620  7b06                     jnp      0x43363628
43363622  f30f5ec1                 divss    xmm0, xmm1
43363626  eb12                     jmp      0x4336363a
43363628  8b86a0000000             mov      eax, dword ptr [esi + 0xa0]
4336362e  83e00f                   and      eax, 0xf
43363631  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
4336363a  8b4508                   mov      eax, dword ptr [ebp + 8]
4336363d  8d9424a00e0000           lea      edx, [esp + 0xea0]
43363644  f30f1144241c             movss    dword ptr [esp + 0x1c], xmm0
4336364a  8b480c                   mov      ecx, dword ptr [eax + 0xc]
4336364d  e8fb550600               call     0x433c8c4d
43363652  f30f10667c               movss    xmm4, dword ptr [esi + 0x7c]
43363657  33d2                     xor      edx, edx
43363659  f30f109e80000000         movss    xmm3, dword ptr [esi + 0x80]
43363661  42                       inc      edx
43363662  f30f5c27                 subss    xmm4, dword ptr [edi]
43363666  f30f5c5f04               subss    xmm3, dword ptr [edi + 4]
4336366b  f30f109684000000         movss    xmm2, dword ptr [esi + 0x84]
43363673  f30f5c5708               subss    xmm2, dword ptr [edi + 8]
43363678  f30f102d14054743         movss    xmm5, dword ptr [0x43470514]
43363680  0f28cc                   movaps   xmm1, xmm4
43363683  0f28f5                   movaps   xmm6, xmm5
43363686  0f28c3                   movaps   xmm0, xmm3
43363689  f30f59cc                 mulss    xmm1, xmm4
4336368d  8b86a0000000             mov      eax, dword ptr [esi + 0xa0]
43363693  f30f59c3                 mulss    xmm0, xmm3
43363697  89442464                 mov      dword ptr [esp + 0x64], eax
4336369b  f30f58c8                 addss    xmm1, xmm0
4336369f  0f28c2                   movaps   xmm0, xmm2
433636a2  f30f59c2                 mulss    xmm0, xmm2
433636a6  f30f58c8                 addss    xmm1, xmm0
433636aa  0f28c1                   movaps   xmm0, xmm1
433636ad  f30f108c24a80e0000       movss    xmm1, dword ptr [esp + 0xea8]
433636b6  f30f51c0                 sqrtss   xmm0, xmm0
433636ba  f30f11442434             movss    dword ptr [esp + 0x34], xmm0
433636c0  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433636c8  f30f5ef0                 divss    xmm6, xmm0
433636cc  0f28c6                   movaps   xmm0, xmm6
433636cf  0f28fe                   movaps   xmm7, xmm6
433636d2  f30f59c4                 mulss    xmm0, xmm4
433636d6  f30f59fb                 mulss    xmm7, xmm3
433636da  f30f59f2                 mulss    xmm6, xmm2
433636de  f30f11442428             movss    dword ptr [esp + 0x28], xmm0
433636e4  f30f117c2448             movss    dword ptr [esp + 0x48], xmm7
433636ea  f30f11742450             movss    dword ptr [esp + 0x50], xmm6
433636f0  8496a4000000             test     byte ptr [esi + 0xa4], dl
433636f6  0f84bb050000             je       0x43363cb7
433636fc  33c9                     xor      ecx, ecx
433636fe  f30f114c2430             movss    dword ptr [esp + 0x30], xmm1
43363704  0f57ed                   xorps    xmm5, xmm5
43363707  894c2440                 mov      dword ptr [esp + 0x40], ecx
4336370b  0f2ec5                   ucomiss  xmm0, xmm5
4336370e  9f                       lahf     
4336370f  f6c444                   test     ah, 0x44
43363712  7a75                     jp       0x43363789
43363714  0f2efd                   ucomiss  xmm7, xmm5
43363717  9f                       lahf     
43363718  f6c444                   test     ah, 0x44
4336371b  7a6c                     jp       0x43363789
4336371d  f30f108c2488000000       movss    xmm1, dword ptr [esp + 0x88]
43363726  0f57db                   xorps    xmm3, xmm3
43363729  0f28d6                   movaps   xmm2, xmm6
4336372c  f30f118c2498000000       movss    dword ptr [esp + 0x98], xmm1
43363735  0f5715d0034743           xorps    xmm2, xmmword ptr [0x434703d0]
4336373c  0f57e4                   xorps    xmm4, xmm4
4336373f  0f57c9                   xorps    xmm1, xmm1
43363742  f30f11642420             movss    dword ptr [esp + 0x20], xmm4
43363748  f30f11a42494000000       movss    dword ptr [esp + 0x94], xmm4
43363751  f30f114c2418             movss    dword ptr [esp + 0x18], xmm1
43363757  f30f118c249c000000       movss    dword ptr [esp + 0x9c], xmm1
43363760  f30f1154242c             movss    dword ptr [esp + 0x2c], xmm2
43363766  f30f1154246c             movss    dword ptr [esp + 0x6c], xmm2
4336376c  f30f115c2424             movss    dword ptr [esp + 0x24], xmm3
43363772  f30f115c2470             movss    dword ptr [esp + 0x70], xmm3
43363778  f30f115c244c             movss    dword ptr [esp + 0x4c], xmm3
4336377e  f30f115c2474             movss    dword ptr [esp + 0x74], xmm3
43363784  e975010000               jmp      0x433638fe
43363789  0f28d8                   movaps   xmm3, xmm0
4336378c  0f28e6                   movaps   xmm4, xmm6
4336378f  f30f59e5                 mulss    xmm4, xmm5
43363793  0f28d7                   movaps   xmm2, xmm7
43363796  f30f59dd                 mulss    xmm3, xmm5
4336379a  f30f5cd4                 subss    xmm2, xmm4
4336379e  f30f5ce0                 subss    xmm4, xmm0
433637a2  0f28c7                   movaps   xmm0, xmm7
433637a5  f30f59c5                 mulss    xmm0, xmm5
433637a9  0f28ca                   movaps   xmm1, xmm2
433637ac  f30f5cd8                 subss    xmm3, xmm0
433637b0  f30f59ca                 mulss    xmm1, xmm2
433637b4  0f28c4                   movaps   xmm0, xmm4
433637b7  f30f59c4                 mulss    xmm0, xmm4
433637bb  f30f58c8                 addss    xmm1, xmm0
433637bf  0f28c3                   movaps   xmm0, xmm3
433637c2  f30f59c3                 mulss    xmm0, xmm3
433637c6  f30f58c8                 addss    xmm1, xmm0
433637ca  0f28c1                   movaps   xmm0, xmm1
433637cd  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
433637d5  f30f51c0                 sqrtss   xmm0, xmm0
433637d9  f30f1144247c             movss    dword ptr [esp + 0x7c], xmm0
433637df  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433637e7  f30f5ec8                 divss    xmm1, xmm0
433637eb  0f28c1                   movaps   xmm0, xmm1
433637ee  f30f59c2                 mulss    xmm0, xmm2
433637f2  f30f11442420             movss    dword ptr [esp + 0x20], xmm0
433637f8  f30f10542420             movss    xmm2, dword ptr [esp + 0x20]
433637fe  f30f11842494000000       movss    dword ptr [esp + 0x94], xmm0
43363807  0f28c1                   movaps   xmm0, xmm1
4336380a  f30f59c4                 mulss    xmm0, xmm4
4336380e  f30f59cb                 mulss    xmm1, xmm3
43363812  0f28e0                   movaps   xmm4, xmm0
43363815  f30f11842488000000       movss    dword ptr [esp + 0x88], xmm0
4336381e  f30f11842498000000       movss    dword ptr [esp + 0x98], xmm0
43363827  0f28c1                   movaps   xmm0, xmm1
4336382a  f30f114c2418             movss    dword ptr [esp + 0x18], xmm1
43363830  f30f59c7                 mulss    xmm0, xmm7
43363834  0f28d9                   movaps   xmm3, xmm1
43363837  f30f118c249c000000       movss    dword ptr [esp + 0x9c], xmm1
43363840  f30f104c2428             movss    xmm1, dword ptr [esp + 0x28]
43363846  f30f59e6                 mulss    xmm4, xmm6
4336384a  f30f59d9                 mulss    xmm3, xmm1
4336384e  f30f5ce0                 subss    xmm4, xmm0
43363852  0f28c2                   movaps   xmm0, xmm2
43363855  f30f59c6                 mulss    xmm0, xmm6
43363859  f30f59d7                 mulss    xmm2, xmm7
4336385d  f30f5cd8                 subss    xmm3, xmm0
43363861  f30f10842488000000       movss    xmm0, dword ptr [esp + 0x88]
4336386a  f30f59c1                 mulss    xmm0, xmm1
4336386e  0f28cc                   movaps   xmm1, xmm4
43363871  f30f59cc                 mulss    xmm1, xmm4
43363875  f30f5cd0                 subss    xmm2, xmm0
43363879  0f28c3                   movaps   xmm0, xmm3
4336387c  f30f59c3                 mulss    xmm0, xmm3
43363880  f30f58c8                 addss    xmm1, xmm0
43363884  0f28c2                   movaps   xmm0, xmm2
43363887  f30f59c2                 mulss    xmm0, xmm2
4336388b  f30f58c8                 addss    xmm1, xmm0
4336388f  0f28c1                   movaps   xmm0, xmm1
43363892  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
4336389a  f30f51c0                 sqrtss   xmm0, xmm0
4336389e  f30f11442478             movss    dword ptr [esp + 0x78], xmm0
433638a4  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
433638ac  f30f5ec8                 divss    xmm1, xmm0
433638b0  0f28c1                   movaps   xmm0, xmm1
433638b3  f30f59c4                 mulss    xmm0, xmm4
433638b7  f30f10642420             movss    xmm4, dword ptr [esp + 0x20]
433638bd  f30f1144242c             movss    dword ptr [esp + 0x2c], xmm0
433638c3  f30f1144246c             movss    dword ptr [esp + 0x6c], xmm0
433638c9  0f28c1                   movaps   xmm0, xmm1
433638cc  f30f59ca                 mulss    xmm1, xmm2
433638d0  f30f1054242c             movss    xmm2, dword ptr [esp + 0x2c]
433638d6  f30f59c3                 mulss    xmm0, xmm3
433638da  f30f114c244c             movss    dword ptr [esp + 0x4c], xmm1
433638e0  f30f114c2474             movss    dword ptr [esp + 0x74], xmm1
433638e6  f30f104c2418             movss    xmm1, dword ptr [esp + 0x18]
433638ec  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
433638f2  f30f11442470             movss    dword ptr [esp + 0x70], xmm0
433638f8  f30f10442428             movss    xmm0, dword ptr [esp + 0x28]
433638fe  8b842480000000           mov      eax, dword ptr [esp + 0x80]
43363905  c744245820000000         mov      dword ptr [esp + 0x58], 0x20
4336390d  eb03                     jmp      0x43363912
4336390f  0f57ed                   xorps    xmm5, xmm5
43363912  f30f5920                 mulss    xmm4, dword ptr [eax]
43363916  f30f109c2488000000       movss    xmm3, dword ptr [esp + 0x88]
4336391f  f30f5918                 mulss    xmm3, dword ptr [eax]
43363923  f30f58e0                 addss    xmm4, xmm0
43363927  0f28c2                   movaps   xmm0, xmm2
4336392a  0f28d1                   movaps   xmm2, xmm1
4336392d  f30f594004               mulss    xmm0, dword ptr [eax + 4]
43363932  f30f58df                 addss    xmm3, xmm7
43363936  f30f5910                 mulss    xmm2, dword ptr [eax]
4336393a  f30f58e0                 addss    xmm4, xmm0
4336393e  f30f10442424             movss    xmm0, dword ptr [esp + 0x24]
43363944  f30f594004               mulss    xmm0, dword ptr [eax + 4]
43363949  f30f58d6                 addss    xmm2, xmm6
4336394d  f30f103d14054743         movss    xmm7, dword ptr [0x43470514]
43363955  f30f58d8                 addss    xmm3, xmm0
43363959  f30f1044244c             movss    xmm0, dword ptr [esp + 0x4c]
4336395f  0f28cc                   movaps   xmm1, xmm4
43363962  f30f594004               mulss    xmm0, dword ptr [eax + 4]
43363967  f30f59cc                 mulss    xmm1, xmm4
4336396b  f30f58d0                 addss    xmm2, xmm0
4336396f  0f28c3                   movaps   xmm0, xmm3
43363972  f30f59c3                 mulss    xmm0, xmm3
43363976  f30f58c8                 addss    xmm1, xmm0
4336397a  0f28c2                   movaps   xmm0, xmm2
4336397d  f30f59c2                 mulss    xmm0, xmm2
43363981  f30f58c8                 addss    xmm1, xmm0
43363985  0f28c1                   movaps   xmm0, xmm1
43363988  f30f51c0                 sqrtss   xmm0, xmm0
4336398c  f30f1184248c000000       movss    dword ptr [esp + 0x8c], xmm0
43363995  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
4336399d  f30f5ef8                 divss    xmm7, xmm0
433639a1  f30f10442430             movss    xmm0, dword ptr [esp + 0x30]
433639a7  0f28f7                   movaps   xmm6, xmm7
433639aa  f30f59f4                 mulss    xmm6, xmm4
433639ae  0f28e7                   movaps   xmm4, xmm7
433639b1  f30f59e3                 mulss    xmm4, xmm3
433639b5  f30f59fa                 mulss    xmm7, xmm2
433639b9  f30f59f0                 mulss    xmm6, xmm0
433639bd  f30f59e0                 mulss    xmm4, xmm0
433639c1  f30f59f8                 mulss    xmm7, xmm0
433639c5  39542464                 cmp      dword ptr [esp + 0x64], edx
433639c9  0f843e010000             je       0x43363b0d
433639cf  8bf7                     mov      esi, edi
433639d1  894c2438                 mov      dword ptr [esp + 0x38], ecx
433639d5  8dbc2404080000           lea      edi, [esp + 0x804]
433639dc  8d9424a0270000           lea      edx, [esp + 0x27a0]
433639e3  89542444                 mov      dword ptr [esp + 0x44], edx
433639e7  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
433639e8  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
433639e9  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
433639ea  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
433639ee  f30f104f04               movss    xmm1, dword ptr [edi + 4]
433639f3  f30f105708               movss    xmm2, dword ptr [edi + 8]
433639f8  f30f58cc                 addss    xmm1, xmm4
433639fc  f30f1007                 movss    xmm0, dword ptr [edi]
43363a00  f30f58d7                 addss    xmm2, xmm7
43363a04  f30f58c6                 addss    xmm0, xmm6
43363a08  f30f118c2414080000       movss    dword ptr [esp + 0x814], xmm1
43363a11  f30f11942418080000       movss    dword ptr [esp + 0x818], xmm2
43363a1a  f30f11842410080000       movss    dword ptr [esp + 0x810], xmm0
43363a23  8bc1                     mov      eax, ecx
43363a25  89442414                 mov      dword ptr [esp + 0x14], eax
43363a29  390a                     cmp      dword ptr [edx], ecx
43363a2b  7659                     jbe      0x43363a86
43363a2d  8db280000000             lea      esi, [edx + 0x80]
43363a33  f30f1006                 movss    xmm0, dword ptr [esi]
43363a37  0f2fc5                   comiss   xmm0, xmm5
43363a3a  7639                     jbe      0x43363a75
43363a3c  8b46d4                   mov      eax, dword ptr [esi - 0x2c]
43363a3f  83e00f                   and      eax, 0xf
43363a42  f30f10048540454743       movss    xmm0, dword ptr [eax*4 + 0x43474540]
43363a4b  0f2f44241c               comiss   xmm0, dword ptr [esp + 0x1c]
43363a50  721f                     jb       0x43363a71
43363a52  8d4ed8                   lea      ecx, [esi - 0x28]
43363a55  8d942404080000           lea      edx, [esp + 0x804]
43363a5c  e881910300               call     0x4339cbe2
43363a61  f30f100e                 movss    xmm1, dword ptr [esi]
43363a65  0f2fc8                   comiss   xmm1, xmm0
43363a68  8b542444                 mov      edx, dword ptr [esp + 0x44]
43363a6c  7379                     jae      0x43363ae7
43363a6e  0f57ed                   xorps    xmm5, xmm5
43363a71  8b442414                 mov      eax, dword ptr [esp + 0x14]
43363a75  40                       inc      eax
43363a76  81c690000000             add      esi, 0x90
43363a7c  89442414                 mov      dword ptr [esp + 0x14], eax
43363a80  3b02                     cmp      eax, dword ptr [edx]
43363a82  72af                     jb       0x43363a33
43363a84  33c9                     xor      ecx, ecx
43363a86  33d2                     xor      edx, edx
43363a88  884c243f                 mov      byte ptr [esp + 0x3f], cl
43363a8c  42                       inc      edx
43363a8d  8b742440                 mov      esi, dword ptr [esp + 0x40]
43363a91  807c243f00               cmp      byte ptr [esp + 0x3f], 0
43363a96  f30f10742450             movss    xmm6, dword ptr [esp + 0x50]
43363a9c  f30f107c2448             movss    xmm7, dword ptr [esp + 0x48]
43363aa2  f30f10442428             movss    xmm0, dword ptr [esp + 0x28]
43363aa8  8d4601                   lea      eax, [esi + 1]
43363aab  f30f104c2418             movss    xmm1, dword ptr [esp + 0x18]
43363ab1  0f44c6                   cmove    eax, esi
43363ab4  f30f1054242c             movss    xmm2, dword ptr [esp + 0x2c]
43363aba  8bf0                     mov      esi, eax
43363abc  8b842480000000           mov      eax, dword ptr [esp + 0x80]
43363ac3  f30f10642420             movss    xmm4, dword ptr [esp + 0x20]
43363ac9  83c020                   add      eax, 0x20
43363acc  836c245801               sub      dword ptr [esp + 0x58], 1
43363ad1  89742440                 mov      dword ptr [esp + 0x40], esi
43363ad5  89842480000000           mov      dword ptr [esp + 0x80], eax
43363adc  0f852dfeffff             jne      0x4336390f
43363ae2  e939070000               jmp      0x43364220
43363ae7  8b742438                 mov      esi, dword ptr [esp + 0x38]
43363aeb  81c2c00a0000             add      edx, 0xac0
43363af1  46                       inc      esi
43363af2  89542444                 mov      dword ptr [esp + 0x44], edx
43363af6  89742438                 mov      dword ptr [esp + 0x38], esi
43363afa  83fe03                   cmp      esi, 3
43363afd  0f8da6010000             jge      0x43363ca9
43363b03  0f57ed                   xorps    xmm5, xmm5
43363b06  33c9                     xor      ecx, ecx
43363b08  e916ffffff               jmp      0x43363a23
43363b0d  f30f1007                 movss    xmm0, dword ptr [edi]
43363b11  f30f104f04               movss    xmm1, dword ptr [edi + 4]
43363b16  f30f105708               movss    xmm2, dword ptr [edi + 8]
43363b1b  f30f11b424400a0000       movss    dword ptr [esp + 0xa40], xmm6
43363b24  f30f11a424440a0000       movss    dword ptr [esp + 0xa44], xmm4
43363b2d  f30f59f6                 mulss    xmm6, xmm6
43363b31  898c24700a0000           mov      dword ptr [esp + 0xa70], ecx
43363b38  f30f59e4                 mulss    xmm4, xmm4
43363b3c  889424740a0000           mov      byte ptr [esp + 0xa74], dl
43363b43  f30f11bc24480a0000       movss    dword ptr [esp + 0xa48], xmm7
43363b4c  f30f59ff                 mulss    xmm7, xmm7
43363b50  889424750a0000           mov      byte ptr [esp + 0xa75], dl
43363b57  f30f58f4                 addss    xmm6, xmm4
43363b5b  f30f118424300a0000       movss    dword ptr [esp + 0xa30], xmm0
43363b64  0f57c0                   xorps    xmm0, xmm0
43363b67  f30f118c24340a0000       movss    dword ptr [esp + 0xa34], xmm1
43363b70  f30f119424380a0000       movss    dword ptr [esp + 0xa38], xmm2
43363b79  0f298424500a0000         movaps   xmmword ptr [esp + 0xa50], xmm0
43363b81  0f298424600a0000         movaps   xmmword ptr [esp + 0xa60], xmm0
43363b89  f30f58f7                 addss    xmm6, xmm7
43363b8d  0f2ef5                   ucomiss  xmm6, xmm5
43363b90  9f                       lahf     
43363b91  f6c444                   test     ah, 0x44
43363b94  7a07                     jp       0x43363b9d
43363b96  888c24750a0000           mov      byte ptr [esp + 0xa75], cl
43363b9d  894c2438                 mov      dword ptr [esp + 0x38], ecx
43363ba1  8db424b4270000           lea      esi, [esp + 0x27b4]
43363ba8  838c243c0e0000ff         or       dword ptr [esp + 0xe3c], 0xffffffff
43363bb0  8d8424f80d0000           lea      eax, [esp + 0xdf8]
43363bb7  838c24480e0000ff         or       dword ptr [esp + 0xe48], 0xffffffff
43363bbf  50                       push     eax
43363bc0  898c24480e0000           mov      dword ptr [esp + 0xe48], ecx
43363bc7  8d460c                   lea      eax, [esi + 0xc]
43363bca  c78424280e00000000803f   mov      dword ptr [esp + 0xe28], 0x3f800000
43363bd5  8d8c24340a0000           lea      ecx, [esp + 0xa34]
43363bdc  66c78424320e00000000     mov      word ptr [esp + 0xe32], 0
43363be6  8b16                     mov      edx, dword ptr [esi]
43363be8  50                       push     eax
43363be9  e8a0be0300               call     0x4339fa8e
43363bee  85c0                     test     eax, eax
43363bf0  0f888efeffff             js       0x43363a84
43363bf6  f30f108424240e0000       movss    xmm0, dword ptr [esp + 0xe24]
43363bff  33c9                     xor      ecx, ecx
43363c01  8bc1                     mov      eax, ecx
43363c03  f30f11442468             movss    dword ptr [esp + 0x68], xmm0
43363c09  89442414                 mov      dword ptr [esp + 0x14], eax
43363c0d  394eec                   cmp      dword ptr [esi - 0x14], ecx
43363c10  767f                     jbe      0x43363c91
43363c12  8bce                     mov      ecx, esi
43363c14  0f57c9                   xorps    xmm1, xmm1
43363c17  894c2444                 mov      dword ptr [esp + 0x44], ecx
43363c1b  8b11                     mov      edx, dword ptr [ecx]
43363c1d  f30f104230               movss    xmm0, dword ptr [edx + 0x30]
43363c22  0f2fc1                   comiss   xmm0, xmm1
43363c25  7654                     jbe      0x43363c7b
43363c27  837a0403                 cmp      dword ptr [edx + 4], 3
43363c2b  7406                     je       0x43363c33
43363c2d  837a0402                 cmp      dword ptr [edx + 4], 2
43363c31  7548                     jne      0x43363c7b
43363c33  8d8424f80d0000           lea      eax, [esp + 0xdf8]
43363c3a  c78424240e00000000803f   mov      dword ptr [esp + 0xe24], 0x3f800000
43363c45  8b11                     mov      edx, dword ptr [ecx]
43363c47  50                       push     eax
43363c48  8d410c                   lea      eax, [ecx + 0xc]
43363c4b  50                       push     eax
43363c4c  8d8c24380a0000           lea      ecx, [esp + 0xa38]
43363c53  e836be0300               call     0x4339fa8e
43363c58  85c0                     test     eax, eax
43363c5a  7814                     js       0x43363c70
43363c5c  f30f10442468             movss    xmm0, dword ptr [esp + 0x68]
43363c62  0f2f8424240e0000         comiss   xmm0, dword ptr [esp + 0xe24]
43363c6a  0f8714feffff             ja       0x43363a84
43363c70  8b442414                 mov      eax, dword ptr [esp + 0x14]
43363c74  0f57c9                   xorps    xmm1, xmm1
43363c77  8b4c2444                 mov      ecx, dword ptr [esp + 0x44]
43363c7b  40                       inc      eax
43363c7c  81c190000000             add      ecx, 0x90
43363c82  89442414                 mov      dword ptr [esp + 0x14], eax
43363c86  894c2444                 mov      dword ptr [esp + 0x44], ecx
43363c8a  3b46ec                   cmp      eax, dword ptr [esi - 0x14]
43363c8d  728c                     jb       0x43363c1b
43363c8f  33c9                     xor      ecx, ecx
43363c91  8b442438                 mov      eax, dword ptr [esp + 0x38]
43363c95  81c6c00a0000             add      esi, 0xac0
43363c9b  40                       inc      eax
43363c9c  89442438                 mov      dword ptr [esp + 0x38], eax
43363ca0  83f803                   cmp      eax, 3
43363ca3  0f8cfffeffff             jl       0x43363ba8
43363ca9  33d2                     xor      edx, edx
43363cab  42                       inc      edx
43363cac  33c9                     xor      ecx, ecx
43363cae  8854243f                 mov      byte ptr [esp + 0x3f], dl
43363cb2  e9d6fdffff               jmp      0x43363a8d
43363cb7  f30f114c2430             movss    dword ptr [esp + 0x30], xmm1
43363cbd  0f57c9                   xorps    xmm1, xmm1
43363cc0  0f2ec1                   ucomiss  xmm0, xmm1
43363cc3  9f                       lahf     
43363cc4  f6c444                   test     ah, 0x44
43363cc7  7a69                     jp       0x43363d32
43363cc9  0f2ef9                   ucomiss  xmm7, xmm1
43363ccc  9f                       lahf     
43363ccd  f6c444                   test     ah, 0x44
43363cd0  7a60                     jp       0x43363d32
43363cd2  0f57c0                   xorps    xmm0, xmm0
43363cd5  f30f11442424             movss    dword ptr [esp + 0x24], xmm0
43363cdb  f30f11842494000000       movss    dword ptr [esp + 0x94], xmm0
43363ce4  f30f10842488000000       movss    xmm0, dword ptr [esp + 0x88]
43363ced  f30f11842498000000       movss    dword ptr [esp + 0x98], xmm0
43363cf6  0f57c0                   xorps    xmm0, xmm0
43363cf9  f30f11442440             movss    dword ptr [esp + 0x40], xmm0
43363cff  f30f1184249c000000       movss    dword ptr [esp + 0x9c], xmm0
43363d08  0f28c6                   movaps   xmm0, xmm6
43363d0b  0f5705d0034743           xorps    xmm0, xmmword ptr [0x434703d0]
43363d12  f30f1144244c             movss    dword ptr [esp + 0x4c], xmm0
43363d18  f30f1144246c             movss    dword ptr [esp + 0x6c], xmm0
43363d1e  0f57c0                   xorps    xmm0, xmm0
43363d21  f30f11442458             movss    dword ptr [esp + 0x58], xmm0
43363d27  f30f11442474             movss    dword ptr [esp + 0x74], xmm0
43363d2d  e949010000               jmp      0x43363e7b
43363d32  0f28d8                   movaps   xmm3, xmm0
43363d35  0f28e6                   movaps   xmm4, xmm6
43363d38  f30f59e1                 mulss    xmm4, xmm1
43363d3c  0f28d7                   movaps   xmm2, xmm7
43363d3f  f30f59d9                 mulss    xmm3, xmm1
43363d43  f30f5cd4                 subss    xmm2, xmm4
43363d47  f30f5ce0                 subss    xmm4, xmm0
43363d4b  0f28c7                   movaps   xmm0, xmm7
43363d4e  f30f59c1                 mulss    xmm0, xmm1
43363d52  0f28ca                   movaps   xmm1, xmm2
43363d55  f30f5cd8                 subss    xmm3, xmm0
43363d59  f30f59ca                 mulss    xmm1, xmm2
43363d5d  0f28c4                   movaps   xmm0, xmm4
43363d60  f30f59c4                 mulss    xmm0, xmm4
43363d64  f30f58c8                 addss    xmm1, xmm0
43363d68  0f28c3                   movaps   xmm0, xmm3
43363d6b  f30f59c3                 mulss    xmm0, xmm3
43363d6f  f30f58c8                 addss    xmm1, xmm0
43363d73  0f28c1                   movaps   xmm0, xmm1
43363d76  0f28cd                   movaps   xmm1, xmm5
43363d79  f30f51c0                 sqrtss   xmm0, xmm0
43363d7d  f30f11442420             movss    dword ptr [esp + 0x20], xmm0
43363d83  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43363d8b  f30f5ec8                 divss    xmm1, xmm0
43363d8f  0f28c1                   movaps   xmm0, xmm1
43363d92  0f28e9                   movaps   xmm5, xmm1
43363d95  f30f59c4                 mulss    xmm0, xmm4
43363d99  f30f59cb                 mulss    xmm1, xmm3
43363d9d  0f28e0                   movaps   xmm4, xmm0
43363da0  f30f11842488000000       movss    dword ptr [esp + 0x88], xmm0
43363da9  f30f11842498000000       movss    dword ptr [esp + 0x98], xmm0
43363db2  0f28c1                   movaps   xmm0, xmm1
43363db5  f30f59ea                 mulss    xmm5, xmm2
43363db9  f30f59c7                 mulss    xmm0, xmm7
43363dbd  0f28d9                   movaps   xmm3, xmm1
43363dc0  f30f114c2440             movss    dword ptr [esp + 0x40], xmm1
43363dc6  0f28d5                   movaps   xmm2, xmm5
43363dc9  f30f118c249c000000       movss    dword ptr [esp + 0x9c], xmm1
43363dd2  f30f104c2428             movss    xmm1, dword ptr [esp + 0x28]
43363dd8  f30f59e6                 mulss    xmm4, xmm6
43363ddc  f30f59d9                 mulss    xmm3, xmm1
43363de0  f30f5ce0                 subss    xmm4, xmm0
43363de4  f30f59d7                 mulss    xmm2, xmm7
43363de8  0f28c5                   movaps   xmm0, xmm5
43363deb  f30f116c2424             movss    dword ptr [esp + 0x24], xmm5
43363df1  f30f59c6                 mulss    xmm0, xmm6
43363df5  f30f11ac2494000000       movss    dword ptr [esp + 0x94], xmm5
43363dfe  f30f5cd8                 subss    xmm3, xmm0
43363e02  f30f10842488000000       movss    xmm0, dword ptr [esp + 0x88]
43363e0b  f30f59c1                 mulss    xmm0, xmm1
43363e0f  0f28cc                   movaps   xmm1, xmm4
43363e12  f30f59cc                 mulss    xmm1, xmm4
43363e16  f30f5cd0                 subss    xmm2, xmm0
43363e1a  0f28c3                   movaps   xmm0, xmm3
43363e1d  f30f59c3                 mulss    xmm0, xmm3
43363e21  f30f58c8                 addss    xmm1, xmm0
43363e25  0f28c2                   movaps   xmm0, xmm2
43363e28  f30f59c2                 mulss    xmm0, xmm2
43363e2c  f30f58c8                 addss    xmm1, xmm0
43363e30  0f28c1                   movaps   xmm0, xmm1
43363e33  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43363e3b  f30f51c0                 sqrtss   xmm0, xmm0
43363e3f  f30f11442418             movss    dword ptr [esp + 0x18], xmm0
43363e45  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43363e4d  f30f5ec8                 divss    xmm1, xmm0
43363e51  0f28c1                   movaps   xmm0, xmm1
43363e54  f30f59c4                 mulss    xmm0, xmm4
43363e58  f30f1144244c             movss    dword ptr [esp + 0x4c], xmm0
43363e5e  f30f1144246c             movss    dword ptr [esp + 0x6c], xmm0
43363e64  0f28c1                   movaps   xmm0, xmm1
43363e67  f30f59ca                 mulss    xmm1, xmm2
43363e6b  f30f59c3                 mulss    xmm0, xmm3
43363e6f  f30f114c2458             movss    dword ptr [esp + 0x58], xmm1
43363e75  f30f114c2474             movss    dword ptr [esp + 0x74], xmm1
43363e7b  8b8c2490000000           mov      ecx, dword ptr [esp + 0x90]
43363e82  83c108                   add      ecx, 8
43363e85  f30f11442470             movss    dword ptr [esp + 0x70], xmm0
43363e8b  f30f11442438             movss    dword ptr [esp + 0x38], xmm0
43363e91  8b01                     mov      eax, dword ptr [ecx]
43363e93  ff5028                   call     dword ptr [eax + 0x28]
43363e96  85c0                     test     eax, eax
43363e98  750c                     jne      0x43363ea6
43363e9a  06                       push     es
43363e9b  11e1                     adc      ecx, esp
43363e9d  7724                     ja       0x43363ec3
43363e9f  f216                     push     ss
43363ea1  15387bf0a5               adc      eax, 0xa5f07b38
43363ea6  8bc8                     mov      ecx, eax
43363ea8  e87e4b0500               call     0x433b8a2b
43363ead  8b842480000000           mov      eax, dword ptr [esp + 0x80]
43363eb4  0f57ff                   xorps    xmm7, xmm7
43363eb7  c784248c00000020000000   mov      dword ptr [esp + 0x8c], 0x20
43363ec2  33f6                     xor      esi, esi
43363ec3  f6f3                     div      bl
43363ec4  f30f10642424             movss    xmm4, dword ptr [esp + 0x24]
43363ec5  0f10642424               movups   xmm4, xmmword ptr [esp + 0x24]
43363eca  33c9                     xor      ecx, ecx
43363ecc  f30f5920                 mulss    xmm4, dword ptr [eax]
43363ed0  f30f1044244c             movss    xmm0, dword ptr [esp + 0x4c]
43363ed6  f30f594004               mulss    xmm0, dword ptr [eax + 4]
43363edb  f30f58642428             addss    xmm4, dword ptr [esp + 0x28]
43363ee1  f30f10b42488000000       movss    xmm6, dword ptr [esp + 0x88]
43363eea  f30f5930                 mulss    xmm6, dword ptr [eax]
43363eee  f30f10542440             movss    xmm2, dword ptr [esp + 0x40]
43363ef4  f30f5910                 mulss    xmm2, dword ptr [eax]
43363ef8  f30f58e0                 addss    xmm4, xmm0
43363efc  f30f58742448             addss    xmm6, dword ptr [esp + 0x48]
43363f02  f30f10442438             movss    xmm0, dword ptr [esp + 0x38]
43363f08  f30f594004               mulss    xmm0, dword ptr [eax + 4]
43363f0d  f30f58542450             addss    xmm2, dword ptr [esp + 0x50]
43363f13  0f28cc                   movaps   xmm1, xmm4
43363f16  f30f106c2430             movss    xmm5, dword ptr [esp + 0x30]
43363f1c  f30f58f0                 addss    xmm6, xmm0
43363f20  f30f59cc                 mulss    xmm1, xmm4
43363f24  f30f10442458             movss    xmm0, dword ptr [esp + 0x58]
43363f2a  f30f594004               mulss    xmm0, dword ptr [eax + 4]
43363f2f  f30f58d0                 addss    xmm2, xmm0
43363f33  0f28c6                   movaps   xmm0, xmm6
43363f36  f30f59c6                 mulss    xmm0, xmm6
43363f3a  f30f58c8                 addss    xmm1, xmm0
43363f3e  0f28c2                   movaps   xmm0, xmm2
43363f41  f30f59c2                 mulss    xmm0, xmm2
43363f45  f30f58c8                 addss    xmm1, xmm0
43363f49  0f28c1                   movaps   xmm0, xmm1
43363f4c  f30f100d14054743         movss    xmm1, dword ptr [0x43470514]
43363f54  f30f51c0                 sqrtss   xmm0, xmm0
43363f58  f30f1144242c             movss    dword ptr [esp + 0x2c], xmm0
43363f5e  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43363f66  f30f5ec8                 divss    xmm1, xmm0
43363f6a  f30f59e1                 mulss    xmm4, xmm1
43363f6e  f30f59f1                 mulss    xmm6, xmm1
43363f72  f30f59d1                 mulss    xmm2, xmm1
43363f76  0f28cc                   movaps   xmm1, xmm4
43363f79  f30f59cc                 mulss    xmm1, xmm4
43363f7d  0f28c6                   movaps   xmm0, xmm6
43363f80  f30f59c6                 mulss    xmm0, xmm6
43363f84  f30f58c8                 addss    xmm1, xmm0
43363f88  0f28c2                   movaps   xmm0, xmm2
43363f8b  f30f59c2                 mulss    xmm0, xmm2
43363f8f  f30f58c8                 addss    xmm1, xmm0
43363f93  0f28c1                   movaps   xmm0, xmm1
43363f96  f30f104f04               movss    xmm1, dword ptr [edi + 4]
43363f9b  f30f51c0                 sqrtss   xmm0, xmm0
43363f9f  f30f11842490000000       movss    dword ptr [esp + 0x90], xmm0
43363fa8  f30f580508214743         addss    xmm0, dword ptr [0x43472108]
43363fb0  f30f5ee8                 divss    xmm5, xmm0
43363fb4  f30f1007                 movss    xmm0, dword ptr [edi]
43363fb8  0f28dd                   movaps   xmm3, xmm5
43363fbb  f30f59dc                 mulss    xmm3, xmm4
43363fbf  0f28e5                   movaps   xmm4, xmm5
43363fc2  f30f59e6                 mulss    xmm4, xmm6
43363fc6  f30f59ea                 mulss    xmm5, xmm2
43363fca  f30f105708               movss    xmm2, dword ptr [edi + 8]
43363fcf  f30f11a42434060000       movss    dword ptr [esp + 0x634], xmm4
43363fd8  f30f119c2430060000       movss    dword ptr [esp + 0x630], xmm3
43363fe1  f30f59e4                 mulss    xmm4, xmm4
43363fe5  898c2460060000           mov      dword ptr [esp + 0x660], ecx
43363fec  f30f59db                 mulss    xmm3, xmm3
43363ff0  c684246406000001         mov      byte ptr [esp + 0x664], 1
43363ff8  f30f11ac2438060000       movss    dword ptr [esp + 0x638], xmm5
43364001  f30f59ed                 mulss    xmm5, xmm5
43364005  c684246506000001         mov      byte ptr [esp + 0x665], 1
4336400d  f30f58e3                 addss    xmm4, xmm3
43364011  f30f118c2424060000       movss    dword ptr [esp + 0x624], xmm1
4336401a  0f57c9                   xorps    xmm1, xmm1
4336401d  f30f11842420060000       movss    dword ptr [esp + 0x620], xmm0
43364026  f30f11942428060000       movss    dword ptr [esp + 0x628], xmm2
4336402f  0f29bc2440060000         movaps   xmmword ptr [esp + 0x640], xmm7
43364037  0f29bc2450060000         movaps   xmmword ptr [esp + 0x650], xmm7
4336403f  f30f58e5                 addss    xmm4, xmm5
43364043  0f2ee1                   ucomiss  xmm4, xmm1
43364046  9f                       lahf     
43364047  f6c444                   test     ah, 0x44
4336404a  7a07                     jp       0x43364053
4336404c  888c2465060000           mov      byte ptr [esp + 0x665], cl
43364053  f30f101514054743         movss    xmm2, dword ptr [0x43470514]
4336405b  bfffffff7f               mov      edi, 0x7fffffff
43364060  838c246c090000ff         or       dword ptr [esp + 0x96c], 0xffffffff
43364068  8bc1                     mov      eax, ecx
4336406a  838c2478090000ff         or       dword ptr [esp + 0x978], 0xffffffff
43364072  c78424540900000000803f   mov      dword ptr [esp + 0x954], 0x3f800000
4336407d  66898c245e090000         mov      word ptr [esp + 0x95e], cx
43364085  898c2474090000           mov      dword ptr [esp + 0x974], ecx
4336408c  f30f11542414             movss    dword ptr [esp + 0x14], xmm2
43364092  894c2478                 mov      dword ptr [esp + 0x78], ecx
43364096  894c247c                 mov      dword ptr [esp + 0x7c], ecx
4336409a  8b80b0494743             mov      eax, dword ptr [eax + 0x434749b0]
433640a0  3b8424e01c0000           cmp      eax, dword ptr [esp + 0x1ce0]
433640a7  0f83ab000000             jae      0x43364158
433640ad  69c090000000             imul     eax, eax, 0x90
433640b3  8d9424f01c0000           lea      edx, [esp + 0x1cf0]
433640ba  03d0                     add      edx, eax
433640bc  89542468                 mov      dword ptr [esp + 0x68], edx
433640c0  8b4244                   mov      eax, dword ptr [edx + 0x44]
433640c3  83e00f                   and      eax, 0xf
433640c6  393c8570494743           cmp      dword ptr [eax*4 + 0x43474970], edi
433640cd  0f8785000000             ja       0x43364158
433640d3  c78424540900000000803f   mov      dword ptr [esp + 0x954], 0x3f800000
433640de  8d842428090000           lea      eax, [esp + 0x928]
433640e5  f30f104270               movss    xmm0, dword ptr [edx + 0x70]
433640ea  8d8c2420060000           lea      ecx, [esp + 0x620]
433640f1  0f2fc1                   comiss   xmm0, xmm1
433640f4  50                       push     eax
433640f5  760a                     jbe      0x43364101
433640f7  8d5240                   lea      edx, [edx + 0x40]
433640fa  e80a4d0900               call     0x433f8e09
433640ff  eb0c                     jmp      0x4336410d
43364101  8d4210                   lea      eax, [edx + 0x10]
43364104  8b5204                   mov      edx, dword ptr [edx + 4]
43364107  50                       push     eax
43364108  e881b90300               call     0x4339fa8e
4336410d  f30f10542414             movss    xmm2, dword ptr [esp + 0x14]
43364113  85c0                     test     eax, eax
43364115  782a                     js       0x43364141
43364117  0f2f942454090000         comiss   xmm2, dword ptr [esp + 0x954]
4336411f  7620                     jbe      0x43364141
43364121  8b442468                 mov      eax, dword ptr [esp + 0x68]
43364125  f30f10942454090000       movss    xmm2, dword ptr [esp + 0x954]
4336412e  f30f11542414             movss    dword ptr [esp + 0x14], xmm2
43364134  89442478                 mov      dword ptr [esp + 0x78], eax
43364138  83784401                 cmp      dword ptr [eax + 0x44], 1
4336413c  751a                     jne      0x43364158
4336413e  6a02                     push     2
43364140  5f                       pop      edi
43364141  8b44247c                 mov      eax, dword ptr [esp + 0x7c]
43364145  0f57c9                   xorps    xmm1, xmm1
43364148  83c004                   add      eax, 4
4336414b  8944247c                 mov      dword ptr [esp + 0x7c], eax
4336414f  83f83c                   cmp      eax, 0x3c
43364152  0f8242ffffff             jb       0x4336409a
43364158  8b442478                 mov      eax, dword ptr [esp + 0x78]
4336415c  8b7c2454                 mov      edi, dword ptr [esp + 0x54]
43364160  85c0                     test     eax, eax
43364162  0f8496000000             je       0x433641fe
43364168  f30f10842430060000       movss    xmm0, dword ptr [esp + 0x630]
43364171  8b4844                   mov      ecx, dword ptr [eax + 0x44]
43364174  f30f59c2                 mulss    xmm0, xmm2
43364178  898c246c090000           mov      dword ptr [esp + 0x96c], ecx
4336417f  8b00                     mov      eax, dword ptr [eax]
43364181  89842478090000           mov      dword ptr [esp + 0x978], eax
43364188  f30f58842420060000       addss    xmm0, dword ptr [esp + 0x620]
43364191  8b4508                   mov      eax, dword ptr [ebp + 8]
43364194  f30f11842434090000       movss    dword ptr [esp + 0x934], xmm0
4336419d  f30f10842434060000       movss    xmm0, dword ptr [esp + 0x634]
433641a6  f30f59c2                 mulss    xmm0, xmm2
433641aa  f30f58842424060000       addss    xmm0, dword ptr [esp + 0x624]
433641b3  f30f11842438090000       movss    dword ptr [esp + 0x938], xmm0
433641bc  f30f10842438060000       movss    xmm0, dword ptr [esp + 0x638]
433641c5  f30f59c2                 mulss    xmm0, xmm2
433641c9  f30f58842428060000       addss    xmm0, dword ptr [esp + 0x628]
433641d2  f30f1184243c090000       movss    dword ptr [esp + 0x93c], xmm0
433641db  83b89c01000001           cmp      dword ptr [eax + 0x19c], 1
433641e2  7f19                     jg       0x433641fd
433641e4  394c2464                 cmp      dword ptr [esp + 0x64], ecx
433641e8  7413                     je       0x433641fd
433641ea  83e10f                   and      ecx, 0xf
433641ed  f30f10048d40454743       movss    xmm0, dword ptr [ecx*4 + 0x43474540]
433641f6  0f2f44241c               comiss   xmm0, dword ptr [esp + 0x1c]
433641fb  7201                     jb       0x433641fe
433641fd  46                       inc      esi
433641fe  8b842480000000           mov      eax, dword ptr [esp + 0x80]
43364205  0f57ff                   xorps    xmm7, xmm7
43364208  83c020                   add      eax, 0x20
4336420b  83ac248c00000001         sub      dword ptr [esp + 0x8c], 1
43364213  89842480000000           mov      dword ptr [esp + 0x80], eax
4336421a  0f85a4fcffff             jne      0x43363ec4
43364220  660f6ec6                 movd     xmm0, esi
43364224  8b74245c                 mov      esi, dword ptr [esp + 0x5c]
43364228  0f5bc0                   cvtdq2ps xmm0, xmm0
4336422b  f30f590528f64643         mulss    xmm0, dword ptr [0x4346f628]
43364233  f30f1186a8000000         movss    dword ptr [esi + 0xa8], xmm0
4336423b  837e2800                 cmp      dword ptr [esi + 0x28], 0
4336423f  0f8438050000             je       0x4336477d
43364245  8d460c                   lea      eax, [esi + 0xc]
43364248  8bf0                     mov      esi, eax
4336424a  898424a0000000           mov      dword ptr [esp + 0xa0], eax
43364251  8b4508                   mov      eax, dword ptr [ebp + 8]
43364254  8dbc24bc010000           lea      edi, [esp + 0x1bc]
4336425b  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336425c  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336425d  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336425e  8db0dc000000             lea      esi, [eax + 0xdc]
43364264  8dbc24a4010000           lea      edi, [esp + 0x1a4]
4336426b  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336426c  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336426d  a5                       movsd    dword ptr es:[edi], dword ptr [esi]
4336426e  8bb8d0010000             mov      edi, dword ptr [eax + 0x1d0]
43364274  a13c7c4643               mov      eax, dword ptr [0x43467c3c]
43364279  897c2444                 mov      dword ptr [esp + 0x44], edi
4336427d  35a6631921               xor      eax, 0x211963a6
43364282  eb02                     jmp      0x43364286
43364284  8bc1                     mov      eax, ecx
43364286  8b481c                   mov      ecx, dword ptr [eax + 0x1c]
43364289  3bc1                     cmp      eax, ecx
4336428b  75f7                     jne      0x43364284
4336428d  394030                   cmp      dword ptr [eax + 0x30], eax
43364290  7439                     je       0x433642cb
43364292  a184704643               mov      eax, dword ptr [0x43467084]
43364297  35f556279c               xor      eax, 0x9c2756f5
4336429c  eb02                     jmp      0x433642a0
4336429e  8bc1                     mov      eax, ecx
433642a0  8b481c                   mov      ecx, dword ptr [eax + 0x1c]
433642a3  3bc1                     cmp      eax, ecx
433642a5  75f7                     jne      0x4336429e
433642a7  f30f10402c               movss    xmm0, dword ptr [eax + 0x2c]
433642ac  0f57db                   xorps    xmm3, xmm3
433642af  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
433642b5  31442414                 xor      dword ptr [esp + 0x14], eax
433642b9  f30f10442414             movss    xmm0, dword ptr [esp + 0x14]
433642bf  0f2fc3                   comiss   xmm0, xmm3
433642c2  0f97c0                   seta     al
433642c5  84c0                     test     al, al
433642c7  753d                     jne      0x43364306
433642c9  eb03                     jmp      0x433642ce
433642cb  0f57db                   xorps    xmm3, xmm3
433642ce  a1908c4643               mov      eax, dword ptr [0x43468c90]
433642d3  35d488d598               xor      eax, 0x98d588d4
433642d8  eb02                     jmp      0x433642dc
433642da  8bc1                     mov      eax, ecx
433642dc  8b481c                   mov      ecx, dword ptr [eax + 0x1c]
433642df  3bc1                     cmp      eax, ecx
433642e1  75f7                     jne      0x433642da
433642e3  f30f10402c               movss    xmm0, dword ptr [eax + 0x2c]
433642e8  f30f11442414             movss    dword ptr [esp + 0x14], xmm0
433642ee  31442414                 xor      dword ptr [esp + 0x14], eax
433642f2  f30f10442414             movss    xmm0, dword ptr [esp + 0x14]
433642f8  0f2fc3                   comiss   xmm0, xmm3
433642fb  0f97c0                   seta     al
433642fe  84c0                     test     al, al
43364300  0f85ea020000             jne      0x433645f0
43364306  f30f108424a4010000       movss    xmm0, dword ptr [esp + 0x1a4]
4336430f  33c9                     xor      ecx, ecx
43364311  f30f108c24a8010000       movss    xmm1, dword ptr [esp + 0x1a8]
4336431a  41                       inc      ecx
4336431b  f30f10a424bc010000       movss    xmm4, dword ptr [esp + 0x1bc]
43364324  f30f10ac24c0010000       movss    xmm5, dword ptr [esp + 0x1c0]
4336432d  f30f5ce0                 subss    xmm4, xmm0
43364331  f30f109424ac010000       movss    xmm2, dword ptr [esp + 0x1ac]
4336433a  f30f5ce9                 subss    xmm5, xmm1
4336433e  f30f10b424c4010000       movss    xmm6, dword ptr [esp + 0x1c4]
43364347  83a424800c000000         and      dword ptr [esp + 0xc80], 0
4336434f  f30f5cf2                 subss    xmm6, xmm2
43364353  f30f118424400c0000       movss    dword ptr [esp + 0xc40], xmm0
4336435c  0f57c0                   xorps    xmm0, xmm0
4336435f  f30f118c24440c0000       movss    dword ptr [esp + 0xc44], xmm1
43364368  0f298424600c0000         movaps   xmmword ptr [esp + 0xc60], xmm0
43364370  0f28cd                   movaps   xmm1, xmm5
43364373  0f298424700c0000         movaps   xmmword ptr [esp + 0xc70], xmm0
4336437b  0f28c4                   movaps   xmm0, xmm4
4336437e  f30f59c4                 mulss    xmm0, xmm4
43364382  888c24840c0000           mov      byte ptr [esp + 0xc84], cl
43364389  f30f59cd                 mulss    xmm1, xmm5
4336438d  888c24850c0000           mov      byte ptr [esp + 0xc85], cl
43364394  f30f119424480c0000       movss    dword ptr [esp + 0xc48], xmm2
4336439d  f30f11a424500c0000       movss    dword ptr [esp + 0xc50], xmm4
433643a6  f30f58c8                 addss    xmm1, xmm0
433643aa  f30f11ac24540c0000       movss    dword ptr [esp + 0xc54], xmm5
433643b3  0f28c6                   movaps   xmm0, xmm6
433643b6  f30f11b424580c0000       movss    dword ptr [esp + 0xc58], xmm6
433643bf  f30f59c6                 mulss    xmm0, xmm6
433643c3  f30f58c8                 addss    xmm1, xmm0
433643c7  0f2ecb                   ucomiss  xmm1, xmm3
433643ca  9f                       lahf     
433643cb  f6c444                   test     ah, 0x44
433643ce  7a08                     jp       0x433643d8
433643d0  c68424850c000000         mov      byte ptr [esp + 0xc85], 0
433643d8  f30f59e4                 mulss    xmm4, xmm4
433643dc  8bd1                     mov      edx, ecx
433643de  894c2424                 mov      dword ptr [esp + 0x24], ecx
433643e2  f30f59ed                 mulss    xmm5, xmm5
433643e6  f30f59f6                 mulss    xmm6, xmm6
433643ea  f30f58e5                 addss    xmm4, xmm5
433643ee  f30f58e6                 addss    xmm4, xmm6
433643f2  0f28c4                   movaps   xmm0, xmm4
433643f5  f30f51c0                 sqrtss   xmm0, xmm0
433643f9  f30f11442468             movss    dword ptr [esp + 0x68], xmm0
433643ff  8b0d90a84643             mov      ecx, dword ptr [0x4346a890]
43364405  52                       push     edx
43364406  8b01                     mov      eax, dword ptr [ecx]
43364408  8b400c                   mov      eax, dword ptr [eax + 0xc]
4336440b  ffd0                     call     eax
4336440d  8bf0                     mov      esi, eax
4336440f  85f6                     test     esi, esi
43364411  0f84c7010000             je       0x433645de
43364417  c74424309e182711         mov      dword ptr [esp + 0x30], 0x1127189e
4336441f  8b542430                 mov      edx, dword ptr [esp + 0x30]
43364423  8b0e                     mov      ecx, dword ptr [esi]
43364425  8b8c0adae9d8ee           mov      ecx, dword ptr [edx + ecx - 0x11271626]
4336442c  8bd6                     mov      edx, esi
4336442e  898c2488030000           mov      dword ptr [esp + 0x388], ecx
43364435  e8050f0800               call     0x433e533f
4336443a  84c0                     test     al, al
4336443c  0f849c010000             je       0x433645de
43364442  a1788e4643               mov      eax, dword ptr [0x43468e78]
43364447  8b00                     mov      eax, dword ptr [eax]
43364449  3305e4844643             xor      eax, dword ptr [0x434684e4]
4336444f  35350e929d               xor      eax, 0x9d920e35
43364454  803c3000                 cmp      byte ptr [eax + esi], 0
43364458  0f8580010000             jne      0x433645de
4336445e  c7442430d5fb2c6d         mov      dword ptr [esp + 0x30], 0x6d2cfbd5
43364466  8bd6                     mov      edx, esi
43364468  8b442430                 mov      eax, dword ptr [esp + 0x30]
4336446c  8b0e                     mov      ecx, dword ptr [esi]
4336446e  40                       inc      eax
4336446f  351640674a               xor      eax, 0x4a674016
43364474  8b8c082846b4d8           mov      ecx, dword ptr [eax + ecx - 0x274bb9d8]
4336447b  898c248c030000           mov      dword ptr [esp + 0x38c], ecx
43364482  e8b80e0800               call     0x433e533f
43364487  85c0                     test     eax, eax
43364489  0f8e4f010000             jle      0x433645de
4336448f  8d4e08                   lea      ecx, [esi + 8]
43364492  8b01                     mov      eax, dword ptr [ecx]
43364494  ff5024                   call     dword ptr [eax + 0x24]
43364497  84c0                     test     al, al
43364499  0f853f010000             jne      0x433645de
4336449f  a1dca54643               mov      eax, dword ptr [0x4346a5dc]
433644a4  8b00                     mov      eax, dword ptr [eax]
433644a6  330530844643             xor      eax, dword ptr [0x43468430]
433644ac  35d290e2cd               xor      eax, 0xcde290d2
433644b1  803c3000                 cmp      byte ptr [eax + esi], 0
433644b5  0f8523010000             jne      0x433645de
433644bb  a1b0884643               mov      eax, dword ptr [0x434688b0]
433644c0  8b00                     mov      eax, dword ptr [eax]
433644c2  330518a54643             xor      eax, dword ptr [0x4346a518]
433644c8  35f686558b               xor      eax, 0x8b5586f6
433644cd  393c30                   cmp      dword ptr [eax + esi], edi
433644d0  0f8508010000             jne      0x433645de
433644d6  8d8424bc010000           lea      eax, [esp + 0x1bc]
433644dd  8bce                     mov      ecx, esi
433644df  50                       push     eax
433644e0  8d8424c00e0000           lea      eax, [esp + 0xec0]
433644e7  50                       push     eax
433644e8  e8739efbff               call     0x4331e360
433644ed  f30f1044246c             movss    xmm0, dword ptr [esp + 0x6c]
433644f3  8d9424a8010000           lea      edx, [esp + 0x1a8]
433644fa  8bc8                     mov      ecx, eax
433644fc  e80b860b00               call     0x4341cb0c
43364501  0f2f05e0204743           comiss   xmm0, dword ptr [0x434720e0]
43364508  0f83d0000000             jae      0x433645de
4336450e  8bce                     mov      ecx, esi
43364510  e8f88d0900               call     0x433fd30d
43364515  85c0                     test     eax, eax
43364517  0f84c1000000             je       0x433645de
4336451d  8b08                     mov      ecx, dword ptr [eax]
4336451f  a140824643               mov      eax, dword ptr [0x43468240]
43364524  8b00                     mov      eax, dword ptr [eax]
43364526  33054ca84643             xor      eax, dword ptr [0x4346a84c]
4336452c  3510fbb6c2               xor      eax, 0xc2b6fb10
43364531  6b3c300c                 imul     edi, dword ptr [eax + esi], 0xc
43364535  03b9b0000000             add      edi, dword ptr [ecx + 0xb0]
4336453b  03f9                     add      edi, ecx
4336453d  0f8497000000             je       0x433645da
43364543  837f0400                 cmp      dword ptr [edi + 4], 0
43364547  0f848d000000             je       0x433645da
4336454d  838c240c0f0000ff         or       dword ptr [esp + 0xf0c], 0xffffffff
43364555  83a424140f000000         and      dword ptr [esp + 0xf14], 0
4336455d  838c24180f0000ff         or       dword ptr [esp + 0xf18], 0xffffffff
43364565  33c0                     xor      eax, eax
43364567  c78424f40e00000000803f   mov      dword ptr [esp + 0xef4], 0x3f800000
43364572  66c78424fe0e00000000     mov      word ptr [esp + 0xefe], 0
4336457c  89442414                 mov      dword ptr [esp + 0x14], eax
43364580  8d0c07                   lea      ecx, [edi + eax]
43364583  034f08                   add      ecx, dword ptr [edi + 8]
43364586  8d8424e00f0000           lea      eax, [esp + 0xfe0]
4336458d  50                       push     eax
4336458e  8d4124                   lea      eax, [ecx + 0x24]
43364591  50                       push     eax
43364592  ff31                     push     dword ptr [ecx]
43364594  8bce                     mov      ecx, esi
43364596  e8d8a2fbff               call     0x4331e873
4336459b  84c0                     test     al, al
4336459d  7429                     je       0x433645c8
4336459f  8b542414                 mov      edx, dword ptr [esp + 0x14]
433645a3  8d8424c80e0000           lea      eax, [esp + 0xec8]
433645aa  50                       push     eax
433645ab  03d7                     add      edx, edi
433645ad  8d8424e40f0000           lea      eax, [esp + 0xfe4]
433645b4  035708                   add      edx, dword ptr [edi + 8]
433645b7  8d8c24440c0000           lea      ecx, [esp + 0xc44]
433645be  50                       push     eax
433645bf  e8cab40300               call     0x4339fa8e
433645c4  85c0                     test     eax, eax
433645c6  795d                     jns      0x43364625
433645c8  8b442414                 mov      eax, dword ptr [esp + 0x14]
433645cc  83c044                   add      eax, 0x44
433645cf  89442414                 mov      dword ptr [esp + 0x14], eax
433645d3  3d0c050000               cmp      eax, 0x50c
433645d8  7ca6                     jl       0x43364580
433645da  8b7c2444                 mov      edi, dword ptr [esp + 0x44]
433645de  8b542424                 mov      edx, dword ptr [esp + 0x24]
433645e2  42                       inc      edx
433645e3  89542424                 mov      dword ptr [esp + 0x24], edx
433645e7  83fa40                   cmp      edx, 0x40
433645ea  0f8e0ffeffff             jle      0x433643ff
433645f0  8b7c245c                 mov      edi, dword ptr [esp + 0x5c]
433645f4  6a7f                     push     0x7f
433645f6  5a                       pop      edx
433645f7  8bca                     mov      ecx, edx
433645f9  f30f104f38               movss    xmm1, dword ptr [edi + 0x38]
433645fe  f30f590da0044743         mulss    xmm1, dword ptr [0x434704a0]
43364606  8b4708                   mov      eax, dword ptr [edi + 8]
43364609  83c005                   add      eax, 5
4336460c  3bc2                     cmp      eax, edx
4336460e  f30f2df1                 cvtss2si esi, xmm1
43364612  0f42c8                   cmovb    ecx, eax
43364615  8b4728                   mov      eax, dword ptr [edi + 0x28]
43364618  3bc8                     cmp      ecx, eax
4336461a  0f42c1                   cmovb    eax, ecx
4336461d  85f6                     test     esi, esi
4336461f  7915                     jns      0x43364636
43364621  33f6                     xor      esi, esi
43364623  eb16                     jmp      0x4336463b
43364625  8b8c24a0000000           mov      ecx, dword ptr [esp + 0xa0]
4336462c  e884d2fcff               call     0x433318b5
43364631  e947010000               jmp      0x4336477d
43364636  3bf2                     cmp      esi, edx
43364638  0f4ff2                   cmovg    esi, edx
4336463b  23f2                     and      esi, edx
4336463d  23c2                     and      eax, edx
4336463f  c1e609                   shl      esi, 9
43364642  0bf0                     or       esi, eax
43364644  837f3003                 cmp      dword ptr [edi + 0x30], 3
43364648  7406                     je       0x43364650
4336464a  837f3002                 cmp      dword ptr [edi + 0x30], 2
4336464e  750f                     jne      0x4336465f
43364650  80bfdd00000000           cmp      byte ptr [edi + 0xdd], 0
43364657  7406                     je       0x4336465f
43364659  81ce00010000             or       esi, 0x100
4336465f  33c9                     xor      ecx, ecx
43364661  41                       inc      ecx
43364662  848f0c010000             test     byte ptr [edi + 0x10c], cl
43364668  7471                     je       0x433646db
4336466a  8b0d90a84643             mov      ecx, dword ptr [0x4346a890]
43364670  ff7704                   push     dword ptr [edi + 4]
43364673  8b01                     mov      eax, dword ptr [ecx]
43364675  8b400c                   mov      eax, dword ptr [eax + 0xc]
43364678  ffd0                     call     eax
4336467a  85c0                     test     eax, eax
4336467c  7454                     je       0x433646d2
4336467e  8b0d747a4643             mov      ecx, dword ptr [0x43467a74]
43364684  8b09                     mov      ecx, dword ptr [ecx]
43364686  330dc0784643             xor      ecx, dword ptr [0x434678c0]
4336468c  81f1542681cd             xor      ecx, 0xcd812654
43364692  8b0c01                   mov      ecx, dword ptr [ecx + eax]
43364695  83f9ff                   cmp      ecx, -1
43364698  7438                     je       0x433646d2
4336469a  a190a84643               mov      eax, dword ptr [0x4346a890]
4336469f  51                       push     ecx
433646a0  8b00                     mov      eax, dword ptr [eax]
433646a2  8b5010                   mov      edx, dword ptr [eax + 0x10]
433646a5  8bc4                     mov      eax, esp
433646a7  8908                     mov      dword ptr [eax], ecx
433646a9  8b0d90a84643             mov      ecx, dword ptr [0x4346a890]
433646af  ffd2                     call     edx
433646b1  85c0                     test     eax, eax
433646b3  741d                     je       0x433646d2
433646b5  8b0d8c904643             mov      ecx, dword ptr [0x4346908c]
433646bb  6a1f                     push     0x1f
433646bd  5a                       pop      edx
433646be  8b09                     mov      ecx, dword ptr [ecx]
433646c0  330da08b4643             xor      ecx, dword ptr [0x43468ba0]
433646c6  81f1bb0f9f5c             xor      ecx, 0x5c9f0fbb
433646cc  66391401                 cmp      word ptr [ecx + eax], dx
433646d0  7406                     je       0x433646d8
433646d2  81ce80000000             or       esi, 0x80
433646d8  33c9                     xor      ecx, ecx
433646da  41                       inc      ecx
433646db  80bfdc00000000           cmp      byte ptr [edi + 0xdc], 0
433646e2  740b                     je       0x433646ef
433646e4  844f34                   test     byte ptr [edi + 0x34], cl
433646e7  7406                     je       0x433646ef
433646e9  81ce00000100             or       esi, 0x10000
433646ef  8b4704                   mov      eax, dword ptr [edi + 4]
433646f2  8bd6                     mov      edx, esi
433646f4  c1e005                   shl      eax, 5
433646f7  81ca00000200             or       edx, 0x20000
433646fd  80b80bbe474300           cmp      byte ptr [eax + 0x4347be0b], 0
43364704  0f44d6                   cmove    edx, esi
43364707  8b7728                   mov      esi, dword ptr [edi + 0x28]
4336470a  89542430                 mov      dword ptr [esp + 0x30], edx
4336470e  85f6                     test     esi, esi
43364710  7e1d                     jle      0x4336472f
43364712  8b4708                   mov      eax, dword ptr [edi + 8]
43364715  48                       dec      eax
43364716  03c6                     add      eax, esi
43364718  99                       cdq      
43364719  f7fe                     idiv     esi
4336471b  8bd1                     mov      edx, ecx
4336471d  3bc1                     cmp      eax, ecx
4336471f  0f4fd0                   cmovg    edx, eax
43364722  85d2                     test     edx, edx
43364724  7904                     jns      0x4336472a
43364726  33d2                     xor      edx, edx
43364728  eb08                     jmp      0x43364732
4336472a  83fa0f                   cmp      edx, 0xf
4336472d  7e03                     jle      0x43364732
4336472f  6a0f                     push     0xf
43364731  5a                       pop      edx
43364732  8b874c010000             mov      eax, dword ptr [edi + 0x14c]
43364738  f7d2                     not      edx
4336473a  83e20f                   and      edx, 0xf
4336473d  c1e213                   shl      edx, 0x13
43364740  0b542430                 or       edx, dword ptr [esp + 0x30]
43364744  8bca                     mov      ecx, edx
43364746  81c900000400             or       ecx, 0x40000
4336474c  2500180000               and      eax, 0x1800
43364751  6a1f                     push     0x1f
43364753  0f44ca                   cmove    ecx, edx
43364756  8b5524                   mov      edx, dword ptr [ebp + 0x24]
43364759  898fe4000000             mov      dword ptr [edi + 0xe4], ecx
4336475f  8bca                     mov      ecx, edx
43364761  58                       pop      eax
43364762  23c8                     and      ecx, eax
43364764  c1ea05                   shr      edx, 5
43364767  33c0                     xor      eax, eax
43364769  40                       inc      eax
4336476a  d3e0                     shl      eax, cl
4336476c  89442430                 mov      dword ptr [esp + 0x30], eax
43364770  8b4520                   mov      eax, dword ptr [ebp + 0x20]
43364773  8b4c2430                 mov      ecx, dword ptr [esp + 0x30]
43364777  8d0490                   lea      eax, [eax + edx*4]
4336477a  f00908                   lock or  dword ptr [eax], ecx
4336477d  5f                       pop      edi
4336477e  5e                       pop      esi
4336477f  8be5                     mov      esp, ebp
43364781  5d                       pop      ebp
43364782  c22000                   ret      0x20
