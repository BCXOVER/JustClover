433e10cc push     edx
433e10cd call     0x433f4b01
433e10d2 ret      
