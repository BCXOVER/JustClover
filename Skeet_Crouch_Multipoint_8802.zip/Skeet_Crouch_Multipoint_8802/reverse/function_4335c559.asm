4335c559 mov      eax, dword ptr [esp + 4]
4335c55d mov      eax, dword ptr [eax + 0x5c]
4335c560 test     eax, eax
4335c562 je       0x4335c567
4335c564 movzx    eax, word ptr [eax]
4335c567 push     -1
4335c569 push     eax
4335c56a call     0x43368201
4335c56f ret      4
