433d7108 push     ebp
433d7109 mov      ebp, esp
433d710b and      esp, 0xfffffff8
433d710e push     ecx
433d710f push     esi
433d7110 mov      esi, dword ptr [ecx + 0xc4]
433d7116 test     esi, esi
433d7118 je       0x433d715c
433d711a push     -1
433d711c push     0x13a3
433d7121 mov      ecx, esi
433d7123 call     0x43368201
433d7128 mov      ecx, esi
433d712a call     0x434084f0
433d712f mov      eax, dword ptr [esi + 0x12c]
433d7135 mov      ecx, dword ptr [eax + 0x90]
433d713b cmp      ecx, dword ptr [eax + 0x94]
433d7141 je       0x433d715c
433d7143 mov      edx, dword ptr [ecx]
433d7145 xor      ecx, ecx
433d7147 mov      eax, dword ptr [esi + 0x130]
433d714d mov      dword ptr [eax + ecx + 0xc], edx
433d7151 add      ecx, 0x10
433d7154 cmp      ecx, 0x410
433d715a jb       0x433d7147
433d715c pop      esi
433d715d mov      esp, ebp
433d715f pop      ebp
433d7160 ret      
