433d66b5 push     edx
433d66b6 call     0x433f2144
433d66bb ret      
