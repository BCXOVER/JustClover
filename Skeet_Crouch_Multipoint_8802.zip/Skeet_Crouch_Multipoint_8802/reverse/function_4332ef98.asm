4332ef98 cmp      byte ptr [ecx + 0x15], 0
4332ef9c jne      0x4332efa3
4332ef9e mov      eax, dword ptr [ecx]
4332efa0 jmp      dword ptr [eax + 0x18]
4332efa3 ret      
