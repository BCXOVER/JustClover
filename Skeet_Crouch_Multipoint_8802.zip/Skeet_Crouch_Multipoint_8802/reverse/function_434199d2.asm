434199d2 push     esi
434199d3 lea      edx, [ecx + 0x80]
434199d9 push     edi
434199da lea      esi, [edx + 0x260]
434199e0 or       edi, 0xffffffff
434199e3 cmp      edx, esi
434199e5 je       0x434199fc
434199e7 add      edx, 0x1c
434199ea mov      dword ptr [edx - 8], edi
434199ed mov      dword ptr [edx], edi
434199ef lea      edx, [edx + 0x20]
434199f2 mov      dword ptr [edx - 0x24], edi
434199f5 lea      eax, [edx - 0x1c]
434199f8 cmp      eax, esi
434199fa jne      0x434199ea
434199fc mov      eax, dword ptr [ecx + 0x328]
43419a02 mov      dword ptr [ecx + 0x2f4], edi
43419a08 mov      dword ptr [ecx + 0x2fc], edi
43419a0e mov      dword ptr [ecx + 0x2f8], edi
43419a14 mov      dword ptr [ecx + 0x314], edi
43419a1a mov      dword ptr [ecx + 0x31c], edi
43419a20 mov      dword ptr [ecx + 0x318], edi
43419a26 mov      dword ptr [ecx + 0x320], edi
43419a2c mov      dword ptr [ecx + 0x324], edi
43419a32 pop      edi
43419a33 mov      dword ptr [ecx + 0x32c], eax
43419a39 pop      esi
43419a3a ret      
