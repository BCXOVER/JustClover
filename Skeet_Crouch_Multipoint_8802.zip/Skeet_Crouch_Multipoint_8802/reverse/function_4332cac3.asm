4332cac3 push     ecx
4332cac4 push     ebx
4332cac5 push     ebp
4332cac6 push     esi
4332cac7 push     edi
4332cac8 mov      edi, ecx
4332caca cmp      dword ptr [edi + 0x84], -1
4332cad1 mov      byte ptr [edi + 0x30], 0
4332cad5 mov      byte ptr [edi + 0x1c], 0
4332cad9 je       0x4332cbfe
4332cadf mov      ecx, dword ptr [0x4346a514]
4332cae5 mov      eax, dword ptr [ecx]
4332cae7 call     dword ptr [eax + 0x68]
4332caea test     al, al
4332caec je       0x4332cbb4
4332caf2 mov      ebx, dword ptr [0x43475808]
4332caf8 test     ebx, ebx
4332cafa je       0x4332cbb4
4332cb00 mov      eax, dword ptr [0x43468968]
4332cb05 mov      esi, dword ptr [eax]
4332cb07 xor      esi, dword ptr [0x43467ea0]
4332cb0d xor      esi, 0xe96443c6
4332cb13 mov      ecx, dword ptr [esi + ebx]
4332cb16 cmp      ecx, -1
4332cb19 je       0x4332cbb4
4332cb1f cmp      ecx, dword ptr [edi + 0x84]
4332cb25 jne      0x4332cbb4
4332cb2b mov      eax, dword ptr [0x4346a890]
4332cb30 push     ecx
4332cb31 mov      eax, dword ptr [eax]
4332cb33 mov      edx, dword ptr [eax + 0x10]
4332cb36 mov      eax, esp
4332cb38 mov      dword ptr [eax], ecx
4332cb3a mov      ecx, dword ptr [0x4346a890]
4332cb40 call     edx
4332cb42 mov      ebp, eax
4332cb44 test     ebp, ebp
4332cb46 je       0x4332cbb0
4332cb48 mov      dword ptr [esp + 0x10], 0x94de6991
4332cb50 mov      edx, ebp
4332cb52 mov      eax, dword ptr [esp + 0x10]
4332cb56 mov      ecx, dword ptr [ebp]
4332cb59 add      eax, 0x5e246aed
4332cb5e ror      eax, 0x11
4332cb61 push     0
4332cb63 push     ebx
4332cb64 mov      ecx, dword ptr [eax + ecx - 0x6a3f752d]
4332cb6b mov      dword ptr [esp + 0x18], ecx
4332cb6f call     0x433e533f
4332cb74 mov      dword ptr [esp + 0x10], 0xa008b771
4332cb7c mov      edx, ebp
4332cb7e mov      eax, dword ptr [esp + 0x10]
4332cb82 mov      ecx, dword ptr [ebp]
4332cb85 rol      eax, 0xf
4332cb88 add      eax, 0x2d432ffb
4332cb8d bswap    eax
4332cb8f sub      ecx, eax
4332cb91 push     ebx
4332cb92 mov      ecx, dword ptr [ecx]
4332cb94 call     0x433e533f
4332cb99 mov      eax, dword ptr [0x43468fec]
4332cb9e mov      eax, dword ptr [eax]
4332cba0 xor      eax, dword ptr [0x4346a3c4]
4332cba6 xor      eax, 0xa2a8247f
4332cbab and      dword ptr [eax + ebx - 4], 0
4332cbb0 or       dword ptr [esi + ebx], 0xffffffff
4332cbb4 mov      ecx, dword ptr [edi + 0x84]
4332cbba cmp      ecx, -1
4332cbbd je       0x4332cbf7
4332cbbf mov      eax, dword ptr [0x4346a890]
4332cbc4 push     ecx
4332cbc5 mov      eax, dword ptr [eax]
4332cbc7 mov      edx, dword ptr [eax + 0x10]
4332cbca mov      eax, esp
4332cbcc mov      dword ptr [eax], ecx
4332cbce mov      ecx, dword ptr [0x4346a890]
4332cbd4 call     edx
4332cbd6 test     eax, eax
4332cbd8 je       0x4332cbf7
4332cbda mov      edx, dword ptr [eax]
4332cbdc mov      ecx, eax
4332cbde call     dword ptr [edx + 0x10]
4332cbe1 mov      esi, eax
4332cbe3 test     esi, esi
4332cbe5 je       0x4332cbf7
4332cbe7 mov      edx, dword ptr [esi]
4332cbe9 mov      ecx, esi
4332cbeb push     1
4332cbed call     dword ptr [edx + 0xc]
4332cbf0 mov      edx, dword ptr [esi]
4332cbf2 mov      ecx, esi
4332cbf4 call     dword ptr [edx + 4]
4332cbf7 or       dword ptr [edi + 0x84], 0xffffffff
4332cbfe pop      edi
4332cbff pop      esi
4332cc00 pop      ebp
4332cc01 pop      ebx
4332cc02 pop      ecx
4332cc03 ret      
