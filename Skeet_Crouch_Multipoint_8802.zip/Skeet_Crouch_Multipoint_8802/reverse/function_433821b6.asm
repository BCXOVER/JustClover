433821b6 push     esi
433821b7 push     edi
433821b8 mov      edi, ecx
433821ba mov      ecx, dword ptr [0x4346a514]
433821c0 push     2
433821c2 pop      esi
433821c3 mov      eax, dword ptr [ecx]
433821c5 call     dword ptr [eax + 0x68]
433821c8 test     al, al
433821ca je       0x4338220f
433821cc mov      ecx, dword ptr [0x4346a514]
433821d2 mov      eax, dword ptr [ecx]
433821d4 call     dword ptr [eax + 0x148]
433821da test     al, al
433821dc jne      0x4338220f
433821de mov      ecx, dword ptr [0x4346a514]
433821e4 mov      eax, dword ptr [ecx]
433821e6 call     dword ptr [eax + 0x174]
433821ec test     al, al
433821ee jne      0x4338220f
433821f0 mov      ecx, dword ptr [0x43475808]
433821f6 test     ecx, ecx
433821f8 je       0x4338220f
433821fa mov      eax, dword ptr [0x434688b0]
433821ff mov      eax, dword ptr [eax]
43382201 xor      eax, dword ptr [0x4346a518]
43382207 xor      eax, 0x8b5586f6
4338220c mov      esi, dword ptr [eax + ecx]
4338220f push     esi
43382210 mov      ecx, edi
43382212 call     0x433ab7c4
43382217 pop      edi
43382218 pop      esi
43382219 ret      4
