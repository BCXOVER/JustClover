#pragma once
#include "local_inventory.h"
namespace local_loadout {
using local_inventory::Session;using local_inventory::Item;
struct Api {
 bool(*current)(const Session&);bool(*owned)(const Session&,const Item&);
 int(*slot)(const Session&,const Item&,int);
 bool(*get)(const Session&,int,int,std::uint64_t&);
 bool(*state)(const Session&,const Item&,int,int);
 bool(*set)(const Session&,int,int,std::uint64_t);
 bool(*clear)(const Session&,const Item&)=nullptr;
};
struct Entry {std::uint64_t saved=0,applied=0;bool active=false;};
struct Loadout {
 Session session{};Entry entries[4][57]{};
 void reset(){session={};for(auto& team:entries)for(auto& e:team)e={};}
 bool bind(const Api& api,const Session& s){if(!api.current(s)){reset();return false;}if(!(session==s)){reset();session=s;}return true;}
 unsigned equip(const Api& api,const Session& s,const Item& item) {
  if(!bind(api,s)||!api.owned(s,item))return 0;unsigned teams=0;
  for(int team:{2,3}) {
   const int slot=api.slot(s,item,team);if(slot<0||slot>=57)continue;
   std::uint64_t previous=0;if(!api.get(s,team,slot,previous))continue;
   auto& e=entries[team][slot];const bool replace=e.active&&previous==e.applied;
   // Preserve a real/manual loadout choice made after our previous operation.
   const auto saved=replace?e.saved:previous;
   if(!api.state(s,item,team,slot))continue;
   if(!api.set(s,team,slot,item.id)){api.state(s,item,team,0xffff);std::uint64_t current=0;if(api.get(s,team,slot,current)&&current==item.id)api.set(s,team,slot,previous);continue;}
   e={saved,item.id,true};teams|=1u<<team;
  }
  return teams;
 }
 bool detach(const Api& api,std::uint64_t id) {
  if(!api.current(session)){reset();return true;}bool done=true;
  for(int team:{2,3})for(int slot=0;slot<57;slot++) {
   auto& e=entries[team][slot];if(!e.active||e.applied!=id)continue;
   std::uint64_t current=0;if(!api.get(session,team,slot,current)){done=false;continue;}
   if(current==e.applied&&!api.set(session,team,slot,e.saved)){done=false;continue;}
   e={};
  }
  return done;
 }
};
}
