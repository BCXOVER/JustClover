#pragma once
#include "local_inventory.h"
#include "local_loadout.h"
namespace skin_mirror {
using namespace local_inventory;
inline bool equal(const Spec& a,const Spec& b){return a.weapon==b.weapon&&a.paint==b.paint&&a.seed==b.seed&&a.wear==b.wear&&a.rarity==b.rarity&&!std::strcmp(a.name,b.name);}
struct Preset {int weapon=0,slot=-1;std::uint64_t id=0;Spec desired{},applied{};bool enabled=false,pending=false,ignored=false;unsigned changed=0,retry=0;};
struct Mirror {
 std::array<Preset,96> presets{};local_loadout::Loadout loadout{};Session session{};const char* status="";
 void observe(const Spec& s,bool enabled,unsigned now) {
  if(!valid(s))return;Preset* p=nullptr;
  for(auto& e:presets)if(e.weapon==s.weapon){p=&e;break;}
  if(!p)for(auto& e:presets)if(!e.weapon){p=&e;e.weapon=s.weapon;break;}
  if(!p)return;
  if(!equal(p->desired,s)||p->enabled!=enabled){p->desired=s;p->enabled=enabled;p->pending=true;p->changed=now;p->retry=0;p->ignored=false;}
  else if(p->slot<0&&!p->ignored&&enabled&&!p->pending){p->pending=true;p->changed=now;}
 }
 void deleted(unsigned slot) {for(auto& p:presets)if(p.slot==int(slot)){p.slot=-1;p.id=0;p.pending=false;p.ignored=true;}}
 void changed_session(const Session& s) {
  if(session==s)return;session=s;loadout.reset();
  for(auto& p:presets){p.slot=-1;p.id=0;p.ignored=false;p.pending=p.weapon&&p.enabled;p.retry=0;}
 }
 bool tick(Inventory& inventory,const Api& api,const local_loadout::Api& equip,bool enabled,unsigned now) {
  bool changed=false;changed_session(inventory.current);
  bool work=false;for(const auto& p:presets)if(p.weapon&&(((!enabled||!p.enabled)&&p.slot>=0)||(enabled&&p.enabled&&!p.ignored&&p.pending&&now-p.changed>=350&&(!p.retry||now-p.retry>=2000))))work=true;
  if(!work)return false;const auto previous_session=inventory.current;
  if(!inventory.refresh(api)){status=inventory.error;return false;}
  changed=!(previous_session==inventory.current);changed_session(inventory.current);
  for(auto& p:presets) {
   if(!p.weapon)continue;
   if(enabled&&p.enabled&&(p.ignored||!p.pending||now-p.changed<350||(p.retry&&now-p.retry<2000)))continue;
   bool own=p.slot>=0&&unsigned(p.slot)<inventory.items.size()&&inventory.items[p.slot].object&&inventory.items[p.slot].id==p.id;
   if(own&&!api.contains(inventory.current,inventory.items[p.slot].object,p.id)){inventory.items[p.slot]={};own=false;}
   if(!own&&p.slot>=0){p.slot=-1;p.id=0;p.pending=true;}
   if(!enabled||!p.enabled) {
    if(own&&loadout.detach(equip,p.id)&&(!equip.clear||equip.clear(inventory.current,inventory.items[p.slot]))&&inventory.erase(api,unsigned(p.slot))){p.slot=-1;p.id=0;p.pending=true;p.changed=now;changed=true;}
    continue;
   }
   if(p.ignored||!p.pending||now-p.changed<350||(p.retry&&now-p.retry<2000))continue;
   if(own&&equal(p.desired,p.applied)){p.pending=false;continue;}
   p.retry=now;const int next=inventory.add(api,p.desired);if(next<0){status=inventory.error;continue;}
   const unsigned teams=loadout.equip(equip,inventory.current,inventory.items[next]);
   const int old=p.slot;const auto old_id=p.id;
   p.slot=next;p.id=inventory.items[next].id;p.applied=p.desired;p.pending=false;p.retry=0;changed=true;
   if(own&&old!=next&&inventory.items[old].id==old_id&&loadout.detach(equip,old_id)&&(!equip.clear||equip.clear(inventory.current,inventory.items[old])))inventory.erase(api,unsigned(old));
   status=teams?"Skinchanger selection added and equipped locally":"Selection added; local equip unavailable";
  }
  return changed;
 }
};
}
