"""Inline Weapon skin fields, original name callbacks and palette ownership."""
def check_inventory_ui(ns):
 globals().update(ns)
 clock=[1000]
 def tick(u,sp):return clock[0],4
 def from_utf8(u,sp):
  cp,flags,src,n,out,capacity=[word(u,sp+k) for k in [4,8,12,16,20,24]];assert cp==65001 and n==0xffffffff
  data=bytearray()
  while bytes(u.mem_read(src+len(data),1))!=b'\0':data.extend(u.mem_read(src+len(data),1))
  result=(data.decode('utf-8')+'\0').encode('utf-16le');assert len(result)//2<=capacity;u.mem_write(out,result);return len(result)//2,28
 def to_utf8(u,sp):
  cp,flags,src,n,out,capacity=[word(u,sp+k) for k in [4,8,12,16,20,24]];assert cp==65001 and n==0xffffffff
  data=(wide(u,src)+'\0').encode('utf-8');assert len(data)<=capacity;u.mem_write(out,data);return len(data),36
 u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',{'GetTickCount':tick,'MultiByteToWideChar':from_utf8,'WideCharToMultiByte':to_utf8})
 API=0x140000;u.mem_map(API,0x2000);u.mem_map(0x500000,0x200000)
 ctx,menu,tabs,skin_tab,children,panels,api,vt,element_vt,spec=[MEM+0x10000+i*0x1000 for i in range(10)]
 store(u,ctx+0x10,menu);store(u,menu+0x14,800);store(u,menu+0x18,650);store(u,menu+0x34,1);store(u,menu+0x64,5)
 store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs+20,skin_tab)
 store(u,skin_tab+0x70,children);store(u,skin_tab+0x74,children+12);store(u,skin_tab+0x78,children+128)
 for i in range(3):
  c=MEM+0x20000+i*0x1000;store(u,children+4*i,c);store(u,panels+4*i,c);vec=MEM+0x24000+i*0x1000
  for off,v in [(0x80,vec),(0x84,vec),(0x88,vec+1024),(0x28,300),(0x2c,600)]:store(u,c+off,v)
  u.mem_write(c+0x15,b'\1')
 floats(u,0x4346d490,1)
 for i in range(15):store(u,element_vt+4*i,API+0x900+0x20*i)
 allocations=[];constructed=[];labels=[];palette_calls=[];edits=[];native_events=[]
 def alloc(n):
  p=0x500000+len(allocations)*0x1000;assert n<=0x1000;allocations.append((p,n));u.mem_write(p,bytes(0x1000));return p
 def insert(c,p):
  end=word(u,c+0x84);assert end+4<=word(u,c+0x88);store(u,end,p);store(u,c+0x84,end+4)
 def base(p,parent,kind):
  store(u,p,element_vt);store(u,p+0x10,parent);u.mem_write(p+0x14,bytes([1,1,0,1,0,kind]));constructed.append((p,kind))
 def mock(u,a,size,user):
  if not API<=a<API+0x2000:return
  sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX);cleanup=4;result=0
  if a==API+0x100:result=alloc(this)
  elif a==API+0x1c0:base(this,word(u,sp+4),12);store(u,this+0x5c,word(u,sp+8));cleanup=12
  elif a==API+0x200:base(this,word(u,sp+4),8);labels.append(wide(u,word(u,sp+8)));cleanup=12
  elif a==API+0x220:insert(this,word(u,sp+8));cleanup=12
  elif a==API+0x360:base(this,word(u,sp+4),10);cleanup=8
  elif a==API+0x380:pass # Native child layout boundary.
  elif a==API+0x400:
   kit,out,action=[word(u,sp+k) for k in [4,8,12]];assert kit in [344,282]
   if action==0:
    for i in range(4):store(u,out+4*i,0xff112200+i+kit)
   palette_calls.append((kit,action,[word(u,out+4*i) for i in range(4)]));result=1
  elif a==API+0x420:assert word(u,sp+4)==menu;edits.append(1)
  elif a in [API+0x440,API+0x460]:native_events.append(a)
  elif a==API+0x900:cleanup=8
  elif a in [API+0x120,API+0x9a0,API+0x9c0,API+0x9e0,API+0xa00,API+0xa20,API+0xa40]:pass
  else:raise AssertionError(('No extra pages, buttons, checkboxes or selectors allowed',hex(a)))
  u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,word(u,sp))
 u.hook_add(UC_HOOK_CODE,mock)
 for i in range(12):store(u,api+i*4,API+0x100+0x20*i)
 call(u,exp('inventory_ui_setup_probe'),[ctx,api,panels,API+0x300,API+0x320,API+0x340,API+0x360,API+0x380])
 call(u,exp('inventory_inline_callback_probe'),[API+0x400,API+0x420])
 call(u,exp('inventory_ui_frame_probe'))
 assert labels==['Name tag','Skin colors'] and len(constructed)==7
 assert [k for _,k in constructed]==[8,10,8,12,12,12,12]
 assert (word(u,skin_tab+0x74)-word(u,skin_tab+0x70))//4==3
 controls=[call(u,exp('inventory_inline_control_probe'),[i]) for i in range(7)];tag=controls[1];weapon_pane=word(u,panels+4)
 assert all(word(u,p+0x10)==weapon_pane for p in controls)
 def select(weapon,paint):
  u.mem_write(spec,bytes(152));u.mem_write(spec,struct.pack('<iiifI',weapon,paint,0,.01,6));call(u,exp('inventory_inline_select_probe'),[spec])
 def invoke(obj):
  ptr=word(u,obj+0x40);call(u,word(u,ptr+4),ecx=word(u,ptr),edx=obj)
 def text(value):store(u,tag+0x64,len(value));u.mem_write(tag+0x68,(value+'\0').encode('utf-16le'))
 select(9,344);text('Дракон');invoke(tag);assert len(edits)==1
 select(7,282);assert wide(u,tag+0x68)==''
 select(9,344);assert wide(u,tag+0x68)=='Дракон' and bytes(u.mem_read(spec+20,13))=='Дракон'.encode('utf-8')+b'\0'
 # Periodic observation must not erase an in-progress edit before native commit.
 text('Черновик');select(9,344);assert wide(u,tag+0x68)=='Черновик';text('Дракон')
 # A long invalid name does not overwrite the previously committed valid one.
 text('A'*33);invoke(tag);assert len(edits)==1;select(7,282);select(9,344);assert wide(u,tag+0x68)=='Дракон'
 # Commit to the original native text callback as well as the local item.
 source,proxy=MEM+0x30000,MEM+0x31000
 for p in [source,proxy]:base(p,weapon_pane,10)
 store(u,element_vt+5*4,API+0x440);store(u,element_vt+7*4,API+0x460)
 call(u,exp('inventory_inline_native_tag_probe'),[source,proxy])
 text('Феникс');invoke(tag);assert wide(u,source+0x68)=='Феникс' and native_events[:2]==[API+0x440,API+0x460]
 # Palette writes debounce and remain bound to the finish being edited, even
 # when the user changes weapons before the queued write is processed.
 color=word(u,controls[3]+0x5c);store(u,color,0xff123456);invoke(controls[3]);before=len([x for x in palette_calls if x[1]==1])
 clock[0]+=74;call(u,exp('inventory_ui_frame_probe'));assert len([x for x in palette_calls if x[1]==1])==before
 select(7,282);store(u,menu+0x34,0);clock[0]+=1;call(u,exp('inventory_ui_frame_probe'));store(u,menu+0x34,1)
 writes=[x for x in palette_calls if x[1]==1];assert len(writes)==before+1 and writes[-1][0]==344 and writes[-1][2][0]==0xff123456
 count=len(allocations);cases=0
 for dpi in [1.,.75,1.5,2.,1.]:
  floats(u,0x4346d490,dpi);store(u,weapon_pane+0x28,int(300*dpi));store(u,weapon_pane+0x2c,int(600*dpi));call(u,exp('inventory_ui_frame_probe'))
  for p in controls:
   assert word(u,p+0x20)+word(u,p+0x28)<=word(u,weapon_pane+0x28)
   assert word(u,p+0x24)+word(u,p+0x2c)<=word(u,weapon_pane+0x2c)
   assert abs(word(u,p+0x30)*dpi-word(u,p+0x28))<=2
  assert len(allocations)==count;cases+=1
 # A native rebuild may destroy the old tag; do not dereference its stale page.
 end=word(u,weapon_pane+0x84);start=word(u,weapon_pane+0x80)
 for at in range(start,end,4):
  if word(u,at)==tag:
   for tail in range(at,end-4,4):store(u,tail,word(u,tail+4))
   store(u,weapon_pane+0x84,end-4);break
 u.mem_unmap(tag,0x1000);call(u,exp('inventory_ui_frame_probe'))
 assert call(u,exp('inventory_inline_control_probe'),[1])!=tag
 assert (word(u,skin_tab+0x74)-word(u,skin_tab+0x70))//4==3
 return {'fresh_native_controls':7,'extra_pages':0,'extra_buttons':0,'extra_sync_checkboxes':0,'rgb_pickers':4,'inline_name_utf8_and_original_callback':True,'name_per_weapon':True,'typing_not_reset_by_polling':True,'palette_write_bound_to_original_paint':True,'pending_color_committed_with_menu_closed':True,'palette_debounce_ms':75,'resize_roundtrip_cases':cases,'idle_allocate_nothing':True,'stale_inline_tag_recovery':True}
