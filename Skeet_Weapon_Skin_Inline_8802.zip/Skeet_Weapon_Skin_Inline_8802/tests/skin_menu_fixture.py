"""Exercise compiled Skinchanger presentation with native list/combobox caches.
The original application and protected startup never run.
"""
def check_skin_menu(ns):
    globals().update(ns)
    def from_utf8(u,sp):
        cp,flags,source,length,out,capacity=[word(u,sp+k) for k in [4,8,12,16,20,24]];assert cp==65001 and length==0xffffffff
        data=bytearray()
        while bytes(u.mem_read(source+len(data),1))!=b'\0':data.extend(u.mem_read(source+len(data),1))
        result=(data.decode('utf-8')+'\0').encode('utf-16le');assert len(result)//2<=capacity;u.mem_write(out,result);return len(result)//2,28
    def utf8(u,sp):
        codepage,flags,source,length,out,capacity=[word(u,sp+k) for k in [4,8,12,16,20,24]]
        assert codepage==65001 and length==0xffffffff
        data=(wide(u,source)+'\0').encode('utf-8');assert len(data)<=capacity;u.mem_write(out,data);return len(data),36
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',{'WideCharToMultiByte':utf8,'MultiByteToWideChar':from_utf8})
    API=0x140000;u.mem_map(API,0x1000);u.mem_map(0x500000,0x400000)
    ctx,menu,tabs,skin,children,model_child,weapon_child,melems,welems,pane_ptrs,api=[MEM+0x10000+i*0x1000 for i in range(11)]
    store(u,ctx+0x10,menu);store(u,menu+0x14,660);store(u,menu+0x18,640);store(u,menu+0x34,1);store(u,menu+0x64,5)
    store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs+20,skin)
    store(u,skin+0x70,children);store(u,skin+0x74,children+20)
    store(u,children,model_child);store(u,children+4,weapon_child)
    for i in range(3):
        child=MEM+0x30000+i*0x1000;vec=MEM+0x34000+i*0x1000
        store(u,children+8+i*4,child);store(u,pane_ptrs+4*i,child)
        store(u,child+0x80,vec);store(u,child+0x84,vec);store(u,child+0x88,vec+1024)
    def name(object,text):
        ptr=object+0x300;data=text.encode('utf-16le')
        store(u,object+0x38,ptr);u.mem_write(ptr,struct.pack('<HH',0,len(data))+data)
    name(model_child,'Model options');name(weapon_child,'Weapon skin')
    for child,vec,n in [(model_child,melems,2),(weapon_child,welems,4)]:
        u.mem_write(child+0x15,b'\1');store(u,child+0x80,vec);store(u,child+0x84,vec+n*4);store(u,child+0x88,vec+128)
    sources=[MEM+0x40000+i*0x1000 for i in range(6)];values=MEM+0x48000
    types=[3,4,3,3,6,10];names=['Filter by weapon','Player model','Enabled','StatTrak','','']
    src_vt,cb_vt,list_vt,text_vt,check_vt=[MEM+0x49000+i*0x1000 for i in range(5)]
    for i in [5,7]:store(u,src_vt+i*4,API+(0x500 if i==5 else 0x520))
    store(u,src_vt+14*4,API+0x700)
    vt_spec=[(cb_vt,0x4333f5c2,0x43383770,0x433fa887,0x4332bb67),(list_vt,0x433d090d,0x433293ea,0x433ba433,0x4333c9a7),
             (text_vt,0x433e2fcc,0x433cce8e,0x433e2e4e,0x4331e326),(check_vt,0x433950fd,0x433cce8e,0x4332c42a,0x433cce8e)]
    for vt,dtor,config,reset,resize in vt_spec:
        for k,target in [(0,dtor),(4,API+0x720),(5,config),(6,reset),(9,resize),(14,API+0x700)]:store(u,vt+4*k,target)
    for i,(p,t,nm) in enumerate(zip(sources,types,names)):
        store(u,p,src_vt);u.mem_write(p+0x14,bytes([1,1,0,1,0,t]));store(u,p+0x5c,values+16*i if t!=10 else 0)
        store(u,values+16*i,[1,42,1,0,415,0][i]);name(p,nm)
        store(u,p+0x28,190);store(u,p+0x2c,30);store(u,p+0x30,190);store(u,p+0x34,30)
        store(u,(melems if i<2 else welems)+4*(i if i<2 else i-2),p)
    combo=sources[1];vars_=MEM+0x50000
    def wide_vector(vec,text,ptr):
        data=(text+'\0').encode('utf-16le');u.mem_write(ptr,data)
        for off,val in [(0,ptr),(4,ptr+len(data)),(8,ptr+len(data))]:store(u,vec+off,val)
    def combo_vars(items):
        store(u,combo+0x7c,vars_);store(u,combo+0x80,vars_+20*len(items));store(u,combo+0x84,vars_+20*len(items))
        for i,(label,index) in enumerate(items):wide_vector(vars_+20*i,label,MEM+0x52000+i*0x200);store(u,vars_+20*i+16,index)
    combo_vars([('Default',0),('Little Kev',42),('Getaway Sally',73)])
    for off,v in [(0x60,30),(0x64,30),(0x68,15),(0x6c,15)]:store(u,combo+off,v)
    store(u,combo+0xac,0x12345678) # Private schema state belongs only to source.
    skin_list=sources[4];entries=MEM+0x55000;specs=MEM+0x56000
    def list_entries(items):
        for off,v in [(0x90,entries),(0x94,entries+20*len(items)),(0x98,entries+20*len(items)),(0xb0,specs),(0xb4,specs+2*len(items)),(0xb8,specs+2*len(items))]:store(u,skin_list+off,v)
        for i,(label,index) in enumerate(items):store(u,entries+20*i,index);wide_vector(entries+20*i+4,label,MEM+0x57000+i*0x200)
        u.mem_write(specs,struct.pack('<'+'h'*len(items),*range(len(items))))
    list_entries([('Autotronic',573),('Doppler',415),('Tiger Tooth',409)])
    store(u,skin_list+0x60,18);store(u,skin_list+0x64,skin_list+0x84);store(u,skin_list+0x2c,300);store(u,skin_list+0x34,300)
    u.mem_write(skin_list+0x7c,b'\1')
    textbox=sources[5];store(u,textbox+0x64,5);u.mem_write(textbox+0x68,'Knife\0'.encode('utf-16le'))
    floats(u,0x4346d490,1);store(u,0x43468f64,40);store(u,0x43468d44,60);store(u,0x43467be8,360)
    allocations=[];frees=[];callbacks=[];row_events=[];rects=[];draws=[]
    def allocate(n):
        p=0x500000+len(allocations)*0x1000;assert n<0x1000
        allocations.append((p,n));u.mem_write(p,bytes(0x1000));return p
    def insert(parent,item):
        end=word(u,parent+0x84);store(u,end,item);store(u,parent+0x84,end+4)
        u.mem_write(item+0x20,struct.pack('<ii',20,18+32*((end-word(u,parent+0x80))//4)))
    def mock(u,a,size,user):
        if a==0x433837d0:
            sp=u.reg_read(UC_X86_REG_ESP);frees.append(u.reg_read(UC_X86_REG_ECX));u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+4);return
        if not API<=a<API+0x1000:return
        sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);this=u.reg_read(UC_X86_REG_ECX);cleanup=4;result=0
        if a==API+0x100:result=allocate(this)
        elif a in [API+0x140,API+0x180]:
            parent,nm,value=[word(u,sp+k) for k in [4,8,12]];kind=3 if a==API+0x140 else 4
            store(u,this,check_vt if kind==3 else cb_vt);store(u,this+0x10,parent);store(u,this+0x5c,value);u.mem_write(this+0x19,bytes([kind]))
            store(u,this+0x28,190);store(u,this+0x2c,35);store(u,this+0x30,190);store(u,this+0x34,35)
            u.mem_write(value,b'\0' if kind==3 else bytes(4));cleanup=16 if kind==3 else 20;result=this
        elif a==API+0x220:assert word(u,sp+4)==0;insert(this,word(u,sp+8));cleanup=12
        elif a==API+0x300: # Native listbox constructor boundary.
            parent,nm,w,h,value,search=[word(u,sp+k) for k in [4,8,12,16,20,24]]
            assert w==190 and h==300 and search==1
            store(u,this,list_vt);store(u,this+0x10,parent);store(u,this+0x5c,value);u.mem_write(this+0x19,b'\6')
            store(u,this+0x28,w);store(u,this+0x2c,h);store(u,this+0x30,w);store(u,this+0x34,h)
            store(u,this+0x60,18);store(u,this+0x64,this+0x84);u.mem_write(this+0x7c,b'\1');store(u,value,0)
            cleanup=28;result=this
        elif a==API+0x320:
            store(u,this,text_vt);store(u,this+0x10,word(u,sp+4));u.mem_write(this+0x19,b'\x0a');cleanup=8;result=this
        elif a==API+0x500:callbacks.append(('config',this))
        elif a==API+0x520:callbacks.append(('value',this))
        elif a==API+0x700:
            assert this==combo and word(u,this+0xac)==0x12345678
            row_events.append([word(u,sp+4*k) for k in range(1,7)]);cleanup=28
        elif a==API+0x720:draws.append(this);cleanup=12
        elif a==API+0x740:rects.append([word(u,sp+4*k) for k in range(1,6)]);cleanup=24
        else:assert a in [API+0x460,API+0x480,API+0x560],hex(a)
        u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,mock)
    for i in range(12):store(u,api+4*i,API+0x100+0x20*i)
    call(u,exp('skins_setup_probe'),[ctx,api,API+0x560,pane_ptrs,API+0x460,API+0x480,API+0x300,API+0x320])
    assert call(u,exp('skins_rebuild_probe'))==1
    assert call(u,exp('skins_status_probe'))==6
    def proxy(panel,index=0):
        child=word(u,pane_ptrs+4*panel);return word(u,word(u,child+0x80)+4*index)
    out_combo=proxy(0);out_list=proxy(1,2);out_text=proxy(1,3)
    assert word(u,values)==1 and word(u,values+16)==42 and word(u,values+64)==415
    assert word(u,out_combo+0x78)==1 and word(u,out_list+0x88)==1
    assert bytes(u.mem_read(out_text+0x64,132))==bytes(u.mem_read(textbox+0x64,132))
    assert word(u,out_list+0x90)!=entries and word(u,word(u,out_list+0x90)+4)!=word(u,entries+4)
    assert word(u,out_combo+0x7c)!=vars_ and word(u,word(u,out_combo+0x7c))!=word(u,vars_)
    assert not callbacks
    cases=1
    # Real Listbox DPI handler must scale canonical dimensions once. The same
    # list and selected paint survive shrinking, enlargement, and restoration.
    floats(u,0x43470430,18)
    for dpi in [1.5,.75,2.,1.]:
        floats(u,0x4346d490,dpi);store(u,menu+0x14,int(660*dpi));store(u,menu+0x18,int(640*dpi))
        call(u,exp('skins_update_probe'));out_list=proxy(1,2)
        base=[word(u,out_list+off) for off in [0x30,0x34]]
        call(u,0x4339e4df,ecx=out_list)
        actual=[word(u,out_list+off) for off in [0x28,0x2c]]
        assert all(abs(a-b*dpi)<=2 for a,b in zip(actual,base))
        assert word(u,values+64)==415 and not callbacks
        cases+=1
    call(u,exp('skins_update_probe'));out_list=proxy(1,2)
    # Original callback chain and native cache after selecting a paint kit.
    store(u,values+64,409);call(u,exp('skins_change_probe'),[4]);assert callbacks==[('config',skin_list),('value',skin_list)];callbacks.clear();cases+=1
    # The closed and opened rows call the original derived renderer on its real receiver.
    renderer,pos=MEM+0x70000,MEM+0x71000;store(u,renderer,MEM+0x72000);store(u,MEM+0x72000+16,API+0x740)
    store(u,pos,123);store(u,pos+4,456)
    for index in range(3):
        call(u,exp('skins_row_probe'),[renderer,pos,30,index,0xffabcdef,1],out_combo)
        assert row_events[-1]==[renderer,pos,30,index,0xffabcdef,1];assert u.reg_read(UC_X86_REG_ESP)==SP+28;cases+=1
    # List marker rendering respects filtered indices and search row, never source rows.
    call(u,exp('skins_list_draw_probe'),[renderer,pos],out_list);assert draws==[out_list] and len(rects)==3
    assert all(r[4]==0xff4b4beb for r in rects) # These are knife finishes, including the selected one.
    cases+=1
    # Textbox forwards its native local buffer to the source callback.
    store(u,out_text+0x64,3);u.mem_write(out_text+0x68,'AWP\0'.encode('utf-16le'))
    call(u,exp('skins_change_probe'),[5]);assert word(u,textbox+0x64)==3 and wide(u,textbox+0x68)=='AWP'
    assert callbacks==[('config',textbox),('value',textbox)];callbacks.clear();cases+=1
    # External name tag/config change updates existing view without reconstructing it.
    store(u,textbox+0x64,4);u.mem_write(textbox+0x68,'Test\0'.encode('utf-16le'))
    count=len(allocations);call(u,exp('skins_update_probe'));assert wide(u,out_text+0x68)=='Test';assert len(allocations)==count;cases+=1
    # Weapon switches can rebind value pointers and replace contents in-place.
    for n in range(8):
        combo_vars([('Default',0),('Little Kev',42),('Getaway Sally',73),('Number K '+str(n),81)])
        list_entries([('Autotronic',573),('Doppler',415),('Tiger Tooth '+str(n),409)])
        replacement=values+128+16*n;store(u,replacement,1);store(u,sources[2]+0x5c,replacement)
        call(u,exp('skins_update_probe'));assert call(u,exp('skins_status_probe'))==6
        assert word(u,values+16)==42 and word(u,values+64)==409 and word(u,replacement)==1
        assert not callbacks;cases+=1
    # Filter-by-weapon may replace only the displayed-index map.
    store(u,skin_list+0xb4,specs+4);u.mem_write(specs,struct.pack('<hh',2,0))
    call(u,exp('skins_update_probe'));out_list=proxy(1,2)
    assert word(u,out_list+0xb4)-word(u,out_list+0xb0)==4
    assert bytes(u.mem_read(word(u,out_list+0xb0),4))==struct.pack('<hh',2,0);cases+=1
    # Even a queued click is rejected if its original object was deleted by Lua.
    # This separate label lives in an unmapped page after the source list shrinks.
    extra=0x410000;u.mem_map(extra,0x1000);store(u,extra,src_vt);u.mem_write(extra+0x19,b'\3');store(u,extra+0x5c,values+300);name(extra,'Extra')
    store(u,welems+16,extra);store(u,weapon_child+0x84,welems+20)
    call(u,exp('skins_update_probe'));assert call(u,exp('skins_status_probe'))==7
    store(u,weapon_child+0x84,welems+16);u.mem_unmap(extra,0x1000)
    call(u,exp('skins_change_probe'),[6]);assert call(u,exp('skins_status_probe'))==0xffffffff;assert not callbacks
    call(u,exp('skins_update_probe'));assert call(u,exp('skins_status_probe'))==6;cases+=1
    # Russian localized names and multiple grades through the compiled x86
    # drawing path. Selected rows retain the grade, not an accent-green marker.
    list_entries([('История о драконе',344),('Элитное снаряжение',422),('Синий глянец',226),('Красная линия',282),('Кровавая паутина',12)])
    call(u,exp('skins_update_probe'));out_list=proxy(1,2);rects.clear();draws.clear()
    call(u,exp('skins_list_draw_probe'),[renderer,pos],out_list)
    assert [r[4] for r in rects]==[0xff4b4beb,0xffff694b,0xffff4788,0xffe62cd3,0xff808080],rects
    cases+=1
    assert frees # Real native destructors released the proxy-owned vectors/objects.
    assert bytes(u.mem_read(model_child+0x15,1))==b'\0' and bytes(u.mem_read(weapon_child+0x15,1))==b'\0'
    # Read the real source models after the production adapter rebuilt them.
    spec_out,on=MEM+0x73000,MEM+0x74000
    list_entries([('Autotronic',573),('Doppler',415),('Tiger Tooth',409)]);store(u,values+64,409)
    name(combo,'Knife changer');combo_vars([('Default',0),('Butterfly Knife',515)]);store(u,values+16,515)
    call(u,exp('skins_update_probe'))
    assert call(u,exp('skin_mirror_selection_probe'),[spec_out,on])==1
    assert word(u,spec_out)==515 and word(u,spec_out+4)==409 and word(u,on)==1, (word(u,spec_out),word(u,spec_out+4),word(u,on))
    assert bytes(u.mem_read(spec_out+20,5))==b'Test\0';cases+=1
    # Main Weapon skin callback captures selection without opening Local inventory
    # or constructing any sync controls. Re-selecting this weapon updates one preset.
    call(u,exp('skin_mirror_connect_probe'))
    call(u,exp('skins_change_probe'),[4])
    assert callbacks==[('config',skin_list),('value',skin_list)];callbacks.clear()
    assert call(u,exp('skin_mirror_pending_probe'),[515])==409
    store(u,values+64,415);call(u,exp('skins_change_probe'),[4]);callbacks.clear()
    assert call(u,exp('skin_mirror_pending_probe'),[515])==415
    assert call(u,exp('skin_mirror_preset_count_probe'))==1;cases+=1
    store(u,values+64,409)

    # An ambiguous weapon context is rejected instead of fabricating a knife.
    combo_vars([('Default',0)]);store(u,values+16,0);call(u,exp('skins_update_probe'))
    assert call(u,exp('skin_mirror_selection_probe'),[spec_out,on])==0;cases+=1
    # A unique finish identifies an ordinary weapon without touching selectors.
    list_entries([('Dragon Lore',344)]);store(u,values+64,344);call(u,exp('skins_update_probe'))
    assert call(u,exp('skin_mirror_selection_probe'),[spec_out,on])==1 and word(u,spec_out)==9;cases+=1
    # Packed row keys disambiguate finishes without consulting a model guess.
    list_entries([('Redline',(7<<16)|282)]);store(u,values+64,(7<<16)|282);call(u,exp('skins_update_probe'))
    assert call(u,exp('skin_mirror_selection_probe'),[spec_out,on])==1 and word(u,spec_out)==7 and word(u,spec_out+4)==282;cases+=1
    list_entries([('Dragon Lore',(344<<16)|9)]);store(u,values+64,(344<<16)|9);call(u,exp('skins_update_probe'))
    assert call(u,exp('skin_mirror_selection_probe'),[spec_out,on])==1 and word(u,spec_out)==9 and word(u,spec_out+4)==344;cases+=1
    return cases
