#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cwchar>
namespace cs2_visuals {
enum Category {Enemy,Team,World,View,Danger,category_count};
enum Panel {EnemyESP,EnemyModels,TeamESP,TeamModels,OtherESP,WorldModels,Effects,ViewPanel,HUD,DangerItems,panel_count};
inline constexpr const wchar_t* titles[]={L"Enemy ESP",L"Enemy models",L"Team ESP (shared)",L"Team models",L"Other ESP",L"Colored models",L"Effects",L"View",L"HUD",L"Danger Zone items"};
inline constexpr int categories[]={Enemy,Enemy,Team,Team,World,World,World,View,View,Danger};
using Mask=std::uint32_t;
inline constexpr Mask bit(int p){return Mask(1)<<p;}
inline bool eq(const wchar_t* a,const wchar_t* b){return std::wcscmp(a,b)==0;}
inline bool has(const wchar_t* a,const wchar_t* b){return std::wcsstr(a,b)!=nullptr;}
inline Mask route(const wchar_t* group,const wchar_t* name,bool misc=false) {
    if(misc) {
        if(eq(name,L"Override FOV")||eq(name,L"Override zoom FOV")||eq(name,L"Free look"))return bit(ViewPanel);
        if(eq(name,L"Persistent kill feed"))return bit(HUD);
        return 0;
    }
    if(eq(group,L"Player ESP")||eq(group,L"Enemy ESP")) {
        if(eq(name,L"Teammates"))return bit(TeamESP);
        if(eq(name,L"Glow"))return bit(EnemyModels)|bit(TeamModels);
        if(eq(name,L"Hit marker")||eq(name,L"Hit marker sound"))return bit(HUD);
        return bit(EnemyESP)|bit(TeamESP);
    }
    if(eq(group,L"Colored models")) {
        if(has(name,L"Teammate"))return bit(TeamModels);
        if(eq(name,L"Shadow"))return bit(EnemyModels)|bit(WorldModels);
        if(eq(name,L"Player")||eq(name,L"Player behind wall")||eq(name,L"On shot"))return bit(EnemyModels);
        if(has(name,L"Local player")||eq(name,L"Hands")||eq(name,L"Weapon viewmodel"))return bit(ViewPanel);
        return bit(WorldModels);
    }
    if(eq(group,L"Other ESP")) {
        if(eq(name,L"Radar")||eq(name,L"Crosshair")||eq(name,L"Penetration reticle")||
           eq(name,L"Recoil overlay")||eq(name,L"Inaccuracy overlay")||eq(name,L"Spectators")||
           eq(name,L"Feature indicators"))return bit(HUD);
        return bit(OtherESP);
    }
    if(eq(group,L"Effects")) {
        if(has(name,L"Force third person")||eq(name,L"Visual recoil adjustment")||eq(name,L"Instant scope"))return bit(ViewPanel);
        if(eq(name,L"Remove scope overlay"))return bit(HUD);
        if(eq(name,L"Bullet tracers"))return bit(Effects)|bit(EnemyESP);
        return bit(Effects);
    }
    if(has(group,L"Danger Zone"))return bit(DangerItems);
    return bit(OtherESP);
}
inline const wchar_t* caption(const wchar_t* name) {
    if(eq(name,L"Player behind wall"))return L"Player through walls";
    if(eq(name,L"Teammate behind wall"))return L"Teammate through walls";
    if(eq(name,L"Out of FOV arrow"))return L"Off-screen arrow";
    if(eq(name,L"Penetration reticle"))return L"Penetration crosshair";
    return name;
}
inline int rank(int panel,const wchar_t* name) {
    constexpr const wchar_t* player[]={L"Activation type",L"Enabled",L"Bounding box",L"Health bar",L"Name",L"Dormant",L"Teammates",L"Flags",L"Skeleton",L"Weapon icon",L"Weapon text",L"Ammo",L"Distance",L"Out of FOV arrow",L"Visualize aimbot",L"Bullet tracers"};
    constexpr const wchar_t* models[]={L"Player",L"Player behind wall",L"Teammate",L"Teammate behind wall",L"Glow",L"Shadow",L"On shot"};
    constexpr const wchar_t* world[]={L"Dropped weapons",L"Grenades",L"Bomb",L"Grenade trajectory",L"Grenade trajectory (hit)",L"Grenade proximity warning",L"Hostages"};
    constexpr const wchar_t* world_models[]={L"Ragdolls",L"Weapons",L"Disable model occlusion",L"Shadow",L"Props"};
    constexpr const wchar_t* effects[]={L"Remove flashbang effects",L"Remove smoke grenades",L"Remove fog",L"Remove skybox",L"Transparent walls",L"Transparent props",L"Brightness adjustment",L"Disable post processing",L"Disable rendering of teammates",L"Disable rendering of ragdolls",L"Bullet tracers"};
    constexpr const wchar_t* view[]={L"Force third person (alive)",L"Force third person (dead)",L"Override FOV",L"Override zoom FOV",L"Instant scope",L"Visual recoil adjustment",L"Local player",L"Local player fake",L"Local player transparency",L"Hands",L"Weapon viewmodel",L"Free look"};
    constexpr const wchar_t* hud[]={L"Feature indicators",L"Spectators",L"Remove scope overlay",L"Inaccuracy overlay",L"Recoil overlay",L"Penetration reticle",L"Crosshair",L"Persistent kill feed",L"Hit marker",L"Hit marker sound",L"Radar"};
    const wchar_t* const* order=nullptr;unsigned count=0;
    switch(panel) {
    case EnemyESP:case TeamESP:order=player;count=std::size(player);break;
    case EnemyModels:case TeamModels:order=models;count=std::size(models);break;
    case OtherESP:order=world;count=std::size(world);break;
    case WorldModels:order=world_models;count=std::size(world_models);break;
    case Effects:order=effects;count=std::size(effects);break;
    case ViewPanel:order=view;count=std::size(view);break;
    case HUD:order=hud;count=std::size(hud);break;
    }
    for(unsigned i=0;i<count;i++)if(eq(name,order[i]))return int(i);
    return 1000;
}
struct Rect {int x=0,y=0,w=0,h=0;bool operator==(Rect b)const{return x==b.x&&y==b.y&&w==b.w&&h==b.h;}};
struct Layout {Rect category;std::array<Rect,panel_count> panels;std::array<Rect,category_count> icons;};
inline Layout layout(int width,int height,float scale=1) {
    scale=std::clamp(scale,.5f,3.f);
    const auto s=[&](int v){return std::max(1,int(v*scale+.5f));};
    const int left=s(100),right=s(25),gap=s(22),top=s(25),bar=s(58),body=s(22),bottom=s(25);
    const int full=std::max(s(240),width-left-right),col=(full-gap)/2;
    const int y=top+bar+body,h=std::max(s(120),height-y-bottom);
    const Rect a{left,y,col,h},b{left+col+gap,y,full-col-gap,h};
    Layout out{};out.category={left,top,full,bar};
    for(int p=0;p<panel_count;p++)out.panels[p]=(p==EnemyModels||p==TeamModels||p==HUD||p==WorldModels||p==Effects)?b:a;
    const int first=(h-s(14))/2;
    out.panels[WorldModels].h=first;
    out.panels[Effects].y=y+first+s(14);out.panels[Effects].h=h-first-s(14);
    const int step=std::min(s(74),(full-s(36))/category_count);
    for(int i=0;i<category_count;i++)out.icons[i]={left+s(18)+step*i,top+s(11),std::min(s(48),step),s(36)};
    return out;
}
struct Color {unsigned char r,g,b,a=255;unsigned pack()const{return r|(unsigned(g)<<8)|(unsigned(b)<<16)|(unsigned(a)<<24);}};
enum Kind {Fill,Line,Text};
struct Command {Kind kind;Rect r;Color color;const wchar_t* text=nullptr;};
struct Scene {
    std::array<Command,1024> commands{};unsigned count=0;
    void fill(Rect r,Color c){if(r.w>0&&r.h>0&&count<commands.size())commands[count++]={Fill,r,c};}
    void line(int x,int y,int x2,int y2,Color c){if(count<commands.size())commands[count++]={Line,{x,y,x2,y2},c};}
    void text(int x,int y,const wchar_t* t,Color c){if(count<commands.size())commands[count++]={Text,{x,y,0,0},c,t};}
    void disc(int x,int y,int radius,Color c){for(int n=-radius;n<=radius;n++){int half=int(std::sqrt(float(radius*radius-n*n)));fill({x-half,y+n,2*half+1,1},c);}}
};
inline void icon(Scene& s,int category,Rect r,Color c,float scale=1) {
    const auto n=[&](int v){return int(v*scale+.5f);};
    int x=r.x+r.w/2,y=r.y+r.h/2;
    if(category==Enemy||category==Team) {
        s.disc(x-n(4),y-n(8),n(5),c);
        s.fill({x-n(11),y+n(1),n(14),n(12)},c);s.disc(x-n(4),y+n(2),n(7),c);
        if(category==Team){s.fill({x+n(6),y+n(2),n(3),n(12)},c);s.fill({x+n(2),y+n(6),n(11),n(3)},c);}
        else {
            const int cx=x+n(8),cy=y+n(8),ra=n(6);
            for(int i=0;i<28;i++){float a=i*6.2831853f/28,b=(i+1)*6.2831853f/28;s.line(cx+int(ra*std::cos(a)),cy+int(ra*std::sin(a)),cx+int(ra*std::cos(b)),cy+int(ra*std::sin(b)),c);}
            s.line(cx-n(4),cy-n(4),cx+n(4),cy+n(4),c);
        }
    } else if(category==World) {
        const int ra=n(12);
        for(int i=0;i<40;i++){float a=i*6.2831853f/40,b=(i+1)*6.2831853f/40;s.line(x+int(ra*std::cos(a)),y+int(ra*std::sin(a)),x+int(ra*std::cos(b)),y+int(ra*std::sin(b)),c);}
        s.fill({x-n(7),y-n(9),n(8),n(6)},c);s.fill({x-n(10),y-n(3),n(5),n(6)},c);
        s.fill({x-n(2),y+n(3),n(6),n(9)},c);s.fill({x+n(3),y-n(3),n(8),n(5)},c);
    } else if(category==View) {
        const int rx=n(15),ry=n(8);
        for(int i=0;i<36;i++){float a=i*6.2831853f/36,b=(i+1)*6.2831853f/36;s.line(x+int(rx*std::cos(a)),y+int(ry*std::sin(a)),x+int(rx*std::cos(b)),y+int(ry*std::sin(b)),c);}
        s.disc(x,y,n(5),c);s.disc(x,y,n(2),{23,23,23,255});
    } else {s.disc(x-n(1),y+n(2),n(10),c);s.disc(x+n(9),y-n(9),n(4),c);s.disc(x-n(3),y,n(6),{23,23,23,255});}
}
inline void category_scene(Scene& scene,Rect bar,const std::array<Rect,category_count>& buttons,int active,int count,float scale,float alpha) {
    const int title_space=std::max(1,int(10*scale));
    scene.count=0;scene.fill({bar.x+1,bar.y+title_space,bar.w-2,bar.h-title_space-1},{23,23,23,255});
    for(int i=0;i<count;i++)icon(scene,i,buttons[i],i==active?Color{216,216,216,255}:Color{86,86,86,255},scale);
    alpha=std::clamp(alpha,0.f,1.f);
    for(unsigned i=0;i<scene.count;i++)scene.commands[i].color.a=static_cast<unsigned char>(scene.commands[i].color.a*alpha);
}
}
