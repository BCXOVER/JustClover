#!/usr/bin/env python3
"""Compiled eligibility gate + original native selector/getter/apply-prefix.
Engine index lookup, snapshot reset, memcpy and scalar trig are restricted mocks.
No DLL startup, Windows process or game is executed.
"""
from pathlib import Path
import json,struct,subprocess,os,sys,itertools,random,hashlib
import pefile
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
from record_fixture import *
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']=str(ROOT/'.cache/global');env['ZIG_LOCAL_CACHE_DIR']=str(ROOT/'.cache/local')
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++17','-O2','-shared',
               str(ROOT/'tests/record_probe.cpp'),'-o',str(BUILD/'record_probe.dll')],env=env,check=True)
pe=pefile.PE(str(BUILD/'record_probe.dll'));probe_base=pe.OPTIONAL_HEADER.ImageBase
probe=probe_base+next(s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name and 'eligibility_probe' in s.name.decode())
plan_tool=BUILD/'record_plan'
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/record_plan.cpp'),'-o',str(plan_tool)],check=True)
def load_probe(u):u.mem_map(probe_base,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(probe_base,pe.get_memory_mapped_image())
def gate(u,tick,history=HISTORY):
    store(u,SP,STOP);u.reg_write(UC_X86_REG_ESP,SP)
    u.reg_write(UC_X86_REG_ECX,history);u.reg_write(UC_X86_REG_EDX,tick&0xffffffff)
    run_until(u,probe,STOP)
    assert u.reg_read(UC_X86_REG_ESP)==SP+4
    return bool(u.reg_read(UC_X86_REG_EAX))
def patched(location,plan,mode=1,**kwargs):
    u=fixture(**kwargs);load_probe(u);u.mem_map(location,4096)
    u.mem_write(location,plan[:128]);u.mem_write(0x433983c1,plan[128:133]);u.mem_write(0x43398505,plan[133:138])
    store(u,0x23b00c,mode)
    return u

eligibility_cases=native_cases=mode_capture_cases=0
u=fixture();load_probe(u)
for count,head in itertools.product([1,2,8,32],[0,1,17,31,0xffffffff]):
    store(u,HISTORY+0x5d4,head);store(u,HISTORY+0x5d8,count)
    for i in range(count):
        address=0x280000+i*0x1200
        store(u,HISTORY+0x5dc+((head+i)&31)*4,address)
        store(u,address+0x4c,100-i*2);store(u,address+0x5c,4)
        floats(u,address+0x30,100-i,0,0);floats(u,address+0x28,0)
    for tick in range(100-count*2-2,104):
        expected=tick in [100-i*2 for i in range(count)]
        assert gate(u,tick)==expected,(count,head,tick,expected)
        eligibility_cases+=1

mutations=[
    ('empty',lambda u:store(u,HISTORY+0x5d8,0),94,False),
    ('oversized',lambda u:store(u,HISTORY+0x5d8,33),94,False),
    ('null',lambda u:store(u,HISTORY+0x5dc,0),94,False),
    ('invalid bones',lambda u:store(u,OLD+0x5c,0),94,False),
    ('boundary marker',lambda u:store(u,NEW+0x5c,0x204),94,False),
    ('exact boundary marker',lambda u:store(u,NEW+0x5c,0x204),100,True),
    ('origin jump',lambda u:floats(u,HISTORY+0x13c,165,0,0),100,False),
    ('origin exactly 64',lambda u:floats(u,HISTORY+0x13c,164,0,0),100,True),
    ('history jump',lambda u:floats(u,OLD+0x30,35,0,0),94,False),
    ('nonfinite current',lambda u:floats(u,HISTORY+0x13c,float('nan'),0,0),94,False),
    ('nonfinite record',lambda u:floats(u,OLD+0x30,float('inf'),0,0),94,False),
    ('nonfinite yaw',lambda u:floats(u,OLD+0x28,float('nan')),94,False),
    ('duplicate ticks',lambda u:store(u,OLD+0x4c,100),100,True),
]
for label,mutation,tick,expected in mutations:
    u=fixture();load_probe(u);mutation(u)
    assert gate(u,tick)==expected,label;eligibility_cases+=1
assert not gate(u,94,0);eligibility_cases+=1
# Selected-prefix ordering, including equal ticks that the native getter permits.
u=fixture();load_probe(u);store(u,HISTORY+0x5d8,3)
third=0x274000;store(u,HISTORY+0x5e4,third);store(u,third+0x4c,90);store(u,third+0x5c,4)
floats(u,third+0x30,90,0,0);floats(u,third+0x28,0)
store(u,OLD+0x4c,101)
assert not gate(u,90);eligibility_cases+=1

proof={'requested_tick':98}
baseline=fixture()
proof['native_getter']=list(get_pose(baseline,98));proof['native_applied_copy']=list(get_applied_copy(baseline,98))
assert proof['native_getter']==[98,98.,98.] and proof['native_applied_copy']==[94,94.]

for location in [0x50000000,0x60000000,0xf0000000]:
    path=BUILD/f'record_plan_{location:x}.bin'
    subprocess.run([str(plan_tool),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(path),hex(location),hex(probe)],check=True)
    plan=path.read_bytes();assert len(plan)==138
    for gap in [1,2,4,6,10,16]:
        low=100-gap
        for mode,bone in itertools.product([0,1],[0,3]):
            u=patched(location,plan,mode,old_tick=low,old_x=low)
            chosen,score=select_pose(u,low,100,bone)
            if mode:assert chosen in [low,100],(gap,mode,bone,chosen)
            else:
                original=fixture(old_tick=low,old_x=low)
                expected,expected_score=select_pose(original,low,100,bone)
                assert (chosen,score)==(expected,expected_score)
            if mode:
                tick,pos,bone_x=get_pose(u,chosen)
                applied_tick,applied_pos=get_applied_copy(u,chosen)
                assert chosen==tick==applied_tick and abs(pos-applied_pos)<1e-6 and abs(pos-bone_x)<1e-6
            native_cases+=1
    # The fixture prefers synthetic tick 98. The patched selector must choose
    # an eligible real record and keep its point, matrix and applied copy aligned.
    u=patched(location,plan,1)
    chosen,score=select_pose(u)
    assert chosen==100,(chosen,score)
    proof['patched_selected_tick']=chosen
    proof['patched_applied_copy']=list(get_applied_copy(u,chosen))
    # Rejecting a newest record without bones must allow a valid older record.
    u=patched(location,plan,1);store(u,NEW+0x5c,0)
    chosen,_=select_pose(u);assert chosen==94;native_cases+=1
    # No widening of the selector's supplied timing range.
    for low,high in [(95,99),(94,94),(100,100),(90,94),(101,105)]:
        u=patched(location,plan,1);chosen,_=select_pose(u,low,high)
        allowed=[t for t in [94,100] if low<=t<=high]
        assert chosen in allowed if allowed else chosen==0xffffffff,(low,high,chosen)
        native_cases+=1
    for mode in [0,1]:
        u=patched(location,plan,mode);calls=[]
        def change_mode(u,address,size,user):
            if address==(probe if mode else 0x433eedff):
                calls.append(u.reg_read(UC_X86_REG_EDX));store(u,0x23b00c,1-mode)
        h=u.hook_add(UC_HOOK_CODE,change_mode)
        chosen,_=select_pose(u);u.hook_del(h)
        assert chosen==(100 if mode else 98),(mode,chosen,calls)
        assert len(calls)==7
        mode_capture_cases+=1

# Installation does not touch the existing clock/window functions or the
# getter/application code; only the selector's frame and call site change.
report={'passed':True,'eligibility_cases':eligibility_cases,'native_selector_cases':native_cases,
        'captured_mode_cases':mode_capture_cases,'mismatch_reproduction':proof,
        'core_sha256':hashlib.sha256(IMAGE).hexdigest(),
        'scope':'Compiled Windows x86 read-only gate with original selector, getter and pre-application copy. Restricted index/reset/memcpy/trig mocks; no protected startup or game.',
        'game_tested':False,'real_network_ping_tested':False}
(BUILD/'record_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
