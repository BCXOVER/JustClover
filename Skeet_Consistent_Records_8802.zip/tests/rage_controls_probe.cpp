#include "../source/skeet/rage_patch_controls.h"
extern "C" __declspec(dllexport) int attach_probe(void* child,rage_controls::Api* api,
                                                int** states,void** out) {
    return rage_controls::attach(child,*api,states,out)?1:0;
}
