#include "../source/skeet/record_eligibility.h"
extern "C" __declspec(dllexport) int __fastcall eligibility_probe(const void* history,std::int32_t tick) {
    return record_eligibility::eligible(history,tick)?1:0;
}
