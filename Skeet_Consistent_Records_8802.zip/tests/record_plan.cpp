#include "../source/skeet/record_patch.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>
int main(int argc,char** argv) {
    if(argc!=5)return 2;
    std::ifstream input(argv[1],std::ios::binary);
    std::vector<std::uint8_t> image((std::istreambuf_iterator<char>(input)),{});
    if(!scan_patch::matches_original(image.data(),image.size()))return 3;
    const auto address=std::uint32_t(std::stoul(argv[3],nullptr,0));
    const auto check=std::uint32_t(std::stoul(argv[4],nullptr,0));
    record_patch::Plan plan{};
    if(!record_patch::make_plan(image.data(),image.size(),address,0x23b00c,check,plan))return 4;
    for(const auto offset:{record_patch::selector_setup,record_patch::getter_call}) {
        image[offset]^=1;record_patch::Plan invalid{};
        if(record_patch::make_plan(image.data(),image.size(),address,0x23b00c,check,invalid))return 5;
        image[offset]^=1;
    }
    static_assert(sizeof(plan)==138);
    std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<const char*>(&plan),sizeof(plan));
    std::cout<<"Record selector plan and 2 incompatible-site rejections passed.\n";
}
