#pragma once
#include <cstddef>
#include <cstdint>
namespace rage_patch_menu {
bool prepare(std::uint8_t* image,std::size_t size);
bool attach();
}
