#pragma once
#include "scan_patch.h"
#include "record_eligibility.h"
namespace record_patch {
inline volatile int enabled=1;
inline constexpr std::uint32_t selector_setup=0x883c1,getter_call=0x88505;
inline constexpr std::uint8_t setup_before[]={0x83,0xec,0x58,0x56,0x57};
inline constexpr std::uint8_t call_before[]={0xe8,0xf5,0x68,0x05,0};
struct Plan {std::uint8_t code[128]{},setup[5]{},call[5]{};};
inline bool make_plan(const std::uint8_t* image,std::size_t size,std::uint32_t code_address,
                      std::uint32_t state_address,std::uint32_t check_address,Plan& p) {
    if(!image||size!=scan_patch::image_size||
        std::memcmp(image+selector_setup,setup_before,5)||std::memcmp(image+getter_call,call_before,5))return false;
    p=Plan{};
    constexpr std::uint8_t setup[]={0x83,0xec,0x68,0x56,0x57,0xa1,0,0,0,0,0x89,0x44,0x24,0x60,0xe9,0,0,0,0};
    std::memcpy(p.code,setup,sizeof(setup));
    scan_patch::put32(p.code+6,state_address);
    scan_patch::put32(p.code+15,scan_patch::image_base+selector_setup+5-(code_address+19));
    // The flag is fixed for one complete selector invocation. Its original
    // matrix buffer ends at ESP+0x60, exactly before the new private flag.
    constexpr std::uint8_t gate[]={
        0x83,0x7c,0x24,0x70,0,0x74,0x15,0x52,0x51,0xe8,0,0,0,0,
        0x59,0x5a,0x84,0xc0,0x75,0x08,0xb8,0xff,0xff,0xff,0xff,0xc2,0x0c,0,
        0xe9,0,0,0,0};
    std::memcpy(p.code+64,gate,sizeof(gate));
    scan_patch::put32(p.code+64+10,check_address-(code_address+64+14));
    scan_patch::put32(p.code+64+29,0x433eedffU-(code_address+64+33));
    p.setup[0]=0xe9;scan_patch::put32(p.setup+1,code_address-(scan_patch::image_base+selector_setup+5));
    p.call[0]=0xe8;scan_patch::put32(p.call+1,code_address+64-(scan_patch::image_base+getter_call+5));
    return true;
}
#ifdef _WIN32
inline bool __fastcall check(const void* history,std::int32_t tick) {
    return record_eligibility::eligible(history,tick);
}
inline bool apply(std::uint8_t* image,std::size_t size) {
    auto* code=static_cast<std::uint8_t*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
    if(!code)return false;
    Plan p{};
    if(reinterpret_cast<std::uintptr_t>(image)!=scan_patch::image_base||!make_plan(image,size,
        static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(code)),
        static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(&enabled)),
        static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(&check)),p)) {
        VirtualFree(code,0,MEM_RELEASE);SetLastError(ERROR_REVISION_MISMATCH);return false;
    }
    std::memcpy(code,p.code,sizeof(p.code));DWORD old=0;
    if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(p.code))) {
        const auto error=GetLastError();VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    std::memcpy(image+selector_setup,p.setup,5);std::memcpy(image+getter_call,p.call,5);
    if(!FlushInstructionCache(GetCurrentProcess(),image,size)) {
        const auto error=GetLastError();
        std::memcpy(image+selector_setup,setup_before,5);std::memcpy(image+getter_call,call_before,5);
        FlushInstructionCache(GetCurrentProcess(),image,size);
        VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    return true;
}
#endif
}
