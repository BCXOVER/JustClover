#include <windows.h>
#include "../source/skeet/crouch_multipoint.h"
extern "C" {
__declspec(dllexport) unsigned mode_probe(){return reinterpret_cast<unsigned>(&hitscan_mode::selected);}
__declspec(dllexport) unsigned gate_probe(){return reinterpret_cast<unsigned>(&crouch_multipoint::enabled);}
__declspec(dllexport) int __fastcall primary_probe(const unsigned char* args,const void* frame,void* out){return crouch_multipoint::primary(args,frame,out);}
__declspec(dllexport) int __fastcall secondary_probe(const unsigned char* args,const void* frame,void* out){return crouch_multipoint::secondary(args,frame,out);}
}
