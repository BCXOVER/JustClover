#include "../source/skeet/hitscan_patch.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <cassert>
#include <iostream>
int main(int argc,char** argv) {
 assert(argc==5);std::ifstream in(argv[1],std::ios::binary);
 std::vector<unsigned char> image((std::istreambuf_iterator<char>(in)),{});
 hitscan_patch::Plan p{};const unsigned lookup=std::stoul(argv[3],nullptr,0),update=std::stoul(argv[4],nullptr,0);
 assert(hitscan_patch::make(image.data(),image.size(),lookup,update,p));
 const unsigned checks[]={0x41a0b,0x444f5,0xb32a9,0xb5cf2,0xfeb67,0x105024,0x5c53b,0xed846,0xd533f,0x419e8,0x444cf,0xb3286,0xb5cd2,0xfeb43,0x104ffc};
 for(auto at:checks){auto bad=image;bad[at]^=1;hitscan_patch::Plan reject{};assert(!hitscan_patch::make(bad.data(),bad.size(),lookup,update,reject));}
 assert(!hitscan_patch::make(image.data(),image.size()-1,lookup,update,p));
 assert(!hitscan_patch::make(image.data(),image.size(),0,update,p));
 assert(!hitscan_patch::make(image.data(),image.size(),lookup,0,p));
 std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<const char*>(&p),sizeof(p));
 std::cout<<"18 exact-site/dependency/argument guards passed\n";
}
