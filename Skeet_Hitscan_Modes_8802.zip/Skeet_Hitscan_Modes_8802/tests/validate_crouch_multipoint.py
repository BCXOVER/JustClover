#!/usr/bin/env python3
"""Actual native pre-scan append and caller fragments with compiled geometry hook.
No original DLL startup or game process is executed. Native record capture and
point/ray preparation are bounded x86 fixtures, not an in-game accuracy test.
"""
from pathlib import Path
import os,sys,struct,json,subprocess,hashlib,math,itertools
import pefile
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
from record_fixture import *
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR','/workspace/skeet-motion-bt-8802/.cache/global')
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++17','-O2','-shared','-Wl,--image-base,0x30000000',str(ROOT/'tests/crouch_multipoint_probe.cpp'),'-o',str(BUILD/'crouch_multipoint_probe.dll')],env=env,check=True)
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/crouch_multipoint_plan.cpp'),'-o',str(BUILD/'crouch_multipoint_plan')],check=True)
PE=pefile.PE(str(BUILD/'crouch_multipoint_probe.dll'));PB=PE.OPTIONAL_HEADER.ImageBase
EXPORTS={s.name.decode():PB+s.address for s in PE.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def ex(name):return next(v for k,v in EXPORTS.items() if name==k or name in k)
VEC=MEM+0x10000;DEST=MEM+0x20000;SOURCE=MEM+0x50000;JOB=MEM+0x40000;FRAME=SP+0x9000;LIVE=MEM+0x70000;CELL=MEM+0x90000
plans={}
class Case:
    def __init__(self,location):
        self.u=u=fixture();self.location=location;self.helper_calls=[]
        u.mem_map(PB,PE.OPTIONAL_HEADER.SizeOfImage);u.mem_write(PB,PE.get_memory_mapped_image());u.mem_map(location,4096)
        # gate_probe consists only of an address return; call it in the fixture.
        store(u,SP,STOP);u.reg_write(UC_X86_REG_ESP,SP);run_until(u,ex('gate_probe'),STOP);self.gate=u.reg_read(UC_X86_REG_EAX)
        if location not in plans:
            f=BUILD/f'crouch_plan_{location:x}.bin';subprocess.run([str(BUILD/'crouch_multipoint_plan'),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(f),hex(location),hex(ex('primary_probe')),hex(ex('secondary_probe')),hex(self.gate)],check=True);plans[location]=f.read_bytes()
        p=plans[location];assert len(p)==522;u.mem_write(location,p[:512])
        for i,site in enumerate([0x4335e8f2,0x4335eebb]):u.mem_write(site,p[512+i*5:517+i*5])
        imports={}
        for lib in getattr(PE,'DIRECTORY_ENTRY_IMPORT',[]):
            for item in lib.imports:
                target=STOP+0x600+len(imports)*16;imports[target]=item.name.decode();store(u,item.address,target)
        def hook(u,a,size,user):
            if a in [ex('primary_probe'),ex('secondary_probe')]:self.helper_calls.append(a)
            if a not in imports:return
            sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);name=imports[a]
            if name in ['memcpy','memmove']:
                dst,src,n=[word(u,sp+i) for i in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)));u.reg_write(UC_X86_REG_EAX,dst)
            else:raise AssertionError(name)
            u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret)
        u.hook_add(UC_HOOK_CODE,hook)
    def point(self,path=0,duck=1,group=2,on=1,source=(110.,40.,70.),center=(100.,20.,50.),center_group=None,valid=True,missing_job=False):
        u=self.u;self.helper_calls.clear();store(u,self.gate,on)
        store(u,VEC,DEST);store(u,VEC+4,DEST);store(u,VEC+8,DEST+1024)
        u.mem_write(JOB,b'\0'*0x1190);store(u,JOB+0x14c,4 if valid else 0);floats(u,JOB+0x12c,duck)
        store(u,FRAME+0x1c,0 if missing_job else JOB)
        self.center=SP+(0x2f4 if path==0 else 0x254)
        for p,xyz,g in [(SOURCE,source,group),(self.center,center,group if center_group is None else center_group)]:
            floats(u,p,*xyz);floats(u,p+12,.73);store(u,p+16,g);store(u,p+20,0xaabbccdd)
        before_source=bytes(u.mem_read(SOURCE,24));before_center=bytes(u.mem_read(self.center,24));before_job=bytes(u.mem_read(JOB,0x1190))
        store(u,SP-8,0x12345678);store(u,SP-4,SOURCE)
        regs=[UC_X86_REG_EAX,UC_X86_REG_EBX,UC_X86_REG_ECX,UC_X86_REG_EDX,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP]
        for i,r in enumerate(regs):u.reg_write(r,0x123400+100*i)
        u.reg_write(UC_X86_REG_ECX,VEC);u.reg_write(UC_X86_REG_EBP,FRAME);u.reg_write(UC_X86_REG_ESP,SP-8);u.reg_write(UC_X86_REG_EFLAGS,0x206)
        for i in range(8):u.reg_write(UC_X86_REG_XMM0+i,0x123456789abcdef00112233445566000+i)
        old={r:u.reg_read(r) for r in regs};site=[0x4335e8f2,0x4335eebb][path]
        run_until(u,site,site+5,100000)
        assert u.reg_read(UC_X86_REG_ESP)==SP
        for r,v in old.items():assert u.reg_read(r)==(DEST+24 if r==UC_X86_REG_EAX else (0 if r==UC_X86_REG_ECX else v)),(r,hex(u.reg_read(r)),hex(v))
        assert u.reg_read(UC_X86_REG_EFLAGS)==0x206
        for i in range(8):assert u.reg_read(UC_X86_REG_XMM0+i)==0x123456789abcdef00112233445566000+i
        assert word(u,VEC+4)==DEST+24
        assert bytes(u.mem_read(SOURCE,24))==before_source and bytes(u.mem_read(self.center,24))==before_center
        assert bytes(u.mem_read(JOB,0x1190))==before_job
        output=bytes(u.mem_read(DEST,24));assert output[12:]==before_source[12:]
        return struct.unpack('<fff',output[:12]),before_source
checks=0;fast=0
for location in [0x10000000,0x50000000,0xf0000000]:
    c=Case(location)
    for path,on,group,duck in itertools.product([0,1],[0,1],range(1,8),[-.01,0,.55,.725,.90,1.,1.01,2.,float('nan'),float('inf')]):
        xyz,source=c.point(path,duck,group,on)
        blend=0 if not math.isfinite(duck) or duck<-.01 or duck>1.01 or duck<=.55 or group>3 else min(1.,(duck-.55)/(.90-.55))
        factor=1-blend*(1-(.88 if group==1 else .82)) if on else 1
        expected=tuple(b+(a-b)*factor for a,b in zip((110,40,70),(100,20,50)))
        assert all(abs(a-b)<2e-5 for a,b in zip(xyz,expected)),(location,path,on,group,duck,xyz,expected)
        if not on or (math.isfinite(duck) and 0<=duck<=.55):assert not c.helper_calls;fast+=1
        checks+=1
    for path in [0,1]:
        for kw in [dict(valid=False),dict(missing_job=True),dict(center_group=3),dict(source=(float('nan'),40,70)),dict(center=(100,float('inf'),50)),dict(source=(100,20,50)),dict(group=0),dict(group=8)]:
            xyz,source=c.point(path=path,**kw);assert c.u.mem_read(DEST,24)==source;checks+=1
        # Native center append call sites are untouched and copy center verbatim.
        c.point(path=path);u=c.u;store(u,VEC+4,DEST)
        store(u,SP-8,0x55);store(u,SP-4,c.center);u.reg_write(UC_X86_REG_ESP,SP-8);u.reg_write(UC_X86_REG_ECX,VEC)
        site=[0x4335e8ca,0x4335ee93][path];run_until(u,site,site+5)
        assert u.mem_read(DEST,24)==u.mem_read(c.center,24);checks+=1
# Gamesense dropdown bypasses crouch geometry even if its checkbox stays ON.
for location in [0x10000000,0x50000000,0xf0000000]:
    c=Case(location);u=c.u;store(u,SP,STOP);u.reg_write(UC_X86_REG_ESP,SP)
    run_until(u,ex('mode_probe'),STOP);mode=u.reg_read(UC_X86_REG_EAX);store(u,mode,0)
    for path in [0,1]:
        xyz,source=c.point(path=path,on=1);assert u.mem_read(DEST,24)==source;checks+=1
    store(u,mode,1)
# Real native duck capture uses the same record offset, independent of live state.
c=Case(0x50000000);u=c.u
for duck in [0,.55,.725,.9,1]:
    c.point();store(u,0x434679f8,CELL);key=0x12344321;store(u,0x434675f8,key);store(u,CELL,0x2f9c^key^0x3309c0cf);floats(u,LIVE+0x2f9c,duck)
    u.reg_write(UC_X86_REG_EBX,JOB+0xf0);u.reg_write(UC_X86_REG_EBP,LIVE)
    run_until(u,0x433fd7f9,0x433fd811)
    assert abs(scalar(u,JOB+0x12c)-duck)<1e-6
    # Live entity can change its crouch; selected lag record stays historical.
    floats(u,LIVE+0x2f9c,1-duck);assert abs(scalar(u,JOB+0x12c)-duck)<1e-6;checks+=1
# Execute native pre-trace ray direction preparation on the contracted vector.
ray_checks=0
for path in [0,1]:
    xyz,_=c.point(path=path);u=c.u;eye=MEM+0x60000;shooter=eye-0xdc
    floats(u,eye,0,0,0);store(u,FRAME+8,shooter);store(u,shooter+0xc,0x999)
    u.reg_write(UC_X86_REG_EDI,DEST);u.reg_write(UC_X86_REG_ESI,eye);u.reg_write(UC_X86_REG_EBP,FRAME);u.reg_write(UC_X86_REG_ESP,SP)
    run_until(u,0x4335efbf,0x4335f066)
    distance=math.sqrt(sum(x*x for x in xyz));native_distance=scalar(u,u.reg_read(UC_X86_REG_ESP)+0x3dc)
    assert abs(native_distance-distance)<2e-5
    ray_checks+=1
report={'passed':True,'native_append_and_geometry_cases':checks,'gamesense_mode_bypass_cases':6,'off_or_standing_fast_path_cases':fast,'native_pre_trace_direction_cases':ray_checks,'hook_placements':3,'native_point_stride':24,'historical_duck_record_offset':'0x3c','source_points_centers_and_records_preserved':True,'all_metadata_bytes_preserved':True,'both_center_append_sites_preserved':True,'sse_flags_registers_stack_preserved':True,'head_scale':.88,'torso_scale':.82,'other_hitgroups_unchanged':True,'crouch_blend_start':.55,'crouch_blend_end':.90,'owned_instruction_bytes':10,'core_sha256':hashlib.sha256(IMAGE).hexdigest(),'game_tested':False,'scope':__doc__}
(BUILD/'crouch_multipoint_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
