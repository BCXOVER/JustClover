#include <windows.h>
#include "../source/skeet/hitscan_runtime.h"
extern "C" {
__declspec(dllexport) unsigned mode_address(){return reinterpret_cast<unsigned>(&hitscan_mode::selected);}
__declspec(dllexport) void choices_probe(void* history,int requested,float interval,int low,int high,void* out) {
    const auto result=hitscan_records::choose(history,requested,interval,low,high);std::memcpy(out,&result,sizeof(result));
}
__declspec(dllexport) int __fastcall lookup_probe(void* shooter,void* actor,int tick,unsigned flags,void* out,unsigned* out_flags){return hitscan_runtime::lookup(shooter,actor,tick,flags,out,out_flags);}
__declspec(dllexport) void __fastcall update_probe(void* update,void* entity){hitscan_runtime::update(update,entity);}
__declspec(dllexport) int client_layout_probe(){return hitscan_runtime::client_layout();}
}
