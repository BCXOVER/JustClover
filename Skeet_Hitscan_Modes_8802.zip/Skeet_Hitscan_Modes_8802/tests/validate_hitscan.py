#!/usr/bin/env python3
"""Bounded x86 fixtures for production record/animation routing.
Executes native record selection/copy/return and its original animation
call dispatcher. Final entity/bone application is stubbed; game startup is not run.
"""
from pathlib import Path
import os,sys,struct,json,subprocess,hashlib,itertools,math
import pefile
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
from record_fixture import *
BUILD=ROOT/'build';env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR','/workspace/skeet-motion-bt-8802/.cache/global')
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++17','-O2','-shared','-Wl,--image-base,0x30000000',str(ROOT/'tests/hitscan_probe.cpp'),'-o',str(BUILD/'hitscan_probe.dll')],env=env,check=True)
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/hitscan_plan.cpp'),'-o',str(BUILD/'hitscan_plan')],check=True)
PE=pefile.PE(str(BUILD/'hitscan_probe.dll'));CLIENT=0x18000000;JOB=MEM+0x40000;LAYERS=MEM+0x80000
SITES=[0x43351a0b,0x433544f5,0x433c32a9,0x433c5cf2,0x4340eb67,0x43415024]
class Machine:
 def __init__(self,base=0x30000000):
  self.u=u=fixture();self.base=base;pe=pefile.PE(str(BUILD/'hitscan_probe.dll'));pe.relocate_image(base)
  u.mem_map(base,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(base,pe.get_memory_mapped_image())
  self.exports={s.name.decode():base+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
  self.imports={};self.regions=[(MEM,0x100000,4),(BASE,len(IMAGE),0x40),(STOP,0x1000,0x40),(base,pe.OPTIONAL_HEADER.SizeOfImage,0x40)]
  for lib in getattr(pe,'DIRECTORY_ENTRY_IMPORT',[]):
   for item in lib.imports:
    a=STOP+0x800+16*len(self.imports);self.imports[a]=item.name.decode();store(u,item.address,a)
  u.hook_add(UC_HOOK_CODE,self.hook);self.native_calls=[];self.fail=set();self.native_frame=None;self.low=94;self.high=104;self.animation=None;self.update_count=0
  self.mode=self.call('mode_address')
  f=BUILD/f'hitscan_plan_{base:x}.bin';subprocess.run([str(BUILD/'hitscan_plan'),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(f),hex(self.ex('lookup_probe')),hex(self.ex('update_probe'))],check=True)
  plan=f.read_bytes();assert len(plan)==30
  for i,site in enumerate(SITES):u.mem_write(site,plan[i*5:(i+1)*5])
 def ex(self,name):return next(v for k,v in self.exports.items() if k==name or name in k)
 def ret(self,value=0,cleanup=0,sp=None):
  u=self.u;sp=u.reg_read(UC_X86_REG_ESP) if sp is None else sp;ret=word(u,sp)
  u.reg_write(UC_X86_REG_EAX,value&0xffffffff);u.reg_write(UC_X86_REG_ESP,sp+4+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
 def hook(self,u,a,size,_):
  sp=u.reg_read(UC_X86_REG_ESP)
  if a in self.imports:
   name=self.imports[a]
   if name=='VirtualQuery':
    ptr,out,n=[word(u,sp+i) for i in [4,8,12]];result=0
    for first,length,protect in self.regions:
     if first<=ptr<first+length:u.mem_write(out,struct.pack('<7I',first,first,protect,length,0x1000,protect,0x20000));result=28;break
    self.ret(result,12)
   elif name=='GetModuleHandleW':self.ret(CLIENT,4)
   elif name in ['memcpy','memmove']:
    dst,src,n=[word(u,sp+i) for i in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)));self.ret(dst)
   elif name=='memset':
    dst,v,n=[word(u,sp+i) for i in [4,8,12]];u.mem_write(dst,bytes([v&255])*n);self.ret(dst)
   else:raise AssertionError(name)
  elif a in [0x4339438e,0x4337ea43]:self.ret(self.low if a==0x4339438e else self.high)
  elif a==0x4336c53b:
   t,flags,out,fl=[word(u,sp+i) for i in [4,8,12,16]];self.native_calls.append(t)
   assert u.reg_read(UC_X86_REG_ECX)==CONTEXT and u.reg_read(UC_X86_REG_EDX)==ACTOR
   if t in self.fail:
    u.mem_write(out,b'\xa5'*0x10a0);store(u,fl,0xdeadbeef);self.ret(0,16);return
   self.native_frame=(sp,{r:u.reg_read(r) for r in [UC_X86_REG_EBX,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP]})
  elif a==0x43327659:
   # Final native entity/bone application is intentionally stubbed. Record
   # selection, copy, timing branches and native success return execute intact.
   assert u.reg_read(UC_X86_REG_ECX)==CONTEXT and u.reg_read(UC_X86_REG_EDX)==ACTOR
   assert word(u,sp+4)==JOB+0xf0  # Real output address survives every retry.
   self.ret(0,4)
  elif a==STOP+0x500:
   assert u.reg_read(UC_X86_REG_ECX)==ACTOR;self.update_count+=1
   if self.animation:self.animation(u)
   self.ret()
 def call(self,name,args=(),ecx=0,edx=0):
  u=self.u;store(u,SP,STOP)
  for i,v in enumerate(args):store(u,SP+4+i*4,v)
  u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,ecx);u.reg_write(UC_X86_REG_EDX,edx)
  run_until(u,self.ex(name),STOP,200000);assert u.reg_read(UC_X86_REG_ESP)==SP+4
  return u.reg_read(UC_X86_REG_EAX)
 def history(self,ticks=(100,98,96),shot=97/64,head=0):
  u=self.u;store(u,HISTORY+0x5d4,head);store(u,HISTORY+0x5d8,len(ticks));floats(u,HISTORY+0x13c,100,0,0)
  records=[]
  for i,t in enumerate(ticks):
   p=NEW+i*0x2000;records.append(p);u.mem_write(p,bytes(0x10a0));store(u,HISTORY+0x5dc+((head+i)&31)*4,p)
   store(u,p+0x4c,t);store(u,p+0x5c,4);floats(u,p+0x30,100-i,0,0);floats(u,p+0x54,shot)
   for bone in range(19):matrix(u,p+0x230+bone*48,100-i)
  return records
 def choices(self,requested=100,interval=1/64):
  self.call('choices_probe',[HISTORY,requested,fbits(interval),self.low,self.high,MEM+0x7f000]);return struct.unpack('<iii',self.u.mem_read(MEM+0x7f000,12))
 def lookup(self,site=0,on=1,requested=100):
  u=self.u;store(u,self.mode,on);self.native_calls=[];u.mem_write(JOB,bytes(0x1190));store(u,JOB+4,3);store(u,JOB+0xb4,requested)
  # Execute each real caller's entire argument preparation, not only CALL.
  starts=[0x433519e8,0x433544cf,0x433c3286,0x433c5cd2]
  job_slots=[0x4c,0x4c,0x18,0x18];actor_slots=[0x18,0x18,0x0c,0x0c]
  flag_slots=[0x48,0x84,0x3c,0x38];output_slots=[0x1a4,0x1a0,0x84,0x4c]
  fl=SP+output_slots[site];store(u,fl,0x1234)
  store(u,SP+job_slots[site],JOB);store(u,SP+actor_slots[site],ACTOR);store(u,SP+flag_slots[site],0)
  u.reg_write(UC_X86_REG_ESP,SP)
  saved={r:0x123456+10*i for i,r in enumerate([UC_X86_REG_EBX,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP])}
  saved[UC_X86_REG_EDI if site in [0,2] else UC_X86_REG_ESI]=CONTEXT
  for r,v in saved.items():u.reg_write(r,v)
  run_until(u,starts[site],SITES[site]+5,200000)
  assert u.reg_read(UC_X86_REG_ESP)==SP
  for r,v in saved.items():assert u.reg_read(r)==v,(r,hex(u.reg_read(r)),hex(v))
  return u.reg_read(UC_X86_REG_EAX)&255,word(u,JOB+0x13c),word(u,JOB+0xb4),word(u,fl)
 def animation_run(self,site=4,on=1,mutation=None):
  u=self.u;store(u,self.mode,on);store(u,ACTOR+0x2990,LAYERS);store(u,ACTOR+0x299c,13)
  u.mem_write(LAYERS,bytes(13*56))
  for i in [10,11]:store(u,LAYERS+i*56+0x30,ACTOR)
  offsets=[0x250,0x25c,0x288,0x294]
  for i,o in enumerate(offsets):floats(u,LAYERS+o,.2+i*.1)
  original=bytes(u.mem_read(LAYERS,13*56));self.animation=mutation;self.update_count=0
  store(u,0x43476448,STOP+0x700);u.mem_write(STOP+0x700,b'\xff\x23')
  u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,STOP+0x500);u.reg_write(UC_X86_REG_EDX,ACTOR)
  saved={r:0x987654+10*i for i,r in enumerate([UC_X86_REG_EBX,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP])}
  if site==4:saved[UC_X86_REG_EDI]=ACTOR
  for r,v in saved.items():u.reg_write(r,v)
  table=MEM+0x30000;store(u,ACTOR,table);store(u,table+0x380,STOP+0x500)
  run_until(u,0x4340eb43 if site==4 else 0x43414ffc,SITES[site]+5,200000);assert u.reg_read(UC_X86_REG_ESP)==SP and self.update_count==1
  for r,v in saved.items():assert u.reg_read(r)==v
  return original,bytes(u.mem_read(LAYERS,13*56))
choices_cases=routing_cases=animation_cases=layout_cases=0
for base in [0x10000000,0x30000000,0x60000000]:
 m=Machine(base);u=m.u
 for head in [0,1,31,0xffffffff]:
  for shot,expect in [(97/64,98),(99/64,100),(100/64,100),(96/64,96),(101/64,-1),(90/64,-1),(0,-1),(float('nan'),-1),(float('inf'),-1)]:
   m.history(shot=shot,head=head);assert m.choices()[0]==expect,(shot,m.choices());choices_cases+=1
 # Discontinuities, invalid pose, unordered timestamps and bad shapes fail closed.
 for change in ['break','nan','invalid','teleport','count0','count33','unordered','oldjob','window','interval','too_far','bad_new_tick','bad_old_tick']:
  rec=m.history();m.low=94;m.high=104
  if change=='break':store(u,rec[0]+0x5c,0x204)
  elif change=='nan':floats(u,rec[1]+0x230,float('nan'))
  elif change=='invalid':store(u,rec[1]+0x5c,0)
  elif change=='teleport':floats(u,rec[1]+0x30,900,0,0)
  elif change=='count0':store(u,HISTORY+0x5d8,0)
  elif change=='count33':store(u,HISTORY+0x5d8,33)
  elif change=='unordered':store(u,rec[1]+0x4c,101)
  elif change=='window':m.low=99
  elif change=='too_far':m.history((100,98,96,94,92,90),shot=89/64)
  elif change=='bad_new_tick':store(u,rec[0]+0x4c,0x80000000)
  elif change=='bad_old_tick':store(u,rec[1]+0x4c,0x80000000)
  result=m.choices(96 if change=='oldjob' else 100,float('inf') if change=='interval' else 1/64)
  assert result[0]==-1,(change,result);choices_cases+=1
 m.low=94;m.high=104
 for site,on in itertools.product(range(4),[0,1]):
  rec=m.history();before=bytes(u.mem_read(HISTORY,0x65c)),[bytes(u.mem_read(p,0x10a0)) for p in rec]
  result=m.lookup(site,on);expected=98 if on else 100
  assert result[:3]==(1,expected,expected),(site,on,result,m.native_calls)
  assert m.native_calls==[expected]
  assert bytes(u.mem_read(HISTORY,0x65c))==before[0]
  assert [bytes(u.mem_read(p,0x10a0)) for p in rec]==before[1];routing_cases+=1
 for site in range(4):
  m.history();m.fail={98};r=m.lookup(site);assert r[:3]==(1,100,100) and m.native_calls==[98,100];routing_cases+=1
  m.history((100,99,98),shot=0);m.fail={100};r=m.lookup(site);assert r[:3]==(1,99,99) and m.native_calls==[100,99];routing_cases+=1
  m.fail={100,99};r=m.lookup(site);assert r[0]==0 and m.native_calls==[100,99]
  assert u.mem_read(JOB+0xf0,0x10a0)==b'\xa5'*0x10a0 and r[3]==0xdeadbeef;routing_cases+=1
  m.fail=set();m.history();m.low=99;r=m.lookup(site);assert m.native_calls==[100] and r[:3]==(1,100,100);routing_cases+=1;m.low=94
 for site in range(4):
  m.history((101,100,99,98,96),shot=97/64);m.fail={98,100,99}
  r=m.lookup(site);assert r[:3]==(1,101,101) and m.native_calls==[98,100,99,101];routing_cases+=1
 m.fail=set()
 # Optional failure must not publish its scratch data over a native result.
 for site,on,bad in itertools.product([4,5],[0,1],[float('nan'),float('inf'),-1.,2.]):
  def corrupt(u,v=bad):
   for o in [0x250,0x25c,0x288,0x294]:floats(u,LAYERS+o,v)
  before,after=m.animation_run(site,on,corrupt)
  if on:assert after==before
  else:
   for o in [0x250,0x25c,0x288,0x294]:assert after[o:o+4]==struct.pack('<f',bad)
  animation_cases+=1
 for site,change in itertools.product([4,5],['valid','owner','pointer','count','unrelated','individual']):
  def mutate(u):
   if change=='valid':
    for o in [0x250,0x25c,0x288,0x294]:floats(u,LAYERS+o,.8)
   else:
    floats(u,LAYERS+0x250,float('nan'))
    if change=='owner':store(u,LAYERS+0x260,ACTOR+4)
    elif change=='pointer':store(u,ACTOR+0x2990,LAYERS+0x1000)
    elif change=='count':store(u,ACTOR+0x299c,12)
    elif change=='unrelated':floats(u,LAYERS+0x218,123)
  before,after=m.animation_run(site,1,mutate)
  if change=='valid':
   for o in [0x250,0x25c,0x288,0x294]:assert after[o:o+4]==struct.pack('<f',.8)
  elif change in ['owner','pointer','count']:assert math.isnan(scalar(u,LAYERS+0x250))
  else:
   assert after[0x250:0x254]==before[0x250:0x254]
   if change=='unrelated':assert scalar(u,LAYERS+0x218)==123
  animation_cases+=1
 # Layout guard uses actual client headers/function bytes, no client execution.
 client=Path('/workspace/game-8802-modules/client.mapped.bin').read_bytes()
 u.mem_map(CLIENT,0x1000);u.mem_write(CLIENT,client[:0x1000]);u.mem_map(CLIENT+0x3e7000,0x1000);u.mem_write(CLIENT+0x3e7000,client[0x3e7000:0x3e8000])
 m.regions.extend([(CLIENT,0x1000,4),(CLIENT+0x3e7000,0x1000,0x20)])
 assert m.call('client_layout_probe')==1;layout_cases+=1
 for off in [0x3e7a80,0x3e7a89,word(u,CLIENT+0x3c)+8]:
  b=bytes(u.mem_read(CLIENT+off,1));u.mem_write(CLIENT+off,bytes([b[0]^1]));assert m.call('client_layout_probe')==0;u.mem_write(CLIENT+off,b);layout_cases+=1
report={'passed':True,'choices_cases':choices_cases,'native_record_copy_routing_cases':routing_cases,'all_four_native_argument_setups_executed':True,'both_encrypted_animation_dispatch_setups_executed':True,'native_animation_dispatch_cases':animation_cases,'client_guard_cases':layout_cases,'probe_relocation_placements':3,'raw_shot_time_offset':'0x54','raw_simulation_tick_offset':'0x4c','animation_layers':[10,11],'normal_animation_values_preserved':True,'native_dispatch_and_return_path_preserved':True,'shot_window_pairs':4,'retry_tick_radius':1,'max_lookup_calls':4,'native_time_window_preserved':True,'ring_records_unmodified':True,'job_tick_matches_selected_record':True,'default_hitscan':'Neverlose (open-source correction set)','closed_neverlose_core_transferred':False,'custom_extrapolation_enabled':False,'core_sha256':hashlib.sha256(IMAGE).hexdigest(),'client_sha256':hashlib.sha256(Path('/workspace/game-8802-modules/client.dll').read_bytes()).hexdigest(),'game_tested':False,'limits':__doc__}
(BUILD/'hitscan_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
