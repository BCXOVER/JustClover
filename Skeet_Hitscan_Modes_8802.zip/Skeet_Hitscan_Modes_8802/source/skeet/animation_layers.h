#pragma once
#include <cstdint>
#include <cstring>
namespace animation_layers {
inline constexpr unsigned stride=0x38,overlay=0x2990,count_offset=0x299c;
inline constexpr unsigned offsets[]={10*stride+0x20,10*stride+0x2c,11*stride+0x20,11*stride+0x2c};
inline std::uint32_t read(const void* p,unsigned off){std::uint32_t x;std::memcpy(&x,static_cast<const unsigned char*>(p)+off,4);return x;}
inline bool normalized(std::uint32_t bits) {
    if((bits&0x7f800000u)==0x7f800000u)return false;
    float f;std::memcpy(&f,&bits,4);return f>=-.001f&&f<=1.001f;
}
struct Snapshot {void* layers=nullptr;std::uintptr_t owner=0;std::uint32_t saved[4]{};unsigned count=0;};
inline bool owners(const void* layers,std::uintptr_t owner) {
    return layers&&owner&&read(layers,10*stride+0x30)==owner&&read(layers,11*stride+0x30)==owner;
}
inline Snapshot capture(void* layers,unsigned count,std::uintptr_t owner) {
    Snapshot s{};if(count<12||count>15||!owners(layers,owner))return s;
    s.layers=layers;s.owner=owner;s.count=count;
    for(unsigned i=0;i<4;i++)s.saved[i]=read(layers,offsets[i]);return s;
}
inline unsigned repair(const Snapshot& s,void* layers,unsigned count,std::uintptr_t owner) {
    if(!s.layers||s.layers!=layers||s.owner!=owner||s.count!=count||!owners(layers,owner))return 0;
    unsigned n=0;
    for(unsigned i=0;i<4;i++)if(!normalized(read(layers,offsets[i]))&&normalized(s.saved[i])) {
        std::memcpy(static_cast<unsigned char*>(layers)+offsets[i],&s.saved[i],4);++n;
    }
    return n;
}
}
