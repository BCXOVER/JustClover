#pragma once
#include "hitscan_mode.h"
#include "hitscan_records.h"
#include "animation_layers.h"
#include <windows.h>
namespace hitscan_runtime {
inline bool memory(const void* p,std::size_t bytes,bool write=false) {
    if(!p||!bytes)return false;MEMORY_BASIC_INFORMATION m{};
    if(!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
    const auto at=reinterpret_cast<std::uintptr_t>(p),first=reinterpret_cast<std::uintptr_t>(m.BaseAddress);
    if(at<first||bytes>m.RegionSize||at-first>m.RegionSize-bytes)return false;
    return !write||(m.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
}
inline bool client_layout() {
    const auto* b=reinterpret_cast<const unsigned char*>(GetModuleHandleW(L"client.dll"));
    if(!memory(b,0x1000)||*reinterpret_cast<const unsigned short*>(b)!=0x5a4d)return false;
    const unsigned off=animation_layers::read(b,0x3c);if(off>0x800)return false;
    const auto* nt=reinterpret_cast<const IMAGE_NT_HEADERS32*>(b+off);
    if(nt->Signature!=IMAGE_NT_SIGNATURE||nt->FileHeader.Machine!=IMAGE_FILE_MACHINE_I386||nt->FileHeader.TimeDateStamp!=0x65272025||nt->OptionalHeader.SizeOfImage!=0x5509000)return false;
    // UpdateClientSideAnimation in
    // the supplied 8802 client. All checks are relocation independent.
    constexpr unsigned char update[]={0x55,0x8b,0xec,0x51,0x56,0x8b,0xf1,0x80,0xbe,0x14,0x9b,0,0,0,0x74,0x36};
    if(!memory(b+0x3e7a80,sizeof(update))||std::memcmp(b+0x3e7a80,update,sizeof(update)))return false;
    return true;
}
inline animation_layers::Snapshot capture(void* entity) {
    if(!entity)return {};
    const auto* header=static_cast<const unsigned char*>(entity)+animation_layers::overlay;
    if(!memory(header,16))return {};
    const unsigned count=animation_layers::read(header,12);
    auto* layers=reinterpret_cast<void*>(animation_layers::read(header,0));
    if(count<12||count>15||!memory(layers,12*animation_layers::stride,true))return {};
    return animation_layers::capture(layers,count,reinterpret_cast<std::uintptr_t>(entity));
}
inline void restore(void* entity,const animation_layers::Snapshot& s) {
    if(!s.layers)return;
    const auto* header=static_cast<const unsigned char*>(entity)+animation_layers::overlay;
    if(!memory(header,16)||!memory(s.layers,12*animation_layers::stride,true))return;
    auto* layers=reinterpret_cast<void*>(animation_layers::read(header,0));
    animation_layers::repair(s,layers,animation_layers::read(header,12),reinterpret_cast<std::uintptr_t>(entity));
}
using Dispatch=void(__fastcall*)(void*,void*);
inline void __fastcall update(void* target,void* entity) {
    // Use the exact original generic dispatcher (including its return path).
    // A stack-local snapshot also handles nested animation updates correctly.
    animation_layers::Snapshot saved{};
    if(hitscan_mode::enhanced())saved=capture(entity);
    reinterpret_cast<Dispatch>(0x433e533f)(target,entity);
    restore(entity,saved);
}
using NativeLookup=bool(__fastcall*)(void*,void*,int,unsigned,void*,unsigned*);
struct LookupContext {void* shooter;void* actor;unsigned flags;};
inline bool invoke(void* context,int t,void* out,unsigned* flags) {
    auto& c=*static_cast<LookupContext*>(context);
    return reinterpret_cast<NativeLookup>(0x4336c53b)(c.shooter,c.actor,t,c.flags,out,flags);
}
inline bool __fastcall lookup(void* shooter,void* actor,int requested,unsigned flags,void* out,unsigned* out_flags) {
    LookupContext c{shooter,actor,flags};
    if(!hitscan_mode::enhanced()||!shooter||!actor||!out||!out_flags)return invoke(&c,requested,out,out_flags);
    // Only the four verified Rage job callers are redirected. Each supplies
    // job+0xf0 as output and stores the entity index at job+4.
    auto* job=static_cast<unsigned char*>(out)-0xf0;
    if(!memory(job,0x1190,true)||!memory(out_flags,4,true))return invoke(&c,requested,out,out_flags);
    const unsigned index=animation_layers::read(job,4);
    if(index<1||index>64)return invoke(&c,requested,out,out_flags);
    const auto* history=*reinterpret_cast<const void**>(0x434797bc+(index&63u)*4);
    if(!memory(history,0x65c))return invoke(&c,requested,out,out_flags);
    const unsigned count=animation_layers::read(history,0x5d8);
    if(!count||count>32)return invoke(&c,requested,out,out_flags);
    for(unsigned i=0;i<count&&i<=hitscan_records::maximum_pairs;i++)if(!memory(motion_records::record(history,i),motion_records::record_size))return invoke(&c,requested,out,out_flags);
    const auto* interval=*reinterpret_cast<const float* const*>(0x4346a338);
    if(!memory(interval,4))return invoke(&c,requested,out,out_flags);
    using Window=int(__thiscall*)(void*);
    const int low=reinterpret_cast<Window>(0x4339438e)(shooter);
    const int high=reinterpret_cast<Window>(0x4337ea43)(shooter);
    const auto choices=hitscan_records::choose(history,requested,*interval,low,high);
    const bool ok=hitscan_records::lookup(choices,requested,out,out_flags,&invoke,&c);
    if(ok) {
        // Keep the job timestamp consistent with the actually returned pose,
        // including shot preference and a successful neighboring-record retry.
        const int actual=motion_records::tick(out);
        if(actual!=requested&&hitscan_records::in_window(actual,low,high))motion_records::put(job,0xb4,actual);
    }
    return ok;
}
}
