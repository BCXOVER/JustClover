#pragma once
namespace hitscan_ui {
static PElement control=nullptr;
static int value=hitscan_mode::Neverlose;
static void __fastcall changed(void*,void*) {
    value=value==hitscan_mode::Neverlose?hitscan_mode::Neverlose:hitscan_mode::Gamesense;
    hitscan_mode::selected.store(value,std::memory_order_relaxed);
}
static void frame(CMenu* menu) {
    if(!menu||menu->Tabs.size()<=RAGE||!native.combo||!native.insert)return;
    auto* tab=menu->Tabs[RAGE];if(!tab)return;
    Child* other=nullptr;
    for(auto* child:tab->Childs) {
        if(!child)continue;
        wchar_t name[128]{};native_ui_names::decode(child->Name.get(),name,std::size(name));
        if(eq(name,L"Other")){other=child;break;}
    }
    if(!other)return;
    if(control)for(auto* e:other->Elements)if(e==control){changed(nullptr,nullptr);return;}
    control=nullptr;
    auto* p=static_cast<Combobox*>(native.allocate(sizeof(Combobox)));if(!p)return;
    const int previous=hitscan_mode::selected.load(std::memory_order_relaxed);
    native.combo(p,other,L"Hitscan",&value,false);
    for(const auto* name:{L"Gamesense",L"Neverlose"}) {
        BoxVars<wchar_t> item{};item.Index=int(p->Vars.size());
        item.Name.assign(name,name+std::wcslen(name)+1);p->Vars.emplace_back(std::move(item));
    }
    value=previous==hitscan_mode::Neverlose?hitscan_mode::Neverlose:hitscan_mode::Gamesense;
    p->Calls.emplace_back(nullptr,&changed);native.insert(other,false,p);
    control=reinterpret_cast<PElement>(p);
    std::rotate(other->Elements.begin(),other->Elements.end()-1,other->Elements.end());
    auto** table=*reinterpret_cast<void***>(other);reinterpret_cast<NativeLayout>(table[8])(other);
    changed(nullptr,nullptr);
}
}
