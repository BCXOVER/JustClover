#pragma once
#include "motion_records.h"
namespace hitscan_records {
using namespace motion_records;
inline constexpr unsigned maximum_pairs=4,maximum_retries=2;
// The raw Skeet record stores m_flLastShotTime at +0x54, and simulation TICK
// at +0x4c. Neverlose's +0x24 simulation-time layout must not be copied here.
inline bool in_window(int t,int low,int high){return t>=0&&t<=8000000&&low>=0&&high>=low&&high-low<=256&&t>=low&&t<=high;}
inline bool usable(const void* history,const void* r,int low,int high) {
    return r&&in_window(tick(r),low,high)&&record_eligibility::eligible(history,tick(r))&&valid_pose(r);
}
struct Choices {int shot=-1;int retries[maximum_retries]{-1,-1};};
inline Choices choose(const void* history,int requested,float interval,int low,int high) {
    Choices out{};if(!history||!finite(interval)||interval<1.f/1024||interval>.1f||!in_window(requested,low,high))return out;
    const unsigned count=motion_records::u32(history,0x5d8);if(!count||count>32)return out;
    const void* newest=record(history,0);if(!newest)return out;
    // Revisit at most the directly adjacent stored ticks after native failure.
    // This is a bounded retry, never an extension of the backtrack window.
    for(unsigned i=0;i<count&&i<=maximum_pairs;i++) {
        const auto* r=record(history,i);if(!r)break;const int t=tick(r);
        if(t==requested-1&&usable(history,r,low,high))out.retries[0]=t;
        if(t==requested+1&&usable(history,r,low,high))out.retries[1]=t;
        if(motion_records::u32(r,0x5c)&0x200)break;
    }
    // Only the latest-pose job may prefer a shot record. Explicitly chosen old
    // poses remain independent scan jobs rather than all collapsing to a shot.
    if(!usable(history,newest,low,high)||requested<tick(newest)-1)return out;
    const float shot=f32(newest,0x54);if(!finite(shot)||shot<=0)return out;
    const void* newer=newest;
    if(float(tick(newer))*interval==shot){out.shot=tick(newer);return out;}
    for(unsigned i=1;i<count&&i<=maximum_pairs;i++) {
        const auto* older=record(history,i);if(!older||motion_records::u32(newer,0x5c)&0x200)return out;
        const int nt=tick(newer),ot=tick(older);
        if(nt<0||nt>8000000||ot<0||ot>8000000||nt<=ot||nt-ot>16||!record_eligibility::continuous(position(newer,0x30),position(older,0x30)))return out;
        if(float(ot)*interval==shot) {
            if(usable(history,older,low,high))out.shot=ot;
            return out;
        }
        if(float(nt)*interval>=shot&&shot>float(ot)*interval) {
            if(usable(history,newer,low,high))out.shot=nt;
            return out;
        }
        newer=older;
    }
    return out;
}
using Lookup=bool(*)(void*,int,void*,unsigned*);
// Every native call receives the real job output: native bone preparation may
// retain its address. Roll back rejected optional writes with a stack snapshot.
// At most four calls, no recursion and no heap allocation.
inline bool lookup(const Choices& choices,int requested,void* output,unsigned* flags,Lookup original,void* context) {
    if(!original||!output||!flags)return false;
    alignas(16) unsigned char saved[record_size];unsigned saved_flags=0;
    const auto attempt=[&](int t) {
        std::memcpy(saved,output,sizeof(saved));saved_flags=*flags;
        if(original(context,t,output,flags)&&tick(output)==t&&valid_pose(output))return true;
        std::memcpy(output,saved,sizeof(saved));*flags=saved_flags;return false;
    };
    if(choices.shot>=0&&choices.shot!=requested&&attempt(choices.shot))return true;
    if(original(context,requested,output,flags))return true;
    for(int t:choices.retries)if(t>=0&&t!=choices.shot&&t!=requested&&attempt(t))return true;
    return false;
}
}
