#pragma once
#include <atomic>
namespace hitscan_mode {
enum Value {Gamesense=0,Neverlose=1};
// This selects the open Neverlose-derived corrections, not its closed core.
inline std::atomic<int> selected{Neverlose};
inline bool enhanced(){return selected.load(std::memory_order_relaxed)==Neverlose;}
static_assert(std::atomic<int>::is_always_lock_free);
}
