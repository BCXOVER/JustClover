#pragma once
// Included inside cs2_visuals: shares the verified native UI constructors and
// the single SDK implementation. Only presentation is changed.
namespace skin {
using skin_menu_design::Panel;
using ListCtor=void*(__thiscall*)(void*,void*,const wchar_t*,int,int,int*,bool);
using TextCtor=void*(__thiscall*)(void*,void*);
using NativeElementDraw=void(__thiscall*)(void*,IRenderer*,const Vec2*);
using NativeRow=void(__thiscall*)(void*,IRenderer*,const Vec2*,int,unsigned,unsigned,unsigned);
static ListCtor list_ctor=nullptr;static TextCtor text_ctor=nullptr;
struct Pane {Child* child=nullptr;void* table[13]{};NativeChildDraw draw=nullptr;NativeLayout layout=nullptr;int index=0;};
struct View {
    PElement proxy=nullptr,source=nullptr;Pane* pane=nullptr;int type=0;
    unsigned char observed[132]{};unsigned observed_size=0;
    bool agent=false;int rarity_weapon=0;void* table[16]{};NativeRow row=nullptr;NativeElementDraw draw=nullptr;
};
static Pane panes[skin_menu_design::Count]{};
static View views[256]{};static unsigned view_count=0;
static Child* sources[32]{};static bool source_visible[32]{};static unsigned source_count=0;
static bool initialized=false,attached=false,pending_refresh=false,refreshing=false;
static std::uint64_t captured=0,failed=0;
static Pane* pane(Child* child){for(auto& p:panes)if(p.child==child)return &p;return nullptr;}
static bool owned(Child* child){auto* p=pane(child);return p&&*reinterpret_cast<void***>(child)==p->table;}
static bool value_type(int t){return (native_ui_proxy::supported(t)&&t!=UiLabel)||t==UiListbox;}
static bool supported(int t){return native_ui_proxy::supported(t)||t==UiButton||t==UiListbox||t==UiTextbox;}
static std::uint64_t fingerprint(CMenu* menu) {
    if(!menu||menu->Tabs.size()!=9||!menu->Tabs[SKINS])return 0;
    auto* tab=menu->Tabs[SKINS];if(tab->Childs.empty()||tab->Childs.size()>35)return 0;
    std::uint64_t h=0xcbf29ce484222325ULL;
    const auto add=[&](std::uintptr_t n){h=(h^n)*0x100000001b3ULL;};
    add(reinterpret_cast<std::uintptr_t>(tab));
    for(auto* child:tab->Childs) {
        if(!child)return 0;add(reinterpret_cast<std::uintptr_t>(child));
        if(owned(child)){add(0x534b494e);continue;}
        if(child->Elements.size()>256)return 0;add(child->Elements.size());
        for(auto* e:child->Elements) {
            if(!e)return 0;auto* c=e->GetAs<Checkbox>();const int t=c->Header.Type;
            add(reinterpret_cast<std::uintptr_t>(e));add(t);
            if(value_type(t))add(reinterpret_cast<std::uintptr_t>(native_ui_proxy::pointer(e,0x5c)));
            if(t==UiCombobox) {
                auto* combo=e->GetAs<Combobox>();if(combo->Vars.size()>512)return 0;add(combo->Vars.size());
                for(auto& v:combo->Vars){if(v.Name.size()>256)return 0;add(v.Index);for(auto ch:v.Name)add(unsigned(ch));}
            } else if(t==UiListbox) {
                auto* list=e->GetAs<Listbox>();if(list->Info.Items.size()>8192)return 0;add(list->Info.Items.size());
                for(auto& v:list->Info.Items){if(v.Name.size()>256)return 0;add(v.Index);for(auto ch:v.Name)add(unsigned(ch));}
                // Filtering can change only the displayed-index map while all
                // item/model pointers remain the same.
                if(list->SSpecs.size()>8193)return 0;add(list->SSpecs.size());
                for(auto index:list->SSpecs)add(static_cast<unsigned short>(index));
            }
        }
    }
    return h;
}
static View* view(PElement proxy){for(unsigned i=0;i<view_count;i++)if(views[i].proxy==proxy)return &views[i];return nullptr;}
static void position(Pane& p) {
    const auto r=skin_menu_design::layout(context->Menu->Size.x,context->Menu->Size.y,scale())[p.index];
    p.child->Pos={r.x,r.y};p.child->Size=p.child->DefSize={r.w,r.h};
}
static void __fastcall pane_layout(Child* child,void*) {
    auto* p=pane(child);if(!p)return;position(*p);p->layout(child);
    bool resized=false;
    for(unsigned i=0;i<view_count;i++)if(views[i].pane==p&&views[i].type==UiListbox) {
        auto* list=views[i].proxy->GetAs<Listbox>();
        const int w=std::max(60,child->Size.x-int(40*scale()));
        const int h=std::max(int(90*scale()),child->Size.y-list->Pos.y-int(55*scale()));
        if(list->Size.x!=w||list->Size.y!=h) {
            list->Size={w,h};
            list->DisplayedCount=std::max(1,h/std::max(1,list->ElementSize)-(list->SearchPresent?1:0));
            list->HandleResize();resized=true;
        }
    }
    if(resized)p->layout(child);
}
static void __fastcall pane_draw(Child* child,void*,IRenderer* renderer,const Vec2* origin) {
    if(!attached)return;auto* p=pane(child);if(!p)return;
    position(*p);p->draw(child,renderer,origin);
}
static void restore(CMenu* menu) {
    if(!menu||menu->Tabs.size()!=9||!menu->Tabs[SKINS])return;
    for(auto* child:menu->Tabs[SKINS]->Childs)if(child) {
        if(owned(child))child->Header.Flags.Visible=false;
        else for(unsigned i=0;i<source_count;i++)if(child==sources[i])child->Header.Flags.Visible=source_visible[i];
    }
}
static void invalidate(CMenu* menu) {
    attached=false;pending_refresh=true;
    if(!menu||menu->Tabs.size()!=9||!menu->Tabs[SKINS])return;
    for(auto* child:menu->Tabs[SKINS]->Childs)if(child&&owned(child))for(auto* e:child->Elements)if(e) {
        auto* item=e->GetAs<Checkbox>();item->Calls.clear();item->Header.Flags.Visible=false;
        if(value_type(item->Header.Type))*reinterpret_cast<void**>(reinterpret_cast<char*>(e)+0x5c)=nullptr;
        item->ResetInputState();
    }
}
static unsigned snapshot(View& v,unsigned char* data) {
    if(v.type==UiTextbox){std::memcpy(data,reinterpret_cast<char*>(v.source)+0x64,132);return 132;}
    if(!value_type(v.type))return 0;
    auto* ptr=static_cast<unsigned char*>(native_ui_proxy::pointer(v.source,0x5c));if(!ptr)return 0;
    const unsigned n=v.type==UiCheckbox?1:(v.type==UiHotkey?8:4);
    std::memcpy(data,ptr+(v.type==UiHotkey?16:0),n);return n;
}
static void sync(CMenu* menu) {
    if(!attached||refreshing)return;refreshing=true;
    if(fingerprint(menu)!=captured){refreshing=false;invalidate(menu);return;}
    bool dirty[skin_menu_design::Count]{};
    for(unsigned i=0;i<view_count;i++) {
        auto& v=views[i];auto* out=v.proxy->GetAs<Checkbox>();auto* from=v.source->GetAs<Checkbox>();
        if(out->Header.Flags.Visible!=from->Header.Flags.Visible){visible(out,from->Header.Flags.Visible);dirty[v.pane->index]=true;}
        out->Header.Flags.Editable=from->Header.Flags.Editable;out->Header.Flags.AllowMouseInput=from->Header.Flags.AllowMouseInput;
        unsigned char current[132]{};const unsigned n=snapshot(v,current);
        if(n&&std::memcmp(current,v.observed,n)) {
            if(v.type==UiTextbox)std::memcpy(reinterpret_cast<char*>(v.proxy)+0x64,current,n);
            else out->OnConfigLoad();
            std::memcpy(v.observed,current,n);
        }
    }
    for(unsigned i=0;i<source_count;i++)if(sources[i]->Header.Flags.Visible)visible(sources[i],false);
    for(auto& p:panes) {
        if(!p.child->Header.Flags.Visible){visible(p.child,true);dirty[p.index]=true;}
        if(dirty[p.index])pane_layout(p.child,nullptr);
    }
    refreshing=false;
}
static void __fastcall changed(void* arg,void*) {
    if(!attached||refreshing)return;auto* menu=context->Menu;
    if(fingerprint(menu)!=captured){invalidate(menu);return;}
    auto* v=static_cast<View*>(arg);if(!v||!v->source)return;
    if(v->type==UiTextbox)std::memcpy(reinterpret_cast<char*>(v->source)+0x64,reinterpret_cast<char*>(v->proxy)+0x64,132);
    if(v->type!=UiButton)v->source->GetAs<Checkbox>()->OnConfigLoad();
    if(fingerprint(menu)!=captured){invalidate(menu);return;}
    v->source->GetAs<Checkbox>()->OnValueSet();
    if(fingerprint(menu)!=captured){invalidate(menu);return;}
    snapshot(*v,v->observed);sync(menu);
}
static void __fastcall agent_row(void* self,void*,IRenderer* renderer,const Vec2* pos,int height,unsigned index,unsigned color,unsigned flags) {
    auto* v=view(static_cast<PElement>(self));if(!attached||!v||!renderer||!pos)return;
    // Skin model combos can be derived native classes carrying schema/rarity
    // metadata beyond the base object. Invoke their real row renderer on the
    // original live object rather than shallow-copying that private state.
    if(!v->agent||v->row!=reinterpret_cast<NativeRow>(0x433b1508)) {
        v->row(v->source,renderer,pos,height,index,color,flags);return;
    }
    auto* combo=static_cast<Combobox*>(self);if(index>=combo->Vars.size())return;
    auto& name=combo->Vars[index].Name;if(name.empty())return;unsigned len=0;while(len<name.size()&&name[len])++len;
    const auto* sub=skin_menu_design::collection(name.data());
    if(!sub){v->row(v->source,renderer,pos,height,index,color,flags);return;}
    const int inset=std::max(1,int(11*scale()));
    const int top=pos->y+std::max(1,int(3*scale()));
    const int dot=std::max(2,int(3*scale()));
    const unsigned alpha=color&0xff000000U;
    renderer->Rect(pos->x+std::max(1,int(4*scale())),top+std::max(1,int(3*scale())),dot,dot,alpha|0x00ba6c9aU);
    renderer->Text(flags&1,pos->x+inset,top,color,std::max(1,combo->InnerPadding.x-inset-4),name.data(),len);
    renderer->Text(flags&1,pos->x+inset,top+std::max(1,int(12*scale())),alpha|0x007a7a7aU,
                   std::max(1,combo->InnerPadding.x-inset-4),sub,std::wcslen(sub));
}
static void __fastcall list_draw(void* self,void*,IRenderer* renderer,const Vec2* origin) {
    auto* v=view(static_cast<PElement>(self));if(!attached||!v)return;
    v->draw(self,renderer,origin);if(!renderer||!origin)return;
    auto* list=static_cast<Listbox*>(self);const int row=list->ElementSize;if(row<=0)return;
    const unsigned start=list->ScrollbarEnabled?list->Info.ScrollPosition/row:0;
    const int top=origin->y+list->Pos.y+(list->SearchPresent?row:0);
    const unsigned limit=std::min<unsigned>(list->SSpecs.size(),start+std::max(0,list->DisplayedCount));
    for(unsigned i=start;i<limit;i++) {
        const unsigned selected=static_cast<unsigned short>(list->SSpecs[i]);if(selected>=list->Info.Items.size())continue;
        const int y=top+int(i-start)*row+row/2-1;
        if(y+3>=origin->y+list->Pos.y+list->Size.y)break;
        const auto& entry=list->Info.Items[selected];
        const unsigned c=skin_rarity::color(int(entry.Index),entry.Name.data(),entry.Name.size(),list->Header.Flags.Editable?255:80,v->rarity_weapon);
        renderer->Rect(origin->x+list->Pos.x+std::max(2,int(4*scale())),y,std::max(2,int(3*scale())),std::max(2,int(3*scale())),c);
    }
}
static bool make(View& v,const wchar_t* name) {
    const int type=v.type;void* made=nullptr;
    if(type==UiListbox) {
        auto* source=v.source->GetAs<Listbox>();if(source->Info.Items.size()>8192||source->SSpecs.size()>8193)return false;
        skin_rarity::WeaponCandidates candidates;
        for(auto index:source->SSpecs) {
            const auto row=static_cast<unsigned short>(index);if(row>=source->Info.Items.size())continue;
            const auto& e=source->Info.Items[row];candidates.add(skin_rarity::paint_id(int(e.Index),e.Name.data(),e.Name.size()));
            if(candidates.initialized&&!candidates.size)break;
        }
        v.rarity_weapon=candidates.weapon();
        auto* value=static_cast<int*>(native_ui_proxy::pointer(source,0x5c));if(!value)return false;const int saved=*value;
        auto* out=static_cast<Listbox*>(native.allocate(sizeof(Listbox)));if(!out)return false;
        list_ctor(out,v.pane->child,name,source->Size.x,source->Size.y,value,source->SearchPresent);*value=saved;
        try {out->Info.Items=source->Info.Items;out->SSpecs=source->SSpecs;out->AbsoluteHeight=source->AbsoluteHeight;out->OnConfigLoad();}
        catch(...){destroy(out);throw;}
        out->Header.Flags=source->Header.Flags;out->Header.Font=source->Header.Font;
        out->LeftPaddign=source->LeftPaddign;out->Calls.emplace_back(&v,&changed);
        auto** table=*reinterpret_cast<void***>(out);std::memcpy(v.table,table,14*sizeof(void*));
        v.draw=reinterpret_cast<NativeElementDraw>(table[4]);v.table[4]=reinterpret_cast<void*>(&list_draw);*reinterpret_cast<void***>(out)=v.table;
        native.insert(v.pane->child,false,out);made=out;
    } else if(type==UiTextbox) {
        auto* out=native.allocate(sizeof(Textbox));if(!out)return false;text_ctor(out,v.pane->child);
        auto* target=static_cast<Textbox*>(out);auto* source=v.source->GetAs<Textbox>();
        target->Header.Flags=source->Header.Flags;target->Header.Font=source->Header.Font;
        std::memcpy(reinterpret_cast<char*>(out)+0x64,reinterpret_cast<char*>(source)+0x64,132);
        target->Calls.emplace_back(&v,&changed);native.insert(v.pane->child,false,out);made=out;
    } else if(type==UiButton) {
        made=add_button(v.pane->child,false,name,&v,reinterpret_cast<void*>(&changed));
        if(made)static_cast<Button*>(made)->Header.Flags=v.source->GetAs<Button>()->Header.Flags;
    } else {
        // Reuse the verified factory, with a Skinchanger-specific callback.
        auto api=native;
        api.link=[](void* out,void*){static_cast<Checkbox*>(out)->Calls.emplace_back(&views[view_count],&changed);};
        made=native_ui_proxy::create(api,v.pane->child,v.source,name);
    }
    if(!made)return false;v.proxy=static_cast<PElement>(made);
    if(type==UiCombobox) {
        auto* combo=static_cast<Combobox*>(made);auto** table=*reinterpret_cast<void***>(combo);
        std::memcpy(v.table,table,sizeof(v.table));
        auto* source=v.source->GetAs<Combobox>();
        v.row=reinterpret_cast<NativeRow>((*reinterpret_cast<void***>(source))[14]);
        v.table[14]=reinterpret_cast<void*>(&agent_row);*reinterpret_cast<void***>(combo)=v.table;
        combo->Defheigth=source->Defheigth;combo->heigth=source->heigth;
        combo->DefInteractOffset=source->DefInteractOffset;combo->InteractOffset=source->InteractOffset;
        combo->InnerPadding=source->InnerPadding;combo->OuterPadding=source->OuterPadding;
        if(v.agent&&v.row==reinterpret_cast<NativeRow>(0x433b1508)) {
            combo->Defheigth=30;combo->heigth=std::max(1,int(30*scale()));
            combo->OuterPadding.y+=15;combo->InnerPadding.y+=std::max(1,int(15*scale()));
        }
    }
    v.observed_size=snapshot(v,v.observed);return true;
}
static bool create_panes(CMenu* menu) {
    auto* tab=menu->Tabs[SKINS];if(tab->Childs.size()>32)return false;
    for(int i=0;i<skin_menu_design::Count;i++) {
        auto& p=panes[i];p.index=i;
        auto* child=static_cast<Child*>(native.allocate(sizeof(Child)));if(!child)return false;
        child_ctor(child,tab,skin_menu_design::titles[i],int(0xff000000U),0,false);
        p.child=child;child->Header.Flags.Visible=false;
        auto** table=*reinterpret_cast<void***>(child);std::memcpy(p.table,table,sizeof(p.table));
        p.draw=reinterpret_cast<NativeChildDraw>(table[4]);p.layout=reinterpret_cast<NativeLayout>(table[8]);
        p.table[4]=reinterpret_cast<void*>(&pane_draw);p.table[8]=reinterpret_cast<void*>(&pane_layout);
        *reinterpret_cast<void***>(child)=p.table;append_child(tab,child);position(p);
    }
    return true;
}
static bool rebuild(CMenu* menu) {
    auto* tab=menu->Tabs[SKINS];
    for(auto& p:panes){bool live=false;for(auto* c:tab->Childs)if(c==p.child&&owned(c))live=true;if(!live)return false;}
    for(auto& p:panes) {
        for(auto* e:p.child->Elements)if(e){auto* c=e->GetAs<Checkbox>();c->Calls.clear();if(value_type(c->Header.Type))*reinterpret_cast<void**>(reinterpret_cast<char*>(e)+0x5c)=nullptr;c->ResetInputState();destroy(e);}
        p.child->Elements.clear();
    }
    view_count=0;
    Child* previous[32]{};bool previous_visible[32]{};const unsigned previous_count=source_count;
    for(unsigned i=0;i<previous_count;i++){previous[i]=sources[i];previous_visible[i]=source_visible[i];}
    source_count=0;
    for(auto* child:tab->Childs)if(child&&!owned(child)) {
        if(source_count==32||child->Elements.size()>256)return false;
        bool shown=child->Header.Flags.Visible;
        for(unsigned i=0;i<previous_count;i++)if(child==previous[i])shown=previous_visible[i];
        sources[source_count]=child;source_visible[source_count++]=shown;
        wchar_t title[128]{};native_ui_names::decode(child->Name.get(),title,std::size(title));
        int previous_panel=skin_menu_design::Models;
        for(auto* e:child->Elements) {
            if(!e||view_count==std::size(views))return false;
            auto* c=e->GetAs<Checkbox>();if(!supported(c->Header.Type))return false;
            wchar_t name[128]{};native_ui_names::decode(c->Name.get(),name,std::size(name));
            const int target=name[0]?skin_menu_design::route(title,name,source_count-1):previous_panel;
            previous_panel=target;auto& v=views[view_count];v={};v.source=e;v.type=c->Header.Type;v.pane=&panes[target];v.agent=v.type==UiCombobox&&skin_menu_design::agent(name);
            if(!make(v,name))return false;++view_count;
        }
    }
    if(!view_count)return false;captured=fingerprint(menu);if(!captured)return false;
    attached=true;pending_refresh=false;failed=0;sync(menu);
    for(auto& p:panes)pane_layout(p.child,nullptr);return attached;
}
static void update(CMenu* menu) {
    if(!list_ctor||!text_ctor||!context||context->Menu!=menu||menu->Tabs.size()!=9||!menu->Tabs[SKINS])return;
    // Native settings may initialize after the first rendered menu frame.
    if(menu->CurrentTab!=SKINS||!(menu->MenuStatus&MenuOpened))return;
    if(attached&&fingerprint(menu)!=captured)invalidate(menu);
    if(!initialized) {
        if(menu->Tabs[SKINS]->Childs.empty())return;
        initialized=true;
        try {if(create_panes(menu)&&rebuild(menu))return;}
        catch(...){}
        attached=false;restore(menu);failed=fingerprint(menu);pending_refresh=true;
    }
    if(pending_refresh) {
        const auto revision=fingerprint(menu);
        if(revision&&revision!=failed) {
            try {if(rebuild(menu))return;}catch(...){}
            attached=false;restore(menu);failed=fingerprint(menu);
        }
    }
    if(attached) {
        sync(menu);
        if(attached)for(auto& p:panes)pane_layout(p.child,nullptr);
    }
}
}
