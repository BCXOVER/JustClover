#pragma once
namespace motion_settings {
inline constexpr int interpolation=1;
inline constexpr int interpolation_gap=8;
inline constexpr int extrapolation=1;
inline constexpr int extrapolation_ticks=2;
}
