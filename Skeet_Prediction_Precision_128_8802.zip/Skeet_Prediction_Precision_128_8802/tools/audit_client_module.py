#!/usr/bin/env python3
"""Read-only audit of the user-supplied CS:GO client. Never loads DLL code.
Usage: python tools/audit_client_module.py /path/to/client.dll output.json
The two files in bin.zip belong to different years; only the pinned 2023
client below was used to confirm these ABI facts.
"""
from pathlib import Path
import hashlib,json,struct,sys
import pefile

def audit(path):
    raw=Path(path).read_bytes();digest=hashlib.sha256(raw).hexdigest()
    assert digest=='183d42fac8a4ecc24dc02edf5f09122f37fe9e7533ca093a867718b25cfdeb03', 'Different client build; this audit does not apply'
    pe=pefile.PE(data=raw);data=pe.get_memory_mapped_image();base=pe.OPTIONAL_HEADER.ImageBase
    assert pe.FILE_HEADER.Machine==0x14c and base==0x10000000
    def word(rva):return struct.unpack_from('<I',data,rva)[0]
    def code(va):
        section=pe.get_section_by_rva(va-base)
        return bool(section and section.Characteristics&0x20000000)
    facts={}
    for name,rva,expected in [
        ('animation_yaw_limits',0x43e928,'c78634030000000068c2c7863803000000006842'),
        ('local_inventory_getter',0x6c9af0,'8b8100830300c3'),
        ('equip_update_gc_send_call',0x6e6812,'e889471400')]:
        assert data[rva:rva+len(bytes.fromhex(expected))]==bytes.fromhex(expected),name
        facts[name]={'rva':hex(rva),'bytes':expected}
    table=0xcace9c
    methods=[word(table+i*4) for i in range(36)]
    assert all(code(fn) for fn in methods) and not code(word(table+36*4))
    assert methods[20]==base+0x6c9ea0 and methods[23]==base+0x6c9af0 and methods[29]==base+0x6e66b0
    send=base+0x6e6812+5+struct.unpack_from('<i',data,0x6e6813)[0]
    assert send==base+0x82afa0 and code(send)
    return {'passed':True,'source_file':Path(path).name,'sha256':digest,'pe_timestamp':pe.FILE_HEADER.TimeDateStamp,
            'mapped_image_size':pe.OPTIONAL_HEADER.SizeOfImage,'facts':facts,
            'animation_yaw_limits':[-58,58],'server_yaw_limit_verified':False,'desync_60_patch_installed':False,
            'inventory_manager_vtable_rva':hex(table),'inventory_manager_vtable_methods':36,
            'inventory_slot_29_sends_gc':True,'gc_send_rva':hex(send-base),
            'inventory_added_to_release':False,'dll_executed':False}
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit(__doc__)
    result=audit(sys.argv[1]);Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
