#!/usr/bin/env python3
"""Package already-built and validated Windows artifacts without running them."""
from pathlib import Path
import shutil,json,hashlib,difflib,zipfile
ROOT=Path(__file__).resolve().parent
NAME='Skeet_Skin_Menu_Clean_8802';DEST=ROOT/'release'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    if DEST.exists():shutil.rmtree(DEST)
    DEST.mkdir()
    for folder in ['source','tests']:
        shutil.copytree(ROOT/folder,DEST/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for name in ['README_RU.md','requirements-build.txt','build_windows.py','package_release.py','Skinchanger_layout_preview.png','Visuals_layout_preview.png','Visuals_icons_preview.png']:
        shutil.copy2(ROOT/name,DEST/name)
    (DEST/'bin').mkdir();(DEST/'reports').mkdir()
    for name in ['skeet.dll','injector.exe']:shutil.copy2(ROOT/'build'/name,DEST/'bin'/name)
    for name in ['visuals_validation.json','release_validation.json','resolver_validation.json']:
        report=json.loads((ROOT/'build'/name).read_text());assert report['passed'],name
        shutil.copy2(ROOT/'build'/name,DEST/'reports'/name)
    for name in ['dll.log','injector.log','resources.log']:shutil.copy2(ROOT/'build'/name,DEST/'reports'/name)
    old_root=ROOT.parent/'skeet-visuals-lua-fix-8802';diff=[]
    old={str(p.relative_to(old_root)):p for p in (old_root/'source').rglob('*') if p.is_file()}
    new={str(p.relative_to(ROOT)):p for p in (ROOT/'source').rglob('*') if p.is_file()}
    for path in sorted(old.keys()|new.keys()) if (old_root/'source').exists() else []:
        a=old[path].read_bytes() if path in old else b'';b=new[path].read_bytes() if path in new else b''
        if a==b:continue
        diff.extend(difflib.unified_diff(a.decode('utf-8').splitlines(True),b.decode('utf-8').splitlines(True),fromfile='before/'+path,tofile='after/'+path))
    if not (old_root/'source').exists():
        saved=ROOT/'Skin_Menu_Clean.diff'
        diff=[saved.read_text() if saved.exists() else 'Comparison baseline is not bundled; current sources are in source/.\n']
    (DEST/'Skin_Menu_Clean.diff').write_text(''.join(diff))
    entries={str(p.relative_to(DEST)):sha(p.read_bytes()) for p in sorted(DEST.rglob('*')) if p.is_file()}
    (DEST/'SHA256SUMS.txt').write_text(''.join(f'{digest}  {name}\n' for name,digest in entries.items()))
    archive=ROOT.parent/(NAME+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file():z.write(p,NAME+'/'+str(p.relative_to(DEST)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name,digest in entries.items():assert sha(z.read(NAME+'/'+name))==digest,name
    ui=json.loads((ROOT/'build/visuals_validation.json').read_text())
    report={'passed':True,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
        'dll_sha256':sha((DEST/'bin/skeet.dll').read_bytes()),'manifest_files':len(entries),'zip_crc_verified':True,
        'skinchanger_restyled':True,'skin_menu_cases':ui['skin_menu_cases'],'skin_geometry_cases':54,
        'lua_lifecycle_cases':ui['lua_lifecycle_cases'],'derived_native_model_row_renderers_preserved':True,
        'custom_gameplay_patches_removed':True,'custom_hitscan_patch':False,'custom_prediction_patch':False,
        'custom_interpolation_patch':False,'custom_backtrack_patch':False,'native_core_gameplay_preserved':True,
        'skin_peer_sync_added':False,'game_tested':False,'visual_match_verified_in_game':False}
    (ROOT/'build/package_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    archive.with_suffix('.sha256').write_text(report['sha256']+'  '+archive.name+'\n')
    archive.with_suffix('.validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
