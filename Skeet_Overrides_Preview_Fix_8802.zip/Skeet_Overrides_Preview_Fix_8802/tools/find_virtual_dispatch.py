from pathlib import Path
import struct
from capstone import *
from capstone.x86 import *
b=Path('source/skeet/Binary/skeet_cv.bin').read_bytes();base=0x43310000;md=Cs(CS_ARCH_X86,CS_MODE_32);md.detail=True
for o in range(len(b)-5):
 if b[o]!=0xe8 or (base+o+5+struct.unpack_from('<i',b,o+1)[0])&0xffffffff!=0x433e533f:continue
 for start in range(max(0,o-65),o):
  if b[start:start+3]!=b'\xc7\x44\x24' and b[start:start+3]!=b'\xc7\x84\x24':continue
  ins=list(md.disasm(b[start:o],base+start))
  if not ins or ins[-1].address+ins[-1].size!=base+o:continue
  regs={};stack={};offset=None
  for i in ins:
   op=i.operands
   def get(x):
    if x.type==X86_OP_IMM:return x.imm&0xffffffff
    if x.type==X86_OP_REG:return regs.get(x.reg)
    if x.type==X86_OP_MEM and x.mem.base==X86_REG_ESP and not x.mem.index:return stack.get(x.mem.disp)
   if i.mnemonic=='mov' and len(op)==2:
    v=get(op[1]);a=op[0]
    if a.type==X86_OP_REG:
     regs[a.reg]=v
     if a.reg==X86_REG_ECX and op[1].type==X86_OP_MEM:
      m=op[1].mem;r=regs.get(m.base);s=regs.get(m.index)
      if r is not None and m.index:offset=(r+m.disp)&0xffffffff
      elif s is not None and m.base:offset=(s*m.scale+m.disp)&0xffffffff
    elif a.type==X86_OP_MEM and a.mem.base==X86_REG_ESP and not a.mem.index:stack[a.mem.disp]=v
   elif op and op[0].type==X86_OP_REG:
    r=op[0].reg;v=regs.get(r);x=get(op[1]) if len(op)>1 else None;m=i.mnemonic
    if v is None:continue
    if m in ['xor','add','sub','rol','ror'] and x is None:regs[r]=None;continue
    if m=='xor':v^=x
    elif m=='add':v+=x
    elif m=='sub':v-=x
    elif m=='inc':v+=1
    elif m=='dec':v-=1
    elif m=='neg':v=-v
    elif m=='not':v=~v
    elif m=='bswap':v=int.from_bytes(v.to_bytes(4,'little'),'big')
    elif m=='rol':x%=32;v=(v<<x)|(v>>(32-x))
    elif m=='ror':x%=32;v=(v>>x)|(v<<(32-x))
    else:continue
    regs[r]=v&0xffffffff
  if offset==0x380:
   print(hex(base+o),'start',hex(base+start))
   for i in ins:print(f'{i.address:08x} {i.bytes.hex():24} {i.mnemonic:8} {i.op_str}')
   break
