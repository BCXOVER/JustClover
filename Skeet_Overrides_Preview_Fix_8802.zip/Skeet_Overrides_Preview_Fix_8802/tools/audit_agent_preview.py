"""Static ABI audit against the user's supplied Legacy modules; no DLL startup."""
from pathlib import Path
import hashlib,json,struct,sys
import pefile
from capstone import *
from capstone.x86 import X86_OP_IMM
ROOT=Path(__file__).resolve().parents[1]
GAME=Path('/workspace/game-8802-modules');MODS=Path('/workspace/agent-preview-modules')
md=Cs(CS_ARCH_X86,CS_MODE_32);md.detail=True
expected={'client.dll':('183d42fac8a4ecc24dc02edf5f09122f37fe9e7533ca093a867718b25cfdeb03',GAME),
'materialsystem.dll':('011e6fb57fa1856ae946a442a2aa2c930d5b15447b03c7e67a64337571f92cce',MODS),
'studiorender.dll':('391e9a1fe6c4eddff185cd0001e731494f0347f9d7660a2792de509d436300ab',MODS),
'shaderapidx9.dll':('18ba7e4ea0fb5a51e26b4517999911582ae91e7209267532882855f53cbf230a',MODS)}
images={};reports=[]
for name,(digest,folder) in expected.items():
 p=folder/name;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==digest,name
 pe=pefile.PE(data=b);images[name]=pe.get_memory_mapped_image();reports.append({'module':name,'sha256':digest,'timestamp':hex(pe.FILE_HEADER.TimeDateStamp),'size_of_image':hex(pe.OPTIONAL_HEADER.SizeOfImage)})
def cfg(name,rva):
 b=images[name];todo=[rva];out={}
 while todo:
  a=todo.pop()
  if a in out or not rva<=a<rva+0x2000:continue
  i=next(md.disasm(b[a:a+15],0x10000000+a,count=1),None);assert i is not None
  out[a]=i
  if i.group(CS_GRP_RET):continue
  if i.group(CS_GRP_JUMP):
   if i.operands[0].type==X86_OP_IMM:todo.append(i.operands[0].imm-0x10000000)
   if i.mnemonic=='jmp':continue
  todo.append(a+i.size)
 return list(out.values())
def word(name,at):return struct.unpack_from('<I',images[name],at)[0]
abi=[]
for name,table,slots in [('materialsystem.dll',0x9a80c,{84:16,91:16,97:32,115:0}),
 ('studiorender.dll',0x7a090,{21:4,22:8,23:16,27:4,28:4,33:12,34:0}),
 ('materialsystem.dll',0x9ed88,{22:4,23:0,24:0,25:4,26:4,117:20,120:0}),
 ('materialsystem.dll',0x9fa4c,{52:8}),('shaderapidx9.dll',0x6e930,{289:4})]:
 for slot,pop in slots.items():
  rva=word(name,table+slot*4)-0x10000000;ins=cfg(name,rva)
  rets={int(i.op_str,0) if i.op_str else 0 for i in ins if i.group(CS_GRP_RET)}
  assert pop in rets,(name,slot,hex(rva),pop,rets)
  abi.append({'module':name,'vtable_rva':hex(table),'slot':slot,'function_rva':hex(rva),'stack_argument_bytes':pop})
assert word('shaderapidx9.dll',0x6e930+228*4)==0x100210b0
assert any(i.mnemonic=='jmp' and i.op_str=='dword ptr [eax + 0x484]' for i in cfg('shaderapidx9.dll',0x210b0))
assert any(i.mnemonic=='push' and i.op_str=='0x75c' for i in cfg('client.dll',0x9aeaa0))
ins=cfg('client.dll',0x9acb20)
assert all(any(f'[edi + 0x{x:x}]' in i.op_str for i in ins) for x in [0x46,0x47,0x48,0x49])
b=images['client.dll'];assert b[0x9af0ad:0x9af0b0]==b'\xff\x50\x18'
assert word('client.dll',0xd13990)==0x109af290
assert word('client.dll',0xd13990+4*4)==0x109aec30
assert word('client.dll',0xd13990+6*4)==0x100bc890 # empty original callback
# The 4x4 overload really copies sixteen floats. The adjacent 3x4 overload
# explicitly synthesizes the final row: this catches the MSVC overload order.
assert any(i.op_str.endswith('dword ptr [edx + 0x3c]') for i in cfg('materialsystem.dll',0x395e0))
report={'passed':True,'module_fingerprints':reports,'verified_virtual_calls':abi,'native_merged_mdl_size':0x75c,'native_color_byte_offset':0x46,'owned_bone_callback_return_rva':'0x9af0b0','native_model_matrix_mode':10,'shaderapi_texture_handles':'native Texture_t pointers','game_tested':False}
(ROOT/'build/agent_preview_abi_audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Static ABI audit passed:',len(abi),'native call signatures; exact module SHA256 fingerprints')
