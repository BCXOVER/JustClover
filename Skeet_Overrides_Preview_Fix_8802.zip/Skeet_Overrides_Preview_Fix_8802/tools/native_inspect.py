from pathlib import Path
from capstone import *
import sys,struct
BASE=0x43310000
DATA=(Path(__file__).resolve().parents[1]/'source/skeet/Binary/skeet_cv.bin').read_bytes()
md=Cs(CS_ARCH_X86,CS_MODE_32)
def dis(a,n):
 for i in md.disasm(DATA[a-BASE:a-BASE+n],a):print(f'{i.address:08x} {i.bytes.hex():24} {i.mnemonic:8} {i.op_str}')
if sys.argv[1]=='xref':
 target=int(sys.argv[2],16)
 for off in range(len(DATA)-5):
  if DATA[off] in (0xe8,0xe9) and (BASE+off+5+struct.unpack_from('<i',DATA,off+1)[0])&0xffffffff==target:print(hex(BASE+off))
else:dis(int(sys.argv[1],16),int(sys.argv[2],16))
