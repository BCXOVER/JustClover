#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cwchar>
#include "helper_icon_data.h"
namespace cs2_visuals {
enum Category {Enemy,Team,World,View,Helper,Danger,category_count};
enum Panel {EnemyESP,EnemyModels,TeamESP,TeamModels,OtherESP,WorldModels,Effects,ViewPanel,HUD,DangerItems,HelperSettings,panel_count};
inline constexpr const wchar_t* titles[]={L"Enemy ESP",L"Enemy models",L"Team ESP (shared)",L"Team models",L"Other ESP",L"Colored models",L"Effects",L"View",L"HUD",L"Danger Zone items",L"Grenade Helper"};
inline constexpr int categories[]={Enemy,Enemy,Team,Team,World,World,World,View,View,Danger,Helper};
using Mask=std::uint32_t;
inline constexpr Mask bit(int p){return Mask(1)<<p;}
inline bool eq(const wchar_t* a,const wchar_t* b){return std::wcscmp(a,b)==0;}
inline bool has(const wchar_t* a,const wchar_t* b){return std::wcsstr(a,b)!=nullptr;}
inline Mask route(const wchar_t* group,const wchar_t* name,bool misc=false) {
    if(misc) {
        if(eq(name,L"Override FOV")||eq(name,L"Override zoom FOV")||eq(name,L"Free look"))return bit(ViewPanel);
        if(eq(name,L"Persistent kill feed"))return bit(HUD);
        return 0;
    }
    if(eq(group,L"Player ESP")||eq(group,L"Enemy ESP")) {
        if(eq(name,L"Teammates"))return bit(TeamESP);
        if(eq(name,L"Glow"))return bit(EnemyModels)|bit(TeamModels);
        if(eq(name,L"Hit marker")||eq(name,L"Hit marker sound"))return bit(HUD);
        return bit(EnemyESP)|bit(TeamESP);
    }
    if(eq(group,L"Colored models")) {
        if(has(name,L"Teammate"))return bit(TeamModels);
        if(eq(name,L"Shadow"))return bit(EnemyModels)|bit(WorldModels);
        if(eq(name,L"Player")||eq(name,L"Player behind wall")||eq(name,L"On shot"))return bit(EnemyModels);
        if(has(name,L"Local player")||eq(name,L"Hands")||eq(name,L"Weapon viewmodel"))return bit(ViewPanel);
        return bit(WorldModels);
    }
    if(eq(group,L"Other ESP")) {
        if(eq(name,L"Radar")||eq(name,L"Crosshair")||eq(name,L"Penetration reticle")||
           eq(name,L"Recoil overlay")||eq(name,L"Inaccuracy overlay")||eq(name,L"Spectators")||
           eq(name,L"Feature indicators"))return bit(HUD);
        return bit(OtherESP);
    }
    if(eq(group,L"Effects")) {
        if(has(name,L"Force third person")||eq(name,L"Visual recoil adjustment")||eq(name,L"Instant scope"))return bit(ViewPanel);
        if(eq(name,L"Remove scope overlay"))return bit(HUD);
        if(eq(name,L"Bullet tracers"))return bit(Effects)|bit(EnemyESP);
        return bit(Effects);
    }
    if(has(group,L"Danger Zone"))return bit(DangerItems);
    return bit(OtherESP);
}
inline bool helper_control(const wchar_t* name) {
    return eq(name,L"Helper")||(eq(name,L"Aim at location")||eq(name,L"Aim at locations"))||eq(name,L"Show locations behind walls")||eq(name,L"Hide duplicate locations")||has(name,L"Grenade Helper")||has(name,L"Grenade helper");
}
inline const wchar_t* caption(const wchar_t* name) {
    if(eq(name,L"Player behind wall"))return L"Player through walls";
    if(eq(name,L"Teammate behind wall"))return L"Teammate through walls";
    if(eq(name,L"Out of FOV arrow"))return L"Off-screen arrow";
    if(eq(name,L"Penetration reticle"))return L"Penetration crosshair";
    return name;
}
inline int rank(int panel,const wchar_t* name) {
    constexpr const wchar_t* player[]={L"Activation type",L"Enabled",L"Bounding box",L"Health bar",L"Name",L"Dormant",L"Teammates",L"Flags",L"Skeleton",L"Weapon icon",L"Weapon text",L"Ammo",L"Distance",L"Out of FOV arrow",L"Visualize aimbot",L"Bullet tracers"};
    constexpr const wchar_t* models[]={L"Player",L"Player behind wall",L"Teammate",L"Teammate behind wall",L"Glow",L"Shadow",L"On shot"};
    constexpr const wchar_t* world[]={L"Dropped weapons",L"Grenades",L"Bomb",L"Grenade trajectory",L"Grenade trajectory (hit)",L"Grenade proximity warning",L"Hostages"};
    constexpr const wchar_t* world_models[]={L"Ragdolls",L"Weapons",L"Disable model occlusion",L"Shadow",L"Props"};
    constexpr const wchar_t* effects[]={L"Remove flashbang effects",L"Remove smoke grenades",L"Remove fog",L"Remove skybox",L"Transparent walls",L"Transparent props",L"Brightness adjustment",L"Disable post processing",L"Disable rendering of teammates",L"Disable rendering of ragdolls",L"Bullet tracers"};
    constexpr const wchar_t* view[]={L"Force third person (alive)",L"Force third person (dead)",L"Override FOV",L"Override zoom FOV",L"Instant scope",L"Visual recoil adjustment",L"Local player",L"Local player fake",L"Local player transparency",L"Hands",L"Weapon viewmodel",L"Free look"};
    constexpr const wchar_t* hud[]={L"Feature indicators",L"Spectators",L"Remove scope overlay",L"Inaccuracy overlay",L"Recoil overlay",L"Penetration reticle",L"Crosshair",L"Persistent kill feed",L"Hit marker",L"Hit marker sound",L"Radar"};
    constexpr const wchar_t* helper[]={L"Helper",L"Aim at location",L"Aim at locations",L"Show locations behind walls",L"Hide duplicate locations"};
    const wchar_t* const* order=nullptr;unsigned count=0;
    switch(panel) {
    case HelperSettings:order=helper;count=std::size(helper);break;
    case EnemyESP:case TeamESP:order=player;count=std::size(player);break;
    case EnemyModels:case TeamModels:order=models;count=std::size(models);break;
    case OtherESP:order=world;count=std::size(world);break;
    case WorldModels:order=world_models;count=std::size(world_models);break;
    case Effects:order=effects;count=std::size(effects);break;
    case ViewPanel:order=view;count=std::size(view);break;
    case HUD:order=hud;count=std::size(hud);break;
    }
    for(unsigned i=0;i<count;i++)if(eq(name,order[i]))return int(i);
    return 1000;
}
struct Rect {int x=0,y=0,w=0,h=0;bool operator==(Rect b)const{return x==b.x&&y==b.y&&w==b.w&&h==b.h;}};
struct Layout {Rect category;std::array<Rect,panel_count> panels;std::array<Rect,category_count> icons;};
inline Layout layout(int width,int height,float scale=1,unsigned visible=(1u<<category_count)-1,int reserved=0) {
    scale=std::clamp(scale,.5f,3.f);
    const auto s=[&](int v){return std::max(1,int(v*scale+.5f));};
    const int left=std::min(s(100),width/4),right=std::min(s(25),width/20),top=s(25),bar=s(58),body=s(22),bottom=s(25);
    const int full=std::max(2,width-left-right-std::max(0,reserved)),gap=std::min(s(22),std::max(1,full/8)),col=(full-gap)/2;
    const int y=top+bar+body,h=std::max(s(120),height-y-bottom);
    const Rect a{left,y,col,h},b{left+col+gap,y,full-col-gap,h};
    Layout out{};out.category={left,top,full,bar};
    for(int p=0;p<panel_count;p++)out.panels[p]=(p==EnemyModels||p==TeamModels||p==HUD||p==WorldModels||p==Effects)?b:a;
    const int first=(h-s(14))/2;
    out.panels[WorldModels].h=first;
    out.panels[Effects].y=y+first+s(14);out.panels[Effects].h=h-first-s(14);
    out.panels[HelperSettings]={left,y,full,h};
    int count=0;for(int i=0;i<category_count;i++)if(visible&(1u<<i))++count;
    const int step=std::max(1,std::min(s(74),std::max(1,full-s(36))/std::max(1,count)));
    for(int i=0,slot=0;i<category_count;i++)if(visible&(1u<<i))out.icons[i]={left+s(18)+step*slot++,top+s(11),std::min(s(48),step),s(36)};
    return out;
}
struct Color {unsigned char r,g,b,a=255;unsigned pack()const{return r|(unsigned(g)<<8)|(unsigned(b)<<16)|(unsigned(a)<<24);}};
enum Kind {Fill,Line,Text};
struct Command {Kind kind;Rect r;Color color;const wchar_t* text=nullptr;};
struct Scene {
    std::array<Command,8192> commands{};unsigned count=0;
    void fill(Rect r,Color c){if(r.w>0&&r.h>0&&count<commands.size())commands[count++]={Fill,r,c};}
    void line(int x,int y,int x2,int y2,Color c){if(count<commands.size())commands[count++]={Line,{x,y,x2,y2},c};}
    void text(int x,int y,const wchar_t* t,Color c){if(count<commands.size())commands[count++]={Text,{x,y,0,0},c,t};}
    void disc(int x,int y,int radius,Color c){for(int n=-radius;n<=radius;n++){int half=int(std::sqrt(float(radius*radius-n*n)));fill({x-half,y+n,2*half+1,1},c);}}
};
// All five glyphs share a 32-unit grid and a 1.35-unit outline. Coverage is
// supersampled rather than approximated with blocky rectangles/native lines.
struct Point {float x,y;};
template<std::size_t N> inline bool polygon(float x,float y,const Point(&v)[N]) {
    bool inside=false;
    for(std::size_t i=0,j=N-1;i<N;j=i++)
        if((v[i].y>y)!=(v[j].y>y)&&x<(v[j].x-v[i].x)*(y-v[i].y)/(v[j].y-v[i].y)+v[i].x)inside=!inside;
    return inside;
}
inline bool disk(float x,float y,float cx,float cy,float r) {
    x-=cx;y-=cy;return x*x+y*y<=r*r;
}
inline bool segment(float x,float y,float ax,float ay,float bx,float by,float width) {
    const float dx=bx-ax,dy=by-ay;
    const float t=std::clamp(((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy),0.f,1.f);
    return disk(x,y,ax+t*dx,ay+t*dy,width*.5f);
}
inline bool glyph(int category,float x,float y) {
    if(category==Helper) {
        const int px=std::clamp(int(x*3),0,95),py=std::clamp(int(y*3),0,95);
        return helper_icon::coverage[py*96+px]>=8;
    }
    if(category==Enemy||category==Team) {
        const bool head=disk(x,y,12,7,5.1f);
        const float dx=(x-12)/9.5f,dy=(y-24)/10.8f;
        const bool body=y>=15&&y<=28&&dx*dx+dy*dy<=1;
        // Clear separation between the user silhouette and its category badge.
        const bool silhouette=(head||body)&&!disk(x,y,24,24,8.1f);
        if(category==Team)return silhouette||segment(x,y,24,19.5f,24,28.5f,2.4f)||segment(x,y,19.5f,24,28.5f,24,2.4f);
        const bool ring=disk(x,y,24,24,6.6f)&&!disk(x,y,24,24,5.1f);
        return silhouette||ring||segment(x,y,20,20,28,28,1.5f);
    }
    if(category==World) {
        const float d=(x-16)*(x-16)+(y-16)*(y-16);
        if(d>13*13)return false;
        if(d>11.65f*11.65f)return true;
        constexpr Point america[]={{5,8},{9,5},{14,5},{15,8},{12,10},{12,13},{15,15},{14,18},{12,18},{11,23},{9,26},{8,22},{9,18},{6,16},{4,12}};
        constexpr Point eurasia[]={{17,4},{23,5},{27,9},{24,11},{26,13},{28,16},{25,17},{22,14},{20,15},{19,18},{20,21},{17,25},{15,23},{15,18},{16,15},{19,12},{17,10},{14,10},{15,7}};
        constexpr Point australia[]={{24,23},{27,22},{29,25},{26,27},{23,26}};
        return polygon(x,y,america)||polygon(x,y,eurasia)||polygon(x,y,australia);
    }
    if(category==View) {
        const float u=(x-16)/15;
        if(std::fabs(u)>1)return false;
        const float edge=8*(1-u*u),inner=6.35f*(1-u*u);
        const float dy=std::fabs(y-16);
        return (dy<=edge&&dy>=inner)|| (disk(x,y,16,16,5.3f)&&!disk(x,y,16,16,3.6f))||disk(x,y,16,16,1.7f);
    }
    const bool ring=disk(x,y,14,18,11.5f)&&!disk(x,y,14,18,9.8f);
    const bool body=disk(x,y,14,18,8.1f)&&!disk(x,y,18,13,6.8f);
    return ((ring||body)&&!disk(x,y,25,7,6.2f))||disk(x,y,25,7,4.3f);
}
inline void icon(Scene& scene,int category,Rect r,Color color,float scale=1) {
    const int extent=std::max(1,std::min({std::clamp(int(32*scale+.5f),8,96),r.w,r.h}));
    // Coverage changes only with DPI, not with position/hover/active category.
    static std::array<std::array<unsigned char,96*96>,category_count> masks{};
    static int cached_extent=0;
    if(cached_extent!=extent) {
        for(int cat=0;cat<category_count;cat++)for(int py=0;py<extent;py++)for(int px=0;px<extent;px++) {
            unsigned char coverage=0;
            for(int sy=0;sy<4;sy++)for(int sx=0;sx<4;sx++)
                coverage+=glyph(cat,(px+(sx+.5f)/4)*32/extent,(py+(sy+.5f)/4)*32/extent);
            masks[cat][py*extent+px]=coverage;
        }
        cached_extent=extent;
    }
    const int left=r.x+(r.w-extent)/2,top=r.y+(r.h-extent)/2;
    for(int py=0;py<extent;py++) {
        int run=0,last=-1;
        for(int px=0;px<=extent;px++) {
            int coverage=0;
            if(px<extent)coverage=masks[category][py*extent+px];
            if(coverage!=last||px==extent) {
                if(last>0) {Color c=color;c.a=static_cast<unsigned char>((unsigned(color.a)*last+8)/16);scene.fill({left+run,top+py,px-run,1},c);}
                run=px;last=coverage;
            }
        }
    }
}
inline void category_scene(Scene& scene,Rect bar,const std::array<Rect,category_count>& buttons,int active,int count,float scale,float alpha,int hovered=-1,unsigned visible=(1u<<category_count)-1,int reserved=0) {
    const int title_space=std::max(1,int(10*scale));
    scene.count=0;scene.fill({bar.x+1,bar.y+title_space,bar.w-2,bar.h-title_space-1},{23,23,23,255});
    for(int i=0;i<count;i++)if(visible&(1u<<i))icon(scene,i,buttons[i],i==active?Color{225,225,225,255}:(i==hovered?Color{160,160,160,255}:Color{100,100,100,255}),scale);
    alpha=std::clamp(alpha,0.f,1.f);
    for(unsigned i=0;i<scene.count;i++)scene.commands[i].color.a=static_cast<unsigned char>(scene.commands[i].color.a*alpha);
}
}
