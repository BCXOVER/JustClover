#pragma once
#include "agent_preview_plan.h"
#include <windows.h>
#include <cstring>
namespace agent_preview {
// Exact PE headers + relocation-independent entry checks for the supplied
// Legacy modules. Never execute an uploaded image or map it into the game.
struct Module {const wchar_t* name;unsigned timestamp,size;unsigned char* base=nullptr;};
inline Module client{L"client.dll",0x65272025,0x5509000},materials{L"materialsystem.dll",0x63dc3de4,0x114000},
 studio{L"studiorender.dll",0x63dc118b,0x45e000},shader{L"shaderapidx9.dll",0x63dc1158,0xce000};
inline bool readable(const void* p,std::size_t bytes,bool write=false){return local_inventory_client::memory(p,bytes,write);}
inline unsigned word(const void* p,unsigned off=0){unsigned v;std::memcpy(&v,static_cast<const unsigned char*>(p)+off,4);return v;}
inline void* ptr(const void* p,unsigned off=0){return reinterpret_cast<void*>(word(p,off));}
inline void put(void* p,unsigned off,unsigned v){std::memcpy(static_cast<unsigned char*>(p)+off,&v,4);}
inline bool module(Module& m) {
 auto* b=reinterpret_cast<unsigned char*>(GetModuleHandleW(m.name));if(!readable(b,0x1000)||word(b,0x3c)>0x800)return false;
 const auto peoff=word(b,0x3c);auto* pe=reinterpret_cast<const IMAGE_NT_HEADERS32*>(b+peoff);
 if(*reinterpret_cast<unsigned short*>(b)!=IMAGE_DOS_SIGNATURE||pe->Signature!=IMAGE_NT_SIGNATURE||pe->FileHeader.Machine!=IMAGE_FILE_MACHINE_I386||pe->FileHeader.TimeDateStamp!=m.timestamp||pe->OptionalHeader.SizeOfImage!=m.size)return false;
 if(m.base&&m.base!=b)return false;m.base=b;return true;
}
inline bool prefix(Module& m,unsigned off,const unsigned char* bytes,unsigned size){return readable(m.base+off,size)&&!std::memcmp(m.base+off,bytes,size);}
inline void *mat=nullptr,*sr=nullptr,*sa=nullptr,*cache=nullptr,*target=nullptr,*cubemap=nullptr;
inline void* entry(void* obj,unsigned slot) {
 // The existing core can shadow an interface vtable. Keep the same native
 // object/state, but use the audited module entries for our scene setup.
 // Own CMergedMDL callbacks and context/texture subtype dispatch remain virtual.
 if(obj&&obj==mat)return ptr(materials.base+0x9a80c,slot*4);
 if(obj&&obj==sr)return ptr(studio.base+0x7a090,slot*4);
 if(obj&&obj==sa)return ptr(shader.base+0x6e930,slot*4);
 return (*static_cast<void***>(obj))[slot];
}
inline void* method(void* obj,unsigned slot,Module& m) {
 if(!readable(obj,4))return nullptr;auto* t=ptr(obj);if(!readable(t,(slot+1)*4))return nullptr;auto* f=entry(obj,slot);
 const auto at=reinterpret_cast<std::uintptr_t>(f),base=reinterpret_cast<std::uintptr_t>(m.base);
 if(!m.base||at<base+0x1000||at>=base+m.size)return nullptr;
 MEMORY_BASIC_INFORMATION info{};if(!VirtualQuery(f,&info,sizeof(info))||!(info.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY)))return nullptr;return f;
}
template<class R,class... A> inline R call(void* obj,unsigned slot,A... args) {
 using F=R(__thiscall*)(void*,A...);return reinterpret_cast<F>(entry(obj,slot))(obj,args...);
}
inline void* factory(Module& m,const char* name){using F=void*(__cdecl*)(const char*,int*);auto f=reinterpret_cast<F>(GetProcAddress(reinterpret_cast<HMODULE>(m.base),"CreateInterface"));return f?f(name,nullptr):nullptr;}
inline void* chams[4]{};
inline const wchar_t* diagnostic=L"Loading agent preview";
inline bool bound=false,failed=false;
inline unsigned retry_at=0;
struct Joint {float x=0,y=0;int parent=-1;bool used=false,valid=false;};
struct Model {alignas(16) unsigned char bytes[0x75c]{};void* table[9]{};Joint joints[256]{};unsigned joint_count=0;float bounds[4]{.1f,.05f,.8f,.9f};bool constructed=false,loaded=false;};
inline Model player,weapon;
inline Schedule schedule;
inline bool initialize() {
 if(bound)return true;if(failed)return false;
 const unsigned now=GetTickCount();if(retry_at&&int(now-retry_at)<0)return false;retry_at=now+2000;
 if(!module(client)||!module(materials)||!module(studio)||!module(shader)){diagnostic=L"Preview: unsupported or missing game module";return false;}
 constexpr unsigned char ctor[]={0x53,0x8b,0xd9,0x56,0x57,0x8d,0x4b,4};
 constexpr unsigned char draw[]={0x55,0x8b,0xec,0xb8,0x2c,0x30,0,0};
 if(!prefix(client,0x9ae9a0,ctor,sizeof(ctor))||!prefix(client,0x9aefd0,draw,sizeof(draw))){failed=true;diagnostic=L"Preview: model ABI differs";return false;}
 mat=factory(materials,"VMaterialSystem080");sr=factory(studio,"VStudioRender026");sa=factory(shader,"ShaderApi029");
 cache=readable(client.base+0x534d6d4,4)?ptr(client.base+0x534d6d4):nullptr;
 if(!readable(sr,0x278)||!mat||!sa||!cache){diagnostic=L"Preview: renderer is not ready";return false;}
 for(unsigned s:{84u,91u,97u,115u})if(!method(mat,s,materials))return false;
 for(unsigned s:{21u,22u,23u,27u,28u,33u,34u})if(!method(sr,s,studio))return false;
 if(!method(sa,228,shader)||!local_inventory_client::memory(cache,4))return false;
 // Ex (97) owns an extra reference and supports late creation. Ex2 requires
 // Begin/EndRenderTargetAllocation, which resets game resources: never use it.
 target=call<void*>(mat,97,"_skeet_ct_preview_8802",texture_width,texture_height,5,12,1,0xcu,0u);
 if(!target||!method(target,15,materials)||call<bool>(target,15)||call<int>(target,3)!=texture_width||call<int>(target,4)!=texture_height){failed=true;diagnostic=L"Preview: render target unavailable";return false;}
 cubemap=call<void*>(mat,91,"engine/defaultcubemap","CubeMap textures",true,0);
 if(cubemap&&call<bool>(cubemap,15))cubemap=nullptr;
 chams[1]=call<void*>(mat,84,"debug/debugambientcube","Model textures",true,static_cast<const char*>(nullptr));
 chams[2]=call<void*>(mat,84,"debug/debugdrawflat","Model textures",true,static_cast<const char*>(nullptr));
 chams[3]=call<void*>(mat,84,"dev/glow_armsrace","Model textures",true,static_cast<const char*>(nullptr));
 for(unsigned s=1;s<4;s++)if(chams[s]&&call<bool>(chams[s],42))chams[s]=nullptr;
 bound=true;diagnostic=L"CT | SAS";return true;
}
// This callback belongs only to our own CMergedMDL objects. No game entity
// or global StudioRender vtable is patched. The audited native caller keeps
// the root CStudioHdr and freshly built bone matrices at these frame slots.
inline void __cdecl capture_bones(void* self,void* frame,unsigned return_address) {
 if(return_address!=reinterpret_cast<unsigned>(client.base+0x9af0b0)||self!=player.bytes||!readable(static_cast<unsigned char*>(frame)-0x10,0x14))return;
 auto* header_wrapper=ptr(static_cast<unsigned char*>(frame)-4);auto* bones=ptr(static_cast<unsigned char*>(frame)-0x10);
 if(!readable(header_wrapper,4))return;auto* hdr=ptr(header_wrapper);
 if(!readable(hdr,0xa4)||word(hdr)!=0x54534449)return;
 const unsigned n=word(hdr,0x9c),offset=word(hdr,0xa0),length=word(hdr,0x4c);
 if(!n||n>256||length<0xa4||length>32*1024*1024||offset>length||n>(length-offset)/216||!readable(hdr,length)||!readable(bones,n*48))return;
 float lo_x=1,lo_y=1,hi_x=0,hi_y=0;unsigned visible=0;const auto proj=projection(false);
 player.joint_count=n;
 for(unsigned i=0;i<n;i++) {
  auto& out=player.joints[i];out={};auto* bone=static_cast<unsigned char*>(hdr)+offset+i*216;
  out.parent=int(word(bone,4));out.used=(word(bone,0xa0)&0x100)!=0;
  const auto* matrix=reinterpret_cast<const float*>(static_cast<const unsigned char*>(bones)+i*48);
  const float depth=110.f-matrix[3];if(!std::isfinite(depth)||depth<1)continue;
  out.x=.5f+matrix[7]*proj.v[0]/depth*.5f;out.y=.5f-(matrix[11]-36.f)*proj.v[5]/depth*.5f;
  out.valid=std::isfinite(out.x)&&std::isfinite(out.y)&&out.x>=0&&out.x<=1&&out.y>=0&&out.y<=1;
  if(out.valid&&out.used){lo_x=std::min(lo_x,out.x);lo_y=std::min(lo_y,out.y);hi_x=std::max(hi_x,out.x);hi_y=std::max(hi_y,out.y);visible++;}
 }
 if(visible>2) {const float x=std::max(0.f,lo_x-.025f),y=std::max(0.f,lo_y-.025f);player.bounds[0]=x;player.bounds[1]=y;player.bounds[2]=std::min(1.f,hi_x+.025f)-x;player.bounds[3]=std::min(1.f,hi_y+.025f)-y;}
}
__declspec(naked) inline void capture_bones_thunk() {
 __asm {pushfd
 pushad
 mov edx, dword ptr [esp+36]
 push edx
 push ebp
 push ecx
 call capture_bones
 add esp, 12
 popad
 popfd
 ret}
}
inline bool model_ready(Model& model,bool weapon_only) {
 if(model.loaded)return true;if(model.constructed)return false;
 using Ctor=void*(__thiscall*)(void*);reinterpret_cast<Ctor>(client.base+0x9ae9a0)(model.bytes);model.constructed=true;
 std::memcpy(model.table,ptr(model.bytes),sizeof(model.table));
 if(!weapon_only)model.table[6]=reinterpret_cast<void*>(&capture_bones_thunk);
 put(model.bytes,0,reinterpret_cast<unsigned>(model.table));
 call<void>(model.bytes,4,weapon_only?weapon_path:animation_path,static_cast<void*>(nullptr),static_cast<void*>(nullptr));
 if(*reinterpret_cast<unsigned short*>(model.bytes+0x40)==0xffff){diagnostic=L"Preview: model asset missing";return false;}
 if(!weapon_only) {
  using Merge=unsigned short(__thiscall*)(void*,const char*,void*,void*,bool);
  const auto h=reinterpret_cast<Merge>(client.base+0x9af480)(model.bytes,agent_path,nullptr,nullptr,false);
  if(h==0xffff){diagnostic=L"Preview: CT model asset missing";return false;}
  // Attachment is optional; the agent remains available without the weapon.
  reinterpret_cast<Merge>(client.base+0x9af480)(model.bytes,weapon_path,nullptr,nullptr,false);
 }
 // Select an idle sequence by label in the locally stored UI animation set.
 // Validate all offsets against the native studiohdr length before reading.
 using GetHdr=void*(__thiscall*)(void*,unsigned short);
 auto* get=(*static_cast<void***>(cache))[14];auto* hdr=reinterpret_cast<GetHdr>(get)(cache,*reinterpret_cast<unsigned short*>(model.bytes+0x40));
 unsigned sequence=0;
 if(readable(hdr,0xc4)&&word(hdr)==0x54534449) {
  const unsigned len=word(hdr,0x4c),count=word(hdr,0xbc),start=word(hdr,0xc0);
  if(count<=4096&&len<=32*1024*1024&&start<=len&&count<=(len-start)/212&&readable(hdr,len))
   for(unsigned i=0;i<count;i++) {
    const unsigned at=start+i*212,off=word(hdr,at+4);if(off>=len-at)continue;
    const char* name=static_cast<const char*>(hdr)+at+off;const auto remaining=len-at-off;
    if(remaining<5||!std::memchr(name,0,std::min<unsigned>(remaining,96)))continue;
    if(!std::strcmp(name,"idle")||!std::strcmp(name,"idle_unarmed")||!std::strcmp(name,"idle_rifle")){sequence=i;break;}
   }
 }
 put(model.bytes,0x58,sequence);model.bytes[0x679]=1;
 model.loaded=true;return true;
}
// Native CMDL RGBA is packed at +0x46 (unaligned), not the older SDK's
// assumed aligned offset. CMergedMDL adds its own vptr at +0x0.
inline void tint(Model& m,unsigned rgba,float time) {
 put(m.bytes,0x4a,rgba);std::memcpy(m.bytes+0x64,&time,4);
 const unsigned n=word(m.bytes,0x6e0);auto* list=ptr(m.bytes,0x6d4);
 if(n<=4&&(!n||readable(list,n*0x6d4,true)))for(unsigned i=0;i<n;i++) {
  auto* mdl=static_cast<unsigned char*>(list)+i*0x6d4;put(mdl,0x46,rgba);std::memcpy(mdl+0x60,&time,4);
 }
}
struct StudioState {
 float view[12],ambient[24],color[3],alpha;unsigned char lights[0x160];unsigned count;
 StudioState(){std::memcpy(view,static_cast<unsigned char*>(sr)+0x4c,sizeof(view));std::memcpy(ambient,static_cast<unsigned char*>(sr)+0x7c,sizeof(ambient));std::memcpy(lights,static_cast<unsigned char*>(sr)+0xdc,sizeof(lights));count=word(sr,0x23c);std::memcpy(color,static_cast<unsigned char*>(sr)+0x240,sizeof(color));std::memcpy(&alpha,static_cast<unsigned char*>(sr)+0x24c,4);}
 void restore() {
  call<void>(sr,33,static_cast<void*>(nullptr),0,-1);
  call<void>(sr,21,ambient);call<void>(sr,22,int(count),lights);
  call<void>(sr,23,view,view+3,view+6,view+9);call<void>(sr,27,color);call<void>(sr,28,alpha);
 }
};
inline bool render(unsigned now,int subject,Style style) {
 if(!initialize())return false;
 if(!schedule.due(now,subject,style))return true;
 auto& model=subject==3?weapon:player;if(!model_ready(model,subject==3))return false;
 // Never overwrite another pass's forced material or unsupported lighting.
 if(call<bool>(sr,34)||word(sr,0x23c)>4){diagnostic=L"Preview: waiting for render pass";return false;}
 auto* ctx=call<void*>(mat,115);if(!ctx)return false;
 const auto table=ptr(ctx);const bool known=table==materials.base+0x9ed88||table==materials.base+0x9a414;
 if(!known||!readable(ctx,0x70)){call<int>(ctx,1);diagnostic=L"Preview: unsupported render context";return false;}
 const unsigned old_mode=word(ctx,0x68);if(old_mode>63){call<int>(ctx,1);return false;}
 const auto old_cube=ptr(ctx,0x1c);const auto clear_color=word(sa,0x17e4);StudioState saved;
 call<void>(ctx,2);
 call<void>(ctx,117,target,0,0,texture_width,texture_height);
 // Snapshot every matrix independently and restore the previously selected
 // mode, not merely a guessed default. Avoid global camera/ViewSetup hooks.
 const Matrix matrices[]={view(subject==3),projection(subject==3),identity()};
 constexpr int modes[]={0,1,10};
 for(unsigned i=0;i<3;i++){call<void>(ctx,22,modes[i]);call<void>(ctx,23);call<void>(ctx,26,matrices[i].v);}
 call<void>(ctx,79,static_cast<unsigned char>(17),static_cast<unsigned char>(17),static_cast<unsigned char>(17),static_cast<unsigned char>(255));
 call<void>(ctx,12,true,true,true);if(cubemap)call<void>(ctx,5,cubemap);
 float ambient[24];for(unsigned i=0;i<6;i++){ambient[4*i]=ambient[4*i+1]=ambient[4*i+2]=.7f;ambient[4*i+3]=1;}
 call<void>(sr,21,ambient);call<void>(sr,22,0,static_cast<const unsigned char*>(nullptr));
 float origin[]={subject==3?60.f:110.f,0,subject==3?0.f:36.f},right[]={0,1,0},up[]={0,0,1},normal[]={1,0,0};
 call<void>(sr,23,origin,right,up,normal);
 auto index=static_cast<unsigned>(style.material);if(index>3)index=0;
 if(index&&!chams[index]){index=0;diagnostic=L"Preview: material unavailable; original model";}else diagnostic=subject==3?L"AWP model preview":L"CT | SAS";
 call<void>(sr,33,chams[index],0,-1);tint(model,style.rgba,schedule.advance(now));
 float transform[]={.9659258f,.258819f,0,0,-.258819f,.9659258f,0,0,0,0,1,0};
 if(subject==3){transform[0]=transform[5]=0;transform[1]=-1;transform[4]=1;}
 if(subject!=3)player.joint_count=0;
 call<void>(model.bytes,0,transform);
 saved.restore();call<void>(ctx,5,old_cube);
 for(int i=2;i>=0;i--){call<void>(ctx,22,modes[i]);call<void>(ctx,24);}
 call<void>(ctx,22,int(old_mode));call<void>(ctx,79,static_cast<unsigned char>(clear_color>>16),static_cast<unsigned char>(clear_color>>8),static_cast<unsigned char>(clear_color),static_cast<unsigned char>(clear_color>>24));call<void>(ctx,120);call<void>(ctx,3);call<void>(ctx,4,false);call<int>(ctx,1);
 schedule.submitted(now,subject,style);return true;
}
// GPU-only handoff into the original renderer's texture record. The native
// renderer already releases record+0x24 during device loss and recreates it
// from the fixed-size CPU placeholder. Rebind to the engine's new target on
// the next frame, preserving COM ownership (one AddRef for this record).
inline int texture_id=-1;
inline void* renderer_owner=nullptr;
inline bool gpu_texture(SkeetSDK::IRenderer* renderer) {
 if(!target||!method(target,52,materials))return false;
 auto* handle=call<void*>(target,52,0,0);if(!readable(handle,16))return false;
 auto* gpu=call<void*>(sa,228,handle);if(!readable(gpu,4))return false;
 auto* backend=reinterpret_cast<unsigned char*>(renderer)+4;
 if(!readable(backend,8)||!readable(ptr(backend),84)||ptr(ptr(backend),19*4)!=reinterpret_cast<void*>(0x4336b39c)||ptr(ptr(backend),20*4)!=reinterpret_cast<void*>(0x4335bc40))return false;
 auto* data=ptr(backend,4);if(!readable(data,0xd8,true))return false;
 if(renderer_owner&&renderer_owner!=data){diagnostic=L"Preview: renderer replaced";return false;}
 // Prove the engine texture belongs to exactly the menu's D3D9 device.
 void* device=nullptr;using Device=long(__stdcall*)(void*,void**);
 if(reinterpret_cast<Device>((*static_cast<void***>(gpu))[3])(gpu,&device)<0||!device)return false;
 const bool same=device==ptr(data,0xc8);using Ref=unsigned long(__stdcall*)(void*);
 reinterpret_cast<Ref>((*static_cast<void***>(device))[2])(device);if(!same)return false;
 if(texture_id<0) {
  static unsigned char pixels[texture_width*texture_height*4]{};
  texture_id=renderer->AddTexture(pixels,texture_width,texture_height,sizeof(pixels),0,0x41505256);renderer_owner=data;
 }
 const auto begin=word(data,0xd0),end=word(data,0xd4);
 if(texture_id<0||end<begin||(end-begin)%0x2c||unsigned(texture_id)>=(end-begin)/0x2c)return false;
 auto* record=reinterpret_cast<unsigned char*>(begin)+texture_id*0x2c;
 if(!readable(record,0x2c,true)||word(record)!=0x41505256||word(record,4)!=texture_width||word(record,8)!=texture_height)return false;
 if(ptr(record,0x24)!=gpu) {
  reinterpret_cast<Ref>((*static_cast<void***>(gpu))[1])(gpu);
  auto* old=ptr(record,0x24);put(record,0x24,reinterpret_cast<unsigned>(gpu));record[0x28]=0;
  if(old)reinterpret_cast<Ref>((*static_cast<void***>(old))[2])(old);
 }else record[0x28]=0;
 return true;
}
inline void pause(){schedule.pause();}
}
