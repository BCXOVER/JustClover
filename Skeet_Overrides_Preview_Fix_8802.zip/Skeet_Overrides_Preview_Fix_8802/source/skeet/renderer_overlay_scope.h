#pragma once
// Native slot 27 reports the clipping DISABLE bit (+0x69). ResetBounds(true)
// disables clipping; SetBounds only changes the rectangle. Preserve both.
struct RendererOverlayScope {
 SkeetSDK::IRenderer* r;float alpha=1,depth=0;int bounds[4]{};bool disabled=false;
 explicit RendererOverlayScope(SkeetSDK::IRenderer* renderer):r(renderer){
  std::memcpy(&alpha,reinterpret_cast<const char*>(r)+0x80,4);if(!std::isfinite(alpha)||alpha<0||alpha>1)alpha=1;
  depth=r->GetZBuff();disabled=r->IsBoundsPresent();r->GetBounds(bounds);r->ResetBounds(true);r->SetZBuff(0);r->SetAlpha(1);
 }
 ~RendererOverlayScope(){r->SetBounds(bounds);r->ResetBounds(disabled);r->SetZBuff(depth);r->SetAlpha(alpha);}
};
