#pragma once
namespace motion_settings {
inline constexpr int interpolation=1;
inline constexpr int interpolation_gap=8;
// Additional extrapolation is disabled; there is no UI writer or worker hook.
inline constexpr int extrapolation=0;
inline constexpr int extrapolation_ticks=0;
}
