#pragma once
#include <cstdint>
#include <cmath>
namespace agent_preview {
inline constexpr int texture_width=256,texture_height=512;
inline constexpr char agent_path[]="models/player/custom_player/legacy/ctm_sas.mdl";
inline constexpr char animation_path[]="models/player/custom_player/uiplayer/animset_uiplayer.mdl";
inline constexpr char weapon_path[]="models/weapons/w_snip_awp.mdl";
enum class Material:unsigned {Original,Shaded,Solid,Glow};
struct Style {Material material=Material::Original;std::uint32_t rgba=0xffffffff;bool operator==(const Style&)const=default;};
// A fixed target is independent of menu size/DPI. No model/texture creation on
// resize; inactive menus submit no render work. Unsigned subtraction handles
// GetTickCount wrap. Animation never catches up a long pause in one frame.
struct Schedule {
 std::uint32_t last=0;Style previous{};int previous_subject=-1;bool valid=false;float animation=0;
 bool due(std::uint32_t now,int subject,Style style)const{return !valid||subject!=previous_subject||!(style==previous)||now-last>=33;}
 float advance(std::uint32_t now){const auto elapsed=valid?now-last:0;animation+=float(elapsed>100?100:elapsed)*.001f;return animation;}
 void submitted(std::uint32_t now,int subject,Style style){last=now;previous=style;previous_subject=subject;valid=true;}
 void pause(){valid=false;}
};
struct Matrix {float v[16];};
inline Matrix identity(){Matrix a{};a.v[0]=a.v[5]=a.v[10]=a.v[15]=1;return a;}
inline Matrix view(bool weapon) {
 // Source camera: +X side, looking -X; right +Y, up +Z.
 Matrix a{};a.v[1]=1;a.v[6]=1;a.v[7]=weapon?0.f:-36.f;a.v[8]=1;a.v[11]=weapon?-60.f:-110.f;a.v[15]=1;return a;
}
inline Matrix projection(bool weapon) {
 Matrix a{};const float near_plane=1,far_plane=512;
 const float f=1.f/std::tan((weapon?36.f:28.f)*.00872664626f);
 a.v[0]=f;a.v[5]=f*float(texture_width)/texture_height;a.v[10]=-far_plane/(far_plane-near_plane);a.v[11]=-far_plane*near_plane/(far_plane-near_plane);a.v[14]=-1;return a;
}
}
