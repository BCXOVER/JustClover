#pragma once
#include "cs2_visuals_design.h"
#include <atomic>
#include <cwctype>
namespace menu_interaction {
using cs2_visuals::Rect;
inline bool inside(Rect r,int x,int y){return x>=r.x&&y>=r.y&&x<r.x+r.w&&y<r.y+r.h;}
inline unsigned opacity(unsigned c,float alpha){return (c&0xffffffu)|(unsigned(float(c>>24)*std::clamp(alpha,0.f,1.f))<<24);}
struct Transition {
 int tab=-1,category=-1;unsigned started=0;bool fading=false;
 void observe(int t,int c,unsigned now){if(tab>=0&&(tab!=t||category!=c)){started=now;fading=true;}tab=t;category=c;}
 float cover(unsigned now){const unsigned dt=now-started;if(!fading||dt>=150){fading=false;return 0;}const float t=float(dt)/150;return 1-t*t*(3-2*t);}
};
// Alias matching is deliberately narrow. Ordinary aimbot settings remain inline.
inline int detail(const wchar_t* n) {
 using cs2_visuals::eq;
 if(eq(n,L"Multi-point scale")||eq(n,L"Dynamic multi-point"))return 0;
 if(eq(n,L"Quick stop options"))return 1;
 if(eq(n,L"Maximum peek distance")||eq(n,L"Quick peek assist mode")||eq(n,L"Quick peek assist distance"))return 2;
 if(eq(n,L"Double tap quick stop")||eq(n,L"Double tap mode")||eq(n,L"Double tap hit chance")||eq(n,L"Double tap fake lag limit"))return 3;
 if(eq(n,L"Refine shot"))return 4;
 return -1;
}
inline constexpr const wchar_t* anchors[]={L"Multi-point",L"Quick stop",L"Quick peek assist",L"Double tap",L"Accuracy boost",L"Minimum damage override",L"Minimum hit chance override"};
inline constexpr int flag_count=11;
inline constexpr const wchar_t* flag_names[]={L"Money",L"Armor",L"Zoom",L"Blind",L"Reload",L"Bomb",L"VIP",L"Defuse",L"FD",L"Pin pulled",L"Hit"};
inline constexpr const wchar_t* samples[]={L"$6000",L"HK",L"ZOOM",L"BLIND",L"RELOAD",L"C4",L"VIP",L"DEFUSE",L"FD",L"PIN",L"HIT"};
inline constexpr unsigned flag_colors[]={0xff66b8a3u,0xffeeeeeEu,0xffffc66au,0xffffb862u,0xffffb862u,0xff7878ddu,0xff956cefu,0xff9582efu,0xffeeeeeeu,0xff879bdfu,0xffeeeeeeu};
inline int flag(const wchar_t* t,unsigned length=0) {
 if(!t)return -1;if(!length){while(length<32&&t[length])++length;}if(!length||length>32)return -1;
 wchar_t n[33]{};unsigned j=0;for(unsigned i=0;i<length;i++)if(t[i]!=L' '&&t[i]!=L'-'&&t[i]!=L'_')n[j++]=std::towupper(t[i]);
 const auto equal=[&](const wchar_t* s){return !std::wcscmp(n,s);};
 if(n[0]==L'$')return 0;
 if(equal(L"MONEY"))return 0;
 if(equal(L"ARMOR")||equal(L"HK")||equal(L"K")||equal(L"HELMET"))return 1;
 if(equal(L"ZOOM")||equal(L"ZOOMED")||equal(L"SCOPED"))return 2;
 if(equal(L"BLIND")||equal(L"FLASHED"))return 3;
 if(equal(L"RELOAD")||equal(L"RELOADING"))return 4;
 if(equal(L"BOMB")||equal(L"C4"))return 5;
 if(equal(L"VIP"))return 6;
 if(equal(L"DEFUSE")||equal(L"DEFUSING")||equal(L"DEFUSER"))return 7;
 if(equal(L"FD")||equal(L"FAKEDUCK")||equal(L"DUCKING"))return 8;
 if(equal(L"PIN")||equal(L"PINPULLED"))return 9;
 if(equal(L"HIT"))return 10;
 return -1;
}
enum Side{Right,Left,Top,Bottom};
struct Placement {
 Side side=Right;float along=0;bool custom=false;
 unsigned pack()const{return (custom?0x80000000u:0u)|(unsigned(side)&3u)|(unsigned(std::clamp(along,0.f,1.f)*65535.f+.5f)<<2);}
 static Placement unpack(unsigned n){return {Side(n&3),float((n>>2)&65535)/65535.f,(n&0x80000000u)!=0};}
};
inline std::atomic<unsigned> placements[flag_count]{};
inline Rect placed(Rect box,int w,int h,Placement p,int rank,float dpi=1) {
 const int gap=std::max(3,int(5*dpi));const int along=int(p.along*float(p.side<=Left?std::max(0,box.h-h):std::max(0,box.w-w)));
 if(!p.custom)return {box.x+box.w+gap,box.y+rank*std::max(h+2,int(12*dpi)),w,h};
 switch(p.side){case Right:return {box.x+box.w+gap,box.y+along,w,h};case Left:return {box.x-w-gap-int(7*dpi),box.y+along,w,h};case Top:return {box.x+along,box.y-h-int(18*dpi),w,h};default:return {box.x+along,box.y+box.h+int(20*dpi),w,h};}
}
inline Placement dropped(Rect box,int x,int y) {
 const float nx=float(x-box.x)/std::max(1,box.w),ny=float(y-box.y)/std::max(1,box.h);
 const float distances[]={std::fabs(nx-1),std::fabs(nx),std::fabs(ny),std::fabs(ny-1)};int side=0;
 for(int i=1;i<4;i++)if(distances[i]<distances[side])side=i;
 return {Side(side),std::clamp(side<2?ny:nx,0.f,1.f),true};
}
struct Candidate {Rect box;bool enemy=true;};
inline int owner(const Candidate* list,unsigned count,int x,int y) {
 int found=-1;float best=1e9f,second=1e9f;
 for(unsigned i=0;i<count;i++) {
  const auto b=list[i].box;if(b.w<=1||b.h<=1||y<b.y-4||y>b.y+b.h+4)continue;
  const float dx=std::fabs(float(x-b.x-b.w)-5.f);
  if(dx>std::max(8.f,float(b.w)*.22f))continue;
  const float score=dx+std::fabs(float(y-b.y))*.02f;
  if(score<best){second=best;best=score;found=int(i);}else second=std::min(second,score);
 }
 return found>=0&&second-best>3.f&&list[found].enemy?found:-1;
}
struct Preview {
 Rect area,model,settings,gear,reset;float scale=1;int reserved=0;
};
inline Preview preview(Rect menu,int screen_w,int screen_h,float dpi) {
 // Always dock inside Visuals. This remains visible in a menu-only capture
 // and cannot be placed beyond the monitor by a stretched game window.
 const int inset=std::max(4,int(12*dpi));const int available=std::max(120,menu.w/3);const int w=std::clamp(menu.w/4,std::min(available,std::max(140,int(150*dpi))),std::min(available,std::max(160,int(260*dpi))));
 Rect area{menu.x+menu.w-w-inset,menu.y+std::max(8,int(20*dpi)),w,std::max(180,menu.h-int(40*dpi))};
 const int reserved=w+int(18*dpi);
 const float s=std::min(dpi,float(w)/260.f);const int pad=std::max(8,int(12*s));
 Preview p{};p.area=area;p.scale=s;p.reserved=reserved;
 p.gear={area.x+area.w-int(31*s),area.y+int(8*s),int(20*s),int(20*s)};
 p.reset={area.x+area.w-int(79*s),area.y+int(9*s),int(42*s),int(18*s)};
 const int model_h=std::max(120,std::min(int(350*s),area.h-int(125*s)));
 p.model={area.x+pad,area.y+int(42*s),area.w-pad*2,model_h};
 p.settings={area.x+pad,area.y+area.h-int(105*s),area.w-pad*2,int(94*s)};
 return p;
}
}
