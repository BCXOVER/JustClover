#pragma once
#include "hitchance_override.h"
// Included inside cs2_visuals; values use a separate per-weapon model. Native
// minimum HC / native configs are never overwritten to implement this bind.
namespace hitchance_ui {
inline PElement checkbox=nullptr,slider=nullptr,hotkey=nullptr;
inline int enabled=0,percent=75,profile=-1;inline HotkeyInfo key{};
inline bool publishing=false,loaded=false,dirty=false;inline unsigned changed_at=0;
inline wchar_t profile_caption[128]=L"Weapon profile unavailable";
inline constexpr struct Weapon {unsigned id;const wchar_t* name;} weapons[]={
 {0,L"Global"},{1,L"Desert Eagle"},{2,L"Dual Berettas"},{3,L"Five-SeveN"},{4,L"Glock-18"},{7,L"AK-47"},{8,L"AUG"},{9,L"AWP"},{10,L"FAMAS"},{11,L"G3SG1"},{13,L"Galil AR"},{14,L"M249"},{16,L"M4A4"},{17,L"MAC-10"},{19,L"P90"},{23,L"MP5-SD"},{24,L"UMP-45"},{25,L"XM1014"},{26,L"PP-Bizon"},{27,L"MAG-7"},{28,L"Negev"},{29,L"Sawed-Off"},{30,L"Tec-9"},{32,L"P2000"},{33,L"MP7"},{34,L"MP9"},{35,L"Nova"},{36,L"P250"},{38,L"SCAR-20"},{39,L"SG 553"},{40,L"SSG 08"},{60,L"M4A1-S"},{61,L"USP-S"},{63,L"CZ75-Auto"},{64,L"R8 Revolver"}};
inline int weapon_name(const wchar_t* value){
 const auto normal=[](const wchar_t* in,wchar_t* out){unsigned n=0;for(unsigned i=0;in[i]&&i<127&&n<63;i++){auto c=std::towlower(in[i]);if((c>=L'a'&&c<=L'z')||(c>=L'0'&&c<=L'9'))out[n++]=c;}out[n]=0;};
 wchar_t n[64]{};normal(value,n);for(auto w:weapons){wchar_t key[64]{};normal(w.name,key);if(eq(n,key))return int(w.id);}if(eq(n,L"deagle"))return 1;if(eq(n,L"scout"))return 40;return -1;
}
inline int array_profile(void* value){
 using namespace local_inventory_client;
 const auto v=reinterpret_cast<std::uintptr_t>(value);for(unsigned i=0;i<65;i++){
  if(v<16+i*4)break;auto* node=reinterpret_cast<const unsigned char*>(v-16-i*4);if(!memory(node,16+260))continue;
  unsigned short bytes=0,type=0;std::memcpy(&bytes,node+12,2);std::memcpy(&type,node+14,2);if(bytes!=260||type!=6)continue;
  auto* next=pointer(node,0);auto* prev=pointer(node,4);if(!memory(next,8)||!memory(prev,8)||pointer(next,4)!=node||pointer(prev,0)!=node)continue;
  bool valid=true;for(unsigned j=0;j<65;j++)if(read32(node,16+4*j)>100){valid=false;break;}if(valid)return int(i);
 }return -1;
}
inline int selected(CMenu* m){
 auto* tab=m->Tabs[RAGE];
 for(auto* c:tab->Childs)if(c){wchar_t group[128]{};native_ui_names::decode(c->Name.get(),group,128);if(!eq(group,L"Weapon type"))continue;
  for(auto* e:c->Elements)if(e){auto* h=e->GetAs<Checkbox>();wchar_t name[128]{};native_ui_names::decode(h->Name.get(),name,128);const int direct=weapon_name(name);if(direct>=0)return direct;
   if(h->Header.Type==UiCombobox){auto* combo=e->GetAs<Combobox>();if(combo->Value&&combo->Vars.size()<=128)for(auto& var:combo->Vars)if(var.Index==*combo->Value&&var.Name.size()<128){unsigned at=0;for(auto letter:var.Name){if(!letter||at>=127)break;name[at++]=letter;}name[at]=0;const int id=weapon_name(name);if(id>=0)return id;}}
  }
 }
 // Prefer the explicit selected weapon label: native combo ordinals need
 // not equal item definition IDs. A verified 65-int node is only a fallback.
for(auto* c:tab->Childs)if(c){wchar_t name[128]{};native_ui_names::decode(c->Name.get(),name,128);if(!eq(name,L"Aimbot"))continue;
  for(auto* e:c->Elements)if(e&&e!=checkbox&&e!=slider&&e!=hotkey){native_ui_names::decode(e->GetAs<Checkbox>()->Name.get(),name,128);if(eq(name,L"Minimum hit chance")&&e->GetAs<Checkbox>()->Header.Type==UiSlider){const int result=array_profile(native_ui_proxy::pointer(e,0x5c));if(result>=0)return result;}}
 }
 return -1;
}
inline std::wstring path(){wchar_t out[MAX_PATH]{};const unsigned n=GetEnvironmentVariableW(L"LOCALAPPDATA",out,MAX_PATH);if(!n||n+40>=MAX_PATH)return {};std::wcscat(out,L"\\SkeetLegacy");CreateDirectoryW(out,nullptr);return std::wstring(out)+L"\\rage_overrides.ini";}
inline void persist(bool write){const auto file=path();if(file.empty())return;
 if(write){std::wstring section;for(unsigned i=0;i<65;i++){section+=L"weapon_"+std::to_wstring(i)+L"="+std::to_wstring(hitchance_override::settings[i].load());section.push_back(0);}section.push_back(0);WritePrivateProfileSectionW(L"hitchance",section.c_str(),file.c_str());dirty=false;}
 else for(unsigned i=0;i<65;i++){const auto name=L"weapon_"+std::to_wstring(i);const unsigned v=GetPrivateProfileIntW(L"hitchance",name.c_str(),hitchance_override::Setting{}.pack(),file.c_str());hitchance_override::settings[i]=hitchance_override::Setting::unpack(v).pack();}
}
inline void store(){if(publishing||profile<0||profile>=65)return;hitchance_override::Setting setting{enabled!=0,unsigned(std::clamp(percent,0,100)),unsigned(key.Key),unsigned(key.Mode)};const unsigned v=setting.pack();if(hitchance_override::settings[profile].exchange(v)!=v){dirty=true;changed_at=GetTickCount();}}
inline void __fastcall changed(void*,void*){store();}
inline void frame(CMenu* m){
 if(!m||m->Tabs.size()!=9||!native.check||!native.slider||!native.hotkey)return;
 auto* tab=m->Tabs[RAGE];Child* aim=nullptr;for(auto* c:tab->Childs)if(c){wchar_t name[128]{};native_ui_names::decode(c->Name.get(),name,128);if(eq(name,L"Aimbot")){aim=c;break;}}if(!aim)return;
 if(!loaded){persist(false);loaded=true;}
 if(dirty&&(GetTickCount()-changed_at>=300||!(m->MenuStatus&MenuOpened)))persist(true);
 bool alive=false;for(auto* e:aim->Elements)if(e==checkbox)alive=true;
 if(!alive){checkbox=slider=hotkey=nullptr;publishing=true;
  auto* a=static_cast<Checkbox*>(native.allocate(sizeof(Checkbox)));auto* h=static_cast<Hotkey*>(native.allocate(sizeof(Hotkey)));auto* s=static_cast<Slider*>(native.allocate(sizeof(Slider)));if(!a||!h||!s){for(void* p:{static_cast<void*>(a),static_cast<void*>(h),static_cast<void*>(s)})if(p)Memory::Deallocator(p);publishing=false;return;}native.check(a,aim,L"Minimum hit chance override",&enabled);a->Calls.emplace_back(nullptr,&changed);native.insert(aim,false,a);checkbox=reinterpret_cast<PElement>(a);
  key={};key.base.data_size=8;key.base.data_type=LHOTKEY;key.Mode=OnHotkey;native.hotkey(h,aim,&key,true);h->Calls.emplace_back(nullptr,&changed);native.insert(aim,false,h);hotkey=reinterpret_cast<PElement>(h);
  native.slider(s,aim,L"",0,100,&percent,true,0,1.f);s->Calls.emplace_back(nullptr,&changed);native.insert(aim,false,s);slider=reinterpret_cast<PElement>(s);
  // Add next to the ordinary HC slider; do not append an unrelated bottom row.
  auto end=aim->Elements.end();auto where=end-3;for(auto it=aim->Elements.begin();it!=end-3;it++){wchar_t name[128]{};native_ui_names::decode((*it)->GetAs<Checkbox>()->Name.get(),name,128);if(eq(name,L"Minimum hit chance")){where=it+1;break;}}std::rotate(where,end-3,end);publishing=false;profile=-1;
 }
 store();if(m->CurrentTab!=RAGE||!(m->MenuStatus&MenuOpened))return;const int next=selected(m);if(next!=profile){publishing=true;profile=next;const auto s=profile>=0?hitchance_override::Setting::unpack(hitchance_override::settings[profile]):hitchance_override::Setting{};enabled=s.enabled;percent=int(s.chance);key.Key=s.key;key.Mode=static_cast<HotkeyMode>(s.mode);key.ToogleState=0;
  std::wcscpy(profile_caption,L"Weapon profile unavailable");for(auto w:weapons)if(int(w.id)==profile){std::wcscpy(profile_caption,L"Profile: ");std::wcscat(profile_caption,w.name);break;}
  for(auto* e:{checkbox,slider,hotkey})e->GetAs<Checkbox>()->OnConfigLoad();publishing=false;
 }
 for(auto* e:{checkbox,slider,hotkey})e->GetAs<Checkbox>()->Header.Flags.Editable=profile>=0;
}
}
