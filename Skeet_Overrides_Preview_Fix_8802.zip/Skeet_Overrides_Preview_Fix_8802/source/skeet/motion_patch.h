#pragma once
#include "motion_plan.h"
#include "motion_records.h"
#include "motion_settings.h"
#include "motion_trace.h"
namespace motion_patch {
inline DWORD tls_slot=TLS_OUT_OF_INDEXES;
inline motion_records::Api api{};
inline motion_records::Scratch* scratch() {
    if(tls_slot==TLS_OUT_OF_INDEXES)return nullptr;
    auto* s=static_cast<motion_records::Scratch*>(TlsGetValue(tls_slot));
    if(!s) {
        s=static_cast<motion_records::Scratch*>(HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(*s)));
        if(!s)return nullptr;
        if(!TlsSetValue(tls_slot,s)){HeapFree(GetProcessHeap(),0,s);return nullptr;}
    }
    return s;
}
inline motion_records::Options options() {
    return {1,motion_settings::interpolation,motion_settings::interpolation_gap,
        motion_settings::extrapolation,motion_settings::extrapolation_ticks};
}
inline motion_records::Clock clock(void* context) {
    const auto* interval=*reinterpret_cast<const float* const*>(0x4346a338);
    const auto* now=*reinterpret_cast<const float* const*>(0x43467eb8);
    if(!context||!interval||!now)return {};
    using Upper=int(__thiscall*)(void*);
    return {*interval,*now,motion_records::f32(context,0x198)+*reinterpret_cast<const float*>(0x43476928),
        reinterpret_cast<Upper>(0x4337ea43)(context)};
}
inline void __cdecl begin(void* context,unsigned* args) {
    auto* s=scratch();if(!s)return;
    auto* actor=reinterpret_cast<void*>(args[1]);auto* history=reinterpret_cast<void*>(args[2]);
    int lo=static_cast<int>(args[4]),hi=static_cast<int>(args[5]);
    const auto c=clock(context);
    if(motion_records::begin(*s,actor,history,context,options(),c,lo,hi,args[0]==0x4332ff6b)) {
        args[4]=lo;args[5]=hi;
    }
}
inline int __fastcall getter(const void* history,int requested,int bone,void* origin,void* matrix) {
    auto* s=scratch();
    using Original=int(__fastcall*)(const void*,int,int,void*,void*);
    if(s&&!s->active)return -1;
    if(!s||!s->active||s->history!=history||!motion_records::enhanced(*s))
        return reinterpret_cast<Original>(0x433eedff)(history,requested,bone,origin,matrix);
    return motion_records::point(*s,history,requested,bone,origin,matrix,api)?requested:-1;
}
inline int __cdecl apply_prepared(void* frame,void* caller_frame) {
    if(motion_records::u32(caller_frame,4)!=scan_patch::application_return)return 0;
    auto* s=scratch();if(!s||!s->active||!motion_records::enhanced(*s))return 0;
    const auto* locals=static_cast<const unsigned char*>(frame);
    auto* scope=reinterpret_cast<void*>(motion_records::u32(locals,0x58));
    auto* actor=reinterpret_cast<void*>(motion_records::u32(locals,0x54));
    auto* history=reinterpret_cast<void*>(motion_records::u32(locals,0x7c));
    auto* context=reinterpret_cast<void*>(motion_records::u32(caller_frame,8));
    const int requested=static_cast<int>(motion_records::u32(caller_frame,12));
    // This hook also sees other native users of the apply routine. Only the
    // immediately captured HC session uses our prepared pose.
    if(s->actor!=actor||s->history!=history||s->context!=context)return 0;
    const auto c=clock(context);
    if(c.now!=s->clock.now||c.interval!=s->clock.interval||
       c.correction!=s->clock.correction||c.native_upper!=s->clock.native_upper)return -1;
    return motion_records::apply(*s,actor,history,context,requested,scope,api)?1:-1;
}
inline bool apply(unsigned char* image,std::size_t size) {
    if(reinterpret_cast<std::uintptr_t>(image)!=scan_patch::image_base)return false;
    auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,motion_plan::code_size,
        MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));if(!code)return false;
    motion_plan::Plan plan{};
    if(!motion_plan::make_plan(image,size,reinterpret_cast<unsigned>(code),
        reinterpret_cast<unsigned>(&begin),reinterpret_cast<unsigned>(&apply_prepared),
        reinterpret_cast<unsigned>(&getter),plan)) {
        VirtualFree(code,0,MEM_RELEASE);SetLastError(ERROR_REVISION_MISMATCH);return false;
    }
    std::memcpy(code,plan.code,sizeof(plan.code));DWORD protection=0;
    if(!VirtualProtect(code,motion_plan::code_size,PAGE_EXECUTE_READ,&protection)||
       !FlushInstructionCache(GetCurrentProcess(),code,motion_plan::code_size)) {
        const auto error=GetLastError();VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    tls_slot=TlsAlloc();if(tls_slot==TLS_OUT_OF_INDEXES){VirtualFree(code,0,MEM_RELEASE);return false;}
    motion_trace::initialize();
    api={reinterpret_cast<motion_records::Blend>(code+motion_plan::blend_entry),&motion_trace::sweep};
    for(const auto& e:plan.edits)std::memcpy(image+e.offset,e.after,e.length);
    if(!FlushInstructionCache(GetCurrentProcess(),image,size)) {
        const auto error=GetLastError();
        for(const auto& e:plan.edits)std::memcpy(image+e.offset,e.before,e.length);
        FlushInstructionCache(GetCurrentProcess(),image,size);TlsFree(tls_slot);tls_slot=TLS_OUT_OF_INDEXES;
        VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    return true;
}
}
