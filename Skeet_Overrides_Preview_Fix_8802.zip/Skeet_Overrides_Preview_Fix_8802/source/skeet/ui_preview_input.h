#pragma once
#include <atomic>
#include <windows.h>
namespace ui_preview_input {
inline std::atomic<int> wheel{0};
inline std::atomic<int> left{0},top{0},right{0},bottom{0};
inline std::atomic<bool> enabled{false},held{false},modal{false};
inline std::atomic<unsigned> down{0},up{0},cancel{0},down_pos{0},up_pos{0},position{0};
inline std::atomic<HWND> window{nullptr};inline std::atomic<WNDPROC> previous{nullptr};
inline bool inside(int x,int y){return enabled&&x>=left&&x<right&&y>=top&&y<bottom;}
inline void publish(int x,int y,int w,int h,bool shown){
 if(x!=left||y!=top||x+w!=right||y+h!=bottom||shown!=enabled){enabled=false;held=false;cancel.fetch_add(1);left=x;top=y;right=x+w;bottom=y+h;enabled=shown;}
}
inline bool consume(UINT msg,WPARAM key,LPARAM pos){
 if(msg==WM_KILLFOCUS||msg==WM_CANCELMODE||msg==WM_CAPTURECHANGED){held=false;cancel.fetch_add(1);return false;}
 if(msg==WM_KEYDOWN&&key==VK_ESCAPE&&modal){held=false;cancel.fetch_add(1);return true;}
 const int x=static_cast<short>(LOWORD(pos)),y=static_cast<short>(HIWORD(pos));const bool hit=inside(x,y);
 if((msg==WM_LBUTTONDOWN||msg==WM_LBUTTONDBLCLK)&&hit){position=down_pos=unsigned(pos);held=true;down.fetch_add(1,std::memory_order_release);return true;}
 if(msg==WM_LBUTTONUP&&held.exchange(false)){position=up_pos=unsigned(pos);up.fetch_add(1,std::memory_order_release);return true;}
 if(msg==WM_MOUSEMOVE&&(hit||held)){position=unsigned(pos);return true;}
 if(hit&&msg==WM_MOUSEWHEEL){wheel.fetch_add(short(HIWORD(key)));return true;}
 return hit&&(msg==WM_RBUTTONDOWN||msg==WM_RBUTTONUP||msg==WM_MOUSEWHEEL);
}
inline LRESULT CALLBACK procedure(HWND hwnd,UINT msg,WPARAM w,LPARAM l){
 if(msg==WM_NCDESTROY){publish(0,0,0,0,false);const auto p=previous.exchange(nullptr);window=nullptr;return p?CallWindowProcW(p,hwnd,msg,w,l):DefWindowProcW(hwnd,msg,w,l);}
 LPARAM pos=l;if(msg==WM_MOUSEWHEEL){POINT p{static_cast<short>(LOWORD(l)),static_cast<short>(HIWORD(l))};if(ScreenToClient(hwnd,&p))pos=MAKELPARAM(p.x,p.y);}
 if(consume(msg,w,pos))return 0;const auto p=previous.load();return p?CallWindowProcW(p,hwnd,msg,w,l):DefWindowProcW(hwnd,msg,w,l);
}
inline bool attach(HWND hwnd){
 if(window==hwnd&&previous)return true;if(window||!hwnd||!IsWindow(hwnd))return false;
 DWORD id=0;GetWindowThreadProcessId(hwnd,&id);if(id!=GetCurrentProcessId())return false;
 previous=reinterpret_cast<WNDPROC>(GetWindowLongPtrW(hwnd,GWLP_WNDPROC));if(!previous)return false;
 auto old=reinterpret_cast<WNDPROC>(SetWindowLongPtrW(hwnd,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(&procedure)));
 if(!old){previous=nullptr;return false;}previous=old;window=hwnd;return true;
}
struct Poll {unsigned d=0,u=0,c=0;bool press=false,release=false,cancelled=false;int x=0,y=0,press_x=0,press_y=0;
 void tick(){const auto a=down.load(std::memory_order_acquire),b=up.load(std::memory_order_acquire),e=cancel.load();press=a!=d;release=b!=u;cancelled=e!=c;d=a;u=b;c=e;const unsigned p=position,q=down_pos;x=short(p&65535);y=short(p>>16);press_x=short(q&65535);press_y=short(q>>16);if(cancelled)press=release=false;}
};
}
