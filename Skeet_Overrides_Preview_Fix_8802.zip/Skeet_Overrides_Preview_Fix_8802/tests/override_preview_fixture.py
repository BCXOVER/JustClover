"""Per-weapon HC callbacks and visible preview using a cloned native renderer."""
def check_override_preview(ns):
 globals().update(ns)
 handlers={'towlower':lambda u,s:(ord(chr(word(u,s+4)).lower()),4),'GetForegroundWindow':lambda u,s:(0x1234,4),'GetCurrentProcessId':lambda u,s:(50,4),'GetWindowThreadProcessId':lambda u,s:(store(u,word(u,s+8),50) or 51,12),'GetAsyncKeyState':lambda u,s:(0x8000,8),'GetEnvironmentVariableW':lambda u,s:(0,16),'EnumWindows':lambda u,s:(0,12)}
 u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',handlers);u.mem_map(0x140000,0x1000)
 root,scope=MEM+0x10000,MEM+0x12000;store(u,root+0x848,75)
 setting=lambda hc,key,mode=1:1|(hc<<1)|(key<<8)|(mode<<16)
 call(u,exp('hc_setting_probe'),[0,0]);call(u,exp('hc_setting_probe'),[9,setting(90,5)])
 store(u,scope+0xd8,9);assert call(u,exp('hc_capture_probe'),[root,scope])==90
 store(u,scope+0xd8,40);assert call(u,exp('hc_capture_probe'),[root,scope])==75
 call(u,exp('hc_setting_probe'),[40,setting(35,6)]);assert call(u,exp('hc_capture_probe'),[root,scope])==35
 call(u,exp('hc_setting_probe'),[40,0]);assert call(u,exp('hc_capture_probe'),[root,scope])==75
 # Native config array profile is exact ID, checked against linked-list metadata.
 node,next,prev=MEM+0x14000,MEM+0x15000,MEM+0x16000;store(u,node,next);store(u,node+4,prev);store(u,next+4,node);store(u,prev,node);u.mem_write(node+12,struct.pack('<HH',260,6))
 for i in range(65):store(u,node+16+4*i,75)
 for id in [0,9,40,64]:assert call(u,exp('hc_array_profile_probe'),[node+16+4*id])==id
 store(u,node+16,101);assert call(u,exp('hc_array_profile_probe'),[node+16+4*9])==0xffffffff
 for text,id in [('SSG 08',40),('SSG08',40),('M4A1-S',60),('Global',0)]:
  at=MEM+0x17000;u.mem_write(at,(text+'\0').encode('utf-16le'));assert call(u,exp('hc_weapon_name_probe'),[at])==id
 # A copied vtable with Text intercepted by Lua is still a valid renderer.
 r,vt,data=MEM+0x18000,MEM+0x19000,MEM+0x1a000
 u.mem_write(vt,bytes(u.mem_read(0x43472a80,44*4)));store(u,vt+4*4,0x140800);store(u,vt+8*4,0x140820);store(u,vt+7*4,0x140840);store(u,vt+15*4,0x140880)
 store(u,r,vt);store(u,r+4,0x4346f46c);store(u,r+8,data);store(u,data+0xf4,1920);store(u,data+0xf0,1080);floats(u,r+0x7c,.2,1)
 assert call(u,exp('renderer_supported_probe'),[r])==1;assert call(u,exp('renderer_install_probe'),[r])==1
 ctx,menu,children,controls,tabs,visuals,misc,origin=[MEM+0x20000+i*0x1000 for i in range(8)]
 store(u,ctx,1);store(u,ctx+0x10,menu);store(u,menu+0xc,12);store(u,menu+0x10,13);store(u,menu+0x14,1312);store(u,menu+0x18,640);store(u,menu+0x34,1);store(u,menu+0x64,3);store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36)
 for i in range(9):store(u,tabs+4*i,MEM+0x30000+0x100*i)
 store(u,tabs+12,visuals);store(u,tabs+16,misc);lua=word(u,tabs+32);store(u,lua+0x70,MEM+0x32000);store(u,lua+0x74,MEM+0x32008);store(u,MEM+0x32004,1)
 store(u,visuals+0x70,children);store(u,visuals+0x74,children+48);floats(u,0x4346d490,1)
 for i in range(12):store(u,children+i*4,MEM+0x40000+i*0x200)
 for i in range(6):store(u,controls+i*4,MEM+0x44000+i*0x100)
 draws=[];texts=[]
 def mock(u,a,size,user):
  if a not in [0x140700,0x140720,0x140800,0x140820,0x140840,0x140880,0x433ab0fa]:return
  sp=u.reg_read(UC_X86_REG_ESP);cleanup=4
  if a==0x140700:pass
  elif a==0x140720:cleanup=12
  elif a==0x140800:draws.append([word(u,sp+4*i) for i in range(1,6)]);cleanup=24
  elif a==0x140820:cleanup=24
  elif a==0x140840:cleanup=28
  elif a==0x140880:texts.append(wide(u,word(u,sp+20)));cleanup=28
  elif a==0x433ab0fa:u.reg_write(UC_X86_REG_EAX,0);cleanup=8
  u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
 u.hook_add(UC_HOOK_CODE,mock)
 call(u,exp('category_setup_probe'),[ctx,children,controls,0x140700]);call(u,exp('preview_surface_setup_probe'),[0x140720]);category=word(u,children+44);store(u,origin,12);store(u,origin+4,13)
 call(u,exp('preview_surface_draw_probe'),[r,origin],category,limit=12000000)
 assert call(u,exp('preview_surface_state_probe'))==1 and 'Enemy ESP preview' in texts
 assert any(12<=x<1324 and 13<=y<653 and 150<=w<=300 and h>=400 for x,y,w,h,c in draws)
 return {'per_weapon_capture_cases':4,'native_profile_mapping_cases':8,'cloned_renderer_supported_and_chained':True,'preview_title_drawn_with_live_child_renderer':True,'preview_inside_menu':True,'game_tested':False}
