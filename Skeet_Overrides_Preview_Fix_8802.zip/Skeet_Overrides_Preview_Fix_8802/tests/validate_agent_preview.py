"""Closed x86 ABI/ownership fixture. GPU draws and game asset I/O are mocks.
Selected original constructors and texture methods run inside Unicorn only.
"""
from pathlib import Path
import struct,json,hashlib,subprocess,os,sys
import pefile
from unicorn import *
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build'
env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']='/workspace/skeet-motion-bt-8802/.cache/global';env['ZIG_LOCAL_CACHE_DIR']=str(ROOT/'.cache/local')
with (BUILD/'agent_preview_probe.log').open('w') as log:
 subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++23','-fms-extensions','-fasm-blocks','-O1','-shared','-I',str(ROOT/'source/compat'),'-Wl,--image-base,0x30000000',str(ROOT/'tests/agent_preview_probe.cpp'),'-o',str(BUILD/'agent_preview_probe.dll')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['g++','-std=c++20','-O2',str(ROOT/'tests/agent_preview_plan.cpp'),'-o',str(BUILD/'agent_preview_plan')],check=True)
subprocess.run([str(BUILD/'agent_preview_plan')],check=True)
CB,MB,SB,AB=0x10000000,0x20000000,0x24000000,0x28000000
MEM=0x200000;SP=0x2f0000;STOP=0x100000;API=0x140000
u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(MEM,0x100000);u.mem_map(STOP,0x1000);u.mem_map(0x130000,0x20000)
modules=[]
for name,base,p in [('client',CB,Path('/workspace/game-8802-modules/client.dll')),('materialsystem',MB,Path('/workspace/agent-preview-modules/materialsystem.dll')),('studiorender',SB,Path('/workspace/agent-preview-modules/studiorender.dll')),('shaderapidx9',AB,Path('/workspace/agent-preview-modules/shaderapidx9.dll'))]:
 pe=pefile.PE(str(p));pe.relocate_image(base);u.mem_map(base,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(base,pe.get_memory_mapped_image());modules.append((name,base))
pe=pefile.PE(str(BUILD/'agent_preview_probe.dll'));PB=pe.OPTIONAL_HEADER.ImageBase;assert PB==0x30000000
u.mem_map(PB,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(PB,pe.get_memory_mapped_image())
# Native menu backend, not its protected entry point.
core=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes();u.mem_map(0x43310000,0x2fc000);u.mem_write(0x43310000,core)
def w(a):return struct.unpack('<I',u.mem_read(a,4))[0]
def put(a,x):u.mem_write(a,struct.pack('<I',x&0xffffffff))
def blob(a,data):u.mem_write(a,bytes(data))
def words(a,n):return [w(a+4*i) for i in range(n)]
def cstr(a,wide=False):
 b=bytearray();step=2 if wide else 1
 while True:
  n=bytes(u.mem_read(a+len(b),step))
  if n==bytes(step):return b.decode('utf-16le' if wide else 'utf-8')
  b+=n
exports={s.name.decode().lstrip('_'):PB+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def exp(name):return next(v for k,v in exports.items() if name in k)
imports={}
for lib in pe.DIRECTORY_ENTRY_IMPORT:
 for i in lib.imports:
  addr=0x130000+16*len(imports);put(i.address,addr);imports[addr]=i.name.decode()
mat,sr,sa,cache,target,cube,cham,ctx,heap,heapcell,heapvt,hdr,handle,handles,gpu,gpuvt,device,devvt,renderer,rvt,data,record=[MEM+0x10000+i*0x1000 for i in range(22)]
put(mat,MB+0x9a80c);put(sr,SB+0x7a090);put(sa,AB+0x6e930);put(ctx,MB+0x9ed88);put(target,MB+0x9fa4c);put(cube,MB+0x9fa4c)
# Distinct material vtable used just for the IsErrorMaterial callback.
put(cham,cham+0x100);put(cham+0x100+42*4,API+0x100)
put(cache,cache+0x100);put(cache+0x100+10*4,API+0x120);put(cache+0x100+26*4,API+0x140);put(cache+0x100+14*4,API+0x160)
for off,obj in [(0x534d6c0,mat),(0x534d6c4,mat),(0x534d6c8,sr),(0x534d6d4,cache)]:put(CB+off,obj)
put(CB+0xb3a2c0,heapcell);put(heapcell,heap);put(heap,heapvt);put(heapvt+4,API+0x180)
put(hdr,0x54534449);put(hdr+0x4c,0x400);put(hdr+0xbc,1);put(hdr+0xc0,0x100);put(hdr+0x104,0xd4);blob(hdr+0x1d4,b'idle\0')
put(target+0x24,2);blob(target+0x3e,b'\1\0');put(target+0x50,handles);put(handles,handle);blob(handle+8,b'\1');put(handle+12,gpu)
put(gpu,gpuvt);put(gpuvt+4,API+0x200);put(gpuvt+8,API+0x220);put(gpuvt+12,API+0x240);put(device,devvt);put(devvt+8,API+0x260)
put(renderer,rvt);put(rvt+19*4,API+0x280);put(renderer+4,0x4346f46c);put(renderer+8,data);put(data+0xc8,device);put(data+0xd0,record);put(data+0xd4,record)
put(ctx+0x68,4);put(ctx+0x1c,cube);put(sa+0x17e4,0x7f112233)
blob(sr+0x4c,struct.pack('<12f',*range(12)));blob(sr+0x7c,struct.pack('<24f',*[i/32 for i in range(24)]));put(sr+0x23c,1);blob(sr+0xdc,b'\x57'*0x160);blob(sr+0x240,struct.pack('<4f',.1,.2,.3,.4))
initial=bytes(u.mem_read(sr+0x4c,0x204));events=[];matrix_stacks={0:[],1:[],10:[]};model_calls=[];asset_calls=[];clock=[100];refs=[0];uploads=[0];lost=[False]
alloccursor=[MEM+0x60000]
def alloc(n):
 p=alloccursor[0];alloccursor[0]+=(n+15)&~15;assert alloccursor[0]<SP-0x10000;blob(p,bytes(n));return p
def finish(sp,result=0,cleanup=4):u.reg_write(UC_X86_REG_EAX,result&0xffffffff);u.reg_write(UC_X86_REG_EIP,w(sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
matfn={w(MB+0x9a80c+4*s):s for s in [84,91,97,115]}
ctxfn={w(MB+0x9ed88+4*s):s for s in [1,2,3,4,5,12,22,23,24,26,79,117,120]}
studiofn={w(SB+0x7a090+4*s):s for s in [21,22,23,27,28,33,34]}
texfn={w(MB+0x9fa4c+4*s):s for s in [3,4,15,64]}
getmod={name+'.dll':base for name,base in modules}
def hook(u,a,size,user):
 sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX)
 if a in imports:
  fn=imports[a]
  if fn=='GetModuleHandleW':finish(sp,getmod.get(cstr(w(sp+4),True),0),8)
  elif fn=='GetProcAddress':
   name=cstr(w(sp+8));assert name=='CreateInterface';base=w(sp+4);assert base in [MB,SB,AB];finish(sp,API+{MB:0x300,SB:0x320,AB:0x340}[base],12)
  elif fn=='GetTickCount':finish(sp,clock[0],4)
  elif fn=='VirtualQuery':
   at,out,n=words(sp+4,3);assert n==28
   for lo,hi,perm in u.mem_regions():
    if lo<=at<=hi:blob(out,struct.pack('<7I',lo,lo,0x40,hi-lo+1,0x1000,0x40,0x20000));finish(sp,28,16);break
   else:finish(sp,0,16)
  elif fn in ['memcpy','memmove']:
   dst,src,n=words(sp+4,3);blob(dst,u.mem_read(src,n));finish(sp,dst)
  elif fn=='memset':
   dst,c,n=words(sp+4,3);blob(dst,bytes([c&255])*n);finish(sp,dst)
  elif fn=='memcmp':
   x,y,n=words(sp+4,3);finish(sp,int(bytes(u.mem_read(x,n))!=bytes(u.mem_read(y,n))))
  elif fn in ['strcmp','strncmp']:
   x,y=words(sp+4,2);left,right=cstr(x),cstr(y);finish(sp,(left>right)-(left<right))
  elif fn=='memchr':
   x,c,n=words(sp+4,3);b=bytes(u.mem_read(x,n));i=b.find(bytes([c&255]));finish(sp,x+i if i>=0 else 0)
  else:raise AssertionError(fn)
 elif a in [API+0x300,API+0x320,API+0x340]:
  name=cstr(w(sp+4));assert name in ['VMaterialSystem080','VStudioRender026','ShaderApi029'];finish(sp,{'VMaterialSystem080':mat,'VStudioRender026':sr,'ShaderApi029':sa}[name])
 elif a in matfn:
  slot=matfn[a];assert this==mat
  if slot==97:
   assert cstr(w(sp+4))=='_skeet_ct_preview_8802';assert words(sp+8,7)==[256,512,5,12,1,12,0];events.append('create_target');finish(sp,target,36)
  elif slot==91:assert 'cubemap' in cstr(w(sp+4));finish(sp,cube,20)
  elif slot==84:assert cstr(w(sp+4)) in ['debug/debugambientcube','debug/debugdrawflat','dev/glow_armsrace'];finish(sp,cham,20)
  elif slot==115:finish(sp,ctx)
 elif a in texfn:
  slot=texfn[a]
  if slot==3:finish(sp,256)
  elif slot==4:finish(sp,512)
  elif slot==15:finish(sp,0)
  elif slot==64:finish(sp,0,8) # game texture-exclusion system boundary only
 elif a in studiofn:
  slot=studiofn[a];assert this==sr
  if slot==34:finish(sp,int(w(sr+0x250)!=0))
  elif slot==33:put(sr+0x250,w(sp+4));put(sr+0x260,w(sp+8));put(sr+0x264,w(sp+12));finish(sp,0,16)
  elif slot==21:blob(sr+0x7c,u.mem_read(w(sp+4),96));finish(sp,0,8)
  elif slot==22:
   n,p=words(sp+4,2);put(sr+0x23c,n)
   if n:blob(sr+0xdc,u.mem_read(p,0x160))
   finish(sp,0,12)
  elif slot==23:
   for i,p in enumerate(words(sp+4,4)):blob(sr+0x4c+12*i,u.mem_read(p,12))
   finish(sp,0,20)
  elif slot==27:blob(sr+0x240,u.mem_read(w(sp+4),12));finish(sp,0,8)
  elif slot==28:put(sr+0x24c,w(sp+4));finish(sp,0,8)
 elif a in ctxfn:
  slot=ctxfn[a];assert this==ctx
  if slot in [1,2,3]:events.append(('ctx',slot));finish(sp)
  elif slot==4:events.append(('flush',w(sp+4)));finish(sp,0,8)
  elif slot==5:put(ctx+0x1c,w(sp+4));finish(sp,0,8)
  elif slot==12:assert words(sp+4,3)==[1,1,1];finish(sp,0,16)
  elif slot==22:put(ctx+0x68,w(sp+4));finish(sp,0,8)
  elif slot==23:matrix_stacks[w(ctx+0x68)].append(True);finish(sp)
  elif slot==24:assert matrix_stacks[w(ctx+0x68)].pop();finish(sp)
  elif slot==26:assert len(u.mem_read(w(sp+4),64))==64;finish(sp,0,8)
  elif slot==79:
   r,g,b,alpha=words(sp+4,4);put(sa+0x17e4,alpha<<24|r<<16|g<<8|b);finish(sp,0,20)
  elif slot==117:assert words(sp+4,5)==[target,0,0,256,512];events.append('push_target');finish(sp,0,24)
  elif slot==120:events.append('pop_target');finish(sp)
 elif a==API+0x100:finish(sp,0)
 elif a==API+0x120:
  name=cstr(w(sp+4));asset_calls.append(name);finish(sp,len(asset_calls),8)
 elif a==API+0x140:finish(sp,0,8)
 elif a==API+0x160:finish(sp,hdr,8)
 elif a==API+0x180:finish(sp,alloc(w(sp+4)),8)
 elif a==CB+0xacb6e0:
  dst,c,n=words(sp+4,3);blob(dst,bytes([c&255])*n);finish(sp,dst)
 elif a==CB+0x9aeb60:
  put(this+0x40,w(sp+4));finish(sp,0,16)
 elif a==CB+0x9af400:
  n=w(this+0x6e0);p=w(this+0x6d4)
  if not p:p=alloc(3*0x6d4);put(this+0x6d4,p)
  put(p+n*0x6d4+0x3c,w(sp+4));put(this+0x6e0,n+1);finish(sp,0,20)
 elif a==CB+0x9aefd0:
  assert w(ctx+0x68)==10;assert w(sr+0x23c)==0
  assert words(this+0x6a0,12)[10]==0x3f800000
  model_calls.append((this,w(this+0x4a),w(sr+0x250)));finish(sp)
 elif a in [API+0x200,API+0x220]:
  assert w(sp+4)==gpu;refs[0]+=1 if a==API+0x200 else -1;finish(sp,refs[0],8)
 elif a==API+0x240:assert w(sp+4)==gpu;put(w(sp+8),device);finish(sp,0,12)
 elif a==API+0x260:assert w(sp+4)==device;finish(sp,0,8)
 elif a==API+0x280:
  assert this==renderer and u.reg_read(UC_X86_REG_EDX)!=0;assert words(sp+4,5)==[256,512,524288,0,0x41505256]
  for off,x in [(0,0x41505256),(4,256),(8,512),(0x24,0)]:put(record+off,x)
  put(data+0xd4,record+0x2c);uploads[0]+=1;finish(sp,0,24)
 elif a in [STOP,CB+0x9af0b0]:u.emu_stop()
u.hook_add(UC_HOOK_CODE,hook)
def call(name,args=()):
 for i,x in enumerate([STOP,*args]):put(SP+4*i,x)
 u.reg_write(UC_X86_REG_ESP,SP);u.emu_start(exp(name),STOP+1,count=1500000)
 assert u.reg_read(UC_X86_REG_EIP)==STOP,hex(u.reg_read(UC_X86_REG_EIP));return u.reg_read(UC_X86_REG_EAX)
assert call('agent_initialize_probe')==1
assert call('agent_render_probe',[100,0,0,0xffffffff])==1
assert asset_calls==['models/player/custom_player/uiplayer/animset_uiplayer.mdl','models/player/custom_player/legacy/ctm_sas.mdl','models/weapons/w_snip_awp.mdl']
assert bytes(u.mem_read(sr+0x4c,0x204))==initial
assert w(ctx+0x68)==4 and w(ctx+0x1c)==cube and w(sa+0x17e4)==0x7f112233
assert all(not v for v in matrix_stacks.values())
assert events.count('create_target')==1 and events.count('push_target')==events.count('pop_target')==1
assert call('agent_gpu_probe',[renderer])==1 and refs[0]==1 and uploads[0]==1
assert call('agent_gpu_probe',[renderer])==1 and refs[0]==1 and uploads[0]==1
for t in range(101,133):assert call('agent_render_probe',[t,0,0,0xffffffff])==1
assert len(model_calls)==1
assert call('agent_render_probe',[101,0,2,0x80123456])==1 and model_calls[-1][1:]==(0x80123456,cham)
assert bytes(u.mem_read(sr+0x4c,0x204))==initial
# Existing core may replace the StudioRender vtable. Private scene setup uses
# audited native entries and preserves the shadow table itself.
shadow=alloc(53*4);blob(shadow,u.mem_read(SB+0x7a090,53*4));put(shadow+33*4,API+0xff0);put(sr,shadow)
for t in [150,200,250]:assert call('agent_render_probe',[t,0,1,0xff123456])==1
assert events.count('create_target')==1 and len(asset_calls)==3 and w(sr)==shadow
call('agent_pause_probe');before=len(model_calls);assert call('agent_render_probe',[50000,0,1,0xff123456])==1 and len(model_calls)==before+1
# Native renderer device-loss contract: it releases its reference and clears
# record+0x24. The next presentation rebinds once, without a new texture slot.
refs[0]-=1;put(record+0x24,0);assert call('agent_gpu_probe',[renderer])==1 and refs[0]==1 and uploads[0]==1
put(sr+0x250,cham);before=len(model_calls);assert call('agent_render_probe',[50100,0,0,0xffffffff])==0 and len(model_calls)==before;put(sr+0x250,0)
# The owned CMergedMDL callback receives the original caller's EBP, preserves
# all integer registers/flags, and projects a real matrix array (no stick mesh).
model=call('agent_model_probe',[0]);frame=MEM+0x51000;wrapper=MEM+0x52000;bones=MEM+0x53000
put(wrapper,hdr);put(frame-4,wrapper);put(frame-0x10,bones)
put(hdr+0x9c,3);put(hdr+0xa0,0x100)
for i in range(3):
 put(hdr+0x100+i*216+4,i-1);put(hdr+0x100+i*216+0xa0,0x100)
 m=[1.,0,0,0,0,1.,0,float((i-1)*10),0,0,1.,float(i*36)];blob(bones+i*48,struct.pack('<12f',*m))
thunk=call('agent_thunk_probe');put(SP,CB+0x9af0b0)
u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_EBP,frame);u.reg_write(UC_X86_REG_ECX,model);u.reg_write(UC_X86_REG_EBX,0x12345678)
u.emu_start(thunk,STOP+1,count=1000000)
assert u.reg_read(UC_X86_REG_EIP)==CB+0x9af0b0 and u.reg_read(UC_X86_REG_ESP)==SP+4
assert u.reg_read(UC_X86_REG_EBP)==frame and u.reg_read(UC_X86_REG_EBX)==0x12345678
assert call('agent_joints_probe')==3
report={'passed':True,'game_tested':False,'native_mdl_constructor_executed':True,'native_set_mdl_string_and_merge_dispatch_executed':True,'native_mdl_draw_transform_executed':True,'owned_bone_callback_and_matrix_projection_checked':True,'actual_model_draw_and_game_asset_io':'mocked boundaries','native_texture_handle_and_d3d_texture_getters_executed':True,'render_target_creations':1,'cpu_texture_registrations':uploads[0],'repeat_frames_no_model_reloads':True,'state_restore_checked':['matrix stacks','matrix mode','render target push/pop','cubemap','clear color','studio camera','ambient cube','local lights','color/alpha','forced material'],'device_loss_rebind_checked':True,'existing_shadow_interface_preserved':True,'source_sha256':hashlib.sha256((ROOT/'source/skeet/agent_preview_native.h').read_bytes()).hexdigest()}
(BUILD/'agent_preview_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
