"""Execute the override snapshot hook and native early/late HC consumers in Unicorn."""
from pathlib import Path
import subprocess,struct,json
from unicorn import *
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build'
subprocess.run(['g++','-std=c++20','-O2',str(ROOT/'tests/hitchance_override_plan.cpp'),'-o',str(BUILD/'hitchance_override_plan')],check=True)
cases=0
for address in [0x10000000,0x60000000,0xf0000000]:
 path=BUILD/f'hitchance_override_{address:x}.bin';subprocess.run([str(BUILD/'hitchance_override_plan'),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(path),hex(address)],check=True);blob=path.read_bytes()
 for native in [0,1,75,100]:
  for chosen in [None,0,1,35,80,100]:
   u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(0x43310000,0x2fc000);u.mem_write(0x43310000,blob[1280:]);u.mem_map(address,0x3000);u.mem_write(address,blob[:256]);u.mem_write(address+0x1000,blob[256:1280]);u.mem_map(0x200000,0x100000);u.mem_map(0x100000,0x1000)
   sp,root,scope,frame=0x280000,0x210000,0x220000,0x290000
   def word(a):return struct.unpack('<I',u.mem_read(a,4))[0]
   def put(a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
   value=native if chosen is None else chosen
   put(root+0x848,native);put(scope+0xd8,40);put(frame+8,scope);put(sp+0x75c,128);put(sp+0x760,0xcccccccc);put(0x23b004,1)
   saved={UC_X86_REG_EBX:0x12345678,UC_X86_REG_ESI:0x76543210,UC_X86_REG_EDI:0x87654321,UC_X86_REG_EDX:0x22446688,UC_X86_REG_EBP:frame,UC_X86_REG_XMM6:0x112233445566778899aabbccddeeff00}
   for r,v in saved.items():u.reg_write(r,v)
   u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_EAX,scope);u.reg_write(UC_X86_REG_ECX,root)
   def callback(u,a,size,user):
    if a!=0x100600:return
    esp=u.reg_read(UC_X86_REG_ESP);assert u.reg_read(UC_X86_REG_ECX)==root and u.reg_read(UC_X86_REG_EDX)==scope;u.reg_write(UC_X86_REG_EAX,value);u.reg_write(UC_X86_REG_EIP,word(esp));u.reg_write(UC_X86_REG_ESP,esp+4)
   u.hook_add(UC_HOOK_CODE,callback)
   def run(start,end):
    u.emu_start(start,end,count=10000);assert u.reg_read(UC_X86_REG_EIP)==end
   run(0x4332fd43,0x4332fd4d)
   assert u.reg_read(UC_X86_REG_ESP)==sp and u.reg_read(UC_X86_REG_EAX)==scope and u.reg_read(UC_X86_REG_ECX)==scope+0x174
   assert all(u.reg_read(r)==v for r,v in saved.items());assert word(sp+0x760)==value and word(sp+0x75c)==128
   final=sp-4;u.reg_write(UC_X86_REG_ESP,final);u.reg_write(UC_X86_REG_EDI,root);u.reg_write(UC_X86_REG_ECX,0);run(0x43330098,0x4333009e);assert bool(u.reg_read(UC_X86_REG_EFLAGS)&64)==(value==0)
   u.reg_write(UC_X86_REG_EAX,0xcccccccc);run(0x4333016c,0x43330172);assert u.reg_read(UC_X86_REG_EAX)==value
   run(0x43330172,0x4333017e);assert u.reg_read(UC_X86_REG_EAX)==(value*128+99)//100 and u.reg_read(UC_X86_REG_ECX)==1
   assert word(root+0x848)==native;cases+=1
report={'passed':True,'snapshot_native_branch_threshold_cases':cases,'preserved_integer_and_sse_state':True,'native_hc_not_overwritten':True,'early_zero_and_threshold_share_snapshot':True,'disabled_uses_native_chance':True,'game_tested':False}
(BUILD/'hitchance_override_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
