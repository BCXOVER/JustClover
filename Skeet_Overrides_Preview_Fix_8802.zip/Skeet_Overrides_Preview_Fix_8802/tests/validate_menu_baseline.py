"""Prove UI work did not alter any gameplay, loader or inventory source."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent/'skeet-menu-preview-8802'
allowed={f'source/skeet/{name}' for name in ['skeet.cpp','cs2_visuals_impl.h','menu_interaction_design.h','esp_layout_runtime.h','rage_settings_ui.h','enemy_preview_ui.h']}
added={f'source/skeet/{name}.h' for name in ['hitchance_override','hitchance_override_patch','hitchance_override_ui']}
sha=lambda b:hashlib.sha256(b).hexdigest()
old={str(p.relative_to(BASE)):p for p in (BASE/'source').rglob('*') if p.is_file()}
new={str(p.relative_to(ROOT)):p for p in (ROOT/'source').rglob('*') if p.is_file()}
assert new.keys()-old.keys()==added
assert not old.keys()-new.keys()
changes=[path for path in old if old[path].read_bytes()!=new[path].read_bytes()]
assert set(changes)==allowed,changes
unchanged={p:sha(new[p].read_bytes()) for p in old if p not in allowed}
report={'passed':True,'baseline_commit':'a1a6994b7914e95a9eade9d2109bbf66f75533ea','unchanged_source_files':len(unchanged),'changed_existing_source':sorted(changes),'new_presentation_headers':sorted(added),'gameplay_change':'explicit per-weapon HC override; default disabled; native snapshot preserved','loader_unchanged':True,'skinchanger_unchanged':True,'embedded_resources_unchanged':True,'unchanged_source_sha256':unchanged}
(ROOT/'build/menu_baseline_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('UI scope verified:',len(unchanged),'baseline source files byte-for-byte unchanged; only approved override/UI files changed')
