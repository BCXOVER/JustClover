#pragma once
namespace appearance_preview {
using namespace cs2_visuals;using namespace SkeetSDK;
namespace design=appearance_design;
static int subject=design::Enemy,last_category=-1;
static float yaw=.25f;static unsigned saved_flags[4]{};
static const wchar_t* status=L"Illustrated appearance preview";
static bool live() {return attached&&(!captured_topology||topology()==captured_topology);}
static int esp_panel(){return subject==design::Team?TeamESP:EnemyESP;}
static int model_panel(){return subject==design::Enemy?EnemyModels:subject==design::Team?TeamModels:ViewPanel;}
static const wchar_t* model_name(){return subject==design::Enemy?L"Player":subject==design::Team?L"Teammate":subject==design::Local?L"Local player":L"Weapon viewmodel";}
static Binding* find(int panel,const wchar_t* name,int type) {
    if(!live())return nullptr;
    for(unsigned i=0;i<binding_count;i++) {
        auto& b=bindings[i];
        if(b.group&&b.group->panel==panel&&eq(b.anchor,name)&&b.source&&b.source->GetAs<Checkbox>()->Header.Type==type)return &b;
    }
    return nullptr;
}
static void* value(Binding* b){return b?native_ui_proxy::pointer(b->source,0x5c):nullptr;}
static bool editable(Binding* b){return b&&value(b)&&b->source->GetAs<Checkbox>()->Header.Flags.Editable;}
static unsigned read(Binding* b,unsigned fallback=0) {
    const auto* p=value(b);if(!p)return fallback;
    if(b->source->GetAs<Checkbox>()->Header.Type==UiCheckbox)return *static_cast<const unsigned char*>(p)!=0;
    unsigned n=0;std::memcpy(&n,p,4);return n;
}
static bool write(Binding* b,unsigned n) {
    if(!editable(b)||!live())return false;
    if(b->source->GetAs<Checkbox>()->Header.Type==UiCheckbox)*static_cast<unsigned char*>(value(b))=n!=0;
    else std::memcpy(value(b),&n,4);
    changed(b,nullptr);return live();
}
static Binding* element(int index) {
    if(subject>design::Team||index<0||index>=8)return nullptr;
    auto* b=find(esp_panel(),design::elements[index],UiCheckbox);
    if(!b&&index==7)b=find(esp_panel(),L"Flags",UiMultiselect);
    return b;
}
static bool toggle(int index) {
    auto* b=element(index);if(!editable(b))return false;
    const auto old=read(b);unsigned next=!old;
    if(b->source->GetAs<Checkbox>()->Header.Type==UiMultiselect) {
        auto* source=b->source->GetAs<Multiselect>();if(source->Vars.size()>32)return false;
        unsigned mask=0;for(const auto& v:source->Vars)mask|=static_cast<unsigned>(v.Index);
        if(old){if(source->NotNull)return false;saved_flags[subject]=old;next=0;}
        else {next=saved_flags[subject]&mask;if(!next)next=mask;}
    }
    return write(b,next);
}
static bool preset(int which) {
    if(which<0||which>=4)return false;
    auto* enabled=find(model_panel(),model_name(),UiCheckbox);
    auto* picker=find(model_panel(),model_name(),UiColorPicker);
    if(!editable(enabled)||!value(picker))return false;
    // Re-resolve after each callback: a Lua callback can rebuild the menu.
    if(!write(enabled,1))return false;
    picker=find(model_panel(),model_name(),UiColorPicker);
    if(!write(picker,design::themes[which].color.pack()))return false;
    auto* binding=find(model_panel(),model_name(),UiCombobox);bool material=false;
    if(editable(binding)) {
        auto* combo=binding->source->GetAs<Combobox>();
        if(combo->Vars.size()<=128) {
            const auto choose=[&](const wchar_t* name){
                for(auto& v:combo->Vars)if(v.Name.size()&&v.Name.size()<128) {
                    const auto n=std::wcslen(name);
                    if((v.Name.size()==n||(v.Name.size()==n+1&&v.Name.data()[n]==0))&&std::equal(name,name+n,v.Name.data()))return write(binding,static_cast<unsigned>(v.Index));
                }
                return false;
            };
            material=choose(design::themes[which].material);
            if(!material&&live())material=choose(L"Solid");
        }
    }
    status=material?L"Style applied":L"Color applied; current material kept";
    return true;
}
// Presets are ordinary native comboboxes in the model panels, independent of
// the preview window. Their selected index is derived from the real color.
static Combobox* style_controls[4]{};static int style_values[4]{};
static constexpr int style_panels[]={EnemyModels,TeamModels,ViewPanel,ViewPanel};
static constexpr const wchar_t* style_labels[]={L"Player color preset",L"Teammate color preset",L"Local player color preset",L"Weapon viewmodel color preset"};
static void clear_styles(){for(auto& c:style_controls)c=nullptr;}
static void __fastcall style_changed(void* context,void* sender) {
    const auto slot=static_cast<unsigned>(reinterpret_cast<std::uintptr_t>(context));
    if(slot>=4||refreshing||!live()||sender!=style_controls[slot])return;
    const int selected=style_values[slot];if(selected<1||selected>4)return;
    subject=slot;
    if(!preset(selected-1))status=L"Model color unavailable in this profile";
}
static void sync_styles() {
    if(!live())return;const int saved=subject;
    for(int slot=0;slot<4;slot++)if(auto* control=style_controls[slot]) {
        subject=slot;auto* enabled=find(model_panel(),model_name(),UiCheckbox);auto* picker=find(model_panel(),model_name(),UiColorPicker);
        const bool available=editable(enabled)&&value(picker);int selected=0;
        if(read(enabled))for(int n=0;n<4;n++)if(read(picker)==design::themes[n].color.pack())selected=n+1;
        control->Header.Flags.Editable=control->Header.Flags.AllowMouseInput=available;
        if(style_values[slot]!=selected){style_values[slot]=selected;control->OnConfigLoad();}
    }
    subject=saved;
}
static bool add_styles() {
    const int saved=subject;
    for(int slot=0;slot<4;slot++) {
        subject=slot;
        // Partial source menus (including script-only menus) need no controls.
        if(!find(model_panel(),model_name(),UiCheckbox)||!find(model_panel(),model_name(),UiColorPicker))continue;
        auto& parent=groups[style_panels[slot]];if(!parent.child){subject=saved;return false;}
        auto* control=static_cast<Combobox*>(native.allocate(sizeof(Combobox)));
        if(!control){subject=saved;return false;}
        native.combo(control,parent.child,style_labels[slot],&style_values[slot],false);
        try {
            control->Vars.resize(5);
            for(int n=0;n<5;n++) {
                const wchar_t* name=n?design::themes[n-1].name:L"Custom";
                control->Vars[n].Name.assign(name,name+std::wcslen(name)+1);control->Vars[n].Index=n;
            }
            control->OnConfigLoad();
            control->Calls.emplace_back(reinterpret_cast<void*>(static_cast<std::uintptr_t>(slot)),&style_changed);
            native.insert(parent.child,false,control);style_controls[slot]=control;++parent.items;
            auto& elements=parent.child->Elements;const unsigned position=slot==design::Weapon&&style_controls[design::Local]?1:0;
            for(unsigned i=elements.size()-1;i>position;i--)elements[i]=elements[i-1];elements[position]=reinterpret_cast<PElement>(control);
        }catch(...){destroy(control);subject=saved;throw;}
    }
    subject=saved;sync_styles();return true;
}
static void action(int code) {
    if(code>=10&&code<14){subject=code-10;status=L"Illustrated appearance preview";}
    else if(code>=20&&code<28){if(!toggle(code-20))status=L"Option unavailable in this profile";}
    else if(code>=40&&code<44){if(!preset(code-40))status=L"Model color unavailable in this profile";}
}
static bool native_popup() {
    for(unsigned i=0;i<binding_count;i++) {
        auto* e=bindings[i].proxy;if(!e)continue;
        auto* base=e->GetAs<Checkbox>();if(!base->Header.Flags.Visible||(bindings[i].group&&bindings[i].group->child&&!bindings[i].group->child->Header.Flags.Visible))continue;
        const int t=base->Header.Type;
        if((t==UiCombobox&&e->GetAs<Combobox>()->Open)||(t==UiMultiselect&&e->GetAs<Multiselect>()->Popup)||
           (t==UiColorPicker&&e->GetAs<CPicker>()->Status!=PickerIdle)||
           (t==UiHotkey&&e->GetAs<Hotkey>()->Popup&&e->GetAs<Hotkey>()->Popup->Header.Flags.Visible))return true;
    }
    for(int slot=0;slot<4;slot++)if(style_controls[slot]&&style_controls[slot]->Open&&groups[style_panels[slot]].child&&groups[style_panels[slot]].child->Header.Flags.Visible)return true;
    return false;
}
static unsigned opacity(unsigned c,float alpha){return (c&0xffffffU)|(unsigned((c>>24)*alpha)<<24);}
struct Paint {
    IRenderer* r;float dpi,alpha;Rect clip;
    int s(int n)const{return std::max(1,int(n*dpi+.5f));}
    void fill(Rect box,unsigned color){if(box.w>0&&box.h>0)r->Rect(box.x,box.y,box.w,box.h,opacity(color,alpha));}
    void border(Rect b,unsigned c){fill({b.x,b.y,b.w,1},c);fill({b.x,b.y+b.h-1,b.w,1},c);fill({b.x,b.y,1,b.h},c);fill({b.x+b.w-1,b.y,1,b.h},c);}
    void text(int x,int y,const wchar_t* str,unsigned color,int max=0) {
        if(!str)return;int available=std::max(0,clip.x+clip.w-x-s(4));if(max>0)available=std::min(available,max);
        if(available>0)r->Text(0,x,y,opacity(color,alpha),available,str,std::wcslen(str));
    }
    void button(Rect b,const wchar_t* label,bool selected=false,bool available=true) {
        fill(b,selected?0xff303a24U:0xff222222U);border(b,selected?0xff719e99U:0xff383838U);
        text(b.x+s(6),b.y+s(5),label,available?(selected?0xffa8d59bU:0xffc8c8c8U):0xff666666U,b.w-s(10));
    }
};
static void draw(IRenderer* renderer,Rect box,float dpi,float alpha) {
    Paint p{renderer,dpi,alpha,box};const auto ui=design::controls(box,dpi);
    p.fill(box,0xff111111U);p.border(box,0xff404040U);p.border({box.x+2,box.y+2,box.w-4,box.h-4},0xff242424U);
    p.fill({box.x+p.s(4),box.y+p.s(4),box.w-p.s(8),1},0xff9bc166U);
    p.text(box.x+p.s(13),box.y+p.s(13),design::titles[subject],0xffdadadaU,box.w-p.s(50));
    p.fill({box.x+p.s(12),box.y+p.s(33),box.w-p.s(24),1},0xff303030U);
    {
        p.fill(ui.settings,0xff191919U);
        for(int i=0;i<4;i++)p.button(ui.subjects[i],design::names[i],subject==i);
        for(int i=0;i<8;i++) {
            auto* b=element(i);const bool available=editable(b),on=read(b)!=0;const auto r=ui.elements[i];
            const int d=p.s(5);p.fill({r.x,r.y+p.s(5),d,d},available?(on?0xff75b4a8U:0xff494949U):0xff2b2b2bU);
            p.text(r.x+p.s(11),r.y+p.s(3),design::elements[i],available?0xffbbbbbbU:0xff626262U,r.w-p.s(12));
        }
        p.text(ui.themes[0].x,ui.themes[0].y-p.s(17),L"Color presets",0xffd0d0d0U);
        const bool available=editable(find(model_panel(),model_name(),UiCheckbox))&&value(find(model_panel(),model_name(),UiColorPicker));
        for(int i=0;i<4;i++) {
            p.button(ui.themes[i],design::themes[i].name,false,available);
            const auto r=ui.themes[i];p.fill({r.x+r.w-p.s(11),r.y+p.s(7),p.s(4),p.s(9)},design::themes[i].color.pack());
        }
    }
    {
        p.text(ui.settings.x,ui.settings.y,L"Manage elements",0xffd0d0d0U);
        const Rect body=ui.model;
        const auto color=read(find(model_panel(),model_name(),UiColorPicker),0xffbab7aeU);
        auto tint=design::Color{static_cast<unsigned char>(color),static_cast<unsigned char>(color>>8),static_cast<unsigned char>(color>>16),static_cast<unsigned char>(color>>24)};
        if(!read(find(model_panel(),model_name(),UiCheckbox)))tint={124,132,145,255};
        static design::Mesh mesh;static Rect old_body{};static unsigned old_tint=0;static float old_yaw=0;static int old_subject=-1;
        if(!(body==old_body)||old_tint!=tint.pack()||old_yaw!=yaw||old_subject!=subject) {
            mesh.build(body,tint,yaw,subject==design::Weapon);old_body=body;old_tint=tint.pack();old_yaw=yaw;old_subject=subject;
        }
        for(unsigned i=0;i<mesh.count;i++) {
            const auto& t=mesh.triangles[i];renderer->Triangle(t.x[0],t.y[0],t.x[1],t.y[1],t.x[2],t.y[2],opacity(t.color.pack(),alpha));
        }
        if(subject<=design::Team) {
            const Rect target{body.x+p.s(18),body.y+p.s(25),std::max(1,body.w-p.s(25)),body.h-p.s(21)};
            if(read(element(0)))p.border(target,read(find(esp_panel(),L"Bounding box",UiColorPicker),0xffeeeeeeU));
            if(read(element(1))){p.fill({target.x-p.s(7),target.y,p.s(3),target.h},0xff242424U);p.fill({target.x-p.s(7),target.y+target.h/4,p.s(3),target.h*3/4},0xff68c58cU);}
            if(read(element(2)))p.text(target.x+p.s(12),target.y-p.s(18),L"Player",read(find(esp_panel(),L"Name",UiColorPicker),0xffeeeeeeU));
            if(read(element(3))) {
                const int x=target.x+target.w/2,y=target.y;const unsigned c=opacity(read(find(esp_panel(),L"Skeleton",UiColorPicker),0xffeed1a2U),alpha);
                const int pts[][4]={{0,12,0,55},{0,29,-20,48},{0,29,20,48},{0,55,-14,91},{0,55,14,91}};
                for(const auto& v:pts)renderer->Line(x+v[0]*target.w/100,y+v[1]*target.h/100,x+v[2]*target.w/100,y+v[3]*target.h/100,c);
            }
            if(read(element(4))||read(element(5)))p.text(target.x+p.s(16),target.y+target.h+p.s(6),L"AWP",0xffdededeU);
            if(read(element(6))){p.fill({target.x,target.y+target.h+p.s(3),target.w,p.s(2)},0xff303030U);p.fill({target.x,target.y+target.h+p.s(3),target.w*3/4,p.s(2)},0xffd3a964U);}
            if(read(element(7)))p.text(target.x+target.w+p.s(5),target.y+p.s(9),L"HK",0xff9dcbd3U,p.s(30));
        }
    }
    p.text(box.x+p.s(12),box.y+box.h-p.s(10),status,0xff818181U,box.w-p.s(24));
}
static int screen_width=0,screen_height=0;
static void prepare(CMenu* menu) {
    appearance_reserve_width=0;
    if(screen_width&&screen_height&&ready(menu)&&menu->CurrentTab==VISUALS&&(menu->MenuStatus&MenuOpened))
        appearance_reserve_width=design::dock({menu->Pos.x,menu->Pos.y,menu->Size.x,menu->Size.y},screen_width,screen_height,scale()).reserved;
}
static void frame(CMenu* menu) {
    using namespace preview_window_input;
    if(!ready(menu)||!live()||menu->CurrentTab!=VISUALS||!(menu->MenuStatus&MenuOpened)) {
        publish(0,0,0,0,false);return;
    }
    auto* hwnd=*reinterpret_cast<HWND*>(reinterpret_cast<char*>(menu)+8);
    if(!preview_window_input::attach(hwnd)||GetForegroundWindow()!=hwnd){publish(0,0,0,0,false);return;}
    int sw=0,sh=0;auto* renderer=context->IRenderer;renderer->ScreenSize(&sw,&sh);
    if(sw<320||sh<300||sw>16384||sh>16384){publish(0,0,0,0,false);return;}
    if(active!=last_category) {
        if(active==Enemy)subject=design::Enemy;else if(active==Team)subject=design::Team;else if(active==View)subject=design::Local;
        last_category=active;
    }
    screen_width=sw;screen_height=sh;
    const auto placement=design::dock({menu->Pos.x,menu->Pos.y,menu->Size.x,menu->Size.y},sw,sh,scale());
    const auto box=placement.area;const float dpi=placement.dpi;
    publish(box.x,box.y,box.w,box.h,!native_popup());
    int x,y;if(take(x,y))action(design::action(design::controls(box,dpi),x,y,true));
    if(!live()){publish(0,0,0,0,false);return;}
    int bounds[4]{};const bool clipped=renderer->IsBoundsPresent();if(clipped)renderer->GetBounds(bounds);
    const float depth=renderer->GetZBuff();renderer->ResetBounds(false);renderer->SetZBuff(.2f);
    int ours[]={box.x,box.y,box.w,box.h};renderer->SetBounds(ours);
    draw(renderer,box,dpi,std::clamp(menu->MenuAlpha,0.f,1.f));
    if(clipped)renderer->SetBounds(bounds);else renderer->ResetBounds(false);
    renderer->SetZBuff(depth);
}
}
