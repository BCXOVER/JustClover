#pragma once
#include "cs2_visuals_design.h"
namespace appearance_design {
using cs2_visuals::Rect;using cs2_visuals::Color;
enum Subject {Enemy,Team,Local,Weapon,Subjects};
inline constexpr const wchar_t* names[]={L"Enemy",L"Team",L"Self",L"Weapon"};
inline constexpr const wchar_t* titles[]={L"Enemy ESP preview",L"Team ESP preview",L"Local player preview",L"Weapon viewmodel preview"};
inline constexpr const wchar_t* elements[]={L"Bounding box",L"Health bar",L"Name",L"Skeleton",L"Weapon icon",L"Weapon text",L"Ammo",L"Flags"};
struct Theme {const wchar_t* name;Color color;const wchar_t* material;};
inline constexpr Theme themes[]={
    {L"Glacier",{88,196,240,255},L"Solid"},
    {L"Amethyst",{171,133,235,255},L"Solid"},
    {L"Crimson",{225,78,104,255},L"Metallic"},
    {L"Champagne",{224,187,112,255},L"Metallic"}};
inline bool contains(Rect r,int x,int y){return r.w>0&&r.h>0&&x>=r.x&&y>=r.y&&x<r.x+r.w&&y<r.y+r.h;}
inline Rect panel(Rect menu,int sw,int sh,float& dpi) {
    dpi=std::clamp(dpi,.5f,2.f);
    dpi=std::min(dpi,std::max(.5f,(sh-16)/400.f));
    // A separate preview can overlap the menu when neither screen edge has room.
    // Its input region is owned by the window input router, preventing click-through.
    const int gap=std::max(4,int(12*dpi));
    const int width=std::min(int(280*dpi),std::max(160,sw/3));
    dpi=std::min(dpi,width/280.f);
    const int height=std::clamp(menu.h,int(400*dpi),std::max(int(400*dpi),std::min(int(620*dpi),sh-16)));
    int x=menu.x+menu.w+gap;
    if(x+width>sw-8)x=menu.x-width-gap;
    if(x<8)x=std::max(8,sw-width-8);
    const int h=std::min(height,sh-16);
    return {std::clamp(x,8,std::max(8,sw-width-8)),std::clamp(menu.y,8,std::max(8,sh-h-8)),width,h};
}
struct Dock {Rect area;float dpi;int reserved;};
inline Dock dock(Rect menu,int sw,int sh,float dpi) {
    Dock out{panel(menu,sw,sh,dpi),dpi,0};out.dpi=dpi;
    const int gap=std::max(4,int(12*dpi));
    if(menu.x+menu.w+gap+out.area.w>sw-8&&menu.x-gap-out.area.w<8) {
        out.reserved=std::min(out.area.w+gap,std::max(1,menu.w/3));
        out.area.w=std::max(1,out.reserved-gap);out.area.x=menu.x+menu.w-out.reserved;
        out.dpi=std::min(out.dpi,out.area.w/280.f);
    }
    return out;
}
struct Controls {
    Rect model,settings;std::array<Rect,4> subjects,themes;std::array<Rect,8> elements;
};
inline Controls controls(Rect panel,float dpi) {
    const auto s=[&](int n){return std::max(1,int(n*dpi+.5f));};
    Controls c{};const int left=panel.x+s(12),width=panel.w-s(24),gap=s(4);
    const int cell=(width-gap*3)/4;
    for(int i=0;i<4;i++)c.subjects[i]={left+i*(cell+gap),panel.y+s(39),cell,s(22)};
    const int settings_height=s(183);
    c.settings={left,panel.y+panel.h-settings_height-s(12),width,settings_height};
    c.model={left+s(27),panel.y+s(76),width-s(54),std::max(s(80),c.settings.y-panel.y-s(98))};
    const int half=(width-gap)/2;
    for(int i=0;i<8;i++)c.elements[i]={left+(half+gap)*(i%2),c.settings.y+s(23)+s(22)*(i/2),half,s(19)};
    for(int i=0;i<4;i++)c.themes[i]={left+(half+gap)*(i%2),c.settings.y+s(124)+s(26)*(i/2),half,s(22)};
    return c;
}
inline int action(const Controls& c,int x,int y,bool =true) {
    for(int i=0;i<4;i++)if(contains(c.subjects[i],x,y))return 10+i;
    for(int i=0;i<8;i++)if(contains(c.elements[i],x,y))return 20+i;
    for(int i=0;i<4;i++)if(contains(c.themes[i],x,y))return 40+i;
    return 0;
}
// The preview mesh is deliberately a stylized mannequin, not an extracted game
// player model. It communicates ESP placement/colors without engine MDL hooks.
struct Point {float x,y,z;};
struct Triangle {int x[3],y[3];Color color;float depth;};
struct Mesh {
    std::array<Triangle,2200> triangles{};unsigned count=0;Rect area{};float yaw=.25f,unit=1;bool rifle=false;
    Point transform(Point p)const {
        const float c=std::cos(yaw),s=std::sin(yaw);
        return {p.x*c-p.y*s,p.x*s+p.y*c,p.z};
    }
    void box(Point a,Point b,Color color) {
        Point p[8];for(int i=0;i<8;i++)p[i]=transform({i&1?b.x:a.x,i&2?b.y:a.y,i&4?b.z:a.z});
        constexpr int faces[][4]={{0,4,6,2},{1,3,7,5},{0,1,5,4},{2,6,7,3},{4,5,7,6},{0,2,3,1}};
        constexpr float shade[]={.68f,.83f,1.f,.55f,1.13f,.42f};
        for(int f=0;f<6;f++)for(int k=0;k<2;k++) {
            if(count==triangles.size())return;
            const int ids[]={faces[f][0],faces[f][k+1],faces[f][k+2]};auto& t=triangles[count++];t.depth=0;
            for(int n=0;n<3;n++) {
                const auto v=p[ids[n]];
                t.x[n]=int(area.x+area.w*.5f+v.x*unit+v.y*unit*.24f);
                t.y[n]=int((rifle?area.y+area.h*.6f+34*unit:area.y+area.h-2*unit)-v.z*unit+v.y*unit*.12f);t.depth+=v.y;
            }
            t.color={static_cast<unsigned char>(std::clamp(int(color.r*shade[f]),0,255)),
                static_cast<unsigned char>(std::clamp(int(color.g*shade[f]),0,255)),
                static_cast<unsigned char>(std::clamp(int(color.b*shade[f]),0,255)),color.a};
        }
    }
    void ellipsoid(Point a,Point b,Color color) {
        constexpr int slices=12,rings=5;Point points[rings+1][slices];float light[rings+1][slices];
        const Point center{(a.x+b.x)*.5f,(a.y+b.y)*.5f,(a.z+b.z)*.5f};
        for(int j=0;j<=rings;j++)for(int k=0;k<slices;k++) {
            const float latitude=-1.57079633f+j*3.14159265f/rings,longitude=k*6.28318531f/slices;
            const Point n{std::cos(latitude)*std::cos(longitude),std::cos(latitude)*std::sin(longitude),std::sin(latitude)};
            points[j][k]=transform({center.x+n.x*(b.x-a.x)*.5f,center.y+n.y*(b.y-a.y)*.5f,center.z+n.z*(b.z-a.z)*.5f});
            const auto normal=transform(n);light[j][k]=.45f+.65f*std::max(0.f,-normal.x*.3f-normal.y*.7f+normal.z*.55f);
        }
        for(int j=0;j<rings;j++)for(int k=0;k<slices;k++)for(int half=0;half<2;half++) {
            if(count==triangles.size())return;
            const int next=(k+1)%slices;const Point q[]={points[j][k],points[j+1][k],points[j+1][next],points[j][next]};
            const int ids[]={0,half+1,half+2};auto& t=triangles[count++];t.depth=0;
            for(int n=0;n<3;n++) {
                const auto v=q[ids[n]];t.x[n]=int(area.x+area.w*.5f+v.x*unit+v.y*unit*.24f);
                t.y[n]=int((rifle?area.y+area.h*.6f+34*unit:area.y+area.h-2*unit)-v.z*unit+v.y*unit*.12f);t.depth+=v.y;
            }
            const float shade=(light[j][k]+light[j+1][k]+light[j+1][next])*.33333333f;
            t.color={static_cast<unsigned char>(std::clamp(int(color.r*shade),0,255)),static_cast<unsigned char>(std::clamp(int(color.g*shade),0,255)),static_cast<unsigned char>(std::clamp(int(color.b*shade),0,255)),color.a};
        }
    }
    void build(Rect region,Color tint,float rotation,bool weapon) {
        area=region;yaw=rotation;count=0;rifle=weapon;unit=std::min(area.h/82.f,area.w/(weapon?80.f:38.f));
        if(weapon) {
            // A compact rifle and two gloves, no downloaded game assets.
            box({-23,-3,34},{15,3,42},tint);box({15,-1,37},{32,1,39},tint);
            box({-30,-3,36},{-23,3,41},tint);box({-2,-2,25},{4,2,35},tint);
            box({-9,-2,41},{8,2,45},{75,79,87,255});
            ellipsoid({-14,-5,27},{-4,4,34},{105,111,120,255});ellipsoid({10,-5,29},{20,4,35},{105,111,120,255});
        } else {
            ellipsoid({-5,-4,58},{5,4,72},tint);ellipsoid({-3,-2,53},{3,2,63},tint);
            ellipsoid({-8,-4,36},{8,5,59},tint);ellipsoid({-12,-3,49},{12,4,58},tint);
            ellipsoid({-7,-4,30},{7,4,43},tint);
            ellipsoid({-7,-3,14},{0,3,37},tint);ellipsoid({0,-3,14},{7,3,37},tint);
            ellipsoid({-8,-3,2},{-1,3,22},tint);ellipsoid({1,-3,2},{8,3,22},tint);
            ellipsoid({-9,-7,0},{-1,4,7},tint);ellipsoid({1,-7,0},{9,4,7},tint);
            ellipsoid({-13,-3,36},{-7,4,56},tint);ellipsoid({7,-3,36},{13,4,56},tint);
            ellipsoid({-14,-6,25},{-8,2,43},tint);ellipsoid({8,-6,25},{14,2,43},tint);
            box({-4.5f,-4.1f,64},{4.5f,-3.9f,67},{38,42,50,255});
            box({-5,-5,44},{5,-4,53},{48,54,63,255});
        }
        // Painter ordering only affects our own isolated illustrative mesh.
        std::sort(triangles.begin(),triangles.begin()+count,[](const Triangle& a,const Triangle& b){return a.depth>b.depth;});
    }
};
}
