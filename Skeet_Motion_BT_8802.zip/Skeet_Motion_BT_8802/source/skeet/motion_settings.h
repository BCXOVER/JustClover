#pragma once
namespace motion_settings {
inline volatile int interpolation=1;
inline volatile int interpolation_gap=8;
inline volatile int extrapolation=1;
inline volatile int extrapolation_ticks=2;
inline volatile int backtrack=1;
inline volatile int backtrack_ms=200;
}
