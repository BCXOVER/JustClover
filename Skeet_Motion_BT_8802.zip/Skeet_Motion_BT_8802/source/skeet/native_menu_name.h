#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
namespace native_menu_name {
// Same stride-2 decoding as the supplied core's 0x43418122. The SDK's
// GetName wrapper returns a dangling stack pointer, so do not use it here.
inline bool equals(const void* encrypted,const wchar_t* wanted) {
    if(!encrypted||!wanted)return false;
    const auto* data=static_cast<const unsigned char*>(encrypted);
    std::uint16_t key=0,bytes=0;
    std::memcpy(&key,data,2);std::memcpy(&bytes,data+2,2);
    if(bytes>126||(bytes&1))return false;
    const std::size_t length=bytes/2;
    for(std::size_t i=0;i<length;i++) {
        const auto decoded=std::uint16_t((data[4+i*2]^(key&255))|(std::uint16_t(data[5+i*2])<<8));
        const auto expected=static_cast<std::uint16_t>(wanted[i]);
        if(!decoded)return expected==0;
        if(!expected)return false;
        auto a=decoded,b=expected;
        if(a>='A'&&a<='Z')a+=32;
        if(b>='A'&&b<='Z')b+=32;
        if(a!=b)return false;
        key=std::uint16_t((key>>1)|(key<<15));
    }
    return wanted[length]==0;
}
template<class Child> inline Child* other(Child* const* first,Child* const* last) {
    for(;first!=last;++first)
        if(*first&&equals((*first)->Name.get(),L"Other"))return *first;
    return nullptr;
}
}
