#pragma once
#include <cstddef>
#ifdef _WIN32
#define RAGE_THISCALL __thiscall
#else
#define RAGE_THISCALL
#endif
namespace rage_controls {
using Allocate=void*(RAGE_THISCALL*)(int);
using Release=void(RAGE_THISCALL*)(void*);
using Construct=void*(RAGE_THISCALL*)(void*,void*,const wchar_t*,int*);
using Insert=void(RAGE_THISCALL*)(void*,bool,void*);
using Layout=void(RAGE_THISCALL*)(void*);
using Slider=void*(RAGE_THISCALL*)(void*,void*,const wchar_t*,int,int,int*,bool,unsigned int,float);
struct Api {Allocate allocate;Release release;Construct construct;Insert insert;Layout layout;Slider slider;};
struct Spec {const wchar_t* name;bool slider;int minimum,maximum;};
inline constexpr Spec specs[]={
    {L"Patch: history guard",false,0,1},
    {L"Patch: strict hit chance",false,0,1},
    {L"Patch: 64-sample hit chance",false,0,1},
    {L"Patch: consistent records",false,0,1},
    {L"Patch: coherent interpolation",false,0,1},
    {L"Interpolation gap (ticks)",true,0,16},
    {L"Patch: adaptive extrapolation",false,0,1},
    {L"Extrapolation horizon (ticks)",true,0,8},
    {L"Patch: bounded backtrack",false,0,1},
    {L"BT depth (ms)",true,0,200}};
inline constexpr int count=sizeof(specs)/sizeof(specs[0]);
inline bool attach(void* child,const Api& api,int* const states[count],void* out[count]) {
    if(!child||!api.allocate||!api.release||!api.construct||!api.insert||!api.layout||!api.slider)return false;
    for(int i=0;i<count;i++)if(!states[i])return false;
    void* allocated[count]{};
    int previous[count]{};
    for(int i=0;i<count;i++)previous[i]=*states[i];
    for(int i=0;i<count;i++) {
        allocated[i]=api.allocate(specs[i].slider?0x124:0x78);
        if(!allocated[i]) {
            for(int j=0;j<i;j++)api.release(allocated[j]);
            return false;
        }
    }
    for(int i=0;i<count;i++) {
        const auto& spec=specs[i];
        if(spec.slider)api.slider(allocated[i],child,spec.name,spec.minimum,spec.maximum,states[i],true,0,1.f);
        else api.construct(allocated[i],child,spec.name,states[i]);
        api.insert(child,false,allocated[i]);
        *states[i]=previous[i];
        out[i]=allocated[i];
    }
    api.layout(child);
    return true;
}
}
#undef RAGE_THISCALL
