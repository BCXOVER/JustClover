#pragma once
#include "record_eligibility.h"
#include <algorithm>
#include <cstddef>
#include <cstring>

namespace motion_records {
using record_eligibility::u32;using record_eligibility::f32;
using record_eligibility::finite;using record_eligibility::position;
using Vec=record_eligibility::Position;
inline constexpr int record_size=0x10a0,scope_size=record_size+16,capacity=128;
inline int tick(const void* p){return static_cast<std::int32_t>(u32(p,0x4c));}
inline void put(void* p,int off,int value){std::memcpy(static_cast<char*>(p)+off,&value,4);}
inline void put(void* p,int off,float value){std::memcpy(static_cast<char*>(p)+off,&value,4);}
inline void put(void* p,int off,Vec v){std::memcpy(static_cast<char*>(p)+off,&v,12);}
inline Vec add(Vec a,Vec b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
inline Vec sub(Vec a,Vec b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
inline Vec mul(Vec a,float b){return {a.x*b,a.y*b,a.z*b};}
inline float dot(Vec a,Vec b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline bool same(Vec a,Vec b){return a.x==b.x&&a.y==b.y&&a.z==b.z;}
inline int clamp(int v,int lo,int hi){return v<lo?lo:(v>hi?hi:v);}
struct Options {int consistent,interpolation,gap,extrapolation,horizon,backtrack,depth;};
struct Clock {float interval,now,correction;int native_upper;};
// The clone executes only the existing core's record interpolation body.
using Blend=void(*)(const void*,const void*,int,void*);
// A swept player hull must reach its entire requested endpoint.
using Sweep=bool(*)(void* actor,Vec from,Vec to);
struct Api {Blend blend;Sweep sweep;};
struct Entry {int requested,status;alignas(16) unsigned char scope[scope_size];};
struct Scratch {
    bool active;void* actor;const void* history;void* context;
    Options options;Clock clock;int count,head,newest;const void* first;
    Vec current;int low,high,used;
    Entry entries[capacity];
};
inline const void* record(const void* history,unsigned i) {
    return reinterpret_cast<const void*>(static_cast<std::uintptr_t>(
        u32(history,0x5dc+((u32(history,0x5d4)+i)&31)*4)));
}
inline bool valid_clock(Clock c) {
    return finite(c.interval)&&c.interval>=1.f/1024&&c.interval<=.1f&&
        finite(c.now)&&c.now>=0&&c.now/c.interval<8000000&&
        finite(c.correction)&&c.correction>=0&&c.correction<=2;
}
inline int time_upper(Clock c) {
    if(!valid_clock(c))return -1;
    const float raw=(c.now-c.correction+(.2f-c.interval))/c.interval+.5f;
    if(!finite(raw)||raw<0||raw>8000000)return -1;
    return std::min({static_cast<int>(raw),static_cast<int>(c.now/c.interval),c.native_upper});
}
inline bool valid_pose(const void* p) {
    if(!p||!(u32(p,0x5c)&4)||!finite(position(p,0x30))||!finite(f32(p,0x28)))return false;
    if(tick(p)<0||tick(p)>8000000)return false;
    const int sets=(u32(p,0x5c)&0x80)?4:1;
    for(int set=0;set<sets;set++) {
        if(set&&!finite(f32(p,0x220+set*0x3a0)))return false;
        for(int off=0x230;off<0x230+19*48;off+=4)
            if(!finite(f32(p,off+set*0x3a0)))return false;
    }
    return true;
}
inline bool current(const Scratch& s) {
    if(!s.active||!s.history||!s.first||s.count<1||s.count>32||u32(s.history,0x5d8)!=static_cast<unsigned>(s.count)||
        u32(s.history,0x5d4)!=static_cast<unsigned>(s.head)||record(s.history,0)!=s.first)return false;
    return tick(s.first)==s.newest&&same(position(s.history,0x13c),s.current);
}
inline bool enhanced(const Scratch& s) {
    return s.options.consistent||s.options.interpolation||s.options.extrapolation;
}
// Keep every captured option and prepared pose fixed across both bone selectors
// and the subsequent application. No mutation of history or engine cvars.
inline bool begin(Scratch& s,void* actor,const void* history,void* context,
                  Options options,Clock clock,int& low,int& high,bool first_call) {
    if(!actor||!history||!context)return s.active=false;
    const unsigned count=u32(history,0x5d8);
    if(!count||count>32||!record(history,0))return s.active=false;
    if(tick(record(history,0))<0||tick(record(history,0))>8000000)return s.active=false;
    if(first_call||!current(s)||s.actor!=actor||s.history!=history||s.context!=context||
       s.clock.now!=clock.now||s.clock.interval!=clock.interval) {
        s.active=true;s.actor=actor;s.history=history;s.context=context;
        options.gap=clamp(options.gap,0,16);options.horizon=clamp(options.horizon,0,8);
        options.depth=clamp(options.depth,0,200);s.options=options;s.clock=clock;
        s.count=count;s.head=u32(history,0x5d4);s.first=record(history,0);
        s.newest=tick(s.first);s.current=position(history,0x13c);s.used=0;
    }
    if(s.options.backtrack&&valid_clock(s.clock)) {
        const int depth=static_cast<int>(s.options.depth/(1000.f*s.clock.interval));
        low=std::max(low,s.newest-depth);
    }
    // Caller may extend to an actually computed future pose, within the same
    // native timing tolerance and no later than the current engine clock.
    if(s.options.extrapolation&&s.options.horizon&&valid_clock(s.clock))
        high=std::max(high,std::min(s.newest+s.options.horizon,time_upper(s.clock)));
    s.low=low;s.high=high;
    return true;
}
inline bool translate(void* p,Vec delta,int requested) {
    if(!finite(delta)||dot(delta,delta)>1024.f)return false;
    put(p,0x30,add(position(p,0x30),delta));put(p,0x4c,requested);
    const int sets=(u32(p,0x5c)&0x80)?4:1;
    for(int set=0;set<sets;set++) {
        const int base=set*0x3a0;
        for(int bone=0;bone<19;bone++) {
            const int m=base+0x230+bone*48;
            put(p,m+12,f32(p,m+12)+delta.x);
            put(p,m+28,f32(p,m+28)+delta.y);
            put(p,m+44,f32(p,m+44)+delta.z);
        }
    }
    return valid_pose(p);
}
inline bool forecast(const Scratch& s,int requested,const Api& api,void* out) {
    if(!api.sweep||!s.options.extrapolation||!valid_clock(s.clock)||s.count<2)return false;
    const auto* a=s.first;const auto* b=record(s.history,1);
    if(!valid_pose(a)||!valid_pose(b)||(u32(a,0x5c)&0x200))return false;
    const int gap=tick(a)-tick(b),ahead=requested-tick(a);
    if(gap<1||gap>16||ahead<1||ahead>std::min(s.options.horizon,gap)||
       requested>time_upper(s.clock)||!record_eligibility::continuous(position(a,0x30),position(b,0x30)))return false;
    const Vec v=mul(sub(position(a,0x30),position(b,0x30)),1.f/gap);
    // Do not extrapolate a stationary or implausibly fast history segment.
    const float speed2=dot(v,v)/(s.clock.interval*s.clock.interval);
    if(!finite(speed2)||speed2<.01f||speed2>1000000.f)return false;
    float acceleration_z=0;
    if(s.count>=3&&!(u32(b,0x5c)&0x200)) {
        const auto* c=record(s.history,2);
        if(!c||!finite(position(c,0x30))||tick(c)<0||tick(c)>8000000)return false;
        const int gap2=tick(b)-tick(c);
        if(gap2<1||gap2>16||!record_eligibility::continuous(position(b,0x30),position(c,0x30)))return false;
        const Vec old_v=mul(sub(position(b,0x30),position(c,0x30)),1.f/gap2);
        const float xy=v.x*v.x+v.y*v.y,old_xy=old_v.x*old_v.x+old_v.y*old_v.y;
        const float alignment=v.x*old_v.x+v.y*old_v.y;
        if(xy>.0001f&&old_xy>.0001f) {
            if(alignment<=0)return false;
            if((alignment*alignment<.81f*xy*old_xy||xy<old_xy*.4225f||xy>old_xy*2.25f)&&ahead>1)return false;
        } else if((xy>.0001f)!=(old_xy>.0001f)) {if(ahead>1)return false;}
        const float az=(v.z-old_v.z)*2.f/(gap+gap2);
        const float gravity_bound=1200.f*s.clock.interval*s.clock.interval;
        if(az>=-gravity_bound&&az<=0)acceleration_z=az;
        else if((az>gravity_bound||az<-gravity_bound)&&ahead>1)return false;
    }
    const Vec origin=position(a,0x30);Vec last=origin;
    for(int n=1;n<=ahead;n++) {
        Vec delta=mul(v,static_cast<float>(n));
        delta.z+=.5f*acceleration_z*n*(n+gap);
        if(!finite(delta)||dot(delta,delta)>1024.f)return false;
        const Vec next=add(origin,delta);
        if(!api.sweep(s.actor,last,next))return false;
        last=next;
    }
    std::memcpy(out,a,record_size);
    return translate(out,sub(last,origin),requested);
}
inline Entry* prepare(Scratch& s,int requested,const Api& api) {
    if(!current(s)||!enhanced(s))return nullptr;
    for(int i=0;i<s.used;i++)if(s.entries[i].requested==requested)
        return s.entries[i].status?&s.entries[i]:nullptr;
    if(requested<s.low||requested>s.high)return nullptr;
    if(s.used==capacity)return nullptr;
    auto& entry=s.entries[s.used++];entry.requested=requested;entry.status=0;
    std::memset(entry.scope,0,16);put(entry.scope,0,static_cast<int>(reinterpret_cast<std::uintptr_t>(s.actor)));
    auto* out=entry.scope+16;
    const void* newer=nullptr;Vec previous=s.current;int previous_tick=0;
    if(!finite(previous))return nullptr;
    for(int i=0;i<s.count;i++) {
        const auto* p=record(s.history,i);if(!p)return nullptr;
        const auto pos=position(p,0x30);const int t=tick(p);
        if(!finite(pos)||!record_eligibility::continuous(previous,pos)||(i&&t>previous_tick))return nullptr;
        if(i==0&&requested>t) {
            if(!forecast(s,requested,api,out))return nullptr;
            entry.status=3;return &entry;
        }
        if(t<=requested) {
            if(!valid_pose(p))return nullptr;
            if(t==requested) {std::memcpy(out,p,record_size);entry.status=1;return &entry;}
            if(!s.options.interpolation||!api.blend||!newer||!valid_pose(newer)||
               tick(newer)-t>s.options.gap||tick(newer)<=requested)return nullptr;
            std::memcpy(out,newer,record_size);
            api.blend(newer,p,requested,entry.scope);
            if(tick(out)!=requested||!valid_pose(out))return nullptr;
            entry.status=2;return &entry;
        }
        if(u32(p,0x5c)&0x200)return nullptr;
        newer=p;previous=pos;previous_tick=t;
    }
    return nullptr;
}
inline bool point(Scratch& s,const void* history,int requested,int bone,void* origin,void* matrix,const Api& api) {
    if(history!=s.history||bone<0||bone>=19||!origin||!matrix)return false;
    const auto* e=prepare(s,requested,api);if(!e)return false;
    std::memcpy(origin,e->scope+16+0x30,12);
    std::memcpy(matrix,e->scope+16+0x230+bone*48,48);return true;
}
inline bool apply(Scratch& s,void* actor,const void* history,void* context,int requested,void* scope,const Api& api) {
    if(!s.active||s.actor!=actor||s.history!=history||s.context!=context||!scope)return false;
    const auto* e=prepare(s,requested,api);if(!e)return false;
    std::memcpy(static_cast<char*>(scope)+16,e->scope+16,record_size);
    put(scope,4,static_cast<int>(u32(scope,4)|(u32(e->scope,4)&0x10)));return true;
}
}
