#pragma once
// One SDK implementation lives in saver.cpp, as in the previous release.
#include "rage_patch_menu.h"
#include "rage_patch_controls.h"
#include "precision_patch.h"
#include "record_patch.h"
#include "overlay_patch.h"
#include "native_menu_name.h"
#include "motion_settings.h"
namespace rage_patch_menu {
static rage_controls::Construct construct=nullptr;
static rage_controls::Insert insert=nullptr;
static rage_controls::Slider slider=nullptr;
static bool attached=false;
static void* controls[rage_controls::count]{};
static_assert(sizeof(SkeetSDK::Checkbox)==0x78);
static_assert(offsetof(SkeetSDK::Checkbox,Value)==0x5c);
static_assert(sizeof(SkeetSDK::Slider)==0x124);
bool prepare(std::uint8_t* image,std::size_t size) {
    if(!image||size!=scan_patch::image_size)return false;
    constexpr int ctor_pattern[]={0x56,0xff,0x74,0x24,0x10,0x8b,0xf1,0x6a,0x03};
    constexpr int insert_pattern[]={0x56,0x57,0x8b,0xf9,0x8b,0x4f,0x10};
    constexpr int slider_pattern[]={0x55,0x8b,0xec,0x53,0x56,0xff};
    const auto a=overlay_patch::find(image,size,ctor_pattern);
    const auto b=overlay_patch::find(image,size,insert_pattern);
    const auto c=overlay_patch::find(image,size,slider_pattern);
    if(a.count!=1||b.count!=1||c.count!=1){SetLastError(ERROR_REVISION_MISMATCH);return false;}
    construct=reinterpret_cast<rage_controls::Construct>(image+a.offset);
    insert=reinterpret_cast<rage_controls::Insert>(image+b.offset);
    slider=reinterpret_cast<rage_controls::Slider>(image+c.offset);
    return true;
}
bool attach() {
    using namespace SkeetSDK;
    if(attached)return true;
    if(!construct||!insert||!slider||!Menu||!Memory::Allocator||!Memory::Deallocator||Menu->Tabs.size()<=RAGE)return false;
    auto* tab=Menu->Tabs[RAGE];
    if(!tab||tab->Childs.empty())return false;
    PChild child=native_menu_name::other(tab->Childs.data(),tab->Childs.data()+tab->Childs.size());
    if(!child)return false;
    auto** vtable=*reinterpret_cast<void***>(child);
    rage_controls::Api api{Memory::Allocator,Memory::Deallocator,construct,insert,
        reinterpret_cast<rage_controls::Layout>(vtable[8]),slider};
    int* states[]={const_cast<int*>(&scan_patch::history_guard_enabled),
        const_cast<int*>(&scan_patch::strict_threshold_enabled),const_cast<int*>(&precision_patch::enabled),
        const_cast<int*>(&record_patch::enabled),const_cast<int*>(&motion_settings::interpolation),
        const_cast<int*>(&motion_settings::interpolation_gap),const_cast<int*>(&motion_settings::extrapolation),
        const_cast<int*>(&motion_settings::extrapolation_ticks),const_cast<int*>(&motion_settings::backtrack),
        const_cast<int*>(&motion_settings::backtrack_ms)};
    attached=rage_controls::attach(child,api,states,controls);
    if(attached&&child->Elements.size()>=rage_controls::count) {
        // Display new controls first, within Other, so they are reachable even
        // at the original menu height. Stable native object IDs are unchanged.
        std::rotate(child->Elements.begin(),child->Elements.end()-rage_controls::count,child->Elements.end());
        api.layout(child);
    }
    return attached;
}
}
