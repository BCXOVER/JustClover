#include "../source/skeet/rage_patch_controls.h"
#include "../source/skeet/native_menu_name.h"
extern "C" __declspec(dllexport) int attach_probe(void* child,rage_controls::Api* api,
                                                int** states,void** out) {
    return rage_controls::attach(child,*api,states,out)?1:0;
}
struct NameRef {void* data;void* get() const{return data;}};
struct ChildView {unsigned char prefix[0x38];NameRef Name;};
extern "C" __declspec(dllexport) void* choose_other_probe(ChildView** children,unsigned count) {
    return native_menu_name::other(children,children+count);
}
extern "C" __declspec(dllexport) int decode_other_probe(void* encrypted) {
    return native_menu_name::equals(encrypted,L"Other");
}
