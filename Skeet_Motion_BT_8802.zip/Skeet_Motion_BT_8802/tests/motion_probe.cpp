#include <windows.h>
#include "../source/skeet/motion_patch.h"
using namespace motion_records;
extern "C" {
__declspec(dllexport) Scratch probe_scratch{};
__declspec(dllexport) void initialize_probe(unsigned blend,unsigned sweep) {
    motion_patch::tls_slot=7;
    scan_patch::application_return=0x100000;
    motion_patch::api={reinterpret_cast<Blend>(blend),reinterpret_cast<Sweep>(sweep)};
}
__declspec(dllexport) void options_probe(int consistent,int interpolation,int gap,int extrapolation,int horizon,int backtrack,int depth) {
    record_patch::enabled=consistent;motion_settings::interpolation=interpolation;motion_settings::interpolation_gap=gap;
    motion_settings::extrapolation=extrapolation;motion_settings::extrapolation_ticks=horizon;
    motion_settings::backtrack=backtrack;motion_settings::backtrack_ms=depth;
}
__declspec(dllexport) void begin_probe(void* context,unsigned* args){motion_patch::begin(context,args);}
__declspec(dllexport) int __fastcall getter_probe(const void* h,int t,int bone,void* o,void* m) {
    return motion_patch::getter(h,t,bone,o,m);
}
__declspec(dllexport) int apply_probe(void* frame,void* ebp){return motion_patch::apply_prepared(frame,ebp);}
__declspec(dllexport) unsigned scratch_size_probe(){return sizeof(Scratch);}
__declspec(dllexport) int trace_probe(void* actor,Vec from,Vec to){return motion_trace::sweep(actor,from,to);}
__declspec(dllexport) void trace_engine_probe(void* engine){motion_trace::engine=engine;}
}
