#!/usr/bin/env python3
"""Compare the real core's name decoder and slider constructor with our ABI.
Only isolated native methods execute; base constructors and layout are mocked.
"""
import json,struct,itertools
import pefile
from record_fixture import *
PE=pefile.PE(str(ROOT/'build/rage_controls_probe.dll'));PB=PE.OPTIONAL_HEADER.ImageBase
EXP={s.name.decode().lstrip('_'):PB+s.address for s in PE.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def encrypted(s,key,terminator=False):
    raw=bytearray((s+('\0' if terminator else '')).encode('utf-16le'));k=key
    for i in range(0,len(raw),2):
        raw[i]^=k&255;k=(k>>1|k<<15)&65535
    return struct.pack('<HH',key,len(raw))+raw+b'\0\0'
def invoke(u,entry,args,ecx=0,edx=0):
    for i,v in enumerate([STOP,*args]):store(u,SP+i*4,v)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,ecx);u.reg_write(UC_X86_REG_EDX,edx)
    run_until(u,entry,STOP);return u.reg_read(UC_X86_REG_EAX)
u=fixture();u.mem_map(PB,PE.OPTIONAL_HEADER.SizeOfImage);u.mem_write(PB,PE.get_memory_mapped_image())
def memset(u,a,size,user):
    if a!=0x774fdc80:return
    sp=u.reg_read(UC_X86_REG_ESP);dst,value,n=[word(u,sp+i) for i in [4,8,12]]
    u.mem_write(dst,bytes([value&255])*n);u.reg_write(UC_X86_REG_EAX,dst)
    u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+4)
u.hook_add(UC_HOOK_CODE,memset)
name,out=MEM+0x8000,MEM+0x9000;decoder=0
for text,key,terminator in itertools.product(['Other','other','OTHER','Aimbot','Weapon type','Other options',''],[0,1,0x8000,0x1234,0xffff],[False,True]):
    u.mem_write(name,encrypted(text,key,terminator))
    invoke(u,0x43418122,[out,128],name,2)
    native=bytes(u.mem_read(out,128)).decode('utf-16le').split('\0')[0]
    assert native==text
    assert invoke(u,EXP['decode_other_probe'],[name])==int(text.lower()=='other')
    decoder+=1
# Reject unsupported lengths, odd UTF16 payloads and nulls.
for n in [127,128,0xffff]:
    u.mem_write(name,struct.pack('<HH',0,n));assert invoke(u,EXP['decode_other_probe'],[name])==0;decoder+=1
assert invoke(u,EXP['decode_other_probe'],[0])==0;decoder+=1
placement=0
for names in [('Weapon type','Aimbot','Other'),('Other','Aimbot','Weapon type'),('Aimbot','Other'),('Aimbot','Other options'),('Aimbot',None,'OTHER')]:
    children=MEM+0xa000;expected=0
    for i,label in enumerate(names):
        child=MEM+0xb000+i*0x100;enc=MEM+0xc000+i*0x100
        if label is None:store(u,children+4*i,0);continue
        u.mem_write(enc,encrypted(label,0x8821+i));store(u,child+0x38,enc);store(u,children+4*i,child)
        if label.lower()=='other':expected=child
    assert invoke(u,EXP['choose_other_probe'],[children,len(names)])==expected
    placement+=1

# Execute the actual slider ctor. The signature's stack argument ordering,
# range fields, increment, bool tooltip, size and callee cleanup are real.
constructor=0
for maximum,value in [(8,2),(16,8),(200,200)]:
    u=fixture();obj=MEM+0x8000;child=MEM+0xa000;name=MEM+0xb000;state=MEM+0xc000
    u.mem_write(obj-4,b'\xaa'*0x12c);u.mem_write(name,'Test\0'.encode('utf-16le'));store(u,state,value)
    def mocks(u,a,size,user):
        if a not in [0x43383d2b,0x4334d0a8,0x4334a31c]:return
        sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX);ret=word(u,sp);clean=4
        if a==0x43383d2b:
            assert this==obj
            assert [word(u,sp+i) for i in [4,8,12,16]]==[child,name,5,state]
            store(u,obj+0x5c,state);clean=20
        elif a==0x4334d0a8:assert this==obj+0x38
        else:assert this==obj
        u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_ESP,sp+clean);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,mocks)
    result=invoke(u,0x433cf6b2,[child,name,0,maximum,state,1,0,fbits(1.)],obj)
    assert result==obj and u.reg_read(UC_X86_REG_ESP)==SP+36
    assert word(u,obj+0x90)==maximum and word(u,obj+0x94)==0
    assert scalar(u,obj+0x98)==1 and word(u,obj+0x5c)==state
    assert word(u,state)==value
    assert bytes(u.mem_read(obj-4,4))==b'\xaa'*4 and bytes(u.mem_read(obj+0x124,4))==b'\xaa'*4
    constructor+=1
for signature,address in [('55 8b ec 53 56 ff',0x433cf6b2),('56 ff 74 24 10 8b f1 6a 03',0x433adf35),('56 57 8b f9 8b 4f 10',0x4336c436)]:
    pattern=bytes.fromhex(signature);assert IMAGE.count(pattern)==1 and IMAGE[address-BASE:address-BASE+len(pattern)]==pattern
report={'passed':True,'decoder_comparisons':decoder,'other_placement_cases':placement,
    'native_slider_constructor_cases':constructor,'selection':'RAGE child encrypted name Other, independent of child index',
    'scope':__doc__,'game_tested':False}
(ROOT/'build/native_menu_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
