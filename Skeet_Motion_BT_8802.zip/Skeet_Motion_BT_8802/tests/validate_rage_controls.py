#!/usr/bin/env python3
"""Execute the compiled production control attachment helper with mock core APIs."""
from pathlib import Path
import json,struct,subprocess,os,hashlib
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
import sys
env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']=str(ROOT/'.cache/global');env['ZIG_LOCAL_CACHE_DIR']=str(ROOT/'.cache/local')
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++17','-O2','-shared',
               str(ROOT/'tests/rage_controls_probe.cpp'),'-o',str(BUILD/'rage_controls_probe.dll')],env=env,check=True)
pe=pefile.PE(str(BUILD/'rage_controls_probe.dll'))
base=pe.OPTIONAL_HEADER.ImageBase
entry=base+next(s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name and s.name.decode().lstrip('_')=='attach_probe')
MEM=0x200000;STOP=0x100000
def word(u,a):return struct.unpack('<I',u.mem_read(a,4))[0]
def store(u,a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
def wstring(u,a):
    text=[]
    for i in range(100):
        n=struct.unpack('<H',u.mem_read(a+i*2,2))[0]
        if not n:return ''.join(text)
        text.append(chr(n))
    raise ValueError('unbounded name')
names=['Patch: history guard','Patch: strict hit chance','Patch: 64-sample hit chance','Patch: consistent records',
       'Patch: coherent interpolation','Interpolation gap (ticks)','Patch: adaptive extrapolation',
       'Extrapolation horizon (ticks)','Patch: bounded backtrack','BT depth (ms)']
sliders={5:(0,16),7:(0,8),9:(0,200)}
count=len(names)
checks=0
for defaults in [(1,1,1,1,1,8,1,2,1,200),(1,0,1,0,1,16,0,8,1,50),(0,)*count]:
    for fail_allocation in range(count+1):
        u=Uc(UC_ARCH_X86,UC_MODE_32)
        u.mem_map(base,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(base,pe.get_memory_mapped_image())
        u.mem_map(MEM,0x10000);u.mem_map(STOP,0x1000)
        child=MEM+0x3000;api=MEM+0x4000;states=MEM+0x5000;out=MEM+0x6000
        values=[MEM+0x7000+i*4 for i in range(count)]
        for i,v in enumerate(defaults):store(u,values[i],v);store(u,states+i*4,values[i])
        for i in range(6):store(u,api+i*4,STOP+0x100+i*0x100)
        sp=MEM+0x2000
        for i,v in enumerate([STOP,child,api,states,out]):store(u,sp+i*4,v)
        u.reg_write(UC_X86_REG_ESP,sp)
        saved={UC_X86_REG_EBX:0x11223344,UC_X86_REG_ESI:0x22334455,UC_X86_REG_EDI:0x33445566,UC_X86_REG_EBP:0x44556677}
        for reg,v in saved.items():u.reg_write(reg,v)
        allocations=[];released=[];constructed=[];inserted=[];layout=[];finished=[]
        def hook(u,address,size,user):
            frame=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX)
            if address==STOP:
                assert frame==sp+4
                assert u.reg_read(UC_X86_REG_EAX)==int(fail_allocation==0)
                for reg,v in saved.items():assert u.reg_read(reg)==v
                finished.append(True);u.emu_stop();return
            if address not in [STOP+0x100+i*0x100 for i in range(6)]:return
            ret=word(u,frame);cleanup=4;result=0
            if address==STOP+0x100:
                assert this==(0x124 if len(allocations) in sliders else 0x78)
                if fail_allocation and len(allocations)+1==fail_allocation:result=0
                else:
                    result=MEM+0x8000+len(allocations)*0x200
                    allocations.append(result)
            elif address==STOP+0x200:
                released.append(this)
            elif address in [STOP+0x300,STOP+0x600]:
                index=len(constructed)
                assert this==allocations[index]
                assert word(u,frame+4)==child
                assert wstring(u,word(u,frame+8))==names[index]
                if address==STOP+0x600:
                    assert index in sliders
                    assert tuple(word(u,frame+i) for i in [12,16])==sliders[index]
                    value=word(u,frame+20)
                    assert word(u,frame+24)==1 and word(u,frame+28)==0
                    assert word(u,frame+32)==0x3f800000
                    cleanup=36
                else:
                    assert index not in sliders
                    value=word(u,frame+12);cleanup=16
                assert value==values[index]
                store(u,this+0x5c,value)
                u.mem_write(value,b'\x00') # A constructor is allowed to initialize the flag.
                constructed.append(this);result=this
            elif address==STOP+0x400:
                assert this==child and word(u,frame+4)==0
                inserted.append(word(u,frame+8));cleanup=12
            elif address==STOP+0x500:
                assert this==child;layout.append(this)
            u.reg_write(UC_X86_REG_ESP,frame+cleanup)
            u.reg_write(UC_X86_REG_EAX,result)
            u.reg_write(UC_X86_REG_ECX,0xabcdef01);u.reg_write(UC_X86_REG_EDX,0xabcdef02)
            u.reg_write(UC_X86_REG_EIP,ret)
        u.hook_add(UC_HOOK_CODE,hook)
        u.emu_start(entry,STOP+0x800,count=10000)
        assert finished
        assert [word(u,v) for v in values]==list(defaults)
        if fail_allocation:
            assert len(allocations)==fail_allocation-1
            assert released==allocations and not constructed and not inserted and not layout
        else:
            assert len(allocations)==count and inserted==constructed==allocations
            assert not released and len(layout)==1
            for i,v in enumerate(values):
                native=word(u,out+i*4);assert word(u,native+0x5c)==v
                # Simulate the native checkbox writing its bool storage. The
                # same byte is consumed by the production x86 patch switches.
                if i in sliders:
                    store(u,v,sliders[i][1]);assert word(u,v)==sliders[i][1]
                else:
                    u.mem_write(v,bytes([1-defaults[i]]));assert word(u,v)==1-defaults[i]
        checks+=1
report={'passed':True,'compiled_helper_cases':checks,'native_checkbox_count':7,'native_slider_count':3,
        'labels':names,'checkbox_size':120,'value_offset':92,
        'probe_sha256':hashlib.sha256((BUILD/'rage_controls_probe.dll').read_bytes()).hexdigest(),
        'scope':'Compiled Windows x86 production attachment helper; core allocator, constructors, insertion and layout are mocked.',
        'game_tested':False}
(BUILD/'rage_controls_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
