#!/usr/bin/env python3
"""Reproduce the CALL relocation list without starting the protected core."""
from pathlib import Path
import hashlib,json
from capstone import Cs,CS_ARCH_X86,CS_MODE_32,CS_GRP_JUMP,CS_GRP_RET
from capstone.x86 import X86_OP_IMM
ROOT=Path(__file__).resolve().parents[1]
BASE=0x43310000;BEGIN=0x43344de8;END=0x43345b83
raw=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='bf5cd94cd3511f09f4241d952ed8bdde3eb8fb95d12534fbf4e23bd6b9789fc3'
md=Cs(CS_ARCH_X86,CS_MODE_32);md.detail=True
todo=[BEGIN];nodes={};covered={}
while todo:
    address=todo.pop()
    if address in nodes or address==END:continue
    assert BEGIN<=address<END
    ins=next(md.disasm(raw[address-BASE:address-BASE+15],address,count=1));nodes[address]=ins
    for byte in range(address,address+ins.size):
        assert byte not in covered,('overlapping instructions',hex(address),hex(covered.get(byte,0)))
        covered[byte]=address
    assert not ins.group(CS_GRP_RET)
    if ins.group(CS_GRP_JUMP):
        assert ins.operands[0].type==X86_OP_IMM
        todo.append(ins.operands[0].imm)
        if ins.mnemonic=='jmp':continue
    todo.append(address+ins.size)
calls=[address-BEGIN for address,i in sorted(nodes.items()) if i.mnemonic=='call']
assert len(calls)==34 and all(nodes[BEGIN+off].size==5 and nodes[BEGIN+off].bytes[0]==0xe8 for off in calls)
expected=('#pragma once\n// Generated from the exact supplied core. Only reachable relative CALLs are rebased.\n'
    'namespace motion_plan {\ninline constexpr unsigned blend_begin=0x43344de8,blend_end=0x43345b83;\n'
    'inline constexpr unsigned blend_calls[]={'+','.join(hex(x) for x in calls)+'};\n}\n')
assert (ROOT/'source/skeet/motion_blend_sites.h').read_text()==expected
report={'passed':True,'body_bytes':END-BEGIN,'reachable_call_count':len(calls),
    'body_sha256':hashlib.sha256(raw[BEGIN-BASE:END-BASE]).hexdigest(),
    'overlapping_instructions':False,'calls':[hex(x) for x in calls]}
(ROOT/'build/blend_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('Native interpolation CALL relocation audit: PASS (34 sites, no overlapping instructions)')
