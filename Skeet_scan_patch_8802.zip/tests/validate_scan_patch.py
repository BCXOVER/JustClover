#!/usr/bin/env python3
"""Run original x86 callers and production-generated patch code in Unicorn.

Record application is tested both through bounded mocks and its native early
rejection paths. Engine interfaces and the snapshot destructor are mocked.
No DLL, Windows process, game module, or protected core startup is executed.
"""
from pathlib import Path
import hashlib
import json
import math
import struct
import subprocess
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
from unicorn.x86_const import *

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build'
BUILD.mkdir(exist_ok=True)
CORE = ROOT / 'source/skeet/Binary/skeet_cv.bin'
IMAGE = CORE.read_bytes()
BASE = 0x43310000
STACK = 0x200000
STOP = 0x100000
HELPER = BUILD / 'scan_patch_plan'
subprocess.run(['g++', '-std=c++17', '-O2', str(ROOT/'tests/scan_patch_plan.cpp'),
                '-o', str(HELPER)], check=True)

def word(uc, address):
    return struct.unpack('<I', uc.mem_read(address, 4))[0]

def store(uc, address, value):
    uc.mem_write(address, struct.pack('<I', value & 0xffffffff))

def machine(code_address, plan, patched):
    uc = Uc(UC_ARCH_X86, UC_MODE_32)
    uc.mem_map(BASE, len(IMAGE))
    uc.mem_write(BASE, IMAGE)
    uc.mem_map(code_address, 4096)
    uc.mem_write(code_address, plan[:128])
    uc.mem_map(STACK, 0x10000)
    uc.mem_map(STOP, 4096)
    if patched:
        uc.mem_write(BASE+0x1ffb1, plan[128:133])
        uc.mem_write(BASE+0x20178, plan[133:139])
    return uc

threshold_checks = 0
guard_checks = 0
changed_decisions = 0
for location in [0x10000000, 0x60000000, 0xf0000000]:
    plan_file = BUILD / f'scan_plan_{location:x}.bin'
    subprocess.run([str(HELPER), str(CORE), str(plan_file), hex(location)], check=True)
    plan = plan_file.read_bytes()
    for patched in [False, True]:
        uc = machine(location, plan, patched)
        result = {}
        def threshold_hook(uc, address, size, user):
            if address in (0x433300c8, 0x4333018d):
                result['accepted'] = address == 0x4333018d
                uc.emu_stop()
        hook = uc.hook_add(UC_HOOK_CODE, threshold_hook)
        for percent in range(101):
            required = max(1, math.ceil(percent*32/100) if patched else percent*32//100)
            for hits in range(33):
                sp = STACK+0x1000
                uc.reg_write(UC_X86_REG_ESP, sp)
                uc.reg_write(UC_X86_REG_EDI, STACK+0x2000)
                store(uc, STACK+0x2848, percent)
                store(uc, sp+0xc, hits)
                result.clear()
                uc.emu_start(0x4333016c, STOP, count=150)
                assert result.get('accepted') == (hits >= required), (location, patched, percent, hits, result)
                threshold_checks += 1
                if patched and (hits >= max(1, percent*32//100)) != (hits >= required):
                    changed_decisions += 1
        uc.hook_del(hook)

        for scenario in ['mock_failure', 'mock_success', 'native_empty_history', 'native_teleport']:
            record_ok = scenario == 'mock_success'
            native_record = scenario.startswith('native_')
            for tick in [-1, 100, 1000000]:
                sp = STACK+0x1000
                bp = STACK+0x8000
                target = STACK+0x5000
                original_esi, original_edi = 0x11223344, 0x55667788
                saved_esi, saved_edi, saved_bp = 0x10203040, 0x50607080, 0x12345678
                uc.reg_write(UC_X86_REG_ESP, sp)
                uc.reg_write(UC_X86_REG_EBP, bp)
                uc.reg_write(UC_X86_REG_ESI, original_esi)
                uc.reg_write(UC_X86_REG_EDI, original_edi)
                uc.reg_write(UC_X86_REG_EAX, tick & 0xffffffff)
                store(uc, sp, saved_edi)
                store(uc, sp+4, saved_esi)
                store(uc, bp, saved_bp)
                store(uc, bp+4, STOP)
                store(uc, bp+8, target)
                history, record, vtable = STACK+0x6000, STACK+0x7000, STACK+0x9000
                store(uc, sp+0x2e0, target)
                store(uc, target+8, vtable)
                store(uc, vtable+0x28, STOP+0x100)
                store(uc, 0x4346a338, STACK+0xa000)
                uc.mem_write(STACK+0xa000, struct.pack('<f', 1/64))
                store(uc, 0x434797bc+3*4, history)
                store(uc, history+0x5d4, 0)
                store(uc, history+0x5d8, int(scenario == 'native_teleport'))
                store(uc, history+0x5dc, record)
                uc.mem_write(history+0x13c, struct.pack('<fff', 0, 0, 0))
                uc.mem_write(record+0x30, struct.pack('<fff', 65, 0, 0))
                calls = {'record': 0, 'cleanup': 0}
                outcome = {}
                def record_hook(uc, address, size, user):
                    if address == 0x43344c0c:
                        calls['record'] += 1
                        frame = uc.reg_read(UC_X86_REG_ESP)
                        assert [word(uc, frame+i) for i in (4,8,12)] == [target, tick, 0]
                        assert uc.reg_read(UC_X86_REG_ECX) == sp+0x2e0
                        if native_record:
                            return
                        ret = word(uc, frame)
                        uc.reg_write(UC_X86_REG_EAX, 0x12340000 | int(record_ok))
                        uc.reg_write(UC_X86_REG_EDX, 0xaabbccdd)
                        uc.reg_write(UC_X86_REG_ECX, 0xabcdef01)
                        uc.reg_write(UC_X86_REG_ESP, frame+16)
                        uc.reg_write(UC_X86_REG_EIP, ret)
                    elif address == STOP+0x100:
                        assert native_record
                        frame = uc.reg_read(UC_X86_REG_ESP)
                        ret = word(uc, frame)
                        uc.reg_write(UC_X86_REG_ESP, frame+4)
                        uc.reg_write(UC_X86_REG_EAX, 3)
                        uc.reg_write(UC_X86_REG_EIP, ret)
                    elif address == 0x4336630d:
                        calls['cleanup'] += 1
                        assert uc.reg_read(UC_X86_REG_ECX) == sp+0x2e0
                        frame = uc.reg_read(UC_X86_REG_ESP)
                        ret = word(uc, frame)
                        uc.reg_write(UC_X86_REG_ESP, frame+4)
                        uc.reg_write(UC_X86_REG_EAX, 0xabcdef02)
                        uc.reg_write(UC_X86_REG_EIP, ret)
                    elif address == 0x4332ffb6:
                        outcome['path'] = 'scan'
                        assert uc.reg_read(UC_X86_REG_ESP) == sp
                        assert uc.reg_read(UC_X86_REG_ESI) == original_esi
                        assert uc.reg_read(UC_X86_REG_EDI) == original_edi
                        uc.emu_stop()
                    elif address == STOP:
                        outcome['path'] = 'reject'
                        assert uc.reg_read(UC_X86_REG_EAX) == 0xffffffff
                        assert uc.reg_read(UC_X86_REG_ESP) == bp+24
                        assert uc.reg_read(UC_X86_REG_EBP) == saved_bp
                        assert uc.reg_read(UC_X86_REG_ESI) == saved_esi
                        assert uc.reg_read(UC_X86_REG_EDI) == saved_edi
                        uc.emu_stop()
                hook = uc.hook_add(UC_HOOK_CODE, record_hook)
                # Stop at a hook instead of using the sentinel as emu_start's end,
                # so the final return convention is checked as well.
                try:
                    uc.emu_start(0x4332ff9f, STOP+1, count=300)
                except Exception as exc:
                    raise RuntimeError((hex(location), patched, scenario, tick,
                                        hex(uc.reg_read(UC_X86_REG_EIP)), calls)) from exc
                reject = patched and tick != -1 and not record_ok
                assert outcome.get('path') == ('reject' if reject else 'scan'), (location, patched, record_ok, tick, outcome)
                assert calls == {'record': int(tick != -1), 'cleanup': int(reject)}, calls
                uc.hook_del(hook)
                guard_checks += 1

report = {
    'passed': True,
    'core_sha256': hashlib.sha256(IMAGE).hexdigest(),
    'threshold_cases': threshold_checks,
    'record_guard_cases': guard_checks,
    'changed_threshold_decisions_across_three_locations': changed_decisions,
    'code_locations': ['0x10000000', '0x60000000', '0xf0000000'],
    'scope': 'Original x86 callers and production-generated thunks; both mocked results and original native empty-history/teleport rejection paths. Engine index query and snapshot destructor mocked.',
    'windows_game_tested': False,
}
(BUILD/'scan_patch_validation.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
