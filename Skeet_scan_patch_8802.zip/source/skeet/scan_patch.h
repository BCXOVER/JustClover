#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>

// These offsets belong to the supplied core, not to client.dll or engine.dll.
namespace scan_patch {
inline constexpr std::uint32_t image_base = 0x43310000;
inline constexpr std::size_t image_size = 0x2fc000;
inline constexpr std::size_t guard_call = 0x1ffb1;
inline constexpr std::size_t threshold_call = 0x20178;
inline constexpr std::size_t threshold_stub = 64;
inline constexpr std::uint8_t original_guard[] = {0xe8,0x56,0x4c,0x01,0x00};
inline constexpr std::uint8_t original_threshold[] = {0x99,0xf7,0xf9,0x33,0xc9,0x41};

inline bool matches_original(const void* data, std::size_t size) {
    if (!data || size != image_size) return false;
    auto* bytes = static_cast<const std::uint8_t*>(data);
    std::uint64_t hash = 0xcbf29ce484222325ULL;
    for (std::size_t i = 0; i < size; ++i) hash = (hash ^ bytes[i]) * 0x100000001b3ULL;
    // Compatibility fingerprint; this is not a cryptographic integrity check.
    return hash == 0x0c2e3660b08b6ac4ULL;
}

inline void put32(std::uint8_t* dst, std::uint32_t value) {
    std::memcpy(dst, &value, sizeof(value));
}

struct Plan {
    std::uint8_t code[128]{};
    std::uint8_t guard[5]{};
    std::uint8_t threshold[6]{};
};

inline Plan make_plan(std::uint32_t code_address) {
    Plan plan{};
    // Duplicate the three original stack arguments before calling the original
    // __thiscall function. Its ECX receiver remains unchanged.
    constexpr std::uint8_t guard_code[] = {
        0xff,0x74,0x24,0x0c, 0xff,0x74,0x24,0x0c, 0xff,0x74,0x24,0x0c,
        0xb8,0x0c,0x4c,0x34,0x43, 0xff,0xd0, // original record application
        0x84,0xc0,0x74,0x03, 0xc2,0x0c,0x00, // success: original callee cleanup
        0x83,0xc4,0x10, 0xe9,0,0,0,0 // failure: original snapshot cleanup path
    };
    std::memcpy(plan.code, guard_code, sizeof(guard_code));
    put32(plan.code + 30, 0x433300c8U - (code_address + 34));

    // ceil(EAX / ECX) for positive ECX, retaining the original signed remainder
    // in EDX. Original code continues with ECX=1 and applies max(result, 1).
    constexpr std::uint8_t ceil_code[] = {
        0x99,0xf7,0xf9,0x85,0xd2,0x7e,0x01,0x40,0x33,0xc9,0x41,0xc3
    };
    std::memcpy(plan.code + threshold_stub, ceil_code, sizeof(ceil_code));
    plan.guard[0] = 0xe8;
    put32(plan.guard + 1, code_address - (image_base + guard_call + 5));
    plan.threshold[0] = 0xe8;
    put32(plan.threshold + 1,
        code_address + threshold_stub - (image_base + threshold_call + 5));
    plan.threshold[5] = 0x90;
    return plan;
}

inline bool compatible_sites(const std::uint8_t* image, std::size_t size) {
    constexpr std::uint8_t original_loop[] = {0xc7,0x44,0x24,0x14,0x20,0,0,0};
    constexpr std::uint8_t original_scale[] = {0xc1,0xe0,0x05,0x6a,0x64,0x59};
    constexpr std::uint8_t failure_cleanup[] = {
        0x83,0xce,0xff,0x8d,0x8c,0x24,0xe0,0x02,0,0,0xe8,0x36,0x62,0x03,0
    };
    return image && size == image_size &&
        !std::memcmp(image + guard_call, original_guard, sizeof(original_guard)) &&
        !std::memcmp(image + threshold_call, original_threshold, sizeof(original_threshold)) &&
        !std::memcmp(image + 0x200e9, original_loop, sizeof(original_loop)) &&
        !std::memcmp(image + 0x20172, original_scale, sizeof(original_scale)) &&
        !std::memcmp(image + 0x200c8, failure_cleanup, sizeof(failure_cleanup));
}

#ifdef _WIN32
inline bool apply(std::uint8_t* image, std::size_t size) {
    if (reinterpret_cast<std::uintptr_t>(image) != image_base ||
        !compatible_sites(image, size)) {
        SetLastError(ERROR_REVISION_MISMATCH);
        return false;
    }
    auto* code = static_cast<std::uint8_t*>(VirtualAlloc(
        nullptr, 4096, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE));
    if (!code) return false;
    const auto plan = make_plan(static_cast<std::uint32_t>(reinterpret_cast<std::uintptr_t>(code)));
    std::memcpy(code, plan.code, sizeof(plan.code));
    DWORD old_protection = 0;
    if (!VirtualProtect(code, 4096, PAGE_EXECUTE_READ, &old_protection) ||
        !FlushInstructionCache(GetCurrentProcess(), code, sizeof(plan.code))) {
        const auto error = GetLastError();
        VirtualFree(code, 0, MEM_RELEASE);
        SetLastError(error);
        return false;
    }
    // Installation occurs before the original core's entry thread is resumed.
    std::memcpy(image + guard_call, plan.guard, sizeof(plan.guard));
    std::memcpy(image + threshold_call, plan.threshold, sizeof(plan.threshold));
    if (!FlushInstructionCache(GetCurrentProcess(), image, size)) {
        const auto error = GetLastError();
        std::memcpy(image + guard_call, original_guard, sizeof(original_guard));
        std::memcpy(image + threshold_call, original_threshold, sizeof(original_threshold));
        FlushInstructionCache(GetCurrentProcess(), image, size);
        VirtualFree(code, 0, MEM_RELEASE);
        SetLastError(error);
        return false;
    }
    // The code remains allocated for the lifetime of the original image.
    return true;
}
#endif
}
