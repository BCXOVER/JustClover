#include "../source/skeet/appearance_preview_design.h"
#include <cassert>
#include <fstream>
#include <iostream>
#include <cmath>
using namespace appearance_design;
int main(int argc,char** argv) {
    unsigned checks=0;
    for(int sw:{640,800,1280,1920,3840})for(int sh:{480,720,1080})for(float requested:{.75f,1.f,1.5f,2.f,3.f}) {
        float dpi=requested;const auto r=panel({sw/3,sh/5,sw*2/3-20,sh*3/4},sw,sh,dpi);
        assert(r.x>=0&&r.y>=0&&r.x+r.w<=sw&&r.y+r.h<=sh);
        const auto c=controls(r,dpi);assert(contains(r,c.gear.x,c.gear.y));
        assert(action(c,c.gear.x,c.gear.y,false)==1);
        assert(action(c,c.close.x,c.close.y,false)==3);
        assert(action(c,c.gear.x+c.gear.w,c.gear.y,false)!=1);
        for(int i=0;i<4;i++)assert(action(c,c.subjects[i].x,c.subjects[i].y,true)==10+i);
        for(int i=0;i<8;i++)assert(action(c,c.elements[i].x,c.elements[i].y,true)==20+i);
        for(int i=0;i<4;i++)assert(action(c,c.themes[i].x,c.themes[i].y,true)==40+i);
        assert(c.themes[3].y+c.themes[3].h<c.gear.y);
        checks++;
    }
    Mesh mesh;
    for(bool rifle:{false,true})for(float yaw:{0.f,.4f,1.4f,2.4f,4.f,6.f}) {
        const Rect r{0,0,184,408};mesh.build(r,{174,138,230,255},yaw,rifle);
        assert(mesh.count>80&&mesh.count<mesh.triangles.size());
        for(unsigned i=0;i<mesh.count;i++)for(int p=0;p<3;p++) {
            const auto& t=mesh.triangles[i];if(t.x[p]<-2||t.x[p]>r.w+2||t.y[p]<-2||t.y[p]>r.h+2)std::cerr<<"Mesh bounds "<<rifle<<" yaw "<<yaw<<" x "<<t.x[p]<<" y "<<t.y[p]<<"\n";assert(t.x[p]>=-2&&t.x[p]<=r.w+2&&t.y[p]>=-2&&t.y[p]<=r.h+2);
            assert(std::isfinite(t.depth));
        }
    }
    if(argc>1) {
        mesh.build({35,40,184,400},{174,138,230,255},.4f,false);std::ofstream out(argv[1]);out<<"[";
        for(unsigned i=0;i<mesh.count;i++){if(i)out<<',';const auto& t=mesh.triangles[i];out<<'['<<t.x[0]<<','<<t.y[0]<<','<<t.x[1]<<','<<t.y[1]<<','<<t.x[2]<<','<<t.y[2]<<','<<t.color.pack()<<']';}out<<"]\n";
    }
    std::cout<<checks<<" preview layouts and 12 bounded mesh rotations passed\n";
}
