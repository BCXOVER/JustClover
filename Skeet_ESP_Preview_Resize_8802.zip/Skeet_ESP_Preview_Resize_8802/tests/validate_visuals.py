#!/usr/bin/env python3
"""Closed x86 checks of native UI proxy ABI, bindings and real menu forwarding.
Original constructors/renderers are not started as an application. Native
allocation, callbacks and renderer results are controlled fixtures.
"""
from pathlib import Path
import os,sys,subprocess,struct,json,itertools
import pefile
from record_fixture import *
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']=str(Path('/workspace/skeet-motion-bt-8802/.cache/global') if Path('/workspace/skeet-motion-bt-8802/.cache/global').exists() else ROOT/'.cache/global');env['ZIG_LOCAL_CACHE_DIR']=str(ROOT/'.cache/local')
def build(name,source,large=False):
    args=[sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++23','-O1','-shared']
    if large:args+=['-fms-extensions','-fasm-blocks','-DUNICODE','-D_UNICODE','-I',str(ROOT/'source/compat'),'-I',str(ROOT/'source/skeet')]
    args+=[str(ROOT/'tests'/source),'-o',str(BUILD/name)]
    if large:args+=['-luser32','-ladvapi32','-lpsapi']
    with (BUILD/(name+'.log')).open('w') as log:subprocess.run(args,env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
if '--reuse-probes' in sys.argv:
    for dll,source in [('ui_proxy_probe.dll','ui_proxy_probe.cpp'),('visuals_binding_probe.dll','visuals_binding_probe.cpp')]:
        assert (BUILD/dll).exists()
        for dep in [ROOT/'tests'/source,*(ROOT/'source/skeet').rglob('*.h')]:
            assert dep.stat().st_mtime<=(BUILD/dll).stat().st_mtime, f'Stale probe {dll}: {dep}'
else:
    build('ui_proxy_probe.dll','ui_proxy_probe.cpp')
    build('visuals_binding_probe.dll','visuals_binding_probe.cpp',True)
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/visuals_plan.cpp'),'-o',str(BUILD/'visuals_plan')],check=True)
def load(u,name,handlers=None):
    pe=pefile.PE(str(BUILD/name));base=pe.OPTIONAL_HEADER.ImageBase
    u.mem_map(base,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(base,pe.get_memory_mapped_image())
    symbols={s.name.decode().lstrip('_'):base+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
    u.mem_map(0x130000,0x4000);imports={}
    for library in getattr(pe,'DIRECTORY_ENTRY_IMPORT',[]):
        for item in library.imports:
            target=0x130000+len(imports)*16;imports[target]=item.name.decode() if item.name else str(item.ordinal)
            store(u,item.address,target)
    def crt(u,address,size,user):
        if address not in imports:return
        sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);fn=imports[address]
        cleanup=4
        if fn in ['memcpy','memmove']:
            dst,src,n=[word(u,sp+i) for i in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)));result=dst
        elif fn=='memset':
            dst,value,n=[word(u,sp+i) for i in [4,8,12]];u.mem_write(dst,bytes([value&255])*n);result=dst
        elif fn=='wcslen':
            ptr=word(u,sp+4);result=0
            while bytes(u.mem_read(ptr+result*2,2))!=b'\0\0':result+=1
        elif fn in ['wcscmp','wcsstr','wcscpy']:
            dst,src=[word(u,sp+i) for i in [4,8]]
            def string(ptr):
                data=bytearray()
                while True:
                    pair=bytes(u.mem_read(ptr+len(data),2))
                    if pair==b'\0\0':return data.decode('utf-16le')
                    data.extend(pair)
            left,right=string(dst),string(src)
            if fn=='wcscmp':result=(left>right)-(left<right)
            elif fn=='wcsstr':result=dst+2*left.index(right) if right in left else 0
            else:u.mem_write(dst,(right+'\0').encode('utf-16le'));result=dst
        elif fn=='OutputDebugStringA':result=0;cleanup=8
        elif handlers and fn in handlers:result,cleanup=handlers[fn](u,sp)
        else:raise AssertionError(('unexpected import',fn))
        u.reg_write(UC_X86_REG_EAX,result&0xffffffff);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,crt)
    return pe,lambda name:next(v for k,v in symbols.items() if k==name or name in k)
def call(u,addr,args=(),ecx=0,edx=0,limit=500000):
    for i,v in enumerate([STOP,*args]):store(u,SP+4*i,v)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,ecx);u.reg_write(UC_X86_REG_EDX,edx)
    run_until(u,addr,STOP,limit);return u.reg_read(UC_X86_REG_EAX)
def wide(u,a):
    data=bytes(u.mem_read(a,256));return data.decode('utf-16le').split('\0')[0]
def s32(v):return struct.pack('<I',v&0xffffffff)
factory_cases=0
for kind,same,failure in itertools.product([3,4,5,8,9,12,13],[0,1],['none','allocate','copy']):
    u=fixture();pe,exp=load(u,'ui_proxy_probe.dll')
    factory_api=0x140000;u.mem_map(factory_api,0x1000)
    api,source,parent,name,model_ptr,out=MEM+0x10000,MEM+0x12000,MEM+0x14000,MEM+0x15000,MEM+0x16000,MEM+0x18000
    typesize={3:0x78,4:0xa8,5:0x124,8:0x60,9:0x70,12:0x138,13:0x32c}
    for i in range(12):store(u,api+4*i,factory_api+0x100+0x20*i)
    u.mem_write(source,b'\x5a'*0x340);u.mem_write(model_ptr,b'\x19'*32)
    u.mem_write(source+0x14,bytes([1,1,0,1,same,kind]));store(u,source+0x5c,0 if kind==8 else model_ptr)
    store(u,source+0x1c,7);store(u,source+0x54,20)
    store(u,source+0x90,180);store(u,source+0x94,-90);floats(u,source+0x98,.5);store(u,source+0xa0,0x25)
    u.mem_write(source+0x69,b'\1');u.mem_write(source+0x6a,b'\1')
    u.mem_write(name,'Bound control\0'.encode('utf-16le'))
    before_source=bytes(u.mem_read(source,0x340));before_model=bytes(u.mem_read(model_ptr,32));events=[]
    def mock(u,a,size,user):
        if not factory_api+0x100<=a<factory_api+0x280:return
        n=(a-(factory_api+0x100))//0x20;sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);this=u.reg_read(UC_X86_REG_ECX);cleanup=4;result=0
        if n==0:
            assert this==typesize[kind];events.append('allocate');result=0 if failure=='allocate' else out
            if result:u.mem_write(out,b'\xcc'*typesize[kind])
        elif n==1:
            assert word(u,sp+4)==out;events.append('destroy')
        elif n in range(2,9):
            expected={3:2,4:4,5:3,8:8,9:7,12:6,13:5}[kind];assert n==expected and this==out
            assert word(u,sp+4)==parent
            if kind in [3,4,5,8,13]:assert wide(u,word(u,sp+8))=='Bound control'
            value_offset={3:12,4:12,5:20,8:0,9:8,12:8,13:12}[kind]
            value=word(u,sp+value_offset) if value_offset else 0;assert value==(model_ptr if kind!=8 else 0)
            argc={3:3,4:4,5:8,8:2,9:3,12:2,13:5}[kind];cleanup=4+4*argc
            if kind==5:
                assert word(u,sp+12)==0xffffffa6 and word(u,sp+16)==180
                assert word(u,sp+24)==1 and word(u,sp+28)==0x25 and word(u,sp+32)==fbits(.5)
            if kind==4:assert word(u,sp+16)==same
            if kind==9:assert word(u,sp+12)==1
            if kind==13:assert word(u,sp+16)==0 and word(u,sp+20)==1
            if kind!=8:u.mem_write(value+(16 if kind==9 else 0),bytes(8 if kind==9 else (1 if kind==3 else 4)))
            store(u,out+0x5c,value);u.mem_write(out+0x19,bytes([kind]));events.append('construct');result=out
        elif n==9:
            assert this==parent and word(u,sp+4)==0 and word(u,sp+8)==out
            assert bytes(u.mem_read(model_ptr,32))==before_model
            cleanup=12;events.append('insert')
        elif n==10:
            assert [word(u,sp+i) for i in [4,8,12]]==[out,source,kind]
            assert bytes(u.mem_read(model_ptr,32))==before_model
            result=int(failure!='copy');events.append('copy')
        elif n==11:assert [word(u,sp+i) for i in [4,8]]==[out,source];events.append('link')
        u.reg_write(UC_X86_REG_EAX,result&0xffffffff);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,mock)
    result=call(u,exp('create_proxy_probe'),[api,parent,source,name])
    assert result==(out if failure=='none' else 0)
    assert bytes(u.mem_read(source,0x340))==before_source and bytes(u.mem_read(model_ptr,32))==before_model
    if failure=='none':
        assert events==['allocate','construct','copy','link','insert']
        assert bytes(u.mem_read(out+0x14,5))==bytes([1,1,0,1,same])
        assert word(u,out+0x1c)==7 and word(u,out+0x5c)==(model_ptr if kind!=8 else 0)
    elif failure=='copy':assert events==['allocate','construct','copy','destroy']
    else:assert events==['allocate']
    factory_cases+=1

binding_cases=0
for kind in [3,4,5,9,12,13]:
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll')
    ctx,menu,child,source,proxy,value,vt_src,vt_proxy= [MEM+0x10000+i*0x1000 for i in range(8)]
    store(u,ctx+0x10,menu);store(u,menu+0x14,660);store(u,menu+0x18,560)
    u.mem_write(child+0x15,b'\1')
    for p,vt in [(source,vt_src),(proxy,vt_proxy)]:
        store(u,p,vt);store(u,p+0x5c,value);u.mem_write(p+0x14,bytes([1,1,0,1,0,kind]));store(u,vt+20,STOP+0x300+(p==proxy)*0x20);store(u,vt+28,STOP+0x340)
    events=[]
    def mock(u,a,size,user):
        if a not in [STOP+0x300,STOP+0x320,STOP+0x340,STOP+0x360,STOP+0x380]:return
        sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);this=u.reg_read(UC_X86_REG_ECX);cleanup=4
        if a==STOP+0x300:assert this==source;events.append('source_cache')
        elif a==STOP+0x320:assert this==proxy;events.append('proxy_cache')
        elif a==STOP+0x340:
            assert this==source;events.append('source_callback');u.mem_write(source+0x15,b'\0')
        elif a==STOP+0x360:assert this==child;events.append('layout')
        else:
            assert this==child and [word(u,sp+4),word(u,sp+8)]==[MEM+0x3000,MEM+0x3100]
            cleanup=12;events.append('draw')
        u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,mock)
    call(u,exp('binding_setup_probe'),[ctx,proxy,source,child,STOP+0x360])
    store(u,value+(16 if kind==9 else 0),0x28)
    call(u,exp('binding_sync_probe'));assert events==['proxy_cache'],(kind,events);events.clear()
    call(u,exp('binding_change_probe'));assert events==['source_cache','source_callback','layout'],events
    assert bytes(u.mem_read(proxy+0x15,1))==b'\0';events.clear()
    call(u,exp('binding_sync_probe'));assert not events
    if kind==9:
        store(u,value+16,0x2b);call(u,exp('binding_sync_probe'));assert not events # Only toggle bits changed.
    # Real compiled child bridge preserves two original stack arguments.
    call(u,exp('child_draw_setup_probe'),[STOP+0x380])
    call(u,exp('child_draw_probe'),[MEM+0x3000,MEM+0x3100],child)
    assert events[-1]=='draw' and u.reg_read(UC_X86_REG_ESP)==SP+12
    binding_cases+=1

# Execute deep-copy adapter with the actual native Combobox::OnConfigLoad.
u=fixture();pe,exp=load(u,'visuals_binding_probe.dll')
src,dst,value,vars_,vt,heap=MEM+0x10000,MEM+0x11000,MEM+0x12000,MEM+0x13000,MEM+0x14000,MEM+0x20000
store(u,src+0x5c,value);store(u,dst+0x5c,value);store(u,value,42)
store(u,src+0x7c,vars_);store(u,src+0x80,vars_+40);store(u,src+0x84,vars_+40)
store(u,dst,vt);store(u,vt+20,0x43383770)
for i,(name,index) in enumerate([('Default',7),('Alternative',42)]):
    ptr=MEM+0x15000+i*0x100;data=(name+'\0').encode('utf-16le');u.mem_write(ptr,data)
    for j,v in enumerate([ptr,ptr+len(data),ptr+len(data),0,index]):store(u,vars_+i*20+j*4,v)
allocations=[]
def alloc(u,a,size,user):
    if a not in [STOP+0x400,STOP+0x420]:return
    sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);n=u.reg_read(UC_X86_REG_ECX)
    assert a==STOP+0x400 # Destination starts empty; no source data is released.
    ptr=heap+len(allocations)*0x1000;allocations.append((ptr,n));u.reg_write(UC_X86_REG_EAX,ptr)
    u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret)
u.hook_add(UC_HOOK_CODE,alloc)
assert call(u,exp('variants_copy_probe'),[dst,src,4,STOP+0x400,STOP+0x420])==1
assert word(u,dst+0x78)==1 and word(u,src+0x7c)==vars_
new=word(u,dst+0x7c);assert new!=vars_ and word(u,dst+0x80)==new+40
for i,name in enumerate(['Default','Alternative']):
    ptr=word(u,new+20*i);assert ptr!=word(u,vars_+20*i) and wide(u,ptr)==name

# The multiselect has a native 32-item inline buffer. Copying its variants must
# retain that buffer and create independent strings, not alias the source owner.
u=fixture();pe,exp=load(u,'visuals_binding_probe.dll')
src,dst,value,vt,heap=MEM+0x10000,MEM+0x11000,MEM+0x12000,MEM+0x14000,MEM+0x20000
for p in [src,dst]:
    store(u,p+0x5c,value);store(u,p+0x80,p+0x90);store(u,p+0x84,p+0x90);store(u,p+0x88,p+0x310)
store(u,src+0x84,src+0x90+40);store(u,dst,vt);store(u,vt+20,STOP+0x440);store(u,value,4)
for i,(name,index) in enumerate([('Icon',1),('Text',4)]):
    ptr=MEM+0x15000+i*0x100;data=(name+'\0').encode();u.mem_write(ptr,data)
    for j,v in enumerate([ptr,ptr+len(data),ptr+len(data),0,index]):store(u,src+0x90+i*20+j*4,v)
allocations=[];cache=[]
def multi_alloc(u,a,size,user):
    if a not in [STOP+0x400,STOP+0x420,STOP+0x440]:return
    sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp)
    if a==STOP+0x440:cache.append(True)
    else:
        assert a==STOP+0x400
        ptr=heap+len(allocations)*0x1000;allocations.append(ptr);u.reg_write(UC_X86_REG_EAX,ptr)
    u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret)
u.hook_add(UC_HOOK_CODE,multi_alloc)
assert call(u,exp('variants_copy_probe'),[dst,src,13,STOP+0x400,STOP+0x420])==1
assert cache and word(u,dst+0x80)==dst+0x90 and word(u,dst+0x84)==dst+0x90+40
for i,name in enumerate(['Icon','Text']):
    ptr=word(u,dst+0x90+i*20);assert ptr!=word(u,src+0x90+i*20)
    assert bytes(u.mem_read(ptr,len(name)+1))==name.encode()+b'\0'

category_cases=0
for factor in [1.,1.25,1.5,2.]:
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll')
    ctx,menu,children,controls=MEM+0x10000,MEM+0x11000,MEM+0x12000,MEM+0x13000
    store(u,ctx+0x10,menu);store(u,menu+0x14,int(660*factor));store(u,menu+0x18,int(560*factor));floats(u,0x4346d490,factor)
    for i in range(11):store(u,children+i*4,MEM+0x20000+i*0x200)
    for i in range(5):store(u,controls+i*4,MEM+0x23000+i*0x100)
    category=word(u,children+40);u.mem_write(category+0x94,b'\1');store(u,category+0xa8,83)
    layouts=[]
    def category_layout_mock(u,address,size,user):
        if address!=STOP+0x460:return
        sp=u.reg_read(UC_X86_REG_ESP);layouts.append(u.reg_read(UC_X86_REG_ECX))
        u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+4)
    u.hook_add(UC_HOOK_CODE,category_layout_mock)
    call(u,exp('category_setup_probe'),[ctx,children,controls,STOP+0x460])
    assert word(u,category+0xa8)==0 and bytes(u.mem_read(category+0x94,1))==b'\0'
    for i in range(5):
        button=word(u,controls+4*i);x,y,w,h=[word(u,button+n) for n in [0x20,0x24,0x28,0x2c]]
        assert y==int(11*factor+.5) and h==int(36*factor+.5)
        assert x>=0 and x+w<=word(u,category+0x28)
    for selected in range(5):
        call(u,exp('choose_category_probe'),[selected])
        expected=[i for i,c in enumerate([0,0,1,1,2,2,2,3,3,4]) if c==selected]
        actual=[i for i in range(10) if bytes(u.mem_read(word(u,children+4*i)+0x15,1))!=b'\0']
        assert actual==expected,(factor,selected,actual,expected)
        category_cases+=1

# A deleted source object must not be dereferenced by a queued proxy callback.
# Keep category children; defer destruction/rebinding until outside dispatch.
u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');u.mem_map(0x400000,0x1000)
ctx,menu,child,proxy,value,tabs,visuals,misc,children,original,elements=[MEM+0x10000+i*0x1000 for i in range(11)]
source=0x400000;store(u,ctx+0x10,menu);store(u,menu+0x14,660);store(u,menu+0x18,560)
store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs+3*4,visuals);store(u,tabs+4*4,misc)
store(u,visuals+0x70,children);store(u,visuals+0x74,children+12*4)
store(u,children,original)
for i in range(1,12):store(u,children+i*4,child if i==1 else MEM+0x22000+i*0x100)
store(u,original+0x80,elements);store(u,original+0x84,elements+4);store(u,elements,source)
store(u,source+0x5c,value);u.mem_write(source+0x14,bytes([1,1,0,1,0,3]))
call(u,exp('binding_setup_probe'),[ctx,proxy,source,child,STOP+0x360])
assert call(u,exp('topology_capture_probe'),[original])==1
u.mem_write(original+0x15,b'\0');u.mem_write(child+0x15,b'\1')
store(u,child+0x80,MEM+0x1b000);store(u,child+0x84,MEM+0x1b004);store(u,MEM+0x1b000,proxy)
u.mem_write(proxy+0x19,b'\3');store(u,proxy+0x5c,0x401000)
store(u,proxy,0x434721e8);u.mem_write(proxy+0x16,b'\1');u.mem_write(proxy+0x6c,b'\1')
store(u,original+0x84,elements);u.mem_unmap(source,0x1000)
call(u,exp('binding_change_probe'))
assert bytes(u.mem_read(original+0x15,1))==b'\0' and bytes(u.mem_read(child+0x15,1))==b'\1'
assert word(u,proxy+0x5c)==0 and bytes(u.mem_read(proxy+0x15,1))==b'\0'
assert bytes(u.mem_read(proxy+0x16,1))==b'\0' and bytes(u.mem_read(proxy+0x6c,1))==b'\0'

from resize_fixture import check_resize
resize_cases=check_resize(globals())

from skin_menu_fixture import check_skin_menu
skin_cases=check_skin_menu(globals())

from visuals_lifecycle_fixture import check_lifecycle
lifecycle_cases=check_lifecycle(globals())

from appearance_fixture import check_appearance
appearance_cases=check_appearance(globals())
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/appearance_plan.cpp'),'-o',str(BUILD/'appearance_plan')],check=True)
subprocess.run([str(BUILD/'appearance_plan'),str(BUILD/'mannequin.json')],check=True)
appearance_report={'passed':True,'native_binding_and_input_checks':appearance_cases,'preview_layout_cases':75,'bounded_mesh_rotation_cases':12,
    'illustrative_geometry':True,'uses_game_mdl_models':False,'new_game_shaders':False,
    'color_presets':['Glacier','Amethyst','Crimson','Champagne'],'game_tested':False}
(BUILD/'appearance_validation.json').write_text(json.dumps(appearance_report,indent=2)+'\n')

# Compare original native draw with the actual compiled forwarding callback.
render_cases=0
for location in [0x50000000,0x60000000,0xf0000000]:
    probe_pe=pefile.PE(str(BUILD/'visuals_binding_probe.dll'));pb=probe_pe.OPTIONAL_HEADER.ImageBase
    callback=pb+next(x.address for x in probe_pe.DIRECTORY_ENTRY_EXPORT.symbols if x.name and b'render_callback_probe' in x.name)
    path=BUILD/f'visuals_hook_{location:x}.bin'
    subprocess.run([str(BUILD/'visuals_plan'),str(BUILD/'visuals_preview_layout.json'),str(path),hex(location),hex(callback)],check=True,stdout=subprocess.DEVNULL)
    plan=path.read_bytes();assert len(plan)==19
    for opened,visible in itertools.product([0,1],range(8)):
        traces=[]
        for patched in [False,True]:
            u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');u.mem_map(location,4096);u.mem_write(location,plan[:12])
            call(u,exp('render_setup_probe'),[location])
            if patched:u.mem_write(0x433ac5e2,plan[12:])
            menu,vt,tabs=MEM+0x10000,MEM+0x11000,MEM+0x12000
            store(u,menu,vt);store(u,vt+8,STOP+0x200);store(u,vt+16,STOP+0x300)
            store(u,menu+0x34,opened);store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+12)
            for i in range(3):
                tab=MEM+0x13000+i*0x100;store(u,tabs+i*4,tab);store(u,tab,vt);u.mem_write(tab+0x15,bytes([(visible>>i)&1]))
            trace=[]
            def hook(u,a,size,user):
                if a not in [0x43384045,STOP+0x200,STOP+0x300]:return
                sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);this=u.reg_read(UC_X86_REG_ECX);n=2 if a==STOP+0x300 else 1
                args=[word(u,sp+4*(i+1)) for i in range(n)];assert args[0]==0x1234abcd
                if n==2:assert args[1]==menu+0xc
                trace.append((a,this,args));u.reg_write(UC_X86_REG_EIP,ret);u.reg_write(UC_X86_REG_ESP,sp+4+4*n)
                u.reg_write(UC_X86_REG_ECX,0xff000000);u.reg_write(UC_X86_REG_EDX,0xff000001)
            u.hook_add(UC_HOOK_CODE,hook)
            saved={UC_X86_REG_EBX:0x12345678,UC_X86_REG_ESI:0x23456789,UC_X86_REG_EDI:0x34567890,UC_X86_REG_EBP:0x45678901}
            for reg,v in saved.items():u.reg_write(reg,v)
            call(u,0x433ac5e2,[0x1234abcd],menu)
            assert u.reg_read(UC_X86_REG_ESP)==SP+8
            for reg,v in saved.items():assert u.reg_read(reg)==v
            traces.append(trace)
        assert traces[0]==traces[1];render_cases+=1

report={'passed':True,'proxy_factory_cases':factory_cases,'production_binding_cases':binding_cases,
    'native_combobox_deep_copy':True,'native_menu_forwarding_cases':render_cases,'layout_scene_cases':180,'routing_cases':11,
    'native_multiselect_inline_buffer_copy':True,'compiled_category_switch_cases':category_cases,'category_scrollbar_disabled':True,
    'deleted_source_invalidation_checked_with_unmapped_memory':True,
    'native_resize_dpi_cases':resize_cases,'child_vtable_slots':13,'canonical_child_sizes_checked':True,
    'appearance_preview':appearance_cases,'real_game_models_in_preview':False,
    'skin_menu_cases':skin_cases,'skin_native_derived_rows_preserved':True,
    'skin_native_list_deep_copy_and_destructors':True,
    'lua_lifecycle_cases':lifecycle_cases,'category_selection_and_models_survive_reload':True,
    'patch_controls_added':0,'custom_backtrack_patch':False,'source_elements_reparented':False,
    'scope':__doc__,'game_tested':False,'visual_match_verified_in_game':False}
(BUILD/'visuals_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
