"""Compiled native setting forwarding and Win32 preview input ownership checks."""
def check_appearance(ns):
    globals().update(ns)
    API=0x140000
    def binding_case(subject,theme,expected_combo=17,choices=(('Solid',17),('Metallic',42))):
        u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');u.mem_map(API,0x1000)
        ctx,menu=MEM+0x10000,MEM+0x11000;store(u,ctx+0x10,menu)
        source_list,proxy_list,panel_list,name_list,anchor_list=[MEM+0x12000+i*0x1000 for i in range(5)]
        records=[];models=['Player']*3+['Local player']*3+['Weapon viewmodel']*3+['Bounding box','Flags']
        types=[3,12,4]*3+[3,13];panels=[1]*3+[7]*6+[0,0]
        callbacks=[]
        def callback(u,a,size,user):
            if a not in [API+0x100,API+0x120,API+0x140]:return
            sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX)
            callbacks.append((a,this));u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+4)
        u.hook_add(UC_HOOK_CODE,callback)
        for i,(label,kind,panel) in enumerate(zip(models,types,panels)):
            src=MEM+0x20000+i*0x1000;proxy=src+0x400;value_ptr=src+0x700;vt=src+0x800;pvt=src+0x900;text=src+0xa00
            for p,v in [(src,vt),(proxy,pvt)]:
                store(u,p,v);store(u,p+0x5c,value_ptr);u.mem_write(p+0x14,bytes([1,1,0,1,0,kind]))
            for table,slot,target in [(vt,5,API+0x100),(vt,7,API+0x120),(pvt,5,API+0x140)]:store(u,table+4*slot,target)
            u.mem_write(value_ptr,b'\0\xa5\xa5\xa5' if kind==3 else s32(71 if kind==4 else (8 if kind==13 else 0xff112233)))
            u.mem_write(text,(label+'\0').encode('utf-16le'))
            for base,v in [(source_list,src),(proxy_list,proxy),(panel_list,panel),(name_list,text),(anchor_list,text)]:store(u,base+4*i,v)
            if kind==4:
                variables=src+0xb00
                for off,end in [(0x7c,variables),(0x80,variables+20*len(choices)),(0x84,variables+20*len(choices))]:store(u,src+off,end)
                for n,(name,index) in enumerate(choices):
                    ptr=src+0xc00+0x100*n;data=(name+'\0').encode('utf-16le');u.mem_write(ptr,data)
                    for j,v in enumerate([ptr,ptr+len(data),ptr+len(data),0,index]):store(u,variables+20*n+4*j,v)
            elif kind==13:
                variables=src+0xb00
                for off,v in [(0x80,variables),(0x84,variables+60),(0x88,variables+60)]:store(u,src+off,v)
                for j,mask in enumerate([1,8,0x40]):store(u,variables+20*j+16,mask)
            records.append((src,proxy,value_ptr,kind))
        call(u,exp('appearance_setup_probe'),[ctx,len(records),source_list,proxy_list,panel_list,name_list,anchor_list])
        call(u,exp('appearance_subject_probe'),[subject]);before=[bytes(u.mem_read(v,4)) for _,_,v,_ in records]
        result=call(u,exp('appearance_preset_probe'),[theme]);index={0:0,2:3,3:6}.get(subject)
        if index is None:
            assert result==0 and before==[bytes(u.mem_read(v,4)) for _,_,v,_ in records]
        else:
            assert result==1
            color=[0xfff0c458,0xffeb85ab,0xff684ee1,0xff70bbe0][theme]
            assert bytes(u.mem_read(records[index][2],4))==b'\1\xa5\xa5\xa5'
            assert word(u,records[index+1][2])==color and word(u,records[index+2][2])==expected_combo
            for i,r in enumerate(records):
                if i not in range(index,index+3):assert bytes(u.mem_read(r[2],4))==before[i]
            assert any(a==API+0x120 and this==records[index+1][0] for a,this in callbacks)
        call(u,exp('appearance_subject_probe'),[0]);box_value=records[9][2]
        assert call(u,exp('appearance_toggle_probe'),[0])==1 and bytes(u.mem_read(box_value,4))==b'\1\xa5\xa5\xa5'
        assert call(u,exp('appearance_toggle_probe'),[7])==1 and word(u,records[10][2])==0
        assert call(u,exp('appearance_toggle_probe'),[7])==1 and word(u,records[10][2])==8
        u.mem_write(records[10][0]+0x6a,b'\1')
        assert call(u,exp('appearance_toggle_probe'),[7])==0 and word(u,records[10][2])==8
        renderer,renderer_vt=MEM+0x70000,MEM+0x71000;store(u,renderer,renderer_vt)
        store(u,renderer_vt+4*4,API+0x180);store(u,renderer_vt+15*4,API+0x1a0)
        painted=[];texts=[]
        def render(u,a,size,user):
            if a not in [API+0x180,API+0x1a0]:return
            sp=u.reg_read(UC_X86_REG_ESP);assert u.reg_read(UC_X86_REG_ECX)==renderer
            if a==API+0x180:
                params=[word(u,sp+4*k) for k in range(1,6)];assert params[2]>0 and params[3]>0;painted.append(params);cleanup=24
            else:
                assert u.reg_read(UC_X86_REG_EDX)==0
                params=[word(u,sp+4*k) for k in range(1,7)];assert params[3]>0
                texts.append(wide(u,params[4]));assert params[5]==len(texts[-1]);cleanup=28
            u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
        u.hook_add(UC_HOOK_CODE,render)
        call(u,exp('appearance_draw_settings_probe'),[renderer])
        assert len(painted)>40
        assert all(label in texts for label in ['Glacier','Amethyst','Crimson','Champagne'])
        call(u,exp('appearance_invalidate_probe'))
        for src,_,_,_ in records:u.mem_unmap(src,0x1000)
        assert call(u,exp('appearance_preset_probe'),[0])==0 and call(u,exp('appearance_toggle_probe'),[0])==0
    cases=0
    for subject,theme,index in [(0,1,17),(2,0,17),(3,2,42),(1,3,17)]:binding_case(subject,theme,index);cases+=1
    binding_case(3,2,71,(('Textured',71),));cases+=1
    # Window procedures queue coordinates; they never invoke a native callback.
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll')
    def publish(x=100,y=100,show=1):call(u,exp('preview_publish_probe'),[x,y,280,500,show])
    def event(msg,x=120,y=130):return call(u,exp('preview_consume_probe'),[msg,(y<<16)|(x&0xffff)])
    def take():
        ret=call(u,exp('preview_take_probe'),[MEM+0x5000,MEM+0x5004]);return ret,word(u,MEM+0x5000),word(u,MEM+0x5004)
    publish();assert event(0x201)==1 and event(0x202)==1 and take()==(1,120,130);assert take()[0]==0
    for msg in [0x200,0x204,0x205,0x20a]:assert event(msg)==1
    assert take()[0]==0
    assert event(0x201,5,5)==0 and event(0x202)==0 and take()[0]==0
    assert event(0x201)==1 and event(0x202,5,5)==1 and take()[0]==0
    assert event(0x203)==1 and event(0x202)==1 and take()[0]==1
    assert event(0x201)==1 and event(0x202)==1;publish(400);assert take()[0]==0
    publish();assert event(0x201)==1;event(0x8);assert event(0x202)==0 and take()[0]==0
    publish(show=0);assert event(0x201)==0 and event(0x202)==0
    # Confirm real x86 WinAPI arguments, forwarding and teardown with WinAPI mocks.
    calls=[];proc=[0x12340000];pid=771
    def is_window(u,sp):return int(word(u,sp+4)==0x777),8
    def owner(u,sp):store(u,word(u,sp+8),pid);return 123,12
    def current(u,sp):return pid,4
    def getlong(u,sp):assert word(u,sp+4)==0x777;return proc[0],12
    def setlong(u,sp):
        assert word(u,sp+4)==0x777 and word(u,sp+8)==0xfffffffc
        old=proc[0];proc[0]=word(u,sp+12);calls.append('install');return old,16
    def forward(u,sp):
        assert word(u,sp+4)==0x12340000 and word(u,sp+8)==0x777
        calls.append(('forward',word(u,sp+12)));return 0x11223344,24
    def noerror(u,sp):return 0,8
    handlers={'IsWindow':is_window,'GetWindowThreadProcessId':owner,'GetCurrentProcessId':current,
        'GetWindowLongW':getlong,'SetWindowLongW':setlong,'GetWindowLongPtrW':getlong,'SetWindowLongPtrW':setlong,
        'CallWindowProcW':forward,'SetLastError':noerror}
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',handlers)
    assert call(u,exp('preview_attach_probe'),[0x777])==1
    assert call(u,exp('preview_attach_probe'),[0x777])==1 and calls==['install']
    publish()
    assert call(u,exp('preview_proc_probe'),[0x777,0x100,0,0])==0x11223344
    assert call(u,exp('preview_proc_probe'),[0x777,0x201,0,(130<<16)|120])==0
    assert call(u,exp('preview_proc_probe'),[0x777,0x202,0,(130<<16)|120])==0 and take()==(1,120,130)
    assert call(u,exp('preview_proc_probe'),[0x777,0x82,0,0])==0x11223344
    assert event(0x201)==0
    assert calls==['install',('forward',0x100),('forward',0x82)]
    # Actual native getter returns XMM0. The old SDK declaration expected x87,
    # which would restore an invalid depth after drawing the preview.
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');renderer,vt=MEM+0x70000,MEM+0x71000
    store(u,renderer,vt);store(u,vt+30*4,0x433cfd53);store(u,vt+29*4,0x433b360e)
    depth_calls=[]
    def command(u,a,size,user):
        if a!=0x433ab0fa:return
        sp=u.reg_read(UC_X86_REG_ESP);assert u.reg_read(UC_X86_REG_ECX)==renderer
        assert u.reg_read(UC_X86_REG_EDX)==15 and word(u,sp+4)==4
        depth_calls.append(True);u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+8)
    u.hook_add(UC_HOOK_CODE,command)
    for depth in [0.,.01,.35,.99,1.]:
        bits=fbits(depth);store(u,renderer+0x7c,bits)
        assert call(u,exp('renderer_depth_probe'),[renderer])==bits
        store(u,renderer+0x7c,fbits(.66))
        assert call(u,exp('renderer_set_depth_probe'),[renderer,bits])==bits
    assert len(depth_calls)==5
    return {'native_style_profiles':cases,'esp_toggle_and_invalidation_cases':cases*5,'input_ownership_cases':12,'real_win32_abi_cases':7,'native_renderer_depth_abi_cases':10}
