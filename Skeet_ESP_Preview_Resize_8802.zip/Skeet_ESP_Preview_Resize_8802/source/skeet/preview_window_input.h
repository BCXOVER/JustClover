#pragma once
#include <atomic>
// Only coordinates cross threads. Native setting callbacks run on the render
// thread, never from the window procedure. One release click is one action.
namespace preview_window_input {
inline std::atomic<int> left{0},top{0},right{0},bottom{0};
inline std::atomic<unsigned> revision{2};
inline std::atomic<bool> enabled{false},captured{false};
inline std::atomic<std::uint64_t> click{0};
inline std::atomic<HWND> window{nullptr};inline std::atomic<WNDPROC> previous{nullptr};
inline bool inside(int x,int y) {
    return enabled.load(std::memory_order_acquire)&&x>=left.load()&&x<right.load()&&y>=top.load()&&y<bottom.load();
}
inline void publish(int x,int y,int w,int h,bool shown) {
    if(x!=left.load()||y!=top.load()||x+w!=right.load()||y+h!=bottom.load()||shown!=enabled.load()) {
        enabled.store(false,std::memory_order_release);revision.fetch_add(1);
        left=x;top=y;right=x+w;bottom=y+h;click=0;captured=false;
        revision.fetch_add(1);enabled.store(shown,std::memory_order_release);
    }
}
inline bool consume(UINT message,LPARAM position) {
    if(message==WM_KILLFOCUS||message==WM_CANCELMODE||message==WM_CAPTURECHANGED){captured=false;click=0;return false;}
    const int x=static_cast<short>(LOWORD(position)),y=static_cast<short>(HIWORD(position));
    const unsigned stamp=revision.load();
    if(stamp&1)return false;
    const bool hit=inside(x,y);
    if((message==WM_LBUTTONDOWN||message==WM_LBUTTONDBLCLK)&&hit){captured=true;return true;}
    if(message==WM_LBUTTONUP&&captured.exchange(false)) {
        if(hit&&stamp==revision.load())click.store((std::uint64_t(stamp)<<32)|std::uint32_t(position),std::memory_order_release);
        return true;
    }
    return (message==WM_MOUSEMOVE&&(hit||captured.load()))||
        (hit&&(message==WM_RBUTTONDOWN||message==WM_RBUTTONUP||message==WM_MOUSEWHEEL));
}
inline LRESULT CALLBACK procedure(HWND hwnd,UINT message,WPARAM w,LPARAM l) {
    if(message==WM_NCDESTROY) {
        publish(0,0,0,0,false);const auto chain=previous.exchange(nullptr);window=nullptr;
        return chain?CallWindowProcW(chain,hwnd,message,w,l):DefWindowProcW(hwnd,message,w,l);
    }
    LPARAM local=l;
    if(message==WM_MOUSEWHEEL){POINT point{static_cast<short>(LOWORD(l)),static_cast<short>(HIWORD(l))};if(ScreenToClient(hwnd,&point))local=MAKELPARAM(point.x,point.y);}
    if(consume(message,local))return 0;
    const auto chain=previous.load();return chain?CallWindowProcW(chain,hwnd,message,w,l):DefWindowProcW(hwnd,message,w,l);
}
inline bool attach(HWND hwnd) {
    if(window==hwnd&&previous)return true;
    if(!hwnd||!IsWindow(hwnd))return false;
    DWORD process=0;GetWindowThreadProcessId(hwnd,&process);if(process!=GetCurrentProcessId())return false;
    // Do not replace an already attached chain with a different game window.
    if(window)return false;
    previous=reinterpret_cast<WNDPROC>(GetWindowLongPtrW(hwnd,GWLP_WNDPROC));
    if(!previous.load())return false;
    SetLastError(0);
    auto old=reinterpret_cast<WNDPROC>(SetWindowLongPtrW(hwnd,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(&procedure)));
    if(!old){previous=nullptr;return false;}previous=old;window=hwnd;return true;
}
inline bool take(int& x,int& y) {
    const auto event=click.exchange(0,std::memory_order_acq_rel);
    if(!event||unsigned(event>>32)!=revision.load()||!enabled.load())return false;
    x=static_cast<short>(event&0xffff);y=static_cast<short>((event>>16)&0xffff);return true;
}
}
