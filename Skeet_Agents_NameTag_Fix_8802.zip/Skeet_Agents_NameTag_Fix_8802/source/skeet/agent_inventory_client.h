#pragma once
#include "skin_native_client.h"
#include "local_client_interfaces.h"
namespace agent_inventory_client {
using namespace local_inventory_client;
inline bool definition(void* schema,int id) {
 if(id<1||id>65535)return false;auto* fn=method(schema,4);if(!fn)return false;
 using Get=void*(__thiscall*)(void*,int);return agent_definition(reinterpret_cast<Get>(fn)(schema,id));
}
inline bool label(void* tab,unsigned side,int value,wchar_t (&out)[256]) {
 if(!memory(tab,0x118))return false;auto* combo=pointer(tab,0x110+side*4);
 if(!memory(combo,0x88)||*(static_cast<unsigned char*>(combo)+0x19)!=4)return false;
 auto* rows=static_cast<unsigned char*>(pointer(combo,0x7c));const auto end=read32(combo,0x80),begin=reinterpret_cast<std::uintptr_t>(rows);
 if(end<begin||(end-begin)%20||(end-begin)/20>512||!memory(rows,end-begin))return false;
 for(unsigned i=0;i<(end-begin)/20;i++) {
  auto* row=rows+i*20;if(int(read32(row,16))!=value)continue;
  auto* text=static_cast<wchar_t*>(pointer(row,0));const auto last=read32(row,4),first=reinterpret_cast<std::uintptr_t>(text);
  if(last<first||(last-first)%2||(last-first)/2>256||!memory(text,last-first))return false;
  unsigned n=0;while(n<(last-first)/2&&text[n]){out[n]=text[n];++n;}if(n==256)return false;out[n]=0;
  // Native labels can include a color escape followed by eight hex digits.
  unsigned skip=out[0]==7&&n>=9?9:0;while(skip<n&&(out[skip]==L' '||out[skip]==L'\t'))++skip;
  if(skip){std::memmove(out,out+skip,(n-skip+1)*2);n-=skip;}
  while(n&&(out[n-1]==L' '||out[n-1]==L'\t'))out[--n]=0;return n>0;
 }
 return false;
}
inline int resolve(void* schema,void* tab,unsigned side,int value) {
 if(definition(schema,value))return value;
 wchar_t wanted[256]{};if(!label(tab,side,value,wanted)||!memory(schema,0xe8))return 0;
 auto* nodes=static_cast<unsigned char*>(pointer(schema,0xd0));const unsigned count=read32(schema,0xe4);
 if(!count||count>65536||!memory(nodes,std::size_t(count)*12))return 0;
 auto* loc=local_client_interfaces::core_interface(0x4346a31c);auto* find=local_client_interfaces::method(loc,11);if(!find)return 0;
 using Find=const wchar_t*(__thiscall*)(void*,const char*);using Name=const char*(__thiscall*)(void*);
 int result=0;
 for(unsigned i=0;i<count;i++) {
  auto* row=nodes+i*12;if(int(read32(row,8))<-1)continue;auto* def=pointer(row,4);if(!agent_definition(def))continue;
  const unsigned id=*reinterpret_cast<const unsigned short*>(static_cast<unsigned char*>(def)+8);if(!id||!definition(schema,int(id)))continue;
  auto* getter=method(def,2);if(!getter)continue;const auto* token=reinterpret_cast<Name>(getter)(def);
  bool terminated=false;for(unsigned c=0;c<256;c++){if(!memory(token?token+c:nullptr,1))break;if(!token[c]){terminated=true;break;}}if(!terminated)continue;
  const auto* text=reinterpret_cast<Find>(find)(loc,token);if(!text)continue;
  bool same=false;for(unsigned c=0;c<256;c++){if(!memory(text+c,2)||text[c]!=wanted[c])break;if(!text[c]){same=true;break;}}
  if(same){if(result&&result!=int(id))return 0;result=int(id);}
 }
 return result;
}
inline void normalize(void* tab,skin_native_state::Raw& raw) {
 if(!ready())return;auto* sch=schema();if(!sch)return;
 // Reuse successes and throttle unresolved model labels while UI/schema populates.
 struct Cache {void* schema=nullptr;int value=0,id=0;unsigned attempted=0;wchar_t name[256]{};};static Cache cache[2]{};
 for(unsigned side=0;side<2;side++)if(raw.agent_on[side]&&raw.agent_model[side]>0) {
  const int value=raw.agent_model[side];wchar_t name[256]{};label(tab,side,value,name);auto& c=cache[side];
  const unsigned now=GetTickCount();int id=0;if(c.schema==sch&&c.value==value&&!std::memcmp(c.name,name,sizeof(name))&&(c.id||unsigned(now-c.attempted)<1000))id=c.id;
  else {id=resolve(sch,tab,side,value);c.schema=sch;c.value=value;c.id=id;c.attempted=now;std::memcpy(c.name,name,sizeof(name));}
  if(id)raw.agent_model[side]=id;else raw.agent_on[side]=false;
 }
}
}
