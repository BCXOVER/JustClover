#include "../source/skeet/pch.h"
#include "../source/skeet/local_inventory_client.h"
#include "../source/skeet/local_loadout_client.h"
#include "../source/skeet/local_weapon_names.h"
#include "../source/skeet/agent_inventory_client.h"
static local_loadout::Loadout loadout;
extern "C" {
__declspec(dllexport) unsigned inventory_weapon_names_probe(void* requests,unsigned count){return local_weapon_names::apply(static_cast<local_weapon_names::Request*>(requests),count);}
__declspec(dllexport) unsigned inventory_weapon_name_size_probe(){return sizeof(local_weapon_names::Request);}
__declspec(dllexport) int inventory_agent_resolve_probe(void* schema,void* tab,unsigned side,int value){return agent_inventory_client::resolve(schema,tab,side,value);}

__declspec(dllexport) int inventory_local_clear_probe(void* session,void* object,void* spec){
 auto& s=*static_cast<local_inventory::Session*>(session);auto& v=*static_cast<local_inventory::Spec*>(spec);
 return local_loadout_client::clear(s,{object,local_inventory_client::read64(object,8),v});
}
__declspec(dllexport) unsigned inventory_local_equip_probe(void* session,void* object,void* spec){
 auto& s=*static_cast<local_inventory::Session*>(session);auto& v=*static_cast<local_inventory::Spec*>(spec);
 local_inventory::Item item{object,local_inventory_client::read64(object,8),v};return loadout.equip(local_loadout_client::api,s,item);
}
__declspec(dllexport) int inventory_local_restore_probe(unsigned lo,unsigned hi){return loadout.detach(local_loadout_client::api,(std::uint64_t(hi)<<32)|lo);}

__declspec(dllexport) int inventory_client_session_probe(void* out){return local_inventory_client::session(*static_cast<local_inventory::Session*>(out));}
__declspec(dllexport) int inventory_client_initialize_probe(void* object,void* session,void* spec,unsigned lo,unsigned hi,unsigned position){return local_inventory_client::initialize(object,*static_cast<local_inventory::Session*>(session),*static_cast<local_inventory::Spec*>(spec),(std::uint64_t(hi)<<32)|lo,position);}
__declspec(dllexport) void* inventory_client_create_probe(){return local_inventory_client::create();}
__declspec(dllexport) int inventory_client_palette_probe(int id,void* colors,int action){return local_inventory_client::palette(id,static_cast<unsigned*>(colors),action);}
__declspec(dllexport) int inventory_client_notify_probe(void* session,int event,void* object){return local_inventory_client::notify(*static_cast<local_inventory::Session*>(session),event,object);}
__declspec(dllexport) int inventory_client_insert_probe(void* session,void* item){return local_inventory_client::insert(*static_cast<local_inventory::Session*>(session),item);}
__declspec(dllexport) int inventory_client_remove_probe(void* session,void* item){return local_inventory_client::remove(*static_cast<local_inventory::Session*>(session),item);}

}
