#include "../source/skeet/skin_mirror.h"
#include "../source/skeet/skin_native_state.h"
#include <cassert>
#include <iostream>
using namespace local_inventory;
static Session live{(void*)1,(void*)2,123,1,42};static std::uint64_t ids[4][57]{};static bool present[1024]{};static unsigned nextid=10,allocations=0,deletions=0,notifications=0;static int own_team=0;static bool fail_remove=false;
bool sess(Session& s){s=live;return true;}
bool highest(const Session&,std::uint64_t& id,unsigned& pos){id=nextid++;pos=unsigned(id);return true;}
bool contains(const Session&,void* p,std::uint64_t id){return p==(void*)(std::uintptr_t(id)*16)&&id<1024&&present[id];}
void* make(){allocations++;return (void*)(std::uintptr_t(nextid)*16);}
bool init(void* p,const Session&,const Spec&,std::uint64_t id,unsigned){return p==(void*)(std::uintptr_t(id)*16);}
bool name(void*,const char*){return true;}
bool insert(const Session&,void* p){present[std::uintptr_t(p)/16]=true;return true;}
bool notify(const Session&,int,void*){notifications++;return true;}
bool remove(const Session&,void* p){if(fail_remove)return false;present[std::uintptr_t(p)/16]=false;return true;}
void destroy(void*){deletions++;}
const Api api{sess,highest,contains,make,init,name,insert,notify,remove,destroy};
bool current(const Session& s){return s==live;}
bool owned(const Session& s,const Item& i){return contains(s,i.object,i.id);}
int slot(const Session&,const Item&,int t){return !own_team||own_team==t?3:-1;}
bool get(const Session&,int t,int s,std::uint64_t& id){id=ids[t][s];return true;}
bool state(const Session&,const Item&,int,int){return true;}
bool set(const Session&,int t,int s,std::uint64_t id){ids[t][s]=id;return true;}
const local_loadout::Api equip{current,owned,slot,get,state,set};
int main(){
 Inventory inv;assert(inv.refresh(api));skin_mirror::Mirror mirror;Spec a{};a.weapon=9;a.paint=344;a.rarity=6;
 ids[2][3]=900;ids[3][3]=901;
 mirror.observe(a,true,10);assert(!mirror.tick(inv,api,equip,true,359));assert(allocations==0);
 assert(mirror.tick(inv,api,equip,true,360));assert(allocations==1&&ids[2][3]==11&&ids[3][3]==11);
 for(unsigned i=361;i<1000;i++){mirror.observe(a,true,i);assert(!mirror.tick(inv,api,equip,true,i));}assert(allocations==1);
 Spec b=a;b.seed=42;mirror.observe(b,true,1000);assert(mirror.tick(inv,api,equip,true,1350));assert(allocations==2&&deletions==1&&ids[2][3]==12);
 // Name-only edits update the existing SO and keep its equipped inventory ID.
 const auto named_id=ids[2][3];const auto named_allocs=allocations,named_deletes=deletions;
 std::strcpy(b.name,"Test name");mirror.observe(b,true,1351,true);assert(mirror.tick(inv,api,equip,true,1351));
 assert(ids[2][3]==named_id&&allocations==named_allocs&&deletions==named_deletes);
 b.name[0]=0;mirror.observe(b,true,1352,true);assert(mirror.tick(inv,api,equip,true,1352));assert(ids[2][3]==named_id&&allocations==named_allocs);
 // Disabling returns the original loadout and deletes only mirrored items.
 assert(mirror.tick(inv,api,equip,false,1400));assert(ids[2][3]==900&&ids[3][3]==901&&deletions==2);
 assert(mirror.tick(inv,api,equip,true,1800));assert(allocations==3);
 // A real/manual change is retained when the mirror is later disabled.
 ids[3][3]=999;assert(mirror.tick(inv,api,equip,false,1900));assert(ids[3][3]==999&&ids[2][3]==900);
 assert(mirror.tick(inv,api,equip,true,2300));const auto mirrored_id=ids[2][3];unsigned mirrored_slot=0;while(inv.items[mirrored_slot].id!=mirrored_id)mirrored_slot++;
 assert(mirror.loadout.detach(equip,mirrored_id));assert(inv.erase(api,mirrored_slot));mirror.deleted(mirrored_slot);
 assert(!mirror.tick(inv,api,equip,true,3000));assert(allocations==4); // manual delete is respected
 b.seed=43;mirror.observe(b,true,3100);assert(mirror.tick(inv,api,equip,true,3450));assert(allocations==5);
 // Account/cache switch drops old pointers and does not restore an old account.
 live.account=43;assert(inv.refresh(api));mirror.changed_session(inv.current);ids[2][3]=777;ids[3][3]=778;
 assert(mirror.tick(inv,api,equip,true,4000));assert(ids[2][3]!=777);assert(mirror.tick(inv,api,equip,false,4100));assert(ids[2][3]==777&&ids[3][3]==778);
 // Slot reuse by a manually created item must never turn it into mirror-owned.
 const int manual=inv.add(api,a);assert(manual>=0);const auto manualid=inv.items[manual].id;
 b.seed=44;mirror.observe(b,true,4200);assert(mirror.tick(inv,api,equip,true,4550));assert(mirror.tick(inv,api,equip,false,4600));assert(inv.items[manual].id==manualid&&inv.items[manual].object);
 // Independent native weapon presets remain keyed by weapon, including shared
 // paint kits. Replacing one preset must leave the other weapons untouched.
 skin_mirror::Mirror many;Inventory several;assert(several.refresh(api));
 unsigned now=5000;
 for(int weapon:{7,9,16,515}){Spec v=a;v.weapon=weapon;v.paint=42;many.observe(v,true,now);assert(many.tick(several,api,equip,true,now+350));now+=500;}
 unsigned count=0;for(const auto& i:several.items)if(i.object)count++;assert(count==4);
 std::uint64_t keep[3]{};unsigned n=0;for(const auto& i:several.items)if(i.object&&i.spec.weapon!=9)keep[n++]=i.id;
 Spec revised=a;revised.weapon=9;revised.paint=42;revised.seed=999;many.observe(revised,true,now);assert(many.tick(several,api,equip,true,now+350));
 count=0;n=0;for(const auto& i:several.items)if(i.object){count++;if(i.spec.weapon!=9){bool found=false;for(auto id:keep)found|=i.id==id;assert(found);n++;}}
 assert(count==4&&n==3);
 // Full config snapshot: every native enabled weapon, not just the UI selection.
 skin_native_state::Raw native{};skin_native_state::Rows rows{};
 for(int w=1;w<=64;w++)if(skin_native_state::gun(w)){auto& r=native.records[w];r.enabled=1;r.paint=344;r.seed=w;}
 native.knife_on[0]=native.knife_on[1]=true;native.knife_model[0]=native.knife_model[1]=6;
 for(int w:{42,59}){native.records[w].enabled=1;native.records[w].paint=415;}
 native.agent_on[0]=true;native.agent_model[0]=4619;
 assert(skin_native_state::decode(native,rows));
 // Enabled agent with native default value 0 means no replacement, not an
 // invalid whole config that blocks the remaining weapon profiles.
 auto default_agent=native;default_agent.agent_model[0]=0;skin_native_state::Rows defaults{};assert(skin_native_state::decode(default_agent,defaults)&&defaults.count+1==rows.count);
 skin_mirror::Mirror batch;Inventory batch_inv;assert(batch_inv.refresh(api));
 batch.reconcile(rows,10000);unsigned ticks=0;
 for(;ticks<20;ticks++){batch.tick(batch_inv,api,equip,true,10000+ticks*16);unsigned n=0;for(auto& i:batch_inv.items)if(i.object)n++;if(n==rows.count)break;}
 assert(ticks<12);count=0;for(auto& i:batch_inv.items)if(i.object)count++;assert(count==rows.count&&count>30);
 const auto created=allocations;for(int n=0;n<100;n++){batch.reconcile(rows,11000+n*16);batch.tick(batch_inv,api,equip,true,11000+n*16);}assert(allocations==created);
 // Butterfly Doppler -> M9 with a Negev-origin finish retains the same logical slot.
 native.knife_model[0]=native.knife_model[1]=4;native.records[42].paint=native.records[59].paint=1043;
 assert(skin_native_state::decode(native,rows));batch.reconcile(rows,14000);assert(batch.tick(batch_inv,api,equip,true,14000));
 unsigned m9=0,butterfly=0,agents=0;for(auto& i:batch_inv.items)if(i.object){if(i.spec.source==0x10000){m9+=i.spec.weapon==508&&i.spec.paint==1043;butterfly+=i.spec.weapon==515;}agents+=(i.spec.flags&2u)!=0;}
 assert(m9==1&&butterfly==0&&agents==1);
 // Removing a configured skin and an agent retires their owned items.
 native.records[7].enabled=0;native.agent_on[0]=false;assert(skin_native_state::decode(native,rows));batch.reconcile(rows,15000);
 for(unsigned n=0;n<4;n++)batch.tick(batch_inv,api,equip,true,15000+n*16);
 for(auto& i:batch_inv.items)if(i.object)assert(i.spec.source!=7&&!(i.spec.flags&2u));
 // A transient old-item removal failure is retired and retried, not orphaned.
 skin_mirror::Mirror retry;Inventory retry_inv;assert(retry_inv.refresh(api));Spec one=a;one.source=9;
 retry.observe(one,true,20000,true);assert(retry.tick(retry_inv,api,equip,true,20000));
 one.seed=111;retry.observe(one,true,20100,true);fail_remove=true;assert(retry.tick(retry_inv,api,equip,true,20100));fail_remove=false;
 unsigned owned_count=0;for(const auto& i:retry_inv.items)if(i.object)owned_count++;assert(owned_count==2);
 assert(!retry.tick(retry_inv,api,equip,true,22099));assert(retry.tick(retry_inv,api,equip,true,22100));owned_count=0;for(const auto& i:retry_inv.items)if(i.object)owned_count++;assert(owned_count==1);
 // Rebuilding the game's cache can remove a synthetic item without changing
 // the selected config. The periodic watchdog schedules a fresh owned item.
 unsigned lost_slot=0;while(!retry_inv.items[lost_slot].object)++lost_slot;const auto lost=retry_inv.items[lost_slot].id;present[lost]=false;
 retry.heal(retry_inv,api,23000);assert(retry.tick(retry_inv,api,equip,true,23000));
 owned_count=0;for(const auto& i:retry_inv.items)if(i.object){owned_count++;assert(i.id!=lost);}assert(owned_count==1);
 std::cout<<"Debounce, duplicate prevention, update replacement, disable/restore, manual delete, account change and manual slot ownership passed\n";
}
