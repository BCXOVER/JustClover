-- Legacy Source 1 world controls. No Source 2-only particles, keychains or skins.
local world={}
local function check(name) return ui.new_checkbox('VISUALS','Effects',name) end
local function slider(name,a,b,v,unit,scale) return ui.new_slider('VISUALS','Effects',name,a,b,v,true,unit or '',scale or 1) end
world.sky=check('Override sky')
world.sky_color=ui.new_color_picker('VISUALS','Effects','Sky color',255,255,255,255)
world.preset=ui.new_combobox('VISUALS','Effects','Skybox','Default','Night','Night 2','Daylight','Vertigo','Vietnam','Custom')
world.custom=ui.new_textbox('VISUALS','Effects','Custom skybox name')
world.sky_status=ui.new_label('VISUALS','Effects','Skybox materials not found')
ui.set_visible(world.sky_status,false)
world.light=check('Override lighting')
world.light_color=ui.new_color_picker('VISUALS','Effects','Ambient light color',20,20,20,255)
world.fog=check('Override fog')
world.color=ui.new_color_picker('VISUALS','Effects','Fog color',170,185,205,255)
world.start=slider('Fog start',-1000,10000,0,'u')
world.finish=slider('Fog end',1,20000,1500,'u')
world.density=slider('Fog density',0,100,70,'%')
local fog_names={'fog_override','fog_start','fog_end','fog_maxdensity','fog_color','fog_enable','fog_enableskybox','fog_startskybox','fog_endskybox','fog_maxdensityskybox','fog_colorskybox'}
local originals,lighting_originals,sky_original,sky_applied,sky_attempt={},{},nil,nil,nil
local function save(name)
 local v=cvar[name];if not v then return end
 if originals[name]==nil then originals[name]=v:get_string() end
 return v
end
local function different(a,b) local x,y=tonumber(a),tonumber(b);if x and y then return math.abs(x-y)>.00001 end return a~=b end
local function put(name,value)
 local v=save(name);if v then
  value=tostring(value);if different(v:get_string(),value) then v:set_string(value) end
 end
end
local function restore_fog()
 for name,value in pairs(originals) do local v=cvar[name];if v then v:set_string(value) end end
 originals={}
end
local function visibility()
 local sky=ui.get(world.sky);ui.set_visible(world.sky_color,sky);ui.set_visible(world.light_color,ui.get(world.light));ui.set_visible(world.preset,sky);ui.set_visible(world.custom,sky and ui.get(world.preset)=='Custom')
 local fog=ui.get(world.fog);for _,ref in ipairs({world.color,world.start,world.finish,world.density}) do ui.set_visible(ref,fog) end
end
for _,ref in ipairs({world.sky,world.preset,world.light,world.fog}) do ui.set_callback(ref,visibility) end
visibility()
local skies={Night='sky_csgo_night02',['Night 2']='sky_csgo_night02b',Daylight='sky_cs15_daylight04_hdr',Vertigo='vertigo',Vietnam='vietnam'}
local last_update=-1
local function restore_sky()
 native.clover_sky_tint(nil,0)
 if sky_original then native.clover_sky(sky_original);sky_original=nil;sky_applied=nil;sky_attempt=nil;ui.set_visible(world.sky_status,false) end
end
client.set_event_callback('paint_ui',function()
 local now=globals.realtime();if now-last_update<.1 then return end;last_update=now
 if ui.get(world.light) then
  local r,g,b=ui.get(world.light_color)
  for i,n in ipairs({'mat_ambient_light_r','mat_ambient_light_g','mat_ambient_light_b'}) do
   local v=cvar[n];if v then if lighting_originals[n]==nil then lighting_originals[n]=v:get_string() end;local value=tostring(({r,g,b})[i]/255);if different(v:get_string(),value) then v:set_string(value) end end
  end
 elseif next(lighting_originals) then for n,value in pairs(lighting_originals) do cvar[n]:set_string(value) end;lighting_originals={} end
 if ui.get(world.fog) then
  local r,g,b=ui.get(world.color);local rgb=string.format('%d %d %d',r,g,b)
  local start=ui.get(world.start);local finish=math.max(start+1,ui.get(world.finish));local density=ui.get(world.density)/100
  put('fog_override',1);put('fog_enable',1);put('fog_enableskybox',1)
  put('fog_start',start);put('fog_end',finish);put('fog_maxdensity',density);put('fog_color',rgb)
  put('fog_startskybox',start);put('fog_endskybox',finish);put('fog_maxdensityskybox',density);put('fog_colorskybox',rgb)
 else if next(originals) then restore_fog() end end
 if ui.get(world.sky) then
  if not sky_original then sky_original=cvar.sv_skyname:get_string() end
  local preset=ui.get(world.preset);local name=skies[preset] or (preset=='Custom' and ui.get(world.custom) or sky_original)
  if name~=sky_attempt and name and #name>0 and #name<96 and name:match('^[%w_/-]+$') then
   sky_attempt=name;native.clover_sky_tint(nil,0)
   local ok=native.clover_sky(name)==1;ui.set_visible(world.sky_status,not ok)
   if ok then sky_applied=name end
  end
  if sky_applied then local r,g,b=ui.get(world.sky_color);native.clover_sky_tint(sky_applied,r+g*256+b*65536) end
 elseif sky_original then restore_sky() end
end)
client.set_event_callback('level_init',function() originals={};lighting_originals={};sky_original=nil;sky_applied=nil;sky_attempt=nil;ui.set_visible(world.sky_status,false);last_update=-1;native.clover_sky_tint(nil,0) end)
client.set_event_callback('shutdown',function() restore_fog();restore_sky();for n,value in pairs(lighting_originals) do cvar[n]:set_string(value) end end)
