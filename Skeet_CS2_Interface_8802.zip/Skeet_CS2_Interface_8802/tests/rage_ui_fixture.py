"""Fresh native views retain source models and retire safely after Lua unload."""
def check_rage_ui(ns,damage_kind=3):
 globals().update(ns)
 state={'down':False,'x':107,'y':107}
 def cursor(u,sp):
  at=word(u,sp+4);store(u,at,state['x']);store(u,at+4,state['y']);return 1,8
 handlers={'GetAsyncKeyState':lambda u,sp:(0x8000 if word(u,sp+4)==1 and state['down'] else 0,8),'GetCursorPos':cursor,'GetForegroundWindow':lambda u,sp:(0,4)}
 u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',handlers);api_base=0x140000;u.mem_map(api_base,0x1000);u.mem_map(0x500000,0x400000)
 ctx,menu,tabs,tab,children,aim,other,api,vt,svt=[MEM+0x10000+i*0x1000 for i in range(10)]
 store(u,ctx+0x10,menu);store(u,menu+0x14,660);store(u,menu+0x18,560);store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs,tab)
 store(u,tab+0x70,children);store(u,tab+0x74,children+8);store(u,tab+0x78,children+256);store(u,children,aim);store(u,children+4,other);floats(u,0x4346d490,1)
 cursor=[0x500000];callbacks=[];destroyed=[]
 def alloc(n):
  p=cursor[0];cursor[0]+=(max(n,64)+15)&~15;assert cursor[0]<0x8f0000;u.mem_write(p,bytes(max(n,64)));return p
 def name(at,text):
  p=alloc(512);data=text.encode('utf-16le');store(u,at+0x38,p);u.mem_write(p,struct.pack('<HH',0,len(data))+data)
 def vector(at,offset,capacity=128):
  p=alloc(capacity*4);store(u,at+offset,p);store(u,at+offset+4,p);store(u,at+offset+8,p+capacity*4)
 def insert(parent,offset,item):
  end=word(u,parent+offset+4);assert end+4<=word(u,parent+offset+8);store(u,end,item);store(u,parent+offset+4,end+4)
 for parent,title,x in [(aim,'Aimbot',100),(other,'Other',350)]:
  name(parent,title);u.mem_write(parent+0x14,b'\1\1\0\1');store(u,parent+0x20,x);store(u,parent+0x24,100);store(u,parent+0x28,220);store(u,parent+0x2c,420);vector(parent,0x80)
 for i in range(13):store(u,vt+i*4,api_base+0x400)
 store(u,vt,api_base+0x420);store(u,vt+24,api_base+0x440)
 for i in range(13):store(u,svt+4*i,api_base+0x400)
 store(u,svt+20,api_base+0x500);store(u,svt+28,api_base+0x520)
 source=[];values=[]
 rows=[(aim,'Multi-point',13),(aim,'',5),(aim,'Quick stop',3),(aim,'',13),(aim,'Minimum damage',5),(other,'Double tap',3),(other,'',9),(other,'Double tap hit chance',5),(other,'Quick peek assist',3),(other,'Maximum peek distance',5),(other,'Accuracy boost',4),(other,'Refine shot',3),(aim,'Minimum damage override',damage_kind),(aim,'',9),(aim,'',5),(aim,'Minimum hit chance override',3),(aim,'',9),(aim,'',5)]
 for i,(parent,text,kind) in enumerate(rows):
  e=alloc(0x400);value=alloc(32);store(u,e,svt);u.mem_write(e+0x14,bytes([1,1,0,1,0,kind]));store(u,e+0x5c,value);name(e,text);store(u,value,1 if kind==3 else i+31);store(u,value+16,0x40);insert(parent,0x80,e);source.append(e);values.append((value,word(u,value)))
 def mock(u,a,size,user):
  if not api_base<=a<api_base+0x1000:return
  sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX);result=0;cleanup=4
  if a==api_base+0x100:result=alloc(this)
  elif a in [api_base+0x140,api_base+0x160,api_base+0x180,api_base+0x1a0,api_base+0x1e0]:
   kind={0x140:3,0x160:5,0x180:4,0x1a0:13,0x1e0:9}[a-api_base];parent=word(u,sp+4);v=word(u,sp+(20 if kind==5 else 8 if kind==9 else 12));cleanup={3:16,5:36,4:20,13:24,9:16}[kind]
   store(u,this,vt);store(u,this+0x10,parent);store(u,this+0x5c,v);u.mem_write(this+0x19,bytes([kind]));store(u,v+(16 if kind==9 else 0),0);result=this
  elif a==api_base+0x200:
   parent,nm=word(u,sp+4),word(u,sp+8);store(u,this,vt);store(u,this+0x10,parent);u.mem_write(this+0x14,b'\1\1\0\1');u.mem_write(this+0x19,b'\x08');name(this,wide(u,nm));cleanup=12;result=this
  elif a==api_base+0x220:insert(this,0x80,word(u,sp+8));cleanup=12
  elif a==api_base+0x420:assert word(u,this+0x5c)==0;destroyed.append(this);cleanup=8
  elif a==api_base+0x500:callbacks.append(('config',this))
  elif a==api_base+0x520:callbacks.append(('value',this))
  elif a==api_base+0x600:
   parent,nm=[word(u,sp+i) for i in [4,8]];store(u,this,vt);store(u,this+0x10,parent);u.mem_write(this+0x14,b'\1\1\0\1');name(this,wide(u,nm));vector(this,0x80);cleanup=24;result=this
  elif a==api_base+0x620:insert(this,0x70,word(u,sp+4));cleanup=8
  elif a==api_base+0x640:
   b=alloc(0x80);store(u,b,vt);store(u,b+0x10,this);u.mem_write(b+0x19,b'\2');insert(this,0x80,b);result=b;cleanup=20
  else:assert a in [api_base+0x120,api_base+0x400,api_base+0x440],hex(a)
  u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,word(u,sp))
 u.hook_add(UC_HOOK_CODE,mock)
 for i in range(12):store(u,api+4*i,api_base+0x100+0x20*i)
 call(u,exp('rage_setup_probe'),[ctx,api,api_base+0x600,api_base+0x620,api_base+0x640])
 assert call(u,exp('rage_rebuild_probe'))==1
 assert all(word(u,p)==v for p,v in values);assert bytes(u.mem_read(aim+0x15,1))==b'\0'
 panes=[call(u,exp('rage_pane_probe'),[i]) for i in range(9)]
 expected=[0,2,0,3,0,1,5,5,1,4,1,6,0,7,7,0,8,8]
 if damage_kind==9:expected[12]=7
 for i,pane in enumerate(expected):
  proxy=call(u,exp('rage_proxy_for_source_probe'),[source[i]]);assert word(u,proxy+0x10)==panes[pane];assert rows[i][2]==8 or word(u,proxy+0x5c)==values[i][0]
 assert [(word(u,p+0x84)-word(u,p+0x80))//4 for p in panes]==[9,6,2,2,2,4,2,6 if damage_kind==9 else 4,4]
 call(u,exp('rage_open_probe'),[3]);key_proxy=call(u,exp('rage_proxy_for_source_probe'),[source[6]]);u.mem_write(key_proxy+0x60,b'\1');assert call(u,exp('rage_native_editor_probe'))==1;u.mem_write(key_proxy+0x60,b'\0');assert call(u,exp('rage_native_editor_probe'))==0;call(u,exp('rage_close_probe'))
 # Actual frame polling must intercept row-overlapping gears before native
 # checkbox input and publish the popup in that same frame, even while held.
 store(u,menu+0x34,1);store(u,menu+0x64,0)
 call(u,exp('rage_frame_probe'));call(u,exp('rage_gear_rect_probe'),[2,100,100,17,17])
 peek=call(u,exp('rage_proxy_for_source_probe'),[source[8]]);original_peek=word(u,values[8][0])
 state['down']=True;call(u,exp('rage_frame_probe'))
 assert call(u,exp('rage_popup_probe'))==2
 assert bytes(u.mem_read(panes[4]+0x15,1))==b'\1'
 assert bytes(u.mem_read(peek+0x17,1))==b'\0' and word(u,values[8][0])==original_peek
 call(u,exp('rage_frame_probe'));assert call(u,exp('rage_popup_probe'))==2
 state['down']=False;call(u,exp('rage_frame_probe'))
 detail=call(u,exp('rage_proxy_for_source_probe'),[source[9]])
 assert bytes(u.mem_read(detail+0x17,1))==b'\1'
 # A main-page gear under the open popup must not receive the popup's click.
 state['x']=word(u,panes[4]+0x20)+30;state['y']=word(u,panes[4]+0x24)+30
 call(u,exp('rage_gear_rect_probe'),[0,state['x']-2,state['y']-2,17,17])
 state['down']=True;call(u,exp('rage_frame_probe'));assert call(u,exp('rage_popup_probe'))==2
 state['down']=False;call(u,exp('rage_frame_probe'));state['x']=107;state['y']=107
 call(u,exp('rage_gear_rect_probe'),[0,0,0,0,0])
 state['down']=True;call(u,exp('rage_frame_probe'));assert call(u,exp('rage_popup_probe'))==0xffffffff
 assert bytes(u.mem_read(peek+0x17,1))==b'\0'
 state['down']=False;call(u,exp('rage_frame_probe'));assert bytes(u.mem_read(peek+0x17,1))==b'\1'
 callbacks.clear();store(u,values[9][0],77);call(u,exp('rage_change_probe'),[call(u,exp('rage_index_probe'),[source[9]])]);assert callbacks==[('config',source[9]),('value',source[9])]
 call(u,exp('rage_open_probe'),[2]);assert call(u,exp('rage_popup_probe'))==2;call(u,exp('rage_close_probe'));assert call(u,exp('rage_popup_probe'))==0xffffffff
 # Ownership changed before queued callback: do not forward through retired source.
 callbacks.clear();store(u,other+0x84,word(u,other+0x84)-4);call(u,exp('rage_change_probe'),[call(u,exp('rage_index_probe'),[source[11]])]);assert not callbacks
 assert word(u,call(u,exp('rage_proxy_for_source_probe'),[source[11]])+0x5c)==0
 return {'real_gear_frame_click_does_not_toggle_peek':True,'opening_click_suppressed_until_release':True,'popup_visible_same_frame':True,'popup_occludes_main_gears':True,'native_rage_views':len(rows),'gear_groups':7,'override_binds_in_popup':True,'blank_companions_routed':True,'source_models_preserved':True,'native_callbacks_forwarded_once':True,'retired_callback_invalidated':True,'popup_close_checked':True,'native_key_capture_keeps_parent_popup':True}
