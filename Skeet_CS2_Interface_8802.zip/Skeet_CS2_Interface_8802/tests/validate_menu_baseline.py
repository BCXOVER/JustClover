"""Verify that CS2 presentation and sticker integration preserve gameplay code."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent/'skeet-overrides-preview-fix-8802'
allowed={f'source/skeet/{n}' for n in ['rage_settings_ui.h','local_inventory_client.h','cs2_visuals_design.h','renderer_overlay_scope.h','cs2_visuals_impl.h','skin_mirror.h']}
added={f'source/skeet/{n}.h' for n in ['sticker_catalog','sticker_state','ui_addon_embedded','ui_addon_runtime','weapon_sticker_client']}|{f'source/lua/{n}.lua' for n in ['bridge','clover_cs2_ui_8802','compat','notify.original','stickers','watermark.original','world']}
sha=lambda b:hashlib.sha256(b).hexdigest()
old={str(p.relative_to(BASE)):p for p in (BASE/'source').rglob('*') if p.is_file()};new={str(p.relative_to(ROOT)):p for p in (ROOT/'source').rglob('*') if p.is_file()}
assert new.keys()-old.keys()==added;assert not old.keys()-new.keys()
changes={p for p in old if old[p].read_bytes()!=new[p].read_bytes()};assert changes==allowed,changes
unchanged={p:sha(new[p].read_bytes()) for p in old if p not in allowed}
for p in ['source/skeet/skeet.cpp','source/skeet/motion_patch.h','source/skeet/hitchance_override_patch.h','source/steam/steam.cpp']:
 assert p in unchanged,p
report={'passed':True,'baseline_commit':'bcc35a5230b9ad6420cee02086f17f6e5a06b110','unchanged_source_files':len(unchanged),'changed_existing_source':sorted(changes),'new_source':sorted(added),'gameplay_change':None,'injector_unchanged':True,'inventory_change':'four-slot Legacy stickers; per-weapon revisions and owned weapon view ID bridge','embedded_resources_unchanged':True,'unchanged_source_sha256':unchanged}
(ROOT/'build/menu_baseline_validation.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',len(unchanged),'unchanged source files; gameplay and injector unchanged')
