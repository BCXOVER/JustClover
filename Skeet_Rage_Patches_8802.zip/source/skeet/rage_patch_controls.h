#pragma once
#include <cstddef>
#ifdef _WIN32
#define RAGE_THISCALL __thiscall
#else
#define RAGE_THISCALL
#endif
namespace rage_controls {
using Allocate=void*(RAGE_THISCALL*)(int);
using Release=void(RAGE_THISCALL*)(void*);
using Construct=void*(RAGE_THISCALL*)(void*,void*,const wchar_t*,int*);
using Insert=void(RAGE_THISCALL*)(void*,bool,void*);
using Layout=void(RAGE_THISCALL*)(void*);
struct Api {Allocate allocate;Release release;Construct construct;Insert insert;Layout layout;};
inline constexpr const wchar_t* names[]={
    L"Patch: history guard",L"Patch: strict hit chance",L"Patch: 64-sample hit chance"};
inline bool attach(void* child,const Api& api,int* const states[3],void* out[3]) {
    if(!child||!api.allocate||!api.release||!api.construct||!api.insert||!api.layout)return false;
    for(int i=0;i<3;i++)if(!states[i])return false;
    void* allocated[3]{};
    int previous[3]={*states[0],*states[1],*states[2]};
    for(int i=0;i<3;i++) {
        allocated[i]=api.allocate(0x78);
        if(!allocated[i]) {
            for(int j=0;j<i;j++)api.release(allocated[j]);
            return false;
        }
    }
    for(int i=0;i<3;i++) {
        api.construct(allocated[i],child,names[i],states[i]);
        api.insert(child,false,allocated[i]);
        *states[i]=previous[i];
        out[i]=allocated[i];
    }
    api.layout(child);
    return true;
}
}
#undef RAGE_THISCALL
