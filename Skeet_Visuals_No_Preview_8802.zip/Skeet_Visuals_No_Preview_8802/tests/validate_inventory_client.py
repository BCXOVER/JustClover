"""Selected original 2023-client functions in a closed x86 fixture.
Inventory/GC/renderer callbacks are controlled boundaries. No DLL entry runs.
"""
from pathlib import Path
import struct,json,hashlib
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build'
client=Path('/workspace/game-8802-modules/client.mapped.bin').read_bytes();BASE=0x10000000;MEM=0x200000;SP=0x260000;STOP=0x100000
u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(BASE,0x5509000);u.mem_write(BASE,client);u.mem_map(MEM,0x100000);u.mem_map(STOP,0x1000)
pe=pefile.PE(str(BUILD/'local_inventory_client_probe.dll'));pb=pe.OPTIONAL_HEADER.ImageBase;assert pb==0x30000000
u.mem_map(pb,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(pb,pe.get_memory_mapped_image());u.mem_map(0x130000,0x10000)
def word(a):return struct.unpack('<I',u.mem_read(a,4))[0]
def put(a,x):u.mem_write(a,struct.pack('<I',x&0xffffffff))
def fbits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
exports={s.name.decode().lstrip('_'):pb+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def exp(name):return next(v for k,v in exports.items() if name in k)
imports={}
for lib in pe.DIRECTORY_ENTRY_IMPORT:
 for item in lib.imports:
  a=0x130000+len(imports)*16;put(item.address,a);imports[a]=item.name.decode()
inv,soc,cache,cache_array,sys,kit,nodes,object_,view,session,spec,colors,heap_cell,allocator,allocator_vt=[MEM+0x10000+i*0x1000 for i in range(15)]
schema=sys+4
put(BASE+0x5270ff8,BASE+0xcace9c);put(BASE+0x5270ff8+0x38300,inv)
put(inv,BASE+0xcace34);put(inv+8,42);put(inv+12,0x1100001);put(inv+16,1);put(inv+0xb4,soc)
put(soc+0x10,cache_array);put(soc+0x1c,1);put(cache_array,cache)
put(cache,BASE+0xcdf6e0);put(cache+0x20,1);put(cache+4,cache_array+100);put(cache+0x18,0);put(cache+8,32)
put(BASE+0x534c958,sys);put(sys,BASE+0xcb8f3c);put(schema,BASE+0xcad7e4)
put(schema+0x28c,nodes);put(schema+0x290,1);put(schema+0x298,0);put(schema+0x29c,1);put(schema+0x2a4,0)
for off,n in [(0,-1),(4,-1),(8,-1),(16,344),(20,kit)]:put(nodes+off,n)
put(kit,344);initial=[0xff123456,0xff56789a,0xffabcdef,0xff89abcd]
for i,c in enumerate(initial):put(kit+0x80+4*i,c)
put(BASE+0xb3a2c0,heap_cell);put(heap_cell,allocator);put(allocator,allocator_vt);put(allocator_vt+4,0x131000)
put(BASE+0xdaf8e0,heap_cell+100);put(heap_cell+104,77)
module=[True];calls=[]
def finish(sp,result=0,cleanup=4):
 u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_EIP,word(sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
def read_cstr(a):
 out=bytearray()
 while True:
  n=bytes(u.mem_read(a+len(out),1))
  if n==b'\0':return out.decode('utf-8')
  out+=n
getdef=word(BASE+0xcad7e4+4*4);getattr=word(BASE+0xcad7e4+4*27)
slot34=word(BASE+0xcace9c+4*34)
def hook(u,a,size,user):
 sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX)
 if a in imports:
  fn=imports[a]
  if fn=='GetModuleHandleW':finish(sp,BASE if module[0] else 0,8)
  elif fn=='VirtualQuery':
   addr,out,n=[word(sp+k) for k in [4,8,12]];assert n==28
   for lo,hi,perm in u.mem_regions():
    if lo<=addr<=hi:
     u.mem_write(out,struct.pack('<IIIIIII',lo,lo,0x40,hi-lo+1,0x1000,0x40,0x20000));finish(sp,28,16);break
   else:finish(sp,0,16)
  elif fn in ['memcpy','memmove']:
   dst,src,n=[word(sp+k) for k in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)));finish(sp,dst)
  elif fn=='memset':
   dst,c,n=[word(sp+k) for k in [4,8,12]];u.mem_write(dst,bytes([c&255])*n);finish(sp,dst)
  elif fn=='memcmp':
   left,right,n=[word(sp+k) for k in [4,8,12]];finish(sp,int(bytes(u.mem_read(left,n))!=bytes(u.mem_read(right,n))))
  else:raise AssertionError(fn)
 elif a==0x131000:
  assert this==allocator and word(sp+4)==56;calls.append(('allocate',56));finish(sp,object_,8)
 elif a in [getdef,getattr]:
  index=word(sp+4);assert this==schema
  if a==getdef:assert index==9;finish(sp,MEM+0x90000,8)
  else:assert index in [6,7,8];finish(sp,MEM+0x91000+index*0x100,8)
 elif a==BASE+0x6da0e0:
  attribute,value=[word(sp+k) for k in [4,8]];assert this==object_;calls.append(('attribute',(attribute-(MEM+0x91000))//0x100,word(value)));finish(sp,0,12)
 elif a==BASE+0x6d9160:
  assert this==object_;calls.append(('name',read_cstr(word(sp+4))));finish(sp,0,8)
 elif a in [BASE+0x6e6e90,BASE+0x6e6f60,BASE+0x6e70c0]:
  assert this==inv and [word(sp+4),word(sp+8),word(sp+12),word(sp+20),word(sp+24)]==[42,0x1100001,1,object_,4]
  calls.append(('event',a-BASE));finish(sp,0,28)
 elif a==BASE+0x6cb830:finish(sp)
 elif a==slot34:finish(sp,0,8)
 elif a==BASE+0x6e62f0:finish(sp,0,8)
 elif a==BASE+0x6cc7b0:
  assert word(sp+4)==12 and word(sp+8)==0;calls.append(('view',12));finish(sp,view)
 elif a==BASE+0x71b050:assert this==view;calls.append(('clear_icon',));finish(sp)
 elif a==STOP:u.emu_stop()
u.hook_add(UC_HOOK_CODE,hook)
def call(name,args=()):
 for i,v in enumerate([STOP,*args]):put(SP+4*i,v)
 u.reg_write(UC_X86_REG_ESP,SP);u.emu_start(exp(name),STOP+0x100,count=500000)
 assert u.reg_read(UC_X86_REG_EIP)==STOP,hex(u.reg_read(UC_X86_REG_EIP));return u.reg_read(UC_X86_REG_EAX)
assert call('inventory_client_session_probe',[session])==1
assert [word(session+i) for i in range(0,24,4)]==[inv,cache,42,0x1100001,1,42]
assert call('inventory_client_create_probe')==object_ and word(object_)==BASE+0xcae8f0
u.mem_write(spec,struct.pack('<iii f I',9,344,123,.02,6)+('Дракон\0'.encode('utf-8')))
assert call('inventory_client_initialize_probe',[object_,session,spec,12,0,9])==1
assert word(object_+8)==12 and word(object_+28)==42 and word(object_+32)==9
assert calls[-4:]==[('attribute',6,fbits(344.)),('attribute',7,fbits(123.)),('attribute',8,fbits(.02)),('name','Дракон')]
assert call('inventory_client_insert_probe',[session,object_])==1 and word(cache+0x18)==1
assert call('inventory_client_remove_probe',[session,object_])==1 and word(cache+0x18)==0
assert call('inventory_client_palette_probe',[344,colors,0])==1 and [word(colors+4*i) for i in range(4)]==initial
changed=[0xff00ff00,0xffff00ff,0xff0000ff,0xff00ffff]
for i,c in enumerate(changed):put(colors+4*i,c)
assert call('inventory_client_palette_probe',[344,colors,1])==1 and [word(kit+0x80+4*i) for i in range(4)]==changed
put(kit+0x80,0xff010203)
assert call('inventory_client_palette_probe',[344,colors,2])==0 and word(kit+0x80)==0xff010203
put(kit+0x80,changed[0])
assert call('inventory_client_palette_probe',[344,colors,2])==1 and [word(kit+0x80+4*i) for i in range(4)]==initial
for event in [0,1,2]:assert call('inventory_client_notify_probe',[session,event,object_])==1
module[0]=False;before=bytes(u.mem_read(kit+0x80,16));assert call('inventory_client_palette_probe',[344,colors,1])==0 and before==bytes(u.mem_read(kit+0x80,16));module[0]=True
stamp=word(BASE+word(BASE+0x3c)+8);put(BASE+word(BASE+0x3c)+8,0);assert call('inventory_client_session_probe',[session])==0;put(BASE+word(BASE+0x3c)+8,stamp)
report={'passed':True,'portable_state_cases':117,'native_session_and_allocator_constructor':True,'native_paint_kit_getter':True,'native_type_cache_add_remove_executed':True,
 'native_derived_inventory_event_abi_cases':3,'native_attribute_abi_cases':3,'utf8_name_tag_forwarded':True,
 'native_palette_read_write_restore':True,'external_palette_changes_preserved':True,'missing_module_and_wrong_build_rejected':True,'gc_equip_method_called':False,
 'game_startup_executed':False,'game_tested':False,'palette_scope':'All local instances using this paint kit; only owned-item image caches refreshed'}
(BUILD/'inventory_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
