#include "../source/skeet/pch.h"
#include "../source/skeet/local_inventory_client.h"
extern "C" {
__declspec(dllexport) int inventory_client_session_probe(void* out){return local_inventory_client::session(*static_cast<local_inventory::Session*>(out));}
__declspec(dllexport) int inventory_client_initialize_probe(void* object,void* session,void* spec,unsigned lo,unsigned hi,unsigned position){return local_inventory_client::initialize(object,*static_cast<local_inventory::Session*>(session),*static_cast<local_inventory::Spec*>(spec),(std::uint64_t(hi)<<32)|lo,position);}
__declspec(dllexport) void* inventory_client_create_probe(){return local_inventory_client::create();}
__declspec(dllexport) int inventory_client_palette_probe(int id,void* colors,int action){return local_inventory_client::palette(id,static_cast<unsigned*>(colors),action);}
__declspec(dllexport) int inventory_client_notify_probe(void* session,int event,void* object){return local_inventory_client::notify(*static_cast<local_inventory::Session*>(session),event,object);}
__declspec(dllexport) int inventory_client_insert_probe(void* session,void* item){return local_inventory_client::insert(*static_cast<local_inventory::Session*>(session),item);}
__declspec(dllexport) int inventory_client_remove_probe(void* session,void* item){return local_inventory_client::remove(*static_cast<local_inventory::Session*>(session),item);}

}
