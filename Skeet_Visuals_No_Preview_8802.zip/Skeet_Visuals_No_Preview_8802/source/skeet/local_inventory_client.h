#pragma once
#include "local_inventory.h"
#include "inventory_catalog.h"
#include <windows.h>
namespace local_inventory_client {
using namespace local_inventory;
inline unsigned char* base=nullptr;
inline std::uint32_t read32(const void* p,unsigned off){std::uint32_t x;std::memcpy(&x,static_cast<const unsigned char*>(p)+off,4);return x;}
inline std::uint64_t read64(const void* p,unsigned off){std::uint64_t x;std::memcpy(&x,static_cast<const unsigned char*>(p)+off,8);return x;}
inline void put32(void* p,unsigned off,std::uint32_t x){std::memcpy(static_cast<unsigned char*>(p)+off,&x,4);}
inline bool memory(const void* p,std::size_t bytes,bool write=false) {
 if(!p||!bytes)return false;MEMORY_BASIC_INFORMATION m{};
 if(!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 const auto at=reinterpret_cast<std::uintptr_t>(p),first=reinterpret_cast<std::uintptr_t>(m.BaseAddress);
 if(at<first||bytes>m.RegionSize||at-first>m.RegionSize-bytes)return false;
 if(write&&!(m.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY)))return false;
 return true;
}
inline void* pointer(const void* p,unsigned off){return reinterpret_cast<void*>(read32(p,off));}
inline void* method(void* object,unsigned slot) {
 if(!memory(object,4))return nullptr;auto* table=pointer(object,0);
 if(!memory(table,(slot+1)*4))return nullptr;auto* fn=pointer(table,slot*4);
 const auto at=reinterpret_cast<std::uintptr_t>(fn),start=reinterpret_cast<std::uintptr_t>(base);
 if(!base||at<start+0x1000||at>=start+0xb30000)return nullptr;
 MEMORY_BASIC_INFORMATION m{};if(!VirtualQuery(fn,&m,sizeof(m))||!(m.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY)))return nullptr;return fn;
}
inline bool ready() {
 auto* loaded=reinterpret_cast<unsigned char*>(GetModuleHandleW(L"client.dll"));if(!loaded)return false;
 if(!memory(loaded,0x1000)||*reinterpret_cast<const unsigned short*>(loaded)!=IMAGE_DOS_SIGNATURE)return false;
 const auto peoff=read32(loaded,0x3c);if(peoff>0x800||!memory(loaded+peoff,sizeof(IMAGE_NT_HEADERS32)))return false;
 auto* nt=reinterpret_cast<const IMAGE_NT_HEADERS32*>(loaded+peoff);
 if(nt->Signature!=IMAGE_NT_SIGNATURE||nt->FileHeader.Machine!=IMAGE_FILE_MACHINE_I386||nt->FileHeader.TimeDateStamp!=0x65272025||nt->OptionalHeader.SizeOfImage!=0x5509000)return false;
 // Relocation-independent guards for the supplied 2023 client, checked before
 // any item mutation. No detours or changes to client code are installed.
 constexpr unsigned char factory[]={0x6a,0x38};
 constexpr unsigned char attr[]={0x55,0x8b,0xec,0x83,0xe4,0xf8,0x83,0xec,0x3c,0x53};
 constexpr unsigned char getter[]={0x8b,0x81,0,0x83,3,0,0xc3};
 constexpr unsigned char paint[]={0x55,0x8b,0xec,0x53,0x56,0x57,0x8b,0xf9,0x8b,0x87,0x98,2,0,0};
 if(std::memcmp(loaded+0x6ea215,factory,sizeof(factory))||std::memcmp(loaded+0x6da0e0,attr,sizeof(attr))||
    std::memcmp(loaded+0x6c9af0,getter,sizeof(getter))||std::memcmp(loaded+0x70adb0,paint,sizeof(paint)))return false;
 base=loaded;return true;
}
inline void* schema() {
 using System=void*(__cdecl*)();using Get=void*(__thiscall*)(void*);
 auto* system=memory(base+0x534c958,4)?pointer(base+0x534c958,0):nullptr;auto* get=method(system,0);
 return get?reinterpret_cast<Get>(get)(system):nullptr;
}
inline void* paint_kit(void* s,int id) {
 if(!s||id<=0||id>65535||!memory(s,0x2ac))return nullptr;
 // Bound the tree before entering the original getter, including a cycle guard.
 auto* nodes=pointer(s,0x28c);int index=int(read32(s,0x298));const auto count=read32(s,0x290);
 if(count>65536||!memory(nodes,std::size_t(count)*24))return nullptr;
 for(unsigned depth=0;index!=-1&&depth<64;depth++) {
  if(index<0||unsigned(index)>=count)return nullptr;
  auto* node=static_cast<unsigned char*>(nodes)+index*24;const int key=int(read32(node,16));
  if(key==id) {
   auto* kit=pointer(node,20);
   if(!memory(kit,0xac,true)||read32(kit,0)!=unsigned(id))return nullptr;
   using Get=void*(__thiscall*)(void*,int);return reinterpret_cast<Get>(base+0x70adb0)(s,id)==kit?kit:nullptr;
  }
  index=int(read32(node,key>id?0:4));
 }
 return nullptr;
}
inline bool session(Session& out) {
 if(!ready())return false;
 auto* manager=base+0x5270ff8;auto* getter=method(manager,23);if(getter!=base+0x6c9af0)return false;
 using Get=void*(__thiscall*)(void*);auto* inv=reinterpret_cast<Get>(getter)(manager);
 if(!memory(inv,0xb8)||pointer(inv,0)!=base+0xcace34)return false;
 auto* soc=pointer(inv,0xb4);if(!memory(soc,0x20))return false;
 const auto caches=read32(soc,0x1c);if(caches>4096||(caches&&!memory(pointer(soc,0x10),caches*4)))return false;
 using Cache=void*(__thiscall*)(void*,int);auto* cache=reinterpret_cast<Cache>(base+0x82ea10)(soc,1);
 if(!memory(cache,0x24)||read32(cache,0x20)!=1||!method(cache,1)||!method(cache,3))return false;
 out={inv,cache,read64(inv,8),read32(inv,16),read32(inv,8)};
 return out.account&&method(inv,0)&&method(inv,1)&&method(inv,2);
}
inline bool objects(const Session& s,void*** list,unsigned& count) {
 if(!memory(s.cache,0x24)||read32(s.cache,0x20)!=1)return false;
 count=read32(s.cache,0x18);*list=static_cast<void**>(pointer(s.cache,4));
 return count<=131072&&(!count||memory(*list,count*4));
}
inline bool contains(const Session& s,void* object,std::uint64_t id) {
 void** list=nullptr;unsigned n=0;if(!objects(s,&list,n))return false;
 for(unsigned i=0;i<n;i++)if(list[i]==object)return memory(object,56)&&read64(object,8)==id&&read32(object,28)==s.account;
 return false;
}
inline bool highest(const Session& s,std::uint64_t& id,unsigned& position) {
 void** list=nullptr;unsigned n=0;if(!objects(s,&list,n))return false;
 id=position=0;
 for(unsigned i=0;i<n;i++) {
  if(!memory(list[i],56))return false;const auto current=read64(list[i],8);
  if(current&0xf000000000000000ULL)continue;
  if(current>id)id=current;position=(std::max)(position,read32(list[i],32));
 }
 return true;
}
inline void* create(){using Fn=void*(__stdcall*)();return reinterpret_cast<Fn>(base+0x6ea210)();}
inline bool name(void* item,const char* text){if(!valid_name(text))return false;using Fn=void(__thiscall*)(void*,const char*);reinterpret_cast<Fn>(base+0x6d9160)(item,text);return true;}
inline bool initialize(void* item,const Session& s,const Spec& spec,std::uint64_t id,unsigned position) {
 if(!memory(item,56,true)||!valid(spec))return false;auto* sch=schema();auto* def_get=method(sch,4);auto* attr_get=method(sch,27);
 if(!def_get||!attr_get)return false;
 using Def=void*(__thiscall*)(void*,int);if(!reinterpret_cast<Def>(def_get)(sch,spec.weapon))return false;
 bool combination=spec.paint==0;
 for(const auto& row:inventory_catalog::skins)if(row.weapon==spec.weapon&&row.paint==spec.paint){combination=true;break;}
 if(!combination||(spec.paint&&!paint_kit(sch,spec.paint)))return false;
 void* definitions[3]{};for(unsigned i=0;i<3;i++){definitions[i]=reinterpret_cast<Def>(attr_get)(sch,6+i);if(!definitions[i])return false;}
 std::memcpy(static_cast<unsigned char*>(item)+8,&id,8);const std::uint64_t original=0;std::memcpy(static_cast<unsigned char*>(item)+16,&original,8);
 put32(item,28,s.account);put32(item,32,position);
 const std::uint16_t weapon=std::uint16_t(spec.weapon),bits=std::uint16_t(8|((spec.weapon>=500&&spec.weapon<600?3:4)<<5)|(spec.rarity<<11));
 std::memcpy(static_cast<unsigned char*>(item)+36,&weapon,2);std::memcpy(static_cast<unsigned char*>(item)+38,&bits,2);
 using Attribute=void(__thiscall*)(void*,void*,void*);float values[]={float(spec.paint),float(spec.seed),spec.wear};
 for(unsigned i=0;i<3;i++)reinterpret_cast<Attribute>(base+0x6da0e0)(item,definitions[i],&values[i]);
 return name(item,spec.name);
}
inline bool insert(const Session& s,void* item) {
 using Fn=void(__thiscall*)(void*,void*);auto* fn=method(s.cache,1);if(!fn)return false;
 reinterpret_cast<Fn>(fn)(s.cache,item);return contains(s,item,read64(item,8));
}
inline bool remove(const Session& s,void* item) {
 using Fn=void(__thiscall*)(void*,void*);auto* fn=method(s.cache,3);if(!fn)return false;
 const auto id=read64(item,8);reinterpret_cast<Fn>(fn)(s.cache,item);return !contains(s,item,id);
}
struct SOID {std::uint64_t id;unsigned type,padding;};static_assert(sizeof(SOID)==16);
inline bool notify(const Session& s,int event,void* item) {
 if(event<0||event>2)return false;auto* fn=method(s.inventory,unsigned(event));if(!fn)return false;
 using Fn=void(__thiscall*)(void*,SOID,void*,int);
 reinterpret_cast<Fn>(fn)(s.inventory,{s.owner,s.owner_type,0},item,4);
 if(event!=2) {
  using Find=void*(__cdecl*)(std::uint64_t);auto* view=reinterpret_cast<Find>(base+0x6cc7b0)(read64(item,8));
  if(view){using Clear=void(__thiscall*)(void*);reinterpret_cast<Clear>(base+0x71b050)(view);}
 }
 return true;
}
inline void destroy(void* item){using Fn=void(__thiscall*)(void*,bool);auto* fn=method(item,0);if(fn)reinterpret_cast<Fn>(fn)(item,true);}
inline const Api api{&session,&highest,&contains,&create,&initialize,&name,&insert,&notify,&remove,&destroy};
struct Palette {int kit=0;void* object=nullptr;unsigned original[4]{},applied[4]{};};
inline std::array<Palette,128> palettes{};
inline bool palette(int kit,unsigned colors[4],int action) {
 if(!ready())return false;auto* obj=paint_kit(schema(),kit);if(!obj)return false;
 if(action==0){std::memcpy(colors,static_cast<unsigned char*>(obj)+0x80,16);return true;}
 Palette* saved=nullptr;for(auto& p:palettes)if(p.kit==kit){saved=&p;break;}
 if(action==2) {
  if(!saved||saved->object!=obj)return false;
  if(std::memcmp(static_cast<unsigned char*>(obj)+0x80,saved->applied,16))return false;
  std::memcpy(static_cast<unsigned char*>(obj)+0x80,saved->original,16);std::memcpy(colors,saved->original,16);*saved={};return true;
 }
 if(!saved){for(auto& p:palettes)if(!p.kit){saved=&p;break;}if(!saved)return false;*saved={};saved->kit=kit;saved->object=obj;std::memcpy(saved->original,static_cast<unsigned char*>(obj)+0x80,16);}
 if(saved->object!=obj)return false;
 for(int i=0;i<4;i++)colors[i]|=0xff000000U;
 std::memcpy(saved->applied,colors,16);std::memcpy(static_cast<unsigned char*>(obj)+0x80,colors,16);return true;
}
inline void restore_all_palettes() {
 for(auto& p:palettes)if(p.kit){const int id=p.kit;unsigned values[4]{};palette(id,values,2);p={};}
}

}
