#pragma once
#include "skin_mirror.h"
#include "local_loadout_client.h"
// Included inside cs2_visuals after both Skinchanger and local inventory UI.
namespace skin_mirror_ui {
static skin_mirror::Mirror mirror;
static DWORD sampled=0,checked=0;static bool started=false,checked_once=false;
static void simplify(const wchar_t* text,std::size_t length,wchar_t (&out)[256]) {
 wchar_t clean[256]{};skin_rarity::normalize(text,length,clean);unsigned n=0;
 for(unsigned i=0;clean[i]&&n<255;i++){wchar_t c=clean[i];if(c>=L'A'&&c<=L'Z')c+=L'a'-L'A';if((c>=L'a'&&c<=L'z')||(c>=L'0'&&c<=L'9'))out[n++]=c;}out[n]=0;
 for(const wchar_t* word:{L"knife",L"gloves",L"glove"})if(auto* at=std::wcsstr(out,word))std::memmove(at,at+std::wcslen(word),(std::wcslen(at+std::wcslen(word))+1)*sizeof(wchar_t));
}
static int weapon_label(const wchar_t* text,std::size_t length) {
 wchar_t key[256]{};simplify(text,length,key);if(!key[0]||!std::wcscmp(key,L"default"))return 0;
 for(const auto& w:inventory_ui::weapons){wchar_t candidate[256]{};simplify(w.name,std::wcslen(w.name),candidate);if(!std::wcscmp(key,candidate))return w.id;}
 return 0;
}
static bool combination(int weapon,int paint) {
 if(weapon<=0)return false;if(paint==0){for(const auto& w:inventory_ui::weapons)if(w.id==weapon)return true;return false;}for(const auto& row:inventory_catalog::skins)if(row.weapon==weapon&&row.paint==paint)return true;return false;
}
static unsigned value(const skin::View& view) {
 auto* p=native_ui_proxy::pointer(view.source,0x5c);if(!p)return 0;unsigned result=0;
 if(view.type==UiCheckbox)return *static_cast<const unsigned char*>(p)!=0;
 std::memcpy(&result,p,4);return result;
}
static int model_choice(const skin::View& view) {
 auto* combo=view.source->GetAs<Combobox>();if(combo->Vars.size()>512)return 0;
 const auto selected=value(view);
 for(const auto& item:combo->Vars)if(unsigned(item.Index)==selected&&item.Name.size()<=256)return weapon_label(item.Name.data(),item.Name.size());
 return 0;
}
static bool selection(local_inventory::Spec& out,bool& enabled) {
 auto* menu=context?context->Menu:nullptr;
 if(!menu||menu->CurrentTab!=SKINS||!(menu->MenuStatus&MenuOpened)||!skin::attached||skin::refreshing||skin::fingerprint(menu)!=skin::captured)return false;
 int explicit_weapon=0,knife=0,glove=0;bool have_enabled=false,have_knife=false,have_glove=false;enabled=false;
 for(unsigned i=0;i<skin::view_count;i++) {
  const auto& v=skin::views[i];const auto* label=v.anchor;
  if(v.type==UiCombobox) {
   if(has(label,L"Knife")||has(label,L"knife")){have_knife=true;knife=model_choice(v);}
   else if(has(label,L"Glove")||has(label,L"glove")){have_glove=true;glove=model_choice(v);}
   else if(eq(label,L"Weapon")||eq(label,L"Weapon type"))explicit_weapon=model_choice(v);
  }
  if(v.pane==&skin::panes[skin_menu_design::Weapon]&&v.type==UiCheckbox&&eq(v.name,L"Enabled")){have_enabled=true;enabled=value(v)!=0;}
 }
 if(!have_enabled)return false;const skin::View* selected_list=nullptr;int paint=-1;
 for(unsigned i=0;i<skin::view_count;i++) {
  const auto& v=skin::views[i];if(v.type!=UiListbox||v.pane!=&skin::panes[skin_menu_design::Weapon])continue;
  const auto* list=v.source->GetAs<Listbox>();if(list->Info.Items.size()>8192)continue;
  const auto selected=value(v);
  for(const auto& item:list->Info.Items)if(item.Index==selected&&item.Name.size()<=256) {
   const int id=skin_rarity::paint_id(int(item.Index),item.Name.data(),item.Name.size());
   if(id<0) {
    wchar_t label[256]{};skin_rarity::normalize(item.Name.data(),item.Name.size(),label);
    if(item.Index!=0||(!eq(label,L"Default")&&!eq(label,L"None")))continue;
   }
   if(selected_list)return false;selected_list=&v;paint=id<0?0:id;
  }
 }
 if(!selected_list||paint<0)return false;
 int weapon=explicit_weapon?explicit_weapon:selected_list->rarity_weapon;
 // A filtered finish list can happen to identify Bayonet although the native
 // model selector is Butterfly. The live model wins for knife/glove contexts.
 if(!explicit_weapon&&(weapon==0||weapon>=500)) {
  const bool k=combination(knife,paint),g=combination(glove,paint);
  if(k!=g)weapon=k?knife:glove;
  else if((weapon>=500&&weapon<5000&&have_knife)||(weapon>=5000&&have_glove))return false;
 }
 if(paint>0&&!combination(weapon,paint)) {
  const bool k=combination(knife,paint),g=combination(glove,paint);
  if(k!=g)weapon=k?knife:glove;
  else {skin_rarity::WeaponCandidates candidates;candidates.add(paint);weapon=candidates.weapon();}
 }
 if(!combination(weapon,paint))return false;
 out={};out.weapon=weapon;out.paint=paint;enabled=enabled&&paint>0;
 if(const auto* row=inventory_ui::skin_info(weapon,paint))out.rarity=unsigned(row->rarity);
 for(unsigned i=0;i<skin::view_count;i++) {
  const auto& v=skin::views[i];if(v.pane!=&skin::panes[skin_menu_design::Weapon])continue;
  if(v.type==UiSlider&&eq(v.name,L"Seed"))out.seed=int(value(v));
  if(v.type==UiSlider&&(eq(v.name,L"Quality")||eq(v.name,L"Wear"))) {
   const auto* slider=v.source->GetAs<Slider>();const int lo=slider->Min,hi=slider->Max,x=int(value(v));
   if(hi<=lo||x<lo||x>hi)return false;const float fraction=float(x-lo)/float(hi-lo);out.wear=eq(v.name,L"Quality")?1.f-fraction:fraction;
  }
  if(v.type==UiTextbox) {
   const auto* bytes=reinterpret_cast<const unsigned char*>(v.source);unsigned length=0;std::memcpy(&length,bytes+0x64,4);if(length>63)return false;
   wchar_t text[64]{};std::memcpy(text,bytes+0x68,length*2);
   if(!WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,text,-1,out.name,sizeof(out.name),nullptr,nullptr))return false;
  }
 }
 return local_inventory::valid(out);
}
static void capture(CMenu* menu) {
 if(!context||context->Menu!=menu)return;
 local_inventory::Spec spec{};bool enabled=false;
 if(selection(spec,enabled))mirror.observe(spec,enabled,GetTickCount());
}
static bool deleting(unsigned slot) {
 const auto& inv=inventory_ui::inventory;if(slot>=inv.items.size())return false;
 return mirror.loadout.detach(local_loadout_client::api,inv.items[slot].id)&&local_loadout_client::clear(inv.current,inv.items[slot]);
}
static void deleted(unsigned slot){mirror.deleted(slot);}
static void equip_selected(unsigned slot) {
 auto& inv=inventory_ui::inventory;if(!inv.owned(local_inventory_client::api,slot)){inventory_ui::report(inv.error);return;}
 const auto teams=mirror.loadout.equip(local_loadout_client::api,inv.current,inv.items[slot]);
 inventory_ui::report(teams?"Item equipped locally for its supported teams":"Local equip unavailable for this item");
}
static void frame_impl(CMenu* menu) {
 skin::after_change=&capture;
 inventory_ui::before_delete=&deleting;inventory_ui::after_delete=&deleted;inventory_ui::equip_action=&equip_selected;
 if(!menu||!context||context->Menu!=menu)return;const DWORD now=GetTickCount();
 auto& inv=inventory_ui::inventory;
 if(!checked_once||DWORD(now-checked)>=1000) {
  checked=now;checked_once=true;local_inventory::Session next{};
  if(!local_inventory_client::session(next)){started=false;return;}
  if(!(next==inv.current)){local_inventory_client::restore_all_palettes();inv.items={};inv.current=next;mirror.changed_session(next);inventory_ui::owned_choices();}
  started=true;
 }
 if(!started||!inv.current.inventory)return;
 if(DWORD(now-sampled)>=100) {
  sampled=now;capture(menu);
 }
 if(mirror.tick(inv,local_inventory_client::api,local_loadout_client::api,true,now)) {
  inventory_ui::owned_choices();inventory_ui::report(mirror.status);
 }
}
static void frame(CMenu* menu){try{frame_impl(menu);}catch(...){inventory_ui::report("Skinchanger sync unavailable");}}
}
