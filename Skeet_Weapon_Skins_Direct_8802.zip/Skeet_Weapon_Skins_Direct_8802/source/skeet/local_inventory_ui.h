#pragma once
// Included inside cs2_visuals after the native Skinchanger adapter.
namespace inventory_ui {
using local_inventory::Spec;
struct Weapon {int id;const wchar_t* name;};
inline constexpr Weapon weapons[]={
 {1,L"Desert Eagle"},{2,L"Dual Berettas"},{3,L"Five-SeveN"},{4,L"Glock-18"},{7,L"AK-47"},{8,L"AUG"},{9,L"AWP"},{10,L"FAMAS"},{11,L"G3SG1"},{13,L"Galil AR"},{14,L"M249"},{16,L"M4A4"},{17,L"MAC-10"},{19,L"P90"},{23,L"MP5-SD"},{24,L"UMP-45"},{25,L"XM1014"},{26,L"PP-Bizon"},{27,L"MAG-7"},{28,L"Negev"},{29,L"Sawed-Off"},{30,L"Tec-9"},{32,L"P2000"},{33,L"MP7"},{34,L"MP9"},{35,L"Nova"},{36,L"P250"},{38,L"SCAR-20"},{39,L"SG 553"},{40,L"SSG 08"},{60,L"M4A1-S"},{61,L"USP-S"},{63,L"CZ75-Auto"},{64,L"R8 Revolver"},
 {500,L"Bayonet"},{503,L"Classic Knife"},{505,L"Flip Knife"},{506,L"Gut Knife"},{507,L"Karambit"},{508,L"M9 Bayonet"},{509,L"Huntsman Knife"},{512,L"Falchion Knife"},{514,L"Bowie Knife"},{515,L"Butterfly Knife"},{516,L"Shadow Daggers"},{517,L"Paracord Knife"},{518,L"Survival Knife"},{519,L"Ursus Knife"},{520,L"Navaja Knife"},{521,L"Nomad Knife"},{522,L"Stiletto Knife"},{523,L"Talon Knife"},{525,L"Skeleton Knife"},
 {5027,L"Bloodhound Gloves"},{5030,L"Sport Gloves"},{5031,L"Driver Gloves"},{5032,L"Hand Wraps"},{5033,L"Moto Gloves"},{5034,L"Specialist Gloves"},{5035,L"Hydra Gloves"}};
static bool enabled=true,show=false,built=false,building=false;
struct Pane {Child* child=nullptr;void* table[13]{};NativeChildDraw draw=nullptr;NativeLayout layout=nullptr,resize=nullptr,dpi=nullptr;};
static Pane panels[2]{};
static Button* entry=nullptr;static Combobox *weapon_combo=nullptr,*paint_combo=nullptr,*owned_combo=nullptr;
static Textbox* tag=nullptr;static int weapon=9,paint=344,seed=0,wear=100,selected=-1;
static VecCol colors[4]{{128,128,128,255},{128,128,128,255},{128,128,128,255},{128,128,128,255}};
static local_inventory::Inventory inventory{};
static bool(*before_delete)(unsigned)=nullptr;static void(*after_delete)(unsigned)=nullptr;static void(*equip_action)(unsigned)=nullptr;
static native_layout_state::Epoch geometry{};
static const wchar_t* status=L"Local CS:GO inventory. Items last until the game/cache is closed.";
static wchar_t message[180]{};static std::uint64_t ui_generation=0;
static bool owns(Child* c){if(!c)return false;for(auto& p:panels)if(c==p.child&&*reinterpret_cast<void***>(c)==p.table)return true;return false;}
static bool opened(){return enabled&&show&&built;}
static void report(const char* value){unsigned i=0;for(;value&&value[i]&&i+1<std::size(message);i++)message[i]=static_cast<unsigned char>(value[i]);message[i]=0;status=message;}
static const wchar_t* weapon_name(int id){for(auto& w:weapons)if(w.id==id)return w.name;return L"Item";}
static const inventory_catalog::Skin* skin_info(int w,int p){for(auto& s:inventory_catalog::skins)if(s.weapon==w&&s.paint==p)return &s;return nullptr;}
static void position(unsigned n) {
 auto* menu=context->Menu;const auto r=skin_menu_design::layout(menu->Size.x,menu->Size.y,scale());
 const auto first=r[skin_menu_design::Models],last=r[skin_menu_design::Weapon];
 const int top=int(25*scale()),bottom=int(25*scale());
 const Rect box{n?last.x:first.x,top,n?last.w:first.w,std::max(1,menu->Size.y-top-bottom)};
 native_layout_state::fixed(panels[n].child,box.x,box.y,box.w,box.h,scale());
}
static unsigned panel_index(Child* c){return c==panels[1].child?1:0;}
static void __fastcall layout(Child* c,void*){const auto n=panel_index(c);position(n);panels[n].layout(c);}
static void __fastcall resize(Child* c,void*){const auto n=panel_index(c);position(n);panels[n].resize(c);layout(c,nullptr);}
static void __fastcall dpi(Child* c,void*){const auto n=panel_index(c);position(n);panels[n].dpi(c);layout(c,nullptr);}
static void __fastcall draw(Child* c,void*,IRenderer* renderer,const Vec2* origin) {
 if(!opened())return;const auto n=panel_index(c);position(n);panels[n].draw(c,renderer,origin);
 if(n||!renderer||!origin)return;
 renderer->Text(0,origin->x+c->Pos.x+int(15*scale()),origin->y+c->Pos.y+c->Size.y-int(20*scale()),0xffb0b0b0,
  std::max(1,c->Size.x-int(30*scale())),status,std::wcslen(status));
}
static void choices(Combobox* combo,const wchar_t* name,int id) {
 combo->Vars.emplace_back();auto& v=combo->Vars.back();v.Name.assign(name,name+std::wcslen(name)+1);v.Index=id;
}
static void paint_choices() {
 building=true;paint_combo->Vars.clear();choices(paint_combo,L"Default",0);
 for(const auto& row:inventory_catalog::skins)if(row.weapon==weapon)choices(paint_combo,row.name,row.paint);
 bool found=paint==0;for(const auto& row:paint_combo->Vars)if(row.Index==paint)found=true;
 if(!found)paint=0;paint_combo->OnConfigLoad();building=false;
}
static void owned_choices() {
 if(!owned_combo)return;building=true;owned_combo->Vars.clear();bool exists=false;
 for(unsigned i=0;i<inventory.items.size();i++)if(inventory.items[i].object) {
  const auto& spec=inventory.items[i].spec;const auto* skin=skin_info(spec.weapon,spec.paint);
  std::wstring name=weapon_name(spec.weapon);name+=L" | ";name+=skin?skin->name:L"Default";
  name+=L" #"+std::to_wstring(i+1);choices(owned_combo,name.c_str(),int(i));if(int(i)==selected)exists=true;
 }
 if(owned_combo->Vars.empty()){selected=-1;choices(owned_combo,L"No local items",-1);}
 else if(!exists)selected=owned_combo->Vars.front().Index;
 owned_combo->OnConfigLoad();building=false;
}
static void read_selected() {
 if(!tag||selected<0||unsigned(selected)>=inventory.items.size()||!inventory.items[selected].object)return;
 const auto& spec=inventory.items[selected].spec;
 const int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,spec.name,-1,tag->Text,0x40);
 if(n>0)tag->Length=n-1;else {tag->Text[0]=0;tag->Length=0;}
 unsigned values[4]{};
 if(local_inventory_client::palette(spec.paint,values,0))for(int i=0;i<4;i++)colors[i].set(values[i]);
}
static bool name_value(char out[129]) {
 if(!tag||tag->Length<0||tag->Length>=0x40)return false;
 wchar_t text[0x40]{};std::memcpy(text,tag->Text,std::size_t(tag->Length)*2);
 return WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,text,-1,out,129,nullptr,nullptr)>0&&local_inventory::valid_name(out);
}
static void invalidate_icons(int kit) {
 for(const auto& item:inventory.items)if(item.object&&item.spec.paint==kit&&local_inventory_client::contains(inventory.current,item.object,item.id))
  local_inventory_client::notify(inventory.current,1,item.object);
}
static void __fastcall clicked_impl(void* arg,void* sender) {
 const auto action=static_cast<unsigned>(reinterpret_cast<std::uintptr_t>(arg));
 if(!enabled||building||!context||context->Menu->CurrentTab!=SKINS||!(context->Menu->MenuStatus&MenuOpened))return;
 if(action==0){if(sender==entry)show=true;return;}
 if(!built)return;
 if(action==1){paint_choices();return;}
 if(action==2){read_selected();return;}
 if(action==3){show=false;return;}
 if(action==10)return;
 const auto& api=local_inventory_client::api;
 if(action==4) {
  Spec spec{};spec.weapon=weapon;spec.paint=paint;spec.seed=seed;spec.wear=wear/10000.f;
  if(auto* row=skin_info(weapon,paint))spec.rarity=unsigned(row->rarity);else spec.rarity=1;
  if(!name_value(spec.name)){report("Invalid name tag (maximum 32 characters)");return;}
  const int added=inventory.add(api,spec);if(added>=0)selected=added;report(inventory.error);owned_choices();if(added>=0)read_selected();return;
 }
 if(selected<0||!inventory.owned(api,unsigned(selected))){report(inventory.error);owned_choices();return;}
 if(action==11){if(equip_action)equip_action(unsigned(selected));return;}
 if(action==5) {
  if(before_delete&&!before_delete(unsigned(selected))){report("Could not restore the local loadout; item kept");return;}
  const int kit=inventory.items[selected].spec.paint;
  if(inventory.erase(api,unsigned(selected))) {
   if(after_delete)after_delete(unsigned(selected));
   bool used=false;for(const auto& item:inventory.items)if(item.object&&item.spec.paint==kit)used=true;
   if(!used){unsigned values[4]{};local_inventory_client::palette(kit,values,2);}
  }
  report(inventory.error);owned_choices();read_selected();return;
 }
 if(action==6||action==7) {
  char value[129]{};if(action==6&&!name_value(value)){report("Invalid name tag (maximum 32 characters)");return;}
  inventory.rename(api,unsigned(selected),value);report(inventory.error);read_selected();return;
 }
 if(action==8||action==9) {
  const int kit=inventory.items[selected].spec.paint;unsigned values[4]{};
  for(int i=0;i<4;i++)values[i]=colors[i].pack();
  if(local_inventory_client::palette(kit,values,action==8?1:2)) {
   for(int i=0;i<4;i++)colors[i].set(values[i]);invalidate_icons(kit);
   report(action==8?"Kit palette updated locally. Reopen item inspection.":"Original kit palette restored.");
  }else report("This paint kit has no available palette, or its palette changed elsewhere");
 }
}
static void __fastcall clicked(void* arg,void* sender) {
 try{clicked_impl(arg,sender);}catch(...){report("Inventory operation allocation failed");}
}
static void* label(Child* c,const wchar_t* name){auto* out=native.allocate(sizeof(Label));if(!out)throw std::bad_alloc();native.label(out,c,name);native.insert(c,false,out);return out;}
static void* button(Child* c,const wchar_t* name,unsigned action){auto* out=add_button(c,false,name,reinterpret_cast<void*>(action),reinterpret_cast<void*>(&clicked));if(!out)throw std::bad_alloc();return out;}
static Combobox* combo(Child* c,const wchar_t* name,int& value,unsigned action) {
 auto* out=static_cast<Combobox*>(native.allocate(sizeof(Combobox)));if(!out)throw std::bad_alloc();const int old=value;
 native.combo(out,c,name,&value,false);value=old;native.insert(c,false,out);out->Calls.emplace_back(reinterpret_cast<void*>(action),&clicked);return out;
}
static void slider(Child* c,const wchar_t* name,int max,int& value) {
 auto* out=native.allocate(sizeof(Slider));if(!out)throw std::bad_alloc();const int old=value;
 native.slider(out,c,name,0,max,&value,true,0,1);value=old;native.insert(c,false,out);
}
static bool create(CMenu* menu) {
 if(built)return true;building=true;
 try {
  for(unsigned i=0;i<2;i++) {
   auto& p=panels[i];if(!p.child) {
    p.child=static_cast<Child*>(native.allocate(sizeof(Child)));if(!p.child)throw std::bad_alloc();
    child_ctor(p.child,menu->Tabs[SKINS],i?L"Item customization":L"Local inventory",int(0xff000000),0,false);
    p.child->Header.Flags.Visible=false;auto** table=*reinterpret_cast<void***>(p.child);std::memcpy(p.table,table,sizeof(p.table));
    p.draw=reinterpret_cast<NativeChildDraw>(table[4]);p.layout=reinterpret_cast<NativeLayout>(table[8]);p.resize=reinterpret_cast<NativeLayout>(table[9]);p.dpi=reinterpret_cast<NativeLayout>(table[10]);
    p.table[4]=reinterpret_cast<void*>(&draw);p.table[8]=reinterpret_cast<void*>(&layout);p.table[9]=reinterpret_cast<void*>(&resize);p.table[10]=reinterpret_cast<void*>(&dpi);
    *reinterpret_cast<void***>(p.child)=p.table;append_child(menu->Tabs[SKINS],p.child);
   } else {
    for(auto* e:p.child->Elements)if(e){e->GetAs<Checkbox>()->Calls.clear();destroy(e);}p.child->Elements.clear();
   }
  }
  auto* a=panels[0].child;auto* b=panels[1].child;
  weapon_combo=combo(a,L"Weapon / knife / gloves",weapon,1);for(auto& w:weapons)choices(weapon_combo,w.name,w.id);weapon_combo->OnConfigLoad();
  paint_combo=combo(a,L"Skin",paint,10);paint_choices();
  slider(a,L"Seed",1000,seed);slider(a,L"Wear (0 = factory new, 10000 = worn)",10000,wear);button(a,L"Add to local CS:GO inventory",4);
  label(a,L"Items added by this module");owned_combo=combo(a,L"Local items",selected,2);owned_choices();
  button(a,L"Equip selected item locally",11);button(a,L"Delete selected local item",5);button(a,L"Back to skinchanger",3);
  label(b,L"Name tag (up to 32 characters)");tag=static_cast<Textbox*>(native.allocate(sizeof(Textbox)));if(!tag)throw std::bad_alloc();skin::text_ctor(tag,b);native.insert(b,false,tag);
  button(b,L"Apply name tag",6);button(b,L"Remove name tag",7);
  label(b,L"RGB palette: shared locally by this paint kit");
  constexpr const wchar_t* names[]={L"Color 1",L"Color 2",L"Color 3",L"Color 4"};
  for(int i=0;i<4;i++) {
   label(b,names[i]);auto* out=static_cast<CPicker*>(native.allocate(sizeof(CPicker)));if(!out)throw std::bad_alloc();native.picker(out,b,&colors[i]);out->Header.Flags.SameLine=true;native.insert(b,true,out);
  }
  label(b,L"Some finishes do not use all four palette colors");button(b,L"Apply RGB palette",8);button(b,L"Restore original palette",9);
  built=true;building=false;skin::captured=skin::fingerprint(menu);++ui_generation;return true;
 }catch(...){show=false;building=false;built=false;report("Local inventory UI allocation failed");for(auto& p:panels)if(p.child)visible(p.child,false);return false;}
}
static void frame_impl(CMenu* menu) {
 if(enabled&&built&&menu&&menu->Tabs.size()==9&&menu->Tabs[SKINS]) {
  bool lost=false;
  for(auto& p:panels) {
   bool found=false;for(auto* live:menu->Tabs[SKINS]->Childs)if(live==p.child&&owns(live))found=true;
   if(!found){p={};lost=true;}
  }
  if(lost){for(auto& p:panels)if(p.child)visible(p.child,false);show=false;built=false;weapon_combo=paint_combo=owned_combo=nullptr;tag=nullptr;report("Inventory page changed; reopen Local inventory");}
 }
 if(enabled&&built&&inventory.current.inventory) {
  static DWORD checked=0;const DWORD tick=GetTickCount();
  if(DWORD(tick-checked)>=1000) {
   checked=tick;local_inventory::Session next{};const bool available=local_inventory_client::session(next);
   if(!available||!(next==inventory.current)) {
    local_inventory_client::restore_all_palettes();inventory.items={};inventory.current=available?next:local_inventory::Session{};
    owned_choices();report("Inventory session changed; local list cleared");
   }
  }
 }
 if(!enabled||!skin::attached||!menu||menu->CurrentTab!=SKINS||!(menu->MenuStatus&MenuOpened))return;
 auto* c=skin::panes[skin_menu_design::Settings].child;bool present=false;
 if(!c)return;for(auto* e:c->Elements)if(e==reinterpret_cast<PElement>(entry))present=true;
 if(!present){entry=static_cast<Button*>(button(c,L"Local inventory",0));if(!entry)return;skin::pane_layout(c,nullptr);}
 if(show&&!built&&!create(menu))show=false;
 for(auto& p:skin::panes)visible(p.child,!opened());
 if(built) {
  const int change=geometry.change(menu->Size.x,menu->Size.y,scale());
  for(unsigned i=0;i<2;i++) {
   visible(panels[i].child,opened());if(!opened())continue;
   if(change==2)dpi(panels[i].child,nullptr);else if(change==1)resize(panels[i].child,nullptr);else layout(panels[i].child,nullptr);
  }
  geometry.commit(menu->Size.x,menu->Size.y,scale());
 }
}
static void frame(CMenu* menu) {
 try{frame_impl(menu);}catch(...){show=false;report("Local inventory UI allocation failed");for(auto& p:panels)if(p.child)visible(p.child,false);for(auto& p:skin::panes)if(p.child)visible(p.child,true);}
}
}
